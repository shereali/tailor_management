<?php 

ob_start();
include'library.php';
include'db.php';
	
system('ipconfig /all');
$mycom=ob_get_contents();
ob_clean();
$findme = "Physical";
$pmac = strpos($mycom, $findme);
$mac=substr($mycom,($pmac+36),17);

if(isset($_REQUEST['btn'])){
	@$sec_num=$_POST['sec_num'];
	$sec_sql=$conn->query("SELECT * from device_security where dsecurity='$sec_num'");
	if(mysqli_num_rows($sec_sql)>0){
		echo "Security already active";
	}else{
		if(db("","",$sec_num,2)){
			echo "Save success.";
		}else{
			echo "Save not success.";
		}
	}
}
?>

<form action ="#" method="post">
<input type="hidden" value="<?php echo md5($mac); ?>" name="sec_num"/>
<input type="submit" name="btn" value="Save"/>
</form>

<br/><br/>
<form action="index.php" method="post">
	<input type="submit" name="sub_btn" value="Home"/>
</form>