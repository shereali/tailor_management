
<?php 

	$com_id=$_SESSION['COM_ID'];
	date_default_timezone_set("Asia/Dhaka");
	$dates=date("Y-m-d");
	$dday=$_SESSION['CUS_DELIVERY'];
	$delivery_day=$_SESSION['CUS_DELIVERY'];
	$exday=explode("-",date('d-m-Y', strtotime(date('d-m-Y'). " +$dday day")));
	$cdate=date("h:i:s A");
	$dday=$exday[0]."/".$exday[1]."/".$exday[2];
	$rem_sms=$conn->query("select (select rem_sms from rem_sms where com_id=c.id) remaining,c.status from company c where c.is_active=1 and c.id=$com_id");
	$product=$conn->query("select * from product where is_active=1 and com_id=$com_id and ptype=1 order by steps asc");
	$product_fabrics=$conn->query("select * from product where is_active=2 order by id asc");
	$expense=$conn->query("select * from expense_type where is_active=1");
	$expense_detail=$conn->query("select ex.id,ex.expense_type,ex.expense,ex.remarks,(select expense from expense_type where id=ex.expense_type) ex_title from expenses ex where ex.is_active=1 and date(ex.insert_date)='$dates'");
	mysqli_close($conn);
	if(mysqli_num_rows($rem_sms)>0){
	$srow=mysqli_fetch_array($rem_sms);
	
?>

<ul class="nav nav-tabs">
	<li class="active"><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" onclick="setOrdNum();" href="#menu1">Order/Fabrics</a></li>
	<li><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" onclick="forEditMeasurement();" href="#menu5">Edit Measurement</a></li>
	<li><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" onclick="salesReturnOption();" href="#menu6">Fabrics Sales Record</a></li>
    <li><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" href="#menu3">Expense</a></li>
   
</ul>

<div class="tab-content">
    
	 <div id="menu1" class="tab-pane fade in active">
      <br/>
    <div class="panel-group">
   <div class="panel panel-info">
      <div class="panel-heading" style="overflow:hidden">
	  <span style="float: left;width: 70px;">Order No.- </span><b><span id="head_ord_num"></span></b>
	  <?php if($_SESSION['ACTIVE_REFERENCE']==1){ ?><span style="margin-left: 175px;">Total Point <b><span style="color:#e842d4;" id="tot_remaining_point"></span></b></span><?php }else{ echo "<input type='hidden' id='tot_remaining_point'/>"; } ?>
	  <span style=""><b><span onclick="mergeOrder();" style="color:#1b37bf;margin-left: 150px;cursor:pointer">Merge Order</span></b></span>
	  <span style="float: right;">Maximum <b><span style="color:red" id="max_item">20</span></b> Items</span>
	  </div>
      <div class="panel-body">
		<div id="show_btn"></div>
		<div class="row" id="calculator" style="color: black;box-shadow: inset 0 0 1em gray;padding: 15px;margin-left: 0px;margin-right: 0px;">
		
		<div class="col-xs-12 col-sm-3">
			
		<label for="comment" class="txt_color">Customer Mobile Number<sup style="color:red">*</sup>:<?php if($_SESSION['ACTIVE_REFERENCE']==1){ ?><input style="margin-left: 15px;" type="checkbox" class="chkbox" name="normal" id="ref_chk" value="0"/><?php }else{ echo "<span id='ref_chk'></span>"; } ?></label>
				<input type="text" onkeyup="chkCustomer();" class="form-control" maxlength="11" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;background: #ffeb3b;" name="mobile" id="mobile" />
				<span id="auto_mobile" style="z-index: 99999999999999;
					overflow: hidden;
					position: fixed;
					width: 240px;"></span>
				<input type="hidden" id="chkAuthUser"/>
				<input type="hidden" id="ref_user_id"/>
				<input type="hidden" id="backup_advance"/>
				<input type="hidden" value="0" id="ref_point_check"/>
				<input type="hidden" id="hidden_item_qty"/>
				<input type="hidden" id="hidden_item_name" />
				<input type="hidden" id="hidden_group_name" />
				<input type="hidden" id="increment_number" value="0"/>
				<input type="hidden" id="previous_delivery_date" value="<?php echo $dday; ?>"/>
				<input type="hidden" id="tblid" value="0"/>
				<input type="hidden" id="max_item_hidden" value="20"/>
				<input type="hidden" id="max_fabrics_hidden" value="20"/>
				<input type="hidden" id="apply_selling_price" value="<?php echo $_SESSION['APPLY_SELLING_PRICE']; ?>"/>
				<input type="hidden" id="is_stock" value="<?php echo $_SESSION['IS_STOCK']; ?>"/>
				<input type="hidden" id="merge_order_chk" value=""/>
				<input type="hidden" id="hidden_ord_number" value=""/>
				<input type="hidden" id="hidden_selected_item" value=""/>
				
				<label for="comment" class="txt_color">Customer Name:</label>
				<input type="text" class="form-control" autocomplete="off" maxlength="30" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_name" id="cus_name" />
				<input type="hidden" name="hidden_cus_name" id="hidden_cus_name" />
				<?php if($_SESSION['ACTIVE_REFERENCE']==1){ ?>
				<label for="comment" class="txt_color">Reference Mobile No.<sup style="color:red"></sup>:<span style="cursor: pointer;color: blue;font-size: 11px;margin-left: 10px;" onclick="copyReferenceNumber();">Copy</span> | <span style="cursor: pointer;color: red;font-size: 11px;" onclick="clearReferenceNumber();">Clear</span></label>
				<input readonly type="text" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" maxlength="11" autocomplete="off" name="total_tk" id="ref_mobile_number"/>
				<?php } ?>
				<!--<label for="comment" class="txt_color">Delivery(Day)<sup style="color:red">*</sup>:</label>-->
				<input type="hidden" style="background: #8bc34a;font-weight:bold" onkeyup="return setDeliveryDate();" autocomplete="off" name="delivery_day" id="delivery_day" value="<?php echo $delivery_day; ?>" class="form-control">
				<label for="comment" class="txt_color">Delivery Date<sup style="color:red">*</sup>:</label>
				<input type="text" autocomplete="off" name="date1" id="date1" value="<?php echo $dday; ?>" class="form-control"><!-- data-select="date"--->
				
				
			<div class="row">
				<div class="col-xs-12 col-sm-6">
					<input type="hidden" readonly onkeyup="return getAdvance();" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;text-align:right" autocomplete="off" value="0" name="design_charge" id="design_charge" required/>
					<label for="comment" class="txt_color">Total Item(Qty)<sup style="color:red">*</sup>:</label>
					<input type="text" readonly class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;text-align:right" autocomplete="off" value="0" name="total_item_qty" id="total_item_qty" required/>
				</div>	
				<div class="col-xs-12 col-sm-6">
					<label for="comment" class="txt_color">Making Charge<sup style="color:red">*</sup>:</label>
					<input type="text" readonly onkeyup="return getAdvance();" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;text-align:right" autocomplete="off" value="0" name="total_tk" id="total_tk" required/>
				</div>
			</div>
			
				<input type="hidden" onkeyup="getAdvance();" maxlength="3" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;text-align:right" autocomplete="off" name="discount" id="discount" value="0" required/>
				<input type="hidden" readonly class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;text-align:right" autocomplete="off" name="tdue" id="tdue" value="0" required/>
				<div style="margin: 10px;">
					<input type="hidden" class="form-control" name="txt_sms" id="txt_sms" />
					<input type="checkbox" class="chkbox" checked name="normal" id="normal" value="0"/> <span class="checkboxtext" id="nor">Normal</span>
					<input type="checkbox" class="chkbox" name="emergency" id="emergency" value="1"/> <span class="checkboxtext" id="emg">Urgent</span>
				</div>
			<div class="" id="urdate_option">
				<input type="text" style="font-weight: bold;font-size:18px;font-style: italic;margin-top: 12px;" autocomplete="off" placeholder="Factory Delivery" name="date1" value="" id="urdate" class="form-control" data-select="date">
			</div>
			<div class="" id="urtime_option">
				<input type="text" style="font-weight: bold;font-size:18px;font-style: italic;margin-top: 12px;" autocomplete="off" name="date1" value="<?php echo $cdate; ?>" id="urtime" class="form-control">
			</div>
			<div class="row">
				<input type="hidden" value="" id="master_id"/>
				<input type="hidden" value="" id="karigor_id"/>
			
			</div>
		</div>	
		
		<div class="col-xs-12 col-sm-6">
			<label for="comment" class="txt_color">Fabrics Name<span> (Maximum <b><span style="color:red" id="max_fabrics">20</span></b> Fabrics)</span><img style="height: 17px;width: 17px;margin-left: 12px;cursor: pointer;" onClick="reloadItemList();" src="img/reload.png"/></label>
			<div style="margin-bottom: 5px;" id="reload_item_list">
				<select class="form-control select2" onchange="getDetails();" style="font-weight: bold;font-size:18px;font-style: italic;background:#f9d9a8" id="ds_item_id">
					<option value="">Select One</option>
					<?php 
					while($rows=mysqli_fetch_array($product_fabrics)){
						@$item_code=($rows['item_code']=="")? '' : ' ['.$rows['item_code'].']';
						@$unit=($rows['uom']=="")? '' : '-('.$rows['uom'].')';
						@$avg_price="";//($rows['avg_price']=="")? '0' : '-'.$rows['avg_price'].'/=';
						@$selling_price=($rows['selling_price']=="")? '0' : '-Rate: '.$rows['selling_price'].'/=';
						@$stock_qty=($rows['stock_qty']=="")? '0' : ' Stock: '.$rows['stock_qty'];
						if($_SESSION['IS_STOCK']==0){
						?>
						<option value="<?php echo $rows['id']."#sep#".$rows['product_name']."#sep#".$rows['uom']."#sep#".$rows['selling_price']."#sep#".$rows['stock_qty']."#sep#".$rows['avg_price']."#sep#".$rows['item_code']; ?>"><?php echo $rows['product_name']; ?></option>
						<?php
						}
						if($_SESSION['IS_STOCK']==1){ // maintain stock
						?>
						<option value="<?php echo $rows['id']."#sep#".$rows['product_name']."#sep#".$rows['uom']."#sep#".$rows['selling_price']."#sep#".$rows['stock_qty']."#sep#".$rows['avg_price']."#sep#".$rows['item_code']; ?>"><?php echo $rows['product_name'].$item_code.$unit.$avg_price.$selling_price.$stock_qty; ?></option>
						<?php
						}
					} 
					?>
					
				</select>
			</div>
			<div style="">
				<table id="dynamic-table" class="table table-striped table-bordered table-hover">
					<thead>
						<tr style="background:#D3DCE3;">
							<th>Sl</th>
							<th style="width: 58%;">Item</th>
							<th style="width:10%;text-align:right">Qty(Pic)</th>
							<th style="width: 15%;text-align:right">Price</th>
							<th style="width: 20%;text-align:right">Sub Total</th>
						</tr>
					</thead>
					<tbody id="item_detail">
					</tbody>
				</table>
				<span style="float: right;font-weight: bold;font-size:18px;" class="txt_color" id="sub_tot">
					Fabrics Total: 0.00/=
				</span>
				
				<!--<label for="comment" class="txt_color">Discount(%) </label>-->
				<input type="hidden" onkeyup="febDiscount();" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;text-align:right" autocomplete="off" name="febdis" id="febdis" value="0" required/>
				<!--<span class="txt_color" style="float: right;font-weight: bold;font-size:18px;" id="sub_tot_f">
					Total: 0.00/=
				</span>-->
				
				<input type="hidden" value="0" id="sub_tot_f_val"/>
				<input type="hidden" value="0" id="fab_total"/>
				<span id="item_detail_copy">
				</span>
				<!--<input type="hidden" id="total_h"/>-->
			</div>
			
		</div>
		<div class="col-xs-12 col-sm-3">
			<div class="row">
				<div class="col-xs-12 col-sm-6">
					<label for="comment" class="txt_color">Previous Due<sup style="color:red">*</sup>:<input style="margin-left: 15px;" <?php echo ($_SESSION['ORDER_COPY']==1)? "checked" : ""; ?> type="checkbox" class="chkbox" name="normal" id="order_copy" value="<?php echo ($_SESSION['ORDER_COPY']==1)? "1" : "0"; ?>"/></label>
					<input type="text" readonly class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:25px;font-style: italic;background:#E5E5E5;color: red;text-align: right;" autocomplete="off" value="0.0" name="previous_due" id="previous_due" required/>
				</div>	
				<div class="col-xs-12 col-sm-6">
					<label for="comment" class="txt_color">Sub Total(Tk)<sup style="color:red">*</sup>:</label>
					<input type="text" readonly class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:25px;font-style: italic;background:#E5E5E5;color: #a726bd;text-align: right;" autocomplete="off" value="0.0" name="tftotal_tk" id="total_h" required/>
				</div>
			</div>
			<div class="row">
			<div class="col-xs-12 col-sm-6">
				<label for="comment" class="txt_color">Others(Tk):</label>
				<input type="text" onkeyup="getAdvance();" onclick="clickToSelect('others_tk')" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:25px;font-style: italic;color: #4ba6a6;text-align: right;" autocomplete="off" value="0" name="tftotal_tk" id="others_tk" required/>
				<input type="hidden" onkeyup="discountPercentage();" onclick="clickToSelect('discount_percentage')" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:25px;font-style: italic;color: #4ab556;text-align: right;" autocomplete="off" value="0" name="tftotal_tk" id="discount_percentage" required/>
			</div>	
			<div class="col-xs-12 col-sm-6">
				<label for="comment" class="txt_color">Discount(Tk):</label>
				<input type="text" onkeyup="discountTk();" onclick="clickToSelect('discount_tk')" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:25px;font-style: italic;color: #a726bd;text-align: right;padding-right: 12px;background: bisque;" autocomplete="off" value="0" name="tftotal_tk" id="discount_tk" required/>
			</div>
			</div>
			<div class="row">
			<div class="col-xs-12 col-sm-6">
				<label for="comment" class="txt_color">Total(Tk): </label>
				<input type="text" readonly maxlength="6" onkeyup="getAdvance();" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;text-align: right;" autocomplete="off" value="0.0" name="grant_total" id="grant_total" required/>
			</div>	
			<div class="col-xs-12 col-sm-6">
				<label for="comment" class="txt_color">Advance(Tk): </label>
				<input type="text" maxlength="6" onkeyup="getAdvance();" onclick="clickToSelect('advance_tk')" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;text-align: right;color: white;background: #2d38ea;" autocomplete="off" name="advance_tk" id="advance_tk" required/>
			</div>
			</div>
			<div class="row">
			<div class="col-xs-12 col-sm-6">
				<label for="comment" class="txt_color">Payment Type </label>
				<select id="payment_type" class="form-control">
					<option value="Cash">Cash</option>
					<option value="Bkash">Bkash</option>
					<option value="Rocket">Rocket</option>
					<option value="Nagad">Nagad</option>
					<option value="Upay">Upay</option>
					<option value="Sure Cash">Sure Cash</option>
					<option value="Tap">Tap</option>
					<option value="POS Machine">POS Machine</option>
					<option value="Bank">Bank</option>
				</select>
			</div>
			<div class="col-xs-12 col-sm-6">
				<label for="comment" class="txt_color">Present Due</label>
				<input type="text" readonly class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;color: blue;text-align: right;" autocomplete="off" value="0.0" name="due_tk" id="due_tk" required/>
				<!--<label for="comment" class="txt_color">Total Due</label>-->
				<input type="hidden" readonly class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;color: #5e5ea2;text-align: right;" autocomplete="off" value="0.0" name="total_due" id="total_due" required/>
			</div>
			</div>
				
			
			<button onclick="saveAllInfo();" style="margin-top: 12px;margin-right:5px" name="btn" value="sub" id="save_order" class="btn btn-success">Save</button>
			<button onclick="printOrder('1');" style="margin-top: 12px;" name="btn" value="sub" id="orderbtn1" class="btn btn-info">Print</button>
			<span id="sms"></span>
		</div>

		
		</div>	
			
			<!--------------------------------Item name list start-------------------------------------->
			<?php 
				if($_SESSION['SVERSION']==0){ //0= correcnt, 1=old order
			?>
				<input type="hidden" id="phy_ord_num" value="0"/>
				<input type="hidden" id="tbl_ord_num" value="0"/>
				<?php 
				}else if($_SESSION['SVERSION']==1){
				?>
				<input type="hidden" id="tbl_ord_num" value=""/>
				
			<?php 
			}else if($_SESSION['SVERSION']==2){
				?>
				<input type="hidden" id="tbl_ord_num" value=""/>
				
			<?php } ?> 
			<div id="home" class="tab-pane fade in active">
				<br/>
				<div id="item_head" style="color: black;box-shadow: inset 0 0 1em gray;padding: 15px;">
				<select id="item_type" onchange="changeType();" style="width:8%;margin-right:5px;float:left" class="form-control">
						<option value="1">Gents</option>
						<option value="2">Lady</option>
					
				</select>
				<span id="show_item_btn">
				<?php 
					$ic=1;
					while($rows=mysqli_fetch_array($product)){
						$jj=$ic++;
					?>
					<button  onclick="itemIdWiseDetails('<?php echo $rows['id']."#sep#".$rows['group_id']."#sep#".$rows['product_name']."#sep#".$jj; ?>');" name="btn" value="sub" id="item_btn<?php echo $jj; ?>" class="btn btn-primary"><?php echo $rows['product_name']; ?></button>
					<?php 
					}
					?>
				</span>
					<input type="hidden" value="0" id="selectid"/>
				
				
				</div>
				<div id="page_loading"></div>
				<div id="head_measurement_details" style="color: green;padding: 15px;margin-top: 10px;border:2px solid green;font-weight:bold;text-align:center">
				
				</div>
				<div id="measurement_details" style="">
				
				</div>
				
			</div>
			<div id="getOrderDetails">
			</div>
			<!--------------------------------Item name list end-------------------------------------->
			
	  </div>
    </div>

  </div>
	 
    </div>
	 <div id="menu2" class="tab-pane fade">
      <br/>
    <span id="summery_report"></span>
	 
    </div>
	
	 <div id="menu4" class="tab-pane fade">
		<br/>
		<span id="del_report"></span>
	</div>
	
	 <div id="menu3" class="tab-pane fade">
	 <br/>
		<div class="col-xs-12 col-sm-4">
			<label for="comment">ব্যয়ের ধরণ</label>
				<select id="expense_type" class="form-control">
				<option value="">Select One</option>
				<?php
					while($row=mysqli_fetch_array($expense)){
				?>
					<option value="<?php echo $row['id']."#sep#".$row['expense']; ?>"><?php echo $row['expense']; ?></option>
				<?php } ?>
					
				</select>
					<label for="comment">ব্যয়(টাকা)</label>
					<input type="text" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" autocomplete="off" name="" id="expense_tk" required/>
				
					<label for="comment">মন্তব্য</label>
					<input type="text"  class="form-control"  style="font-weight: bold;font-size:18px;font-style: italic;color: blue;" autocomplete="off" name="remarks" id="remarks" required/>
				<button onclick="saveExpense();" style="margin-top: 12px;margin-right:5px" name="btn" value="sub" id="save_expense" class="btn btn-success">Save</button>
				<span id="expense_sms"></span>
		</div>
		<div class="col-xs-12 col-sm-6">
			<div class="row">
				<div class="col-xs-12 col-sm-6">
					<label for="comment">Calendar:</label>
					<input type="text" autocomplete="off" name="date1" id="srcdate_expense" class="form-control" data-select="date">
				</div>
				<div class="col-xs-12 col-sm-6">
					<button onclick="searchExpense();" style="margin-top:25px" name="btn" value="sub" id="returnBtn" class="btn btn-success">Search</button>
				</div>
			</div>
			<table id="dynamic-table" class="table table-striped table-bordered table-hover">
					<thead>
						<tr>
							<th style="width: 16%;">ক্রমিক নং</th>
							<th style="">ব্যয়ের ধরণ</th>
							<th style="">মন্তব্য</th>
							<th style="text-align:right">টাকা</th>
						</tr>
					</thead>
				
					<tbody id="searching_tbl">
						<?php 
							$sl=0;$i=1;
							if(mysqli_num_rows($expense_detail)>0){
								while($row=mysqli_fetch_array($expense_detail)){
									$sl=$i++;
									$tbl_id=$row['id'];
									?>
									<tr id="delrow<?php echo $tbl_id; ?>">
									<td>
									<button onclick="delExpense('<?php echo $tbl_id; ?>','<?php echo $sl; ?>')" class="btn btn-danger form-control" id="delExbtn<?php echo $sl; ?>"><?php echo $sl; ?></button>
									</td>
									<td><?php echo $row['ex_title']; ?></td>
									<td><?php echo $row['remarks']; ?></td>
									<td style="text-align:right"><?php echo $row['expense'] ?></td>
									</tr>
									<?php 
								}
							}
						?>
					</tbody>
					<input type="hidden" id="ex_last_id" value="<?php echo $sl; ?>"/>
				
			</table>
			<div id="expense_not_found"></div>
		</div>
    </div>
	
	<div id="menu5" class="tab-pane fade">
		  <br/>
		<div class="row">
			<div class="col-xs-12 col-sm-3">
				<label for="comment">Mobile/Order No.:</label>
					<input type="text" class="form-control"  style="font-weight: bold;font-size:18px;font-style: italic;text-transform:uppercase" autocomplete="off" name="edit_ord_number" onkeyup="getEditableOrder()" id="edit_ord_number" required/>
					<span id="editable_auto_mobile" style="z-index: 99999999999999;overflow: hidden;position: fixed;width: 240px;">
					</span>
				<span id="order_list">
				
				</span>
			</div>
			<div class="col-xs-12 col-sm-4" style="margin-top: 12px;">
				<!--<button onclick="srchByOrdNum();" style="margin-top: 12px;" name="btn" value="sub" id="orderbtn" class="btn btn-success">Search</button>-->
				<button onclick="updateMeasurement();" style="margin-top: 12px;" name="btn" value="sub" id="updatebtn" class="btn btn-warning">Update</button>
				<button onclick="newMeasurement();" style="margin-top: 12px;" name="btn" value="sub" id="newordbtn" class="btn btn-danger">New Order</button>
				<input type="hidden" id="new_measurement_parameter" />
			<span id="uload"></span>
			</div>
			<div class="col-xs-12 col-sm-5" style="margin-top: 15px;">
				<span id="item_area"></span>
		 
			</div>
		</div>
		
		<div id="head_measurement"  style="color: black;box-shadow: inset 0 0 1em gray;padding: 15px;margin-top: 10px;"></div>
		<div id="edit_measurement"  style="color: black;box-shadow: inset 0 0 1em gray;padding: 15px;margin-top: 10px;"></div>
		
	</div>
	
	<div id="menu6" class="tab-pane fade">
		<br/>
		<div class="row" style="background: white;">
			<div class="col-xs-12 col-sm-4">
				<div class="row">
					<div class="col-xs-12 col-sm-8">
						<label for="comment">Calendar:</label>
						<input type="text" autocomplete="off" name="date1" id="srcdate" class="form-control" data-select="date">
					</div>
					<div class="col-xs-12 col-sm-2">
						<button onclick="salesReturnOption();" style="margin-top:25px" name="btn" value="sub" id="returnBtn" class="btn btn-success">Search</button>
					</div>
					<div class="col-xs-12 col-sm-12" style="margin-top: 15px;">
						<span id="detail_item"></span>
						<span id="del_sms"></span>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-sm-8" style="margin-top: 26px;">
				<span id="sales_return_page"></span>
				
			</div>
		</div>
    </div>
	
	
	
</div>


 
  
  <script>
  
  
	function saveAllInfo(){
		var chk_fab="",confirms="";
		var phy_ord_num=$("#phy_ord_num").val();
		var tbl_ord_num=$("#tbl_ord_num").val();
		var mobile=$("#mobile").val();
		if(phy_ord_num=="" && parseFloat($("#total_tk").val())>0){
			$("#phy_ord_num").css("border-color","red");
			$("#phy_ord_num").focus();
			$("#ord_success").html("Missing Order Number.").css("color","red");
			exit;
		}else{
			$("#phy_ord_num").css("border-color","#CCCCCC");
			$("#ord_success").html(null);
			$("#mobile").css("border-color","#CCCCCC");
			$("#discount").css("border-color","#CCCCCC");
			if ($("#emergency").is(":checked")) {
				urdate=$("#urdate").val();
				if(urdate!=""){
					$("#urdate").css("border-color","#CCCCCC");
				}else{
					$("#urdate").css("border-color","red");
					exit;
				}
			}
			var fabricsChk=fabricsQtyPriceChk();
			if(fabricsChk!=""){
					var sp=fabricsChk.split("#sep#");
					$("#pricec"+sp[1]).click();
					$("#pricec"+sp[1]).focus();
					alert("Warning!আপনি ফ্যাব্রিক্স টাকা অথবা সংখ্যা বসাননি!!");
					exit;
			}
			
			
			if(mobile=="" || mobile.length<11 || mobile.length>11){
				alert("Warning! Enter valid mobile number.");
				$("#mobile").click();
				$("#mobile").focus();
				$("#mobile").css("border-color","red");
				exit;
			}
			if($("#discount").val()==""){
				$("#discount").css("border-color","red");
				exit;
			}
			if(parseFloat($("#total_tk").val())>0){
				confirms="আপনি কি অর্ডার টি  Confirm করতে চান?";
			}else if(parseFloat($("#total_tk").val())<=0 && queue.length>0){
				confirms="আপনি কি ফ্যাব্রিক্স বিক্রি করতে চান?";
			}else if(parseFloat($("#total_tk").val())<=0 && queue.length==0 && mobile.length==11 && parseFloat($("#advance_tk").val())>0 && parseFloat($("#previous_due").val())>0 && parseFloat($("#discount_tk").val())==0 && parseFloat($("#others_tk").val())==0){  
				confirms="আপনি কি বাকি পরিশোধ করতে চান?";
			}else{
				confirms="আপনি কি ফ্যাব্রিক্স বিক্রি করতে চান?";
			}
				if(confirm(confirms)){	
						document.getElementById("save_order").disabled = true;
						var i="",item_id_info,chk_item_qty="";
						$.ajax({
							type: 'post',
							url: 'sql.php',
							data: {
								chkMonthlyBill:1
							},
							 beforeSend: function () {
								$("#sms").show();
								$("#sms").html('<img src="img/loading.gif"/>');
							},
								success: function (response) {
									console.log(response);
									if(response==1){ // Monthly bill ok
										if(parseFloat($("#total_tk").val())<=0 && queue.length==0 && mobile.length==11 && parseFloat($("#advance_tk").val())>0 && parseFloat($("#previous_due").val())>0 && parseFloat($("#discount_tk").val())==0 && parseFloat($("#others_tk").val())==0){  
											$.ajax({  //Due taka collect
												type: 'post',
												url: 'ajax.php',
												data: {
													previous_due_payable:parseFloat($("#advance_tk").val()),
													mobile:mobile,
													previousDuePayable:1
												},
												 success: function (response) {
													 if(response==1){
														$("#sms").html("Save success!").css("color","green");
														$("#sms").fadeOut(3500);
														$("#previous_due").val(0);
														$("#total_due").val(0);
														$("#advance_tk").val(null);
														$("#mobile").val(null);
														$("#cus_name").val(null);
													 }else{
														$("#sms").html("Save not success!").css("color","green");
														$("#sms").fadeOut(3500); 
													 }
														document.getElementById("save_order").disabled = false;
												}
											});
										}else{
											if(parseFloat($("#total_tk").val())>0){ // dress making qty chk
												for(i=0;i<orderQueue.length;i++){
													if($("#item_qty"+orderQueue[i]).val()==""){
														chk_item_qty="1#sep#"+orderQueue[i];
														break;
													}
												}
												if(chk_item_qty!=""){
													alert("Warning! Item qty missing.");
													var sp=chk_item_qty.split("#sep#");
													$("#item_qty"+sp[1]).click();
													$("#item_qty"+sp[1]).focus();
												}else{
													var measurementChks=measurementChk();
														if(measurementChks!=""){
																var sp=measurementChks.split("#sep#");
																$("#size"+sp[1]+"0").click();
																$("#size"+sp[1]+"0").focus();
																alert("Warning! আপনি মেজারমেন্ট বসাননি!!!");
																$("#sms").html("আপনি মেজারমেন্ট বসাননি!").css("color","red");
																$("#sms").show("slow");
																$("#sms").fadeOut(4500);
																document.getElementById("save_order").disabled = false;
																exit;
														}else{
															saveMeasurement();
															console.log("after save measurement");
														}
												}
											}else{
													if(queue.length>0){ //only fabrics
														sendSms();
													}else{
														$("#sms").html("Select Any Fabrice").css("color","red");
														$("#sms").show("slow");
														$("#sms").fadeOut(3500);
														document.getElementById("save_order").disabled = false;
													}
												}
										}
									}else{ // Monthly bill not ok
										$("#sms").html("Monthly Bill Not Paid!").css("color","red");
										document.getElementById("save_order").disabled = false;
										setTimeout(function() {
											window.location.href = "signout.php";
										}, 2000);
									}
								}
						});
				
				}
				
		}
	}
	
	function fabricsQtyPriceChk(){
		var chk_fab="";
		if(queue.length>0){
			for(var ii=0;ii<queue.length;ii++){
				if(parseFloat($("#qtyc"+queue[ii]).val())==0 || $("#qtyc"+queue[ii]).val()=="" || parseFloat($("#pricec"+queue[ii]).val())==0 || $("#pricec"+queue[ii]).val()==""){
					chk_fab="1#sep#"+queue[ii];
				}
			}
			return chk_fab;
		}else{
			return "";
		}
	}
	
	function reloadItemList(){
		$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					reloadItemList:1
				},
				beforeSend: function () {
					$("#reload_item_list").html('<img src="img/reloading.gif"/>');
				},
				success: function (response) {
					console.log(response);
					$("#reload_item_list").html(response);
				}
		});
	}
	
	function measurementChk(){
		var chk_measurement="";
		if(orderQueue.length>0){
			for(i=0;i<orderQueue.length;i++){
				if($("#size"+orderQueue[i]+"0").val()==""){
					chk_measurement="1#sep#"+orderQueue[i];
				}
			}
			return chk_measurement;
		}else{
			return "";
		}
	}
	
	function mergeOrder(){
		if(confirm("আপনি কি Settings পরিবর্তন করতে চান?")){
		 $.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					meargeOrder:1
				},
				success: function (response) {
					console.log(response);
					location.reload();
				}
			});
		}
	}
  
	window.sizea = [];
	window.sizeida = [];
	window.properticetitlea = [];
	window.properticea = [];
	window.exproperticea = [];
	
	
	window.head_item_id_info = [];
	window.head_item_qty = [];
	window.head_item_type = [];
	window.head_item_name = [];
	window.head_group_name = [];
	window.head_master_name = [];
	window.head_karigor_name = [];
	window.head_design_cost = [];
	window.head_amount_cost = [];
	window.head_txtareaid = [];
	window.head_extra_remarks = [];
	window.head_all_sizeida = []; // measurement id
	window.head_all_sizea = []; // measurement txt
	window.head_all_properticetitlea = []; // propertice txt
	window.head_all_properticea = []; // propertice id
	window.head_all_exproperticea = []; // checkbox id
	
	
	function saveMeasurement(){ 
		var item_id="",item_type="",hiid="",param_item_id;
		//item_type=$("#item_type").val();
		
		var phy_ord_num=$("#phy_ord_num").val();
		var tbl_ord_num=$("#tbl_ord_num").val();
		//var master_id=$("#master_id").val();
		//var karigor_id=$("#karigor_id").val();
		for(hiid=0;hiid<orderQueue.length;hiid++){
			param_item_id=orderQueue[hiid];
			var item_id_info=$("#item_id_info"+param_item_id).val()
			var item_qty=$("#item_qty"+param_item_id).val();
			var item_name=$("#item_name"+param_item_id).val();
			var group_name=$("#group_name"+param_item_id).val();
			var item_type=$("#item_type"+param_item_id).val();
			var master_id=($("#master_id"+param_item_id).val()=="")? '0' : $("#master_id"+param_item_id).val();
			var karigor_id=($("#karigor_id"+param_item_id).val()=="")? '0' : $("#karigor_id"+param_item_id).val();
			var design_cost=$("#item_others"+param_item_id).val();
			var amount_cost=$("#item_amount"+param_item_id).val(); // (item_rate*item_qty)+design_cost
			
			var sizetot=$("#sizetot"+param_item_id).val(); //sizetxt
			var propertice_title_tot=$("#propertice_title_tot"+param_item_id).val(); //propertice
			var expropertice_tot=$("#expropertice_tot"+param_item_id).val(); //expropertice expropertice_tot
			var i="",m="",ep="",epc=0,iid="",jj="",extra_remarks="";
			var txtareaid=$("#txtareaid"+param_item_id).val();
			if(txtareaid>0){
				extra_remarks=$("#extra_remarks"+param_item_id).val().trim();
			}
			
			
			for(i=0; i<sizetot; i++){
				if($("#size"+param_item_id+i).val()!=""){
					sizea.push($("#size"+param_item_id+i).val());
					sizeida.push($("#sizetxt"+param_item_id+i).val());
				}
			}
			for(i=0; i<propertice_title_tot; i++){
					properticetitlea.push($("#propertice_title"+param_item_id+i).val());
					if($("#propertice"+param_item_id+i).val()!=""){
						properticea.push($("#propertice"+param_item_id+i).val());
					}else{
					properticea.push(0);
					}
			}
			if(expropertice_tot!=0){
				for(i=0; i<expropertice_tot; i++){
						if ($('#expropertice'+param_item_id+i).is(":checked")){
							exproperticea.push($("#expropertice"+param_item_id+i).val());
						}else{
							epc++;
						}
				}
				
				var all_exproperticea = exproperticea.join('#sep#');
			}else{
				var all_exproperticea =0;
			}
			
			console.log(expropertice_tot+"= "+epc);
			console.log("size id: "+sizeida);
			console.log("size p: "+sizea);
			console.log("ex p: "+exproperticea);
			console.log("p t: "+properticetitlea);
			console.log("p : "+properticea);
			
			var all_sizeida = sizeida.join('#sep#');
			var all_sizea = sizea.join('#sep#');
			var all_properticetitlea = properticetitlea.join('#sep#');
			var all_properticea = properticea.join('#sep#');
			
			head_item_id_info.push(item_id_info);
			head_item_qty.push(item_qty);
			head_item_name.push(item_name);
			head_group_name.push(group_name);
			head_item_type.push(item_type);
			head_karigor_name.push(karigor_id);
			head_master_name.push(master_id);
			head_design_cost.push(design_cost);
			head_amount_cost.push(amount_cost);
			head_txtareaid.push(txtareaid);
			head_extra_remarks.push(extra_remarks);
			head_all_sizeida.push(all_sizeida); // measurement id
			head_all_sizea.push(all_sizea); // measurement txt
			head_all_properticetitlea.push(all_properticetitlea); // propertice txt
			head_all_properticea.push(all_properticea); // propertice id
			head_all_exproperticea.push(all_exproperticea); // checkbox id
			
			window.sizeida = [];
			window.sizea = [];
			window.exproperticea = [];
			window.properticetitlea = [];
			window.properticea = [];
		}
		
			var item_id = head_item_id_info.join('#head#');
			var item_qty = head_item_qty.join('#sep#');
			var item_name = head_item_name.join('#sep#');
			var group_name = head_group_name.join('#head#');
			var item_type = head_item_type.join('#head#');
			var group_master_name = head_master_name.join('#head#');
			var group_karigor_name = head_karigor_name.join('#head#');
			var design_cost = head_design_cost.join('#head#');
			var amount_cost = head_amount_cost.join('#head#');
			var txtareaid = head_txtareaid.join('#head#');
			var extra_remarks = head_extra_remarks.join('#head#');
			var all_sizeida = head_all_sizeida.join('#head#');
			var all_sizea = head_all_sizea.join('#head#');
			var all_properticetitlea = head_all_properticetitlea.join('#head#');
			var all_properticea = head_all_properticea.join('#head#');
			var all_exproperticea = head_all_exproperticea.join('#head#');
			$("#hidden_item_name").val(item_name);
			$("#hidden_item_qty").val(item_qty);
			$("#hidden_group_name").val(group_name);
			
			console.log("item="+item_id);
			console.log("txtareaid="+txtareaid);
			console.log("extra_remarks="+extra_remarks);
			console.log("all_sizeida="+all_sizeida);
			console.log("all_sizea="+all_sizea);
			console.log("all_properticetitlea="+all_properticetitlea);
			console.log("all_properticea="+all_properticea);
			console.log("all_exproperticea="+all_exproperticea);
			//exit;
		
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						item_id:item_id,
						all_sizeida:all_sizeida,
						all_sizea:all_sizea,
						all_properticetitlea:all_properticetitlea,
						all_properticea:all_properticea,
						all_exproperticea:all_exproperticea,
						phy_ord_num:phy_ord_num,
						tbl_ord_num:tbl_ord_num,
						item_qty:item_qty,
						group_name:group_name,
						master_id:group_master_name,
						karigor_id:group_karigor_name,
						item_type:item_type,
						extra_remarks:extra_remarks,
						txtareaid:txtareaid,
						design_cost:design_cost,
						amount_cost:amount_cost,
						add_order:1
					},
					 success: function (response) {
						console.log(response);
						
							if(response==1){
								window.head_item_id_info = [];
								window.head_item_qty = [];
								window.head_item_name = [];
								window.head_item_type = [];
								window.head_group_name = [];
								window.head_master_name = [];
								window.head_karigor_name = [];
								window.head_design_cost = [];
								window.head_amount_cost = [];
								window.head_txtareaid = [];
								window.head_extra_remarks = [];
								window.head_all_sizeida = []; // measurement id
								window.head_all_sizea = []; // measurement txt
								window.head_all_properticetitlea = []; // propertice txt
								window.head_all_properticea = []; // propertice id
								window.head_all_exproperticea = []; // checkbox id
								window.orderQueue = []; // order item array
								$("#increment_number").val(0);
								sendSms();
								//return 1;
							}
							
					}
			});
		//return 1;
	}
	
  
	window.itema = [];
	window.itemqtya = [];
	
	window.fitempricea = [];
	window.fitemqtya = [];
	window.item_idca = [];
	window.present_stocka = [];
	window.avg_pricea = [];
	function sendSms(){ 
		var txt_sms=$("#txt_sms").val();
		var date1=$("#date1").val();
		var mobile=$("#mobile").val();
		var chkAuthUser=$("#chkAuthUser").val();  // chkAuthUser="" means user not found or new user, chkAuthUser!="" means existing user
		var total_tk=($("#total_tk").val()=="")? 0 : parseFloat($("#total_tk").val()); // making charge
		var previous_due=parseFloat($("#previous_due").val()); // Previous total due
		var total_due=parseFloat($("#total_due").val()); // Total due
		var advance_tk=$("#advance_tk").val();
		var discount=$("#discount").val(); 
		var payment_type=$("#payment_type").val();
		var design_charge=$("#design_charge").val(); // design cost
		var cus_name=$("#cus_name").val();
		var hidden_cus_name=$("#hidden_cus_name").val();
		var order_type="";
		
		var total_h=$("#total_h").val(); // present total tk
		var others_tk=($("#others_tk").val()=="")? 0 : parseFloat($("#others_tk").val()); 
		var grant_total=$("#grant_total").val(); 
		if(parseFloat(advance_tk)>parseFloat(grant_total)){
			advance_tk=grant_total;
		}
		var discount_tk=($("#discount_tk").val()=="")? '0' : $("#discount_tk").val(); 
		var discount_percentage=($("#discount_percentage").val()=="")? '0' : $("#discount_percentage").val(); //over all discount
		 
		var fab_total=$("#fab_total").val(); //feb total before discount
		var febdis=discount_percentage; // $("#febdis").val(); // feb discount
		var sub_tot_f_val=$("#sub_tot_f_val").val(); // feb total after discount
		var merge_order_chk=$("#merge_order_chk").val(); // for merge order checking 
		if(merge_order_chk==""){
			phy_ord_num=0;
		}else{
			phy_ord_num=$("#phy_ord_num").val(); 
		}
		
		var due_tk=$("#due_tk").val(); // present total due
		var tblid=$("#tblid").val();
		var ref_user_id=$("#ref_user_id").val(); //reference cus id
		var ref_point_check=$("#ref_point_check").val(); //if its 1 then customer purchase product using his point.
		if(ref_point_check==0){
			ref_point_check=0;
			earn_point=0;
		}else{
			var earn_point=parseFloat($("#tot_remaining_point").text()); // customers point
		}
		var order_type="",udd="",urdate="",urtime="";
		if(total_tk>0){ //tailor with fabrics 
			if ($("#normal").is(":checked")) {
				order_type=$("#normal").val();
			}
			if ($("#emergency").is(":checked")) {
				order_type=$("#emergency").val();
				urdate=$("#urdate").val();
				urtime=$("#urtime").val();
			}
			
			var all_itema = $("#hidden_item_name").val();
			var all_itemqtya = $("#hidden_item_qty").val();
			var all_groupnamea = $("#hidden_group_name").val();
			
			var t="",m="",e="",ttk="",ord_no="",adv="",tcp="",fichk="",ad="",fabrics_discount_tk=0;
			
			if(queue.length>0){
				
				for(var ii=0;ii<queue.length;ii++){
					if(parseFloat($("#qtyc"+queue[ii]).val())!=0 && parseFloat($("#pricec"+queue[ii]).val())!=0){
						/*if(parseFloat(febdis)>0){
						fitemqtya.push($("#qtyc"+queue[ii]).val());
						fabrics_discount_tk+=((parseFloat($("#pricec"+queue[ii]).val())*parseFloat(febdis))/100);
						fitempricea.push(parseFloat($("#pricec"+queue[ii]).val())-((parseFloat($("#pricec"+queue[ii]).val())*parseFloat(febdis))/100));
						item_idca.push($("#item_idc"+queue[ii]).val());*/
						//}else{
							itema.push($("#item_namec"+queue[ii]).val());
							fitemqtya.push($("#qtyc"+queue[ii]).val());
							fitempricea.push($("#pricec"+queue[ii]).val());
							item_idca.push($("#item_idc"+queue[ii]).val());
							present_stocka.push($("#present_stockc"+queue[ii]).val());
							avg_pricea.push($("#avg_pricec"+queue[ii]).val());
						//}
					}
				}
				var all_itema = itema.join('#sep#');
				var all_fitemqtya = fitemqtya.join('#sep#');
				var all_fitempricea = fitempricea.join('#sep#');
				var all_item_idca = item_idca.join('#sep#');
				
				var all_stock = present_stocka.join('#sep#');
				var all_avg_price = avg_pricea.join('#sep#');
				
			}else{
				var all_itema = "";
				var all_fitemqtya = "";
				var all_fitempricea = "";
				var all_item_idca ="";
				fichk="";
			}
			
			
		if(m==1 || t==1 || e==1 || ttk==1 || ord_no==1 || tcp==1 || fichk==1 || ad==1 || udd==1){
			window.itema = [];
			window.itemqtya = [];
			window.fitempricea = [];
			window.fitemqtya = [];
			window.item_idca = [];
			window.present_stocka = [];
			window.avg_pricea = [];
			exit;
			}else{
				
				$.ajax({
						type: 'post',
						url: 'sql.php',
						data: {
							tblid:queue.length,
							all_item_idca:all_item_idca,
							chkAuthUser:chkAuthUser,
							previous_due:previous_due,
							total_due:total_due,
							due_tk:due_tk,
							design_charge:design_charge,
							fab_total:fab_total,
							febdis:parseFloat(discount_percentage).toFixed(2),
							sub_tot_f_val:sub_tot_f_val,
							all_fitempricea:all_fitempricea,
							all_groupnamea:all_groupnamea,
							all_fitemqtya:all_fitemqtya,
							ta_and_fab:grant_total,
							payment_type:payment_type,
							all_itemqtya:all_itemqtya,
							all_itema:all_itema,
							advance_tk:advance_tk,
							discount:discount_percentage,
							total_tk:total_tk,
							txt_sms: txt_sms,
							mobile:mobile,
							date1:date1,
							tag:1,
							order_type:order_type,
							cus_name:cus_name,
							hidden_cus_name:hidden_cus_name,
							urdate:urdate,
							urtime:urtime,
							fabrics_discount_tk:parseFloat(fabrics_discount_tk).toFixed(2),
							others_tk:others_tk,
							discount_tk:discount_tk,
							ref_user_id:ref_user_id,
							ref_point_check:ref_point_check,
							earn_point:earn_point,
							phy_ord_num:phy_ord_num,
							all_stock:all_stock,
							all_avg_price:all_avg_price,
							btn:1
						},
						beforeSend: function () {
							$("#sms").show();
							$("#sms").html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							document.getElementById("save_order").disabled = false;
							if(response==20000000){
								$("#sms").html("Invalid Text SMS!").css("color","red");
							}else if(response==10000000){
								$("#sms").html("SMS Not Available!").css("color","red");
							}else if(response==30000000){
								$("#sms").html("Invalid Organization!").css("color","red");
								setTimeout(function() {
										window.location.href = "signout.php";
								}, 2000);
							}else if(response==40000000){
								$("#sms").html("SMS Not Available!").css("color","red");
							}else{
								//var sp=response.split("#sep#");
								//console.log(sp[1]);
								//$("#sms").html("Save Success!").css("color","green");
								$("#print_option").show();
								$("#mobile").val(null);
								$("#cus_name").val(null);
								$("#hidden_cus_name").val(null);
								$("#chkAuthUser").val(null);
								$("#total_tk").val(0);
								$("#advance_tk").val(null);
								$("#due_tk").val(0.0);
								$("#total_due").val(0.0);
								$("#previous_due").val(0.0);
								$("#total_h").val(0.0);
								$("#design_charge").val(0.0);
								$("#discount").val(0);
								$("#total_item_qty").val(0);
								$("#tdue").val(0);
								$("#febdis").val(0);
								$("#tblid").val(0);
								$("#discount_percentage").val(0);
								$("#discount_tk").val(0);
								$("#grant_total").val(0.0);
								$("#others_tk").val(0.0);
								$("#sub_tot_f_val").val(0);
								$("#sub_tot_f").html("Total: 0.00/=");
								if(ref_point_check==1){
									$("#tot_remaining_point").html(0);
									$('#ref_chk').prop('checked', false);
								}
								if(ref_user_id!=""){
									$("#ref_user_id").val(null);
									$("#ref_mobile_number").val(null);
								}
								if(merge_order_chk==1){
									$("#merge_order_chk").val(null);
									$("#phy_ord_num").val(null);
									document.getElementById("mobile").disabled = false;
									document.getElementById("cus_name").disabled = false;
									document.getElementById("delivery_day").disabled = false;
								}
								clearMaxVal();
								
								$("#item_detail").html(null);
								$("#item_detail_copy").html(null);
								$("#fab_total").val(0);
								$("#sub_tot").html("Fabrics Total: 0.00/=");
								
								
								/*for(var i=0;i<lastid;i++){
									$("#ord_date"+i).html(sp[1]);
									$("#ord_date2"+i).html(sp[1]);
									$("#del_date"+i).html(sp[2]);
									$("#del_date2"+i).html(sp[2]);
									$("#delOrder"+i).hide();
								}*/
								$("#measurement_details").html(null);
								$("#getOrderDetails").prepend(null);
								$("#getOrderDetails").fadeIn(1500);
								$("#getOrderDetails").prepend(response);
								document.getElementById("orderbtn1").disabled = false;
								$('#normal').prop('checked', true);
								$('#emergency').prop('checked', false);
								$('#urdate_option,#urtime_option').hide();
								$('#urdate').val(null);
								$("#nor").css('color','black');
								$("#emg").css('color','#E0E0E0');
								setOrdNum(); // show order number
								$("#mobile").click();
								$("#mobile").focus();
								$("#sms").fadeOut(2500);
								window.itema = [];
								window.itemqtya = [];
								window.fitempricea = [];
								window.fitemqtya = [];
								window.item_idca = [];
								window.present_stocka = [];
								window.avg_pricea = [];
								window.queue= [];
								window.orderQueue = []; // order item array
							
							}
						 }
				});
			}
		}else{
			var ad="";
			if(queue.length>0){
				if(advance_tk==""){
					advance_tk=0;
				}
				var fabrics_discount_tk=0;
				if(merge_order_chk==1){
					for(var ii=0;ii<queue.length;ii++){
						if(parseFloat($("#qtyc"+queue[ii]).val())!=0 && parseFloat($("#pricec"+queue[ii]).val())!=0){
							//fitemqtya.push($("#qtyc"+queue[ii]).val());
							//if(parseFloat(febdis)>0){
								//fabrics_discount_tk+=((parseFloat($("#pricec"+queue[ii]).val())*parseFloat(febdis))/100);
								//fitempricea.push(parseFloat($("#pricec"+queue[ii]).val())-((parseFloat($("#pricec"+queue[ii]).val())*parseFloat(febdis))/100));
							//}else{
								//fitempricea.push($("#pricec"+queue[ii]).val());
							//}
							//item_idca.push($("#item_idc"+queue[ii]).val());
							
							itema.push($("#item_namec"+queue[ii]).val());
							fitemqtya.push($("#qtyc"+queue[ii]).val());
							fitempricea.push($("#pricec"+queue[ii]).val());
							item_idca.push($("#item_idc"+queue[ii]).val());
							present_stocka.push($("#present_stockc"+queue[ii]).val());
							avg_pricea.push($("#avg_pricec"+queue[ii]).val());
						}
						
					}
				}else{
					for(var ii=0;ii<queue.length;ii++){
						if(parseFloat($("#qtyc"+queue[ii]).val())!=0 && parseFloat($("#pricec"+queue[ii]).val())!=0){
							fitemqtya.push($("#qtyc"+queue[ii]).val());
							if(parseFloat(febdis)>0){
								fabrics_discount_tk+=((parseFloat($("#pricec"+queue[ii]).val())*parseFloat(febdis))/100);
								fitempricea.push(parseFloat($("#pricec"+queue[ii]).val())-((parseFloat($("#pricec"+queue[ii]).val())*parseFloat(febdis))/100));
							}else{
								fitempricea.push($("#pricec"+queue[ii]).val());
							}
							item_idca.push($("#item_idc"+queue[ii]).val());
							itema.push($("#item_namec"+queue[ii]).val());
							present_stocka.push($("#present_stockc"+queue[ii]).val());
							avg_pricea.push($("#avg_pricec"+queue[ii]).val());
						}
						
					}
				}
				var all_fitemqtya = fitemqtya.join('#sep#');
				var all_fitempricea = fitempricea.join('#sep#');
				var all_item_idca = item_idca.join('#sep#');
				var all_namea = itema.join('#sep#');
				
				var all_stock = present_stocka.join('#sep#');
				var all_avg_price = avg_pricea.join('#sep#');
				
				if(ad==1){
					exit();
				}else{
					$.ajax({
							type: 'post',
							url: 'sql.php',
							data: {
								all_fitemqtya:all_fitemqtya,
								all_fitempricea:all_fitempricea,
								all_item_idca:all_item_idca,
								chkAuthUser:chkAuthUser,
								previous_due:previous_due,
								total_due:total_due,
								due_tk:due_tk,
								ta_and_fab:grant_total,
								fab_total:fab_total,
								febdis:parseFloat(discount_percentage).toFixed(2),
								sub_tot_f_val:sub_tot_f_val,
								discount:discount,
								advance_tk:advance_tk,
								payment_type:payment_type,
								mobile:mobile,
								cus_name:cus_name,
								hidden_cus_name:hidden_cus_name,
								fabrics_discount_tk:discount_tk,
								others_tk:others_tk,
								ref_user_id:ref_user_id,
								ref_point_check:ref_point_check,
								earn_point:earn_point,
								phy_ord_num:phy_ord_num,
								itema:all_namea,
								all_stock:all_stock,
								all_avg_price:all_avg_price,
								onlyFabrics:1
							},
							 beforeSend: function () {
								$("#sms").show();
								$("#sms").html('<img src="img/loading.gif"/>');
							},
							 success: function (response) {
								console.log(response);
								
								if(response==30000000 || response==2000000){
									$("#sms").html("Warning! Something is wrong!").css("color","red");
								}else{
									$("#sms").html("Save Success!").css("color","green");
									$("#sms").fadeOut(2500);
									$("#mobile").val(null);
									$("#cus_name").val(null);
									$("#hidden_cus_name").val(null);
									$("#chkAuthUser").val(null);
									$("#item_detail").html(null);
									$("#due_tk").val(0.0);
									$("#total_due").val(0.0);
									$("#previous_due").val(0.0);
									$("#total_h").val(0.0);
									$("#discount_percentage").val(0);
									$("#discount_tk").val(0);
									$("#grant_total").val(0.0);
									$("#others_tk").val(0.0);
									$("#item_detail_copy").html(null);
									$("#fab_total").val(0);
									$("#total_item_qty").val(0);
									$("#advance_tk").val(null);
									$("#discount").val(0);
									$("#sub_tot").html("Fabrics Total: 0.00/=");
									$("#tdue").val(0);
									$("#tblid").val(0);
									$("#febdis").val(0);
									$("#sub_tot_f_val").val(0);
									$("#sub_tot_f").html("Total: 0.00/=");
									$("#mobile").click();
									$("#mobile").focus();
									if(ref_point_check==1){
										$("#tot_remaining_point").html(0);
										$('#ref_chk').prop('checked', false);
									}
									if(ref_user_id!=""){
										$("#ref_user_id").val(null);
										$("#ref_mobile_number").val(null);
									}
									if(merge_order_chk==1){
										$("#merge_order_chk").val(null);
										$("#phy_ord_num").val(null);
										document.getElementById("mobile").disabled = false;
										document.getElementById("cus_name").disabled = false;
										document.getElementById("delivery_day").disabled = false;
									}
									clearMaxVal();
									window.fitempricea = [];
									window.fitemqtya = [];
									window.item_idca = [];
									window.queue= [];
									window.itema= [];
									window.present_stocka = [];
									window.avg_pricea = [];
									window.orderQueue = []; // order item array
									
									$("#measurement_details").html(null);
									$("#getOrderDetails").prepend(null);
									$("#getOrderDetails").fadeIn(1500);
									$("#getOrderDetails").prepend(response);
									document.getElementById("orderbtn1").disabled = false;
								}
								document.getElementById("save_order").disabled = false;
								$("#sms").fadeOut(2500);
							}
					});
				}
				
			}else{
				document.getElementById("save_order").disabled = false;
				$("#sms").show();
				$("#sms").html("Select Any Fabrice").css("color","red");
			}
			
			
		}
		
	}
	
	function clearMaxVal(){
		$("#max_item_hidden").val(20);
		$("#max_fabrics_hidden").val(20);
		$("#max_item").html(20);
		$("#max_fabrics").html(20);
	}
	
	window.esizea = [];
	window.esizeida = [];
	window.eproperticetitlea = [];
	window.eproperticea = [];
	window.eexproperticea = [];
	function updateMeasurement(){
		if(confirm("আপনি কি আপডেট করতে চান?")){
		var ord_tbl_id="";
		var i="",m="",ep="",epc=0,iid="",jj="",extra_remarks="";
		ord_tbl_id=$("#ord_tbl_id").val();
		var calculate_item_id=$("#calculate_item_id").val();
		var item_sl_no=$("#item_sl_no").val();
		var item_namee=$("#item_namee"+calculate_item_id).val();
		var edit_ord_number=$("#edit_ord_number").val();
		
		
		var previous_amount_cost=$("#previous_amount_cost").val(); 
		var previous_design_cost=$("#previous_design_cost").val(); 
		var previous_group_name=$("#previous_group_name").val(); 
		var previous_orderinfo=$("#previous_orderinfo").val(); 
		
		
		var item_amounte=$("#item_amounte"+calculate_item_id).val(); 
		var item_qtye=$("#item_qtye"+calculate_item_id).val(); 
		var item_ratee=$("#item_ratee"+calculate_item_id).val(); 
		var item_otherse=$("#item_otherse"+calculate_item_id).val(); 
		var group_namee=$("#group_namee"+calculate_item_id).val(); 
		var master_ide=$("#master_ide"+calculate_item_id).val(); 
		var karigor_ide=$("#karigor_ide"+calculate_item_id).val(); 
		
		var sizetot=$("#sizetote").val(); //sizetxt
		var propertice_title_tot=$("#propertice_title_tote").val(); //propertice
		var expropertice_tot=$("#expropertice_tote").val(); //expropertice expropertice_tot
		var txtareaid=$("#txtareaide").val(); //
		if(txtareaid>0){
			extra_remarks=$("#extra_remarkse").val();
		}
		
		for(i=0; i<sizetot; i++){
			
			if($("#sizee"+i).val()!=""){
				$("#sizee"+i).css("border-color","#CCCCCC");
				esizea.push($("#sizee"+i).val());
				esizeida.push($("#sizetxte"+i).val());
			}
		}
		for(i=0; i<propertice_title_tot; i++){
				eproperticetitlea.push($("#propertice_titlee"+i).val());
				if($("#properticee"+i).val()!=""){
					eproperticea.push($("#properticee"+i).val());
				}else{
				eproperticea.push(0);
				}
		}
		
		if(expropertice_tot!=0){
			for(i=0; i<expropertice_tot; i++){
					if ($('#exproperticee'+i).is(":checked")){
						eexproperticea.push($("#exproperticee"+i).val());
					}else{
						epc++;
					}
			}
			
			var all_exproperticea = eexproperticea.join('#sep#');
		}else{
			var all_exproperticea =0;
		}
		
		console.log(expropertice_tot+"= "+epc);
		console.log("size id: "+esizeida);
		console.log("size p: "+esizea);
		console.log("ex p: "+eexproperticea);
		console.log("p t: "+eproperticetitlea);
		console.log("p : "+eproperticea);
		
		var all_sizeida = esizeida.join('#sep#');
		var all_sizea = esizea.join('#sep#');
		var all_properticetitlea = eproperticetitlea.join('#sep#');
		var all_properticea = eproperticea.join('#sep#');
		if(ord_tbl_id!=""){
			$("#edit_ord_number").css("border-color","#CCCCCC");
			document.getElementById("updatebtn").disabled = true;
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						ord_tbl_id:ord_tbl_id,
						all_sizeida:all_sizeida,
						all_sizea:all_sizea,
						all_properticetitlea:all_properticetitlea,
						all_properticea:all_properticea,
						all_exproperticea:all_exproperticea,
						txtareaid:txtareaid,
						extra_remarks:extra_remarks,
						previous_amount_cost:previous_amount_cost,
						previous_design_cost:previous_design_cost,
						previous_group_name:previous_group_name,
						previous_orderinfo:previous_orderinfo,
						item_amounte:item_amounte,
						item_qtye:item_qtye,
						item_ratee:item_ratee,
						item_otherse:item_otherse,
						group_namee:group_namee,
						master_ide:master_ide,
						karigor_ide:karigor_ide,
						edit_ord_number:edit_ord_number,
						edit_order:1
					},
					 beforeSend: function () {
						$("#uload").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response==1){
							$("#uload").html(null);
							$("#edit_measurement").html("Update Success!").css("color","green");
							
						}else{
							$("#uload").html("Not Success!").css("color","red");
						}
						srchByOrdNum($("#hidden_ord_number").val());
						document.getElementById("updatebtn").disabled = false;
						esizeida = [];
						esizea = [];
						eexproperticea = [];
						eproperticetitlea = [];
						eproperticea = [];
					}
			});
		}else{
			$("#edit_ord_number").css("border-color","red");
		}
		}
	}
	
	function srchByOrdNum(ord_number){
		var edit_ord_number=ord_number; //$("#edit_ord_number").val();
		
		if(edit_ord_number!=""){
			$("#edit_ord_number").css("border-color","#CCCCCC");
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						edit_ord_number:edit_ord_number,
						get_edit_item:1
					},
					 beforeSend: function () {
						$("#item_area").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response!=2){
							$("#item_area").html(response).css("color","black");
						}else{
							$("#item_area").html("Not Found!").css("color","red");
						}
						var hidden_ord_number=$("#hidden_ord_number").val();
						if(hidden_ord_number!=""){
							$("#active_btn"+hidden_ord_number).css("color","#337ab7");
						}
						$("#hidden_ord_number").val(edit_ord_number);
						$("#active_btn"+edit_ord_number).css("color","red");
					}
			});
		}else{
			$("#edit_ord_number").css("border-color","red");
		}
	}
	
	function AfterOrderDeleteItem(ord_tbl_id,item_id,design_cost,amount_cost,dsms_id,item_name,sl){
		if(confirm("আপনি কি আইটেম Delete করতে চান?")){
			document.getElementById("itemDel"+sl).disabled = true;
			document.getElementById("eitem"+sl).disabled = true;
			$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					ord_tbl_id:ord_tbl_id,
					item_id:item_id,
					design_cost:design_cost,
					amount_cost:amount_cost,
					dsms_id:dsms_id,
					item_name:item_name,
					AfterOrderDeleteItem:1
				}, 
				beforeSend: function () {
						$("#uload").html('<img src="img/loading.gif"/>');
					},
				 success: function (response) {
					 $("#uload").html(null);
					 if(response==1){
						alert("Delete Success!");
						$("#itemDel"+sl).hide("slow");
						$("#eitem"+sl).hide("slow");
					 }else{
						alert("Delete Not Success!");
						document.getElementById("itemDel"+sl).disabled = false;  
						document.getElementById("eitem"+sl).disabled = false;
					 }
				}
			});
		}
	}
	
	function srchByMobileNum(src_mobile){
		$("#edit_ord_number").val(src_mobile);
		var searchable_mobile_num=src_mobile;
		$("#editable_auto_mobile").html(null);  
		if(edit_ord_number!=""){
			$("#edit_ord_number").css("border-color","#CCCCCC");
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						searchable_mobile_num:searchable_mobile_num,
						get_by_mobile_num:1
					},
					 beforeSend: function () {
						$("#item_area").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response!=2){
							$("#order_list").html(response).css("color","black");
						}else{
							$("#order_list").html("Not Found!").css("color","red");
						}
						$("#item_area").html(null);
						
					}
			});
		}else{
			$("#order_list").css("border-color","red");
		}
	}
	
	function getEditableOrder(){
		var edit_ord_number=$("#edit_ord_number").val();
		var first_digit = edit_ord_number.charAt(0);
		 if (first_digit.toLowerCase() == 'a') {
			 $.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					chk_searchable_number: 1, 
					mobile:edit_ord_number,
					autoCompleteMobileSearchable:1
				},
				 success: function (response) {
					 
					 if(mobile!=""){
						$("#editable_auto_mobile").html(response); 
					 }else{
						$("#editable_auto_mobile").html(null);  
					 }
				}
			});
		 }else{
				var mobile=edit_ord_number;
				if(mobile=="" || mobile.length<11 || mobile.length>11){
					$("#cus_name").val(null);
					$.ajax({
						type: 'post',
						url: 'ajax.php',
						data: {
							chk_searchable_number: 2,
							mobile:mobile,
							autoCompleteMobileSearchable:1
						},
						 success: function (response) {
							 
							 if(mobile!=""){
								$("#editable_auto_mobile").html(response); 
							 }else{
								$("#editable_auto_mobile").html(null);  
							 }
						}
					});
					
				}else{
					$.ajax({
						type: 'post',
						url: 'ajax.php',
						data: {
							chk_searchable_number: 2,
							mobile:mobile,
							autoCompleteMobileSearchable:1
						},
						 success: function (response) {
							// $("#editable_auto_mobile").html(null);  
							 if(mobile!=""){
								$("#editable_auto_mobile").html(response); 
							 }else{
								$("#editable_auto_mobile").html(null);  
							 }
								
						}
					});
				}
			}
	}
	
	function chkCustomer(){
		var mobile=$("#mobile").val();
		if(mobile=="" || mobile.length<11 || mobile.length>11){
			$("#previous_due").val(0.0);
			$("#cus_name").val(null);
			$("#hidden_cus_name").val(null);
			$("#tot_remaining_point").html(null);
			document.getElementById("ref_chk").disabled = true;
			getAdvance();
			$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					mobile:mobile,autoCompleteMobile:1
				},
				 success: function (response) {
					 
					 if(mobile!=""){
						$("#auto_mobile").html(response); 
					 }else{
						$("#auto_mobile").html(null);  
					 }
				}
			});
			
		}else{
			$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					mobile:mobile,authCustomer:1
				},
				 success: function (response) {
					 $("#auto_mobile").html(null);  
					 if(response==2){
						$("#chkAuthUser").val(""); // 2=not founded user
					 }else{
						 var sp=response.split("#sep#");
						$("#chkAuthUser").val(sp[1].trim()); //founded user id
						$("#cus_name").val(sp[0].trim()); //Founded User Name 
						$("#hidden_cus_name").val(sp[0].trim()); //Founded User Name 
						if(parseFloat(sp[2])>0){
							document.getElementById("ref_chk").disabled = false;
							$("#tot_remaining_point").html(sp[2]);
						}
						getUpdateDue(sp[1]);
					 }
						
				}
			});
		}
	}
	
	function setMobileNumber(mobile,cus_name,cus_id,point){
		$("#mobile").val(mobile);
		$("#auto_mobile").html(null);
		if(parseFloat(point)>0){
			document.getElementById("ref_chk").disabled = false;
			$("#tot_remaining_point").html(point);
		}		
		$("#chkAuthUser").val(cus_id); //founded user id
		$("#cus_name").val(cus_name); //Founded User Name 
		$("#hidden_cus_name").val(cus_name); //Founded User Name 
		getUpdateDue(cus_id);
	}
	
	function getUpdateDue(cus_id){
		$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				cus_id:cus_id,get_update_due:1
			},
			 success: function (response) {
				var update_due=parseFloat(response).toFixed(2);
				$("#previous_due").val(update_due.trim()); // set individual customers previous due
				getAdvance();
			}
		});
	}
	
	function checkPreviousOrder(){
		var manual_book_ord=$("#phy_ord_num").val();
		console.log(manual_book_ord);
		$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				phy_ord_num:manual_book_ord,
				checkPreviousOrder:1
			},beforeSend: function () {
				$("#ord_success").html('<img src="img/ajax_clock_small.gif"/>');
			},
			 success: function (response) {
				 console.log(response);
				if(response==1){
					$("#manual_book_ord").val(null);
					$("#ord_success").html("Warning! Duplicate.").css("color","red");
					document.getElementById("save_order").disabled = true;
				}else{
					$("#ord_success").html('<img src="img/correct18x18.png"/>');
					document.getElementById("save_order").disabled = false;
				}
			}
		});
	}
	
	function checkPreviousOrderAndMearge(){
		var manual_book_ord=$("#phy_ord_num").val();
		console.log(manual_book_ord);
		$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				phy_ord_num:manual_book_ord,
				checkPreviousOrder2:1
			},beforeSend: function () {
				$("#ord_success").html('<img src="img/ajax_clock_small.gif"/>');
			},
			 success: function (response) {
				 console.log(response);
				 
				if(response==2){
					$("#ord_success").html('<img src="img/cross.png"/>');
					$("#manual_book_ord").val(null);
					document.getElementById("save_order").disabled = true;
					document.getElementById("mobile").disabled = false;
					document.getElementById("cus_name").disabled = false;
					document.getElementById("delivery_day").disabled = false;
					//document.getElementById("discount_percentage").disabled = false;
					//document.getElementById("discount_tk").disabled = false;
					$("#mobile").val("");
					$("#cus_name").val("");
					$("#chkAuthUser").val("");
					$("#merge_order_chk").val("");
					$("#previous_due").val(0); 
					getAdvance();
				}else{
					var sp=response.split("#sep#");
					$("#mobile").val(sp[0].trim());
					$("#cus_name").val(sp[2].trim());
					$("#chkAuthUser").val(sp[1].trim());
					$("#merge_order_chk").val(1);
					document.getElementById("save_order").disabled = false;
					document.getElementById("mobile").disabled = true;
					document.getElementById("cus_name").disabled = true;
					document.getElementById("delivery_day").disabled = true;
					//document.getElementById("discount_percentage").disabled = true;
					//document.getElementById("discount_tk").disabled = true;
					$("#ord_success").html('<img src="img/correct18x18.png"/>');
					getUpdateDue(sp[1].trim());
				}
			}
		});
	}
	
	function newMeasurement(){
		var sp=$("#new_measurement_parameter").val().split("#sep#");
		if(confirm("আপনি কি নতুন অর্ডার নিতে চান?")){
			var increment_number=$("#increment_number").val();
			orderQueue.push(increment_number);
			$("#increment_number").val(parseInt(increment_number)+1);
			
			$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				ord_tbl_id:sp[0],
				group_id:sp[1],
				ptye:sp[2],
				item_id:sp[3],
				item_name:sp[4],
				orderinfo:sp[6],
				design_cost:sp[7],
				amount_cost:sp[8],
				item_qty:sp[9],
				master_id:sp[10],
				karigor_id:sp[11],
				sl_no:sp[5],
				increment_number:increment_number,
				newMeasurement:1
			},
			 beforeSend: function () {
				$("#edit_measurement").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
					$("#measurement_details").prepend(response).css("color","black").show("slow");
					$("#edit_measurement").html("Success!").css("color","green");
					itemAmountChange(increment_number);
					var s_cus_mobile=sp[6].split("_");
					$("#mobile").val(s_cus_mobile[3]);
					chkCustomer();
				}
			});
		}
	}
	
	function salesReturnOption(){
		var srcdate=$("#srcdate").val();
		$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				srcdate:srcdate,salesReturnOption:1
			},
			 beforeSend: function () {
				$("#sales_return_page").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
				if(response!=2){
					$("#sales_return_page").html(response).css("color","black");
				}else{
					$("#sales_return_page").html("No Result Found!").css("color","red");
				}
				
			}
		});
	}
	
	function searchExpense(){
		var srcdate=$("#srcdate_expense").val();
		$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				srcdate:srcdate,searchExpense:1
			},
			 beforeSend: function () {
				$("#searching_tbl").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
				if(response!=2){
					$("#searching_tbl").html(response).css("color","black");
				}else{
					$("#searching_tbl").html(null);
					$("#expense_not_found").html("No Result Found!").css("color","red");
				}
				
			}
		});
	}
	
	function showDetailSales(dstblid){
		$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				dstblid:dstblid,showDetailSales:1
			},
			 beforeSend: function () {
				$("#detail_item").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
				if(response!=2){
					$("#detail_item").html(response).css("color","black");
				}else{
					$("#detail_item").html("No Result Found!").css("color","red");
				}
				
			}
		});
	}
	
	function delDetailSales(deltblid,price,headid,ord_num,item_id,item_qty,cus_mobile){
		 if(confirm("আপনি কি Item টি  Return নিতে চান?")){
			 if(ord_num=="" || ord_num=='0'){
				document.getElementById("delid"+deltblid).disabled = true;	
				$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						headid:headid,
						price:price,
						ord_num:ord_num,
						deltblid:deltblid,
						item_id:item_id,
						item_qty:item_qty,
						cus_mobile:cus_mobile,
						delDetailSales:1
					},
					 beforeSend: function () {
						$("#del_sms").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						 console.log(response);
						if(response==1){
							$("#del_sms").html("Delete Success!").css("color","green");
						}else{
							$("#del_sms").html("Not Success!").css("color","red");
						}
						
					}
				});
			 }else{
				 //alert("Sales return is not possible. Please exchange it!!");
				document.getElementById("delid"+deltblid).disabled = true;	
				$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						headid:headid,
						price:price,
						ord_num:ord_num,
						deltblid:deltblid,
						item_id:item_id,
						item_qty:item_qty,
						cus_mobile:cus_mobile,
						delDetailSales:1
					},
					 beforeSend: function () {
						$("#del_sms").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						 console.log(response);
						if(response==1){
							$("#del_sms").html("Delete Success!").css("color","green");
						}else{
							$("#del_sms").html("Not Success!").css("color","red");
						}
						
					}
				});
			 }
		  }
	}
	
	function updateItemQty(id,update_status){
		var oldqty=$("#oldqty"+id).val();
		var edititemqty=$("#edititemqty"+id).val();
		var edit_ord_number=$("#edit_ord_number").val();
		if(update_status=='0'){
			var comment="আপনি আইটেম সংখ্যা ১ কমাতে চান?";
		}else{
			var comment="আপনি আইটেম সংখ্যা ১ বাড়াতে চান?";
		}
		 if(confirm(comment)){
			if(edititemqty!="" && parseFloat(edititemqty)>0){
				//document.getElementById("itemqtyupdatebtn"+id).disabled = true;
				$("#edititemqty"+id).css("border-color","#CCCCCC");
				$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						oldqty:oldqty,
						edititemqty:edititemqty,
						update_status:update_status,
						edit_ord_number:edit_ord_number,
						updateItemQty:1
					},
					 beforeSend: function () {
						$("#uload").html('<img src="img/loading.gif"/>');
						$("#uload").show();
					},
					 success: function (response) {
						 if(response!=2){
							 var sp=response.split("#sep#");
							$("#org_item_qty"+id).html(sp[1]);
							$("#oldqty"+id).val(response);
							$("#uload").html("Success").css("color","green");
							//$("#edititemqty"+id).val(null);
						 }else{
							 $("#uload").html("Invalid").css("color","red");
						 }
						 //document.getElementById("itemqtyupdatebtn"+id).disabled = false;
					}
				});
			}else{
				if(parseFloat(edititemqty)==0){
					//$("#edititemqty"+id).val(null);
				}
				$("#edititemqty"+id).css("border-color","red");
				document.getElementById("itemqtyupdatebtn"+id).disabled = false;
			}
		 }else{
			 
		 }
	}
	
	function showEditDetails(master_id,karigor_id,ord_tbl_id,group_id,ptye,item_id,item_name,sl,orderinfo,design_cost,amount_cost,item_qty){
		var eitem_chk=$("#eitem_chk").val();
		$("#eitem"+sl).css("color",'red');
		$("#eitem"+eitem_chk).css("color",'#337AB7');
		$("#eitem_chk").val(sl);
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					master_id:master_id,
					karigor_id:karigor_id,
					ord_tbl_id:ord_tbl_id,
					group_id:group_id,
					ptye:ptye,
					item_id:item_id,
					item_name:item_name,
					orderinfo:orderinfo,
					design_cost:design_cost,
					amount_cost:amount_cost,
					item_qty:item_qty,
					sl_no:sl,
					get_item_detail_edit:1
				},
				 beforeSend: function () {
					$("#edit_measurement").html('<img src="img/loading.gif"/>');
					$("#updatebtn,#newordbtn").show();
					$("#new_measurement_parameter").val(ord_tbl_id+"#sep#"+group_id+"#sep#"+ptye+"#sep#"+item_id+"#sep#"+item_name+"#sep#"+sl+"#sep#"+orderinfo+"#sep#"+design_cost+"#sep#"+amount_cost+"#sep#"+item_qty+"#sep#"+master_id+"#sep#"+karigor_id);
				},
				 success: function (response) {
					$("#head_measurement").hide();
					$("#edit_measurement").show("slow");
					$("#edit_measurement").html(response).css("color","black");
				
				}
		});
	}
	
	function showFabricsDetails(order_num){
		$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					order_num:order_num,
					showFabricsDetails:1
				},
				 beforeSend: function () {
					$("#edit_measurement").show("slow");
					$("#edit_measurement").html('<img src="img/loading.gif"/>');
				},
				 success: function (response) {
					$("#edit_measurement").html(response).css("color","black");
				
				}
		});
	}
	
	function changeType(){
		var item_type=$("#item_type").val();
		$.ajax({
						type: 'post',
						url: 'ajax.php',
						data: {
							item_type:item_type,
							get_selected_item:1
						},
						 beforeSend: function () {
							$("#page_loading").show();
							$("#page_loading").html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							$("#page_loading").html(null);
							$("#show_item_btn").html(response);
						
						}
			});
	}
	
	function delExpense(tbl_id,auto_inc){
	    if(confirm("Do you want to delete it?")){
			//var tbl_last_id=$("#tbl_last_id").val();
			document.getElementById("delExbtn"+auto_inc).disabled = true;
			$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					tbl_id:tbl_id,
					delExpense:1
				},
				 success: function (response) {
					console.log(response);
					if(response==1){
						document.getElementById("delExbtn"+auto_inc).disabled = true;
					}else{
						document.getElementById("delExbtn"+auto_inc).disabled = false;
					}
				}
			});
		}
  }
	
	
	function setDeliveryDate(){
		var delivery_day=$("#delivery_day").val();
		var date1=$("#previous_delivery_date").val();
		$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				delivery_day:delivery_day,
				date1:date1,
				set_delivery_date:1
			},
			 success: function (response) {
				$("#date1").val(response.trim());
			}
		});
	}
	

	
	function getOrderDetails(){
			$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					get_order_details:1
				},
				 beforeSend: function () {
					$("#sms").show();
					$("#sms").html('<img src="img/loading.gif"/>');
				},
				 success: function (response) {
					console.log(response);
					$("#sms").hide();
					/*if(response!=2){
					$("#getOrderDetails").html(response);
					}else{
						$("#getOrderDetails").html(null);
					}*/
					//setCusTotalPrice();
					setOrdNum(response);
				}
			});
		
	}
	
	function delOrderDetails(){
		$.ajax({
						type: 'post',
						url: 'ajax.php',
						data: {
							del_get_order_details:1
						},
						 beforeSend: function () {
							$("#sms").show();
							$("#sms").html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							$("#sms").hide();
							$("#del_report").html(response);
						}
			});
	}
	
	function setOrdNum(){ //setOrdNum(response_id)
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					setOrdNum:1
				},
				 success: function (response) {
					/*if(response_id!=2){
						var lastid=$("#last_ids").val();
						for(var i=0;i<lastid;i++){
						$("#ord_one"+i).html(response);
						$("#ord_two"+i).html(response);
						}
					}*/
					$("#head_ord_num").html(response);
					$("#mobile").click();
					$("#mobile").focus();
				}
			});
	}
	
	function setCusTotalPrice(){
		//console.log($("#tot_cus_price").val()+"--------------");
		$("#tdue").val($("#tot_cus_price").val());
		$("#total_tk").val($("#tot_cus_price").val());
		$("#discount").val(0);
		if(parseFloat($("#tot_cus_price").val())>0){
		$("#total_h,#due_tk").val(parseFloat($("#tot_cus_price").val())+parseFloat($("#sub_tot_f_val").val()));
		}else{
		$("#total_h,#due_tk").val(0+parseFloat($("#sub_tot_f_val").val()));	
		}
	}
	
	function delOrderFnc(ord_num,sl){
	document.getElementById("delOrder"+sl).disabled = true;
		$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					ord_num:ord_num,delOrderFnc:1
				},
					 beforeSend: function () {
						$("#sms").show();
						$("#sms").html('<img src="img/loading.gif"/>');
					},
						success: function (response) {
						console.log(response);
						if(response==1){
						$("#sms").hide();
						getOrderDetails();
						}else{
							$("#sms").html("Not Success!").css("color","red");;
						}
					}
			});
	}
	
	function activeOrderFnc(ord_num,sl){
	document.getElementById("actOrder"+sl).disabled = true;
		$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					ord_num:ord_num,activeOrderFnc:1
				},
					 beforeSend: function () {
						$("#sms").show();
						$("#sms").html('<img src="img/loading.gif"/>');
					},
						success: function (response) {
						console.log(response);
						if(response==1){
						$("#sms").hide();
						delOrderDetails();
						}else{
							$("#sms").html("Not Success!").css("color","red");;
						}
					}
			});
	}
	
	
	window.orderQueue = [];
	function itemIdWiseDetails(item_ids){
		var max_item_hidden=$("#max_item_hidden").val();
		if(parseInt(max_item_hidden)<=0){
			alert("Warning! Maximum 20 Items Support.");
			exit;
		}
		$("#getOrderDetails").html(null);
		document.getElementById("orderbtn1").disabled = true;
		var i="",chk_empty_item_qty="";
		var measurementChks=measurementChk();
			if(measurementChks!=""){
					var sp=measurementChks.split("#sep#");
					$("#size"+sp[1]+"0").click();
					$("#size"+sp[1]+"0").focus();
					alert("Warning! Item Measurement Missing.");
					exit;
			}
		var item_id=item_ids; //$("#item_id").val();
		var sp=item_id.split("#sep#");
		var selectid=$("#selectid").val();
				$("#item_btn"+sp[3]).addClass("active");
				$("#item_btn"+selectid).removeClass('active');
				$("#selectid").val(sp[3]);
				$("#chk_desktop_time").html(null);
			var item_type=$("#item_type").val();
			var increment_number=$("#increment_number").val();
			orderQueue.push(increment_number);
			$("#max_item_hidden").val(parseInt(max_item_hidden)-1);
			$("#max_item").html(parseInt(max_item_hidden)-1);
			console.log(orderQueue+"=que in"+increment_number);
			$("#increment_number").val(parseInt(increment_number)+1);
			
				if(item_id!=""){
					$.ajax({
						type: 'post',
						url: 'ajax.php',
						data: {
							item_type:item_type,
							item_id:item_id,
							increment_number:increment_number,
							get_item_detail:1
						},
						 beforeSend: function () {
							$("#page_loading").show();
							$("#page_loading").html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							//console.log(response);
							if(response!=2){
							$("#page_loading").hide();
							$("#measurement_details").prepend(response).css("color","black").show("slow");
							$("#calculator").hide("slow");
							$("#show_btn").show("slow");
							$("#show_btn").html("<button onclick='showAllInfo();' id='show_all_info' class='btn btn-success'>Show All</button>");
							
							$("#size"+increment_number+"0").click();
							$("#size"+increment_number+"0").focus();
							itemAmountChange(increment_number);
							}else{
								$("#page_loading").hide();
								$("#measurement_details").html("No Result Found!").css("color","red");
							}
						}
					});
				}else{
					$("#measurement_details").html(null);
				}
	}
	
	function copyOnlyMeasurement(item_id,increment_number){
		console.log(orderQueue);
		if(orderQueue.length>1){
			var item_ids=$("#hidden_selected_item").val();
				for(var i=0;i<25;i++){
					$('#size'+increment_number+i).val($('#size'+item_ids+i).val());
				}
		}else{
			alert('প্রথমত কোনো একটি আইটেম এর মেজারমেন্ট নিন!');
		}
		
	}
	
	function selectedItem(selected_item){
		$("#hidden_selected_item").val(selected_item);
	}
	
	function calculateSelectAmount(item_id,sl_no){
		$("#item_others"+item_id).val(setAmount(item_id));
		if($("#propertice"+item_id+sl_no).val()==""){
			$("#propertice"+item_id+sl_no).css('border-color','');
			$("#propertice"+item_id+sl_no).css('color','#555');
		}else{
			$("#propertice"+item_id+sl_no).css('border-color','blue');
			$("#propertice"+item_id+sl_no).css('color','blue');
		}
		itemAmountChange(item_id);
		$("#total_tk").val(getTotalMakingTk());
		$("#design_charge").val(getTotalDesignTk());
		getAdvance();
	}
	
	function getCheckBoxAmount(item_id){
		$("#item_others"+item_id).val(setAmount(item_id));
		itemAmountChange(item_id);
		$("#total_tk").val(getTotalMakingTk());
		$("#design_charge").val(getTotalDesignTk());
		getAdvance();
	}
	
	function showAllInfo(){
		$("#calculator").show("slow");
		$("#show_btn").hide("slow");
		$("#getOrderDetails").html(null);
		document.getElementById("orderbtn1").disabled = true;
	}
	
	function getPendingTask(emp_type,get_value,id_name,sl){
		$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				get_value:$("#"+get_value+sl).val(),
				emp_type:emp_type,
				getPendingTask:1
			},
			 beforeSend: function () {
				$("#"+id_name+sl).html('<img src="img/ajax_clock_small.gif"/>');
			},
			 success: function (response) {
				console.log(response);
				$("#"+id_name+sl).html(response).css('color','red');
			}
		});
	}
	
	function copyReferenceNumber(){
		var mobile=$("#mobile").val();
		if(mobile!=""){
			$("#ref_mobile_number").val(mobile);
			$("#ref_user_id").val($("#chkAuthUser").val());
			$("#chkAuthUser").val(null);
			$("#tot_remaining_point").html(null);
			$("#mobile").val(null);
			$("#cus_name").val(null);
			document.getElementById("ref_chk").disabled = true;
		}
	}
	
	function clearReferenceNumber(){
		$("#ref_mobile_number").val(null);
		$("#ref_user_id").val(null);
	}
	
	function enterEvent(id_name,sl){
		var input = document.getElementById(id_name+sl);
		var next_id=parseInt(sl)+1;
		console.log(next_id+"=========");
		input.addEventListener("keyup", function(event) {
		  if (event.keyCode === 13) {
			$("#"+id_name+next_id).click();
			$("#"+id_name+next_id).focus();
			var tag_num = document.getElementById(id_name+next_id);
			tag_num.select();
		  }
		});
	}
	
	function setAmount(item_id){
		var propertice="";
		var propertice_title_tot=$("#propertice_title_tot"+item_id).val();
		var expropertice_tot=$("#expropertice_tot"+item_id).val();
		var i="",amount=0,amount2=0;
		for(i=0;i<propertice_title_tot;i++){
			propertice=$("#propertice"+item_id+i).val();
			if(propertice!=""){
				amount+=parseFloat($("#select_amount"+item_id+i).val());
			}
		}
		
		for(i=0;i<expropertice_tot;i++){
			if ($("#expropertice"+item_id+i).is(":checked")){
				amount2+=parseFloat($("#check_amount"+item_id+i).val());
			}
		}
		
		return (amount+amount2);
	}
	
	function itemAmountChange(item_id){
		var item_qty=parseFloat($("#item_qty"+item_id).val());
		if($("#item_qty"+item_id).val()==""){
			item_qty=0;
		}
		
		var item_rate=parseFloat($("#item_rate"+item_id).val());
		var item_others=($("#item_others"+item_id).val()=="")? 0 : parseFloat($("#item_others"+item_id).val());
		$("#item_amount"+item_id).val(((item_rate*item_qty)+(item_others*item_qty)));
		$("#total_tk").val(getTotalMakingTk());
		$("#design_charge").val(getTotalDesignTk());
		getAdvance();
	}
	
	function getTotalMakingTk(){
		var total_making=0;
		for(i=0;i<orderQueue.length;i++){
			item_qty=($("#item_qty"+orderQueue[i]).val()=="")? 0 : parseFloat($("#item_qty"+orderQueue[i]).val());
			total_making+=(parseFloat($("#item_rate"+orderQueue[i]).val())*item_qty);
		}
		return total_making;
	}
	
	function getTotalDesignTk(){
		var total_others=0;
		for(i=0;i<orderQueue.length;i++){
			var item_qty=parseFloat($("#item_qty"+orderQueue[i]).val());
			if($("#item_qty"+orderQueue[i]).val()==""){
				item_qty=0;
			}
			total_others+=($("#item_others"+orderQueue[i]).val()=="")? 0 : (parseFloat($("#item_others"+orderQueue[i]).val()*item_qty));
		}
		return total_others;
	}
	
	
	function deleteMeasurement(id){
		if(confirm("আপনি কি মেজারমেন্ট Delete করতে চান?")){
			var elem = document.querySelector('#delete_measurement'+id);
			elem.remove();
			const index = orderQueue.indexOf(id);
			if (index > -1) {
				orderQueue.splice(index, 1);
			}
			$("#total_tk").val(getTotalMakingTk());
			$("#design_charge").val(getTotalDesignTk());
			var max_item_hidden=$("#max_item_hidden").val();
			$("#max_item_hidden").val(parseInt(max_item_hidden)+1);
			$("#max_item").html(parseInt(max_item_hidden)+1);
			getAdvance();
			console.log(orderQueue+"=que remove"+id);
		}
	}
	
	/*------------------------------edit-----------------------------------*/
	function itemAmountChangeEdit(item_id){
		var item_qty=parseFloat($("#item_qtye"+item_id).val());
		if($("#item_qtye"+item_id).val()==""){
			item_qty=0;
		}
		
		var item_rate=parseFloat($("#item_ratee"+item_id).val());
		var item_others=parseFloat($("#item_otherse"+item_id).val());
		$("#item_amounte"+item_id).val(((item_rate*item_qty)+(item_others*item_qty)));
	}
	
	function calculateSelectAmountEdit(item_id,sl_no){
		$("#item_otherse"+item_id).val(setAmountEdit(item_id));
		if($("#properticee"+sl_no).val()==""){
			$("#properticee"+sl_no).css('border-color','');
		}else{
			$("#properticee"+sl_no).css('border-color','blue');
		}
		itemAmountChangeEdit(item_id);
	}
	
	function getCheckBoxAmountEdit(item_id){
		$("#item_otherse"+item_id).val(setAmountEdit(item_id));
		itemAmountChangeEdit(item_id);
	}
	
	function setAmountEdit(item_id){
		var propertice="";
		var propertice_title_tot=$("#propertice_title_tote").val();
		var expropertice_tot=$("#expropertice_tote").val();
		var i="",amount=0,amount2=0;
		for(i=0;i<propertice_title_tot;i++){
			propertice=$("#properticee"+i).val();
			if(propertice!=""){
				amount+=parseFloat($("#select_amounte"+i).val());
			}
		}
		
		for(i=0;i<expropertice_tot;i++){
			if ($("#exproperticee"+i).is(":checked")){
				amount2+=parseFloat($("#check_amounte"+i).val());
			}
		}
		
		return (amount+amount2);
	}
	
	/*------------------------------edit- end----------------------------------*/
	
	function forEditMeasurement(){
		$("#edit_ord_number").focus();
		$("#edit_ord_number").click();
		
	}
	
	window.usizea = [];
	window.usizeida = [];
	window.uproperticetitlea = [];
	window.uproperticea = [];
	window.uexproperticea = [];
	function esaveMeasurement(){
		var item_id="",item_type="";
		if($("#edit").val()==1){
			item_id=$("#item_ide").val();
			item_type=$("#item_typee").val();
			var chk_version=$("#chk_version").val();
			if(chk_version==1 || chk_version==2){
				$("#new_ord").html("Invalid! Change Order Type.").css("color","red");
				exit();
			}
		}
		var phy_ord_num=$("#phy_ord_num").val();
		var tbl_ord_num=$("#tbl_ord_num").val();
		var item_qty=$("#item_qtye").val();
		var master_id=$("#master_ide").val();
		var karigor_id=$("#karigor_ide").val();
		var sizetot=$("#sizetote").val(); //sizetxt
		var propertice_title_tot=$("#propertice_title_tote").val(); //propertice
		var expropertice_tot=$("#expropertice_tote").val(); //expropertice expropertice_tot
		var i="",m="",ep="",epc=0,iid="",jj="",extra_remarks="";
		var txtareaid=$("#txtareaide").val();
		if(txtareaid>0){
			extra_remarks=$("#extra_remarkse").val().trim();
		}
		
		if(phy_ord_num==""){
			$("#phy_ord_num").css("border-color","red");
			$("#phy_ord_num").focus();
			jj=1;
		}else{
			$("#phy_ord_num"+i).css("border-color","#CCCCCC");
		}
		
		if(item_qty==""){
			$("#item_qtye").css("border-color","red");
			$("#item_qtye").focus();
			iid=1;
		}else{
			$("#item_qtye"+i).css("border-color","#CCCCCC");
		}
		for(i=0; i<sizetot; i++){
			if($("#sizee"+i).val()!=""){
				$("#size"+i).css("border-color","#CCCCCC");;
				usizea.push($("#sizee"+i).val());
				usizeida.push($("#sizetxte"+i).val());
			}
		}
		for(i=0; i<propertice_title_tot; i++){
				uproperticetitlea.push($("#propertice_titlee"+i).val());
				if($("#properticee"+i).val()!=""){
					uproperticea.push($("#properticee"+i).val());
				}else{
				uproperticea.push(0);
				}
		}
		if(expropertice_tot!=0){
			for(i=0; i<expropertice_tot; i++){
					if ($('#exproperticee'+i).is(":checked")){
						uexproperticea.push($("#exproperticee"+i).val());
					}else{
						epc++;
					}
			}
			
			var all_exproperticea = uexproperticea.join('#sep#');
		}else{
			var all_exproperticea =0;
		}
		
		console.log(expropertice_tot+"= "+epc);
		console.log("size id: "+usizeida);
		console.log("size p: "+usizea);
		console.log("ex p: "+uexproperticea);
		console.log("p t: "+uproperticetitlea);
		console.log("p : "+uproperticea);
		
		var all_sizeida = usizeida.join('#sep#');
		var all_sizea = usizea.join('#sep#');
		var all_properticetitlea = uproperticetitlea.join('#sep#');
		var all_properticea = uproperticea.join('#sep#');
		
		
		if(ep==1 || iid==1 || jj==1){ //m==1 || 
			usizeida = [];
			usizea = [];
			uexproperticea = [];
			uproperticetitlea = [];
			uproperticea = [];
			exit();
		}else{
			document.getElementById("save_measuremente").disabled = true;
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						item_id:item_id,
						all_sizeida:all_sizeida,
						all_sizea:all_sizea,
						all_properticetitlea:all_properticetitlea,
						all_properticea:all_properticea,
						all_exproperticea:all_exproperticea,
						phy_ord_num:phy_ord_num,
						tbl_ord_num:tbl_ord_num,
						item_qty:item_qty,
						master_id:master_id,
						karigor_id:karigor_id,
						item_type:item_type,
						extra_remarks:extra_remarks,
						txtareaid:txtareaid,
						add_order:1
					},
					 beforeSend: function () {
						$("#dtls_load").show();
						$("#dtls_load").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if($("#edit").val()==1){
							$("#head_measurement").html("Save Success!").css("color","green");
							$("#edit_measurement").hide();
						}else{
							if(response==1){
								$("#dtls_load").html("Save Success!").css("color","green");
								$("#measurement_details").hide("slow");
							}else if(response==2){
								$("#dtls_load").html("Invalid Order Number!").css("color","red");
							}else{
								$("#dtls_load").html("Save Not Success!").css("color","red");
								}
						}
						document.getElementById("save_measuremente").disabled = false;
						usizeida = [];
						usizea = [];
						uexproperticea = [];
						uproperticetitlea = [];
						uproperticea = [];
					}
			});
		}
	}
	
	
	function getDeliverySummary(){
		$(".btn-cancel").click();
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						getDeliverySummary:1
					},
					 beforeSend: function () {
						$("#summery_report").show();
						$("#summery_report").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response==1){
							$("#summery_report").html("No result found!").css("color","red");
						}else{
							$("#summery_report").html(response);
							$("#stdv").html("Pending Delivery: "+$("#tdev").val()+" (In 30 days)");
						}
					}
		});
	}
	
	function clickToSelect(txtboxid) {
		const txtbox = document.getElementById(txtboxid);
		txtbox.focus();
		txtbox.select();
 
	}
	
	window.queue = [];
	function getDetails(){
		var selling_price="";
		var present_stock="";
		var avg_price="";
		var is_stock=$("#is_stock").val();
		var apply_selling_price=$("#apply_selling_price").val();
		var max_fabrics_hidden=$("#max_fabrics_hidden").val();
		if(parseInt(max_fabrics_hidden)<=0){
			alert("Warning! Maximum 20 Fabrice Support.");
			exit;
		}
		
		/* var fabricsChk=fabricsQtyPriceChk();
		if(fabricsChk!=""){
				var sp=fabricsChk.split("#sep#");
				$("#pricec"+sp[1]).click();
				$("#pricec"+sp[1]).focus();
				alert("Warning! Fabrice price or qty empty.");
				exit;
		} */
		
		var ds_item_id=$("#ds_item_id").val();
		var sp=ds_item_id.split("#sep#");
		var item_id=sp[0];
		
		/* for(i=0;i<queue.length;i++){
			if($("#item_idc"+queue[i]).val()==item_id){
				alert("Warning! Duplicat Item.");
				return;
			}
		} */
		
		var id=$("#tblid").val();
		id=parseInt(id)+1;
		$("#tblid").val(id);
		if(is_stock==1){ // maintain stock 
			var item_name=sp[1]+" qty: "+sp[4];
			var item_name_receipt=sp[1];
			var present_stock=sp[4];
			var avg_price=sp[5];
		}else{
			var item_name=sp[1];
			var item_name_receipt=sp[1];
		}
		if(apply_selling_price==1){ //apply selling price 
			selling_price=sp[3];
		}
		
			queue.push(id);
			$("#max_fabrics_hidden").val(parseInt(max_fabrics_hidden)-1);
			$("#max_fabrics").html(parseInt(max_fabrics_hidden)-1);
			console.log(id+"array in: "+queue);
			var qname="qtyc";
			var pname="pricec";
			var param='"'+qname+id+'"';
			var param2='"'+pname+id+'"';
				$("#item_detail").prepend("<tr><td id='thd'><span><input type='hidden' class='tag' value='" + id + "'><a href='javascript:void(0)' onClick='return false;' class='removetag" + id + "'>del</a></span></td><td>" + item_name +"<input type='hidden' id='item_namec" + id + "' value='" + item_name_receipt + "'/><input type='hidden' id='item_idc" + id + "' value='" + item_id + "'/></td><td style='width: 10%;' class='text-align-right'><input type='text' maxlength='7' style='text-align:right;color:black;font-size:18px;font-style: italic;font-weight: bold;width: 100%;' autocomplete='off' class='qtycls qtywidth' value='1' placeholder='1' onClick='clickToSelect(" + param + ");' onkeyup='qtyf(" + id + ");' id='qtyc" + id + "'/></td><td style='width: 10%;' id='thd'><input type='text' style='text-align:right;font-size:18px;font-style: italic;color:black;font-weight: bold;width: 100%;' maxlength='7' autocomplete='off' placeholder='0' value='"+selling_price+"' class='price text-align-right' onClick='clickToSelect(" + param2 + ");' onkeyup='pricef(" + id + ");' id='pricec" + id + "'/></td><td id='thd' class='text-align-right'><input type='hidden' id='sub_result_hc" + id + "'/><span class='totalcls' style='float:right;color:black;font-weight: bold;font-size:18px;font-style: italic;' disabled='disabled' id='sub_result" + id + "'>0</span><input type='hidden' value='"+avg_price+"' id='avg_pricec" + id + "'/><input type='hidden' value='"+present_stock+"' id='present_stockc" + id + "'/></td></tr>");
				pricef(id);
				
			$("#pricec"+id).click();
			$("#pricec"+id).focus();
				
			$('.removetag' + id).click(function (e) {
				e.stopImmediatePropagation();
				var elm = $(this).siblings().val();
				$(this).parent().parent().parent().remove();
				
				console.log(id+"=remove id");
					const index = queue.indexOf(id);
					if (index > -1) {
						queue.splice(index, 1);
					}
					console.log(queue+"= after remove array element");
				max_fabrics_hidden=$("#max_fabrics_hidden").val();
				$("#max_fabrics_hidden").val(parseInt(max_fabrics_hidden)+1);
				$("#max_fabrics").html(parseInt(max_fabrics_hidden)+1);
				$("#fab_total").val(getTotalFab());
				$("#total_h").val(getTotal());
				$("#due_tk").val(getTotal());
				$("#febdis").val(0);
				$("#advance_tk").val(0);
				$("#sub_tot").html("Fabrics Total: "+getTotalFab()+"/=");
				$("#sub_tot_f").html("Total: "+getTotalFabOnly()+"/=");
				$("#sub_tot_f_val").val(getTotalFabOnly());
				getAdvance();
			});
	
	}
	
	function qtyf(num){
		var qty=$("#qtyc"+num).val();
		if(parseFloat(qty)>=0){
			if($("#pricec"+num).val()==""){
				$("#pricec"+num).css("border-color","red");
			}else{
				$("#pricec"+num).css("border-color","#CCCCCC");
			}
				if($("#is_stock").val()==1){ // maintain stock 
					if(parseFloat(qty)>parseFloat($("#present_stockc"+num).val())){
						alert("এই পণ্যটির স্টক শেষ হয়েছে!!");
						$("#qtyc"+num).val(1);
					}
				}
			$("#qtyc"+num).css("border-color","#CCCCCC");
			//$("#qtyc"+num).val(qty);
			$("#sub_result_hc"+num).val(getResult(num));
			
			$("#sub_result"+num).html(getResult(num));
			$("#sub_result_h"+num).val(getResult(num));
			
			$("#fab_total").val(getTotalFab());
			$("#total_h").val(getTotal());
			$("#due_tk").val(getTotal());
			$("#sub_tot").html("Fabrics Total: "+getTotalFab()+"/=");
			$("#sub_tot_f").html("Total: "+getTotalFabOnly()+"/=");
			$("#sub_tot_f_val").val(getTotalFabOnly());
			//subClear();
		}else{
			$("#qtyc"+num).val(null);
			$("#sub_result_hc"+num).val(0);
			$("#total_h").val(getTotal());
			$("#due_tk").val(getTotal());
			$("#sub_result"+num).html(null);
			$("#qtyc"+num).css("border-color","red");
			//$("#sub_result_h"+num).val(null);
			
			//$("#fab_total").val(0);
			$("#sub_tot").html("Fabrics Total: 0.00/=");
			$("#sub_tot_f").html("Total: 0.00/=");
			$("#sub_tot_f_val").val(getTotal());
			$("#febdis").val(0);
			//subClear();
		}
		getAdvance();
	}
	
	function pricef(num){
		var is_stock=$("#is_stock").val();
		if(is_stock==1){
			var present_stockc=parseFloat($("#present_stockc"+num).val());
			if(present_stockc<=0){
				alert('আপনার স্টক শেষ হয়েছে!!!');
				$('#pricec'+num).val(null);
			}
		}
		var price=$("#pricec"+num).val();
		if(parseFloat(price)>0){
			$("#sub_result_hc"+num).val(getResult(num));
			$("#pricec"+num).css("border-color","#CCCCCC");
			$("#sub_result"+num).html(getResult(num));
			
			$("#fab_total").val(getTotalFab());
			$("#total_h").val(getTotal());
			$("#due_tk").val(getTotal());
			$("#sub_tot").html("Fabrics Total: "+getTotalFab()+"/=");
			$("#sub_tot_f").html("Total: "+getTotalFabOnly()+"/=");
			$("#sub_tot_f_val").val(getTotalFabOnly());
		}else{
			$("#pricec"+num).val(null);
			$("#sub_result_hc"+num).val(0);
			$("#total_h").val(getTotal());
			$("#due_tk").val(getTotal());
			$("#pricec"+num).css("border-color","red");
			$("#sub_result"+num).html(null);
			$("#sub_tot").html("Fabrics Total: 0.00/=");
			$("#sub_tot_f").html("Total: 0.00/=");
			$("#sub_tot_f_val").val(getTotal());
			$("#febdis").val(0);
		}
		getAdvance();
	}
	
	function getTotal(){
		var tot=0,taitot=0;
		for(var i=0;i<queue.length;i++){
			tot+=($("#sub_result_hc"+queue[i]).val()=="")? 0 : parseFloat($("#sub_result_hc"+queue[i]).val());
	    }
	
		return tot.toFixed(2);
	}
	
	function getTotalFab(){
		var tot=0;
		for(var i=0;i<queue.length;i++){
			tot+=($("#sub_result_hc"+queue[i]).val()=="")? 0 : parseFloat($("#sub_result_hc"+queue[i]).val());
		}
		return tot.toFixed(2);
	}
	
	function getTotalFabOnly(){
		var discount=$("#febdis").val();
		var tot=0;
		for(var i=0;i<queue.length;i++){
			tot+=($("#sub_result_hc"+queue[i]).val()=="")? 0 : parseFloat($("#sub_result_hc"+queue[i]).val());
		}
		//console.log(tot);
		if(parseFloat(discount)>=0 || discount!=""){
			var tot=(tot-((tot*parseFloat(discount))/100));
			return tot.toFixed(2);
		}else{
			return tot.toFixed(2);
		}
	}
	
	
	
	
	function getResult(num){
		
		return ((($("#qtyc"+num).val()=="")? 0 : parseFloat($("#qtyc"+num).val()))*(($("#pricec"+num).val()=="")? 0 : parseFloat($("#pricec"+num).val()))).toFixed(2); //.toFixed(3)
	}
	
	function getAdvance(){
		var i="",chk_item_qty="";
		var previous_due=parseFloat($("#previous_due").val());
		var total_tk=$("#total_tk").val();
		var design_charge=parseFloat($("#design_charge").val());
		var fab_total=parseFloat($("#sub_tot_f_val").val());
		var discount=$("#discount").val();
		var ref_point_check=$("#ref_point_check").val();
		if(ref_point_check==1){
			var advance=($("#advance_tk").val()=="")? '0' : $("#advance_tk").val();
			if(parseFloat(advance)==0){
				$('#ref_chk').prop('checked', false);
			}
		}
	
		if(parseFloat(discount)>100){
			alert("Warning! Discount is not greater than 100.");
			$("#discount").val(0);
			getAdvance();
			exit;
		}
		if(orderQueue.length>0){ 
			var total_item_qty=0;
			for(i=0;i<orderQueue.length;i++){
				total_item_qty+=($("#item_qty"+orderQueue[i]).val()=="")? 0 : parseInt($("#item_qty"+orderQueue[i]).val());
			}
			$("#total_item_qty").val(total_item_qty);
			for(i=0;i<orderQueue.length;i++){
				if($("#item_qty"+orderQueue[i]).val()==""){
					chk_item_qty=orderQueue[i];
					break;
				}
			}
			
			if(chk_item_qty!=""){
				//alert("Warning! Item qty missing.");
				$("#item_qty"+chk_item_qty).click();
				$("#item_qty"+chk_item_qty).focus();
				exit;
			}
		}else{
			$("#total_item_qty").val(0);
		}
			
					if(total_tk!="" || parseFloat(total_tk)>=0){
						if(parseFloat(discount)>=0 || discount!=""){
							var due=((parseFloat(total_tk)+design_charge)-(((parseFloat(total_tk)+design_charge)*parseFloat(discount))/100));
							
							$("#total_h").val((due+fab_total).toFixed(2));
							$("#due_tk").val((due+fab_total).toFixed(2));
							$("#total_due").val((due+fab_total+previous_due).toFixed(2));
							$("#tdue").val(due.toFixed(2));
							$("#discount").css("border-color","#CCCCCC");
						}else{
							$("#discount").css("border-color","red");
							$("#total_h").val((parseFloat(total_tk)+fab_total+design_charge).toFixed(2));
							$("#tdue").val(parseFloat(total_tk).toFixed(2));
							$("#due_tk").val(parseFloat(total_tk).toFixed(2));
							$("#total_due").val((parseFloat(total_tk)+previous_due).toFixed(2));
						}
						$("#total_tk").css("border-color","#CCCCCC");
						
					}else{
						$("#total_tk").css("border-color","red");
						var tailor_zero_tk=parseFloat(fab_total)+0;
						$("#total_h").val(tailor_zero_tk.toFixed(2));
						$("#tdue").val(0);
						$("#due_tk").val(tailor_zero_tk.toFixed(2));
						$("#total_due").val((tailor_zero_tk+previous_due).toFixed(2));
						
					}
				
					var advance_tk=$("#advance_tk").val();
					var total_h_due=parseFloat($("#total_h").val());
						if(total_h_due>=0 || $("#total_h").val()!=""){
							total_h_due=total_h_due;
							if(total_h_due==0){
							    $("#others_tk").val(0);
                		        $("#discount_tk").val(0);
                		        $("#discount_percentage").val(0);
							}
						}else{
							total_h_due=0;
						}
							/*if(parseFloat(advance_tk)>=0){
								$("#due_tk").val((total_h_due-parseFloat(advance_tk)).toFixed(2));
								$("#total_due").val(((total_h_due+previous_due)-parseFloat(advance_tk)).toFixed(2));
							}else{
								$("#due_tk").val(total_h_due.toFixed(2));
								$("#total_due").val((total_h_due+previous_due).toFixed(2));
							}*/
			var grant_total_tk=0,advance_tk_for_due=0;
			previous_due=($("#previous_due").val()=="")? 0 : parseFloat($("#previous_due").val());
			var total_tks=($("#total_tk").val()=="")? 0 : parseFloat($("#total_tk").val());
			var grant_total=($("#grant_total").val()=="")? 0 : parseFloat($("#grant_total").val());
			var total_h=($("#total_h").val()=="")? 0 : parseFloat($("#total_h").val());
			var others_tk=($("#others_tk").val()=="")? 0 : parseFloat($("#others_tk").val());
			var discount_tk=($("#discount_tk").val()=="")? 0 : parseFloat($("#discount_tk").val());
			
			grant_total_tk=total_h+others_tk-discount_tk;
			$("#grant_total").val(grant_total_tk.toFixed(2));
			advance_tk_for_due=advance_tk=($("#advance_tk").val()=="")? 0 : parseFloat($("#advance_tk").val());
			if(queue.length>0 || total_tks>0){
				if(advance_tk>grant_total){
					advance_tk=grant_total;
				}
			}
			
			$("#due_tk").val((grant_total_tk>0)? (grant_total_tk-advance_tk_for_due).toFixed(2) : 0);
			$("#total_due").val((grant_total_tk+previous_due-advance_tk).toFixed(2));
			
	}
	
	function discountPercentage(){
		var grant_total_tk=0;
		var discount_percentage=($("#discount_percentage").val()=="")? 0 : parseFloat($("#discount_percentage").val());
		var total_h=($("#total_h").val()=="")? 0 : parseFloat($("#total_h").val());
		var others_tk=($("#others_tk").val()=="")? 0 : parseFloat($("#others_tk").val());
		grant_total_tk=total_h+others_tk;
		$("#discount_tk").val(Math.round(((grant_total_tk*discount_percentage)/100)));
		getAdvance();
	}
	
	function discountTk(){
		var grant_total_tk=0;
		var discount_tk=($("#discount_tk").val()=="")? 0 : parseFloat($("#discount_tk").val());
		var total_h=($("#total_h").val()=="")? 0 : parseFloat($("#total_h").val());
		var others_tk=($("#others_tk").val()=="")? 0 : parseFloat($("#others_tk").val());
		grant_total_tk=total_h+others_tk;
		$("#discount_percentage").val(((100*discount_tk)/grant_total_tk).toFixed(2));
		getAdvance();
	}
	
	function febDiscount(){
		//var total_tk=$("#total_tk").val();
		var fab_total=$("#fab_total").val();
		var discount=$("#febdis").val();
		var tdue="";
		if(parseFloat($("#tdue").val())>0 || $("#tdue").val()!=""){
			tdue=parseFloat($("#tdue").val());	
		}else{
			tdue=0;
		}
		if(fab_total!="" || parseFloat(fab_total)>=0){
			if(parseFloat(discount)>=0 || discount!=""){
				//var total_tk=parseFloat(fab_total)+parseFloat(total_tk);
				var due=(parseFloat(fab_total)-((parseFloat(fab_total)*parseFloat(discount))/100));
				
				//$("#due_tk").val(due.toFixed(2));
				$("#sub_tot_f_val").val(due.toFixed(2));
				$("#sub_tot_f").html("Total: "+due.toFixed(2));
				$("#total_h").val((due+tdue).toFixed(2));
				$("#due_tk").val((due+tdue).toFixed(2));
				$("#febdis").css("border-color","#CCCCCC");
			}else{
				$("#febdis").css("border-color","red");
				$("#sub_tot_f_val").val(parseFloat(fab_total).toFixed(2));
				$("#sub_tot_f").html("Total: "+parseFloat(fab_total).toFixed(2));
				$("#total_h").val((parseFloat(fab_total)+tdue).toFixed(2));
				$("#due_tk").val((parseFloat(fab_total)+tdue).toFixed(2));
				//$("#due_tk").val(parseFloat(total_tk).toFixed(2));
			}
			//$("#total_tk").css("border-color","#CCCCCC");
			
		}else{
			$("#total_tk").css("border-color","red");
			var tailor_zero_tk=parseFloat(fab_total)+0;
			$("#sub_tot_f_val").val(tailor_zero_tk.toFixed(2));
			$("#sub_tot_f").html("Total: "+tailor_zero_tk.toFixed(2));
			
			$("#total_h").val((tailor_zero_tk+tdue).toFixed(2));
			$("#due_tk").val((tailor_zero_tk+tdue).toFixed(2));
			//$("#due_tk").val(tailor_zero_tk.toFixed(2));
			
		}
		
	}
	
	function saveExpense(){
		var expense_type=$("#expense_type").val();
		var expense_tk=$("#expense_tk").val();
		var remarks=$("#remarks").val();
		var ex_last_id=$("#ex_last_id").val();
		var ex="",tk="";
		if(expense_type==""){
			$("#expense_type").css("border-color","red");
			ex=1;
		}else{
			$("#expense_type").css("border-color","#CCCCCC");
		}
		if(expense_tk==""){
			$("#expense_tk").css("border-color","red");
			tk=1;
		}else{
			$("#expense_tk").css("border-color","#CCCCCC");
		}
		if(ex==1 || tk==1){ //m==1 || 
			exit();
		}else{
			
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						expense_type:expense_type,
						expense_tk:expense_tk,
						remarks:remarks,
						ex_last_id:ex_last_id,
						saveExpense:1
					},
					 beforeSend: function () {
						$("#expense_sms").show();
						$("#expense_sms").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						 if(response==2){
							 $("#expense_sms").html('Warning! Not Success.').css("border-color","red");
						 }else{
							 $("#expense_sms").html(null);
							 $("#searching_tbl").append(response);
							 $("#ex_last_id").val(parseInt(ex_last_id)+1);
							 $("#expense_tk").val(null);
							$("#remarks").val(null);
						 }
						 
					 }
			});
		}
		
	}
	
	$(document).ready(function(){
		$('#urdate_option,#urtime_option,#updatebtn,#newordbtn,#measurement_details,#head_measurement,#edit_measurement,#head_measurement_details').hide();
		$("#print_option").hide();
		$(".select2").select2();
		document.getElementById("orderbtn1").disabled = true;
		document.getElementById("ref_chk").disabled = true;
		setOrdNum();
		$('#normal').prop('checked', true);
		$("#emg").css('color','#E0E0E0');
		$('#normal').click(function () {
			if ($(this).is(":checked")) {
				$('#emergency').prop('checked', false);
				$("#nor").css('color','black');
				$("#emg").css('color','#E0E0E0');
				$('#urdate').val(null);
				$('#urdate_option,#urtime_option').hide();
			}else{
				$('#emergency').prop('checked', true);
				$("#emg").css('color','black');
				$("#nor").css('color','#E0E0E0');
				$('#urdate_option,#urtime_option').show();
			}
		});
		$('#emergency').click(function () {
			if ($(this).is(":checked")) {
				$('#normal').prop('checked', false);
				$("#emg").css('color','black');
				$("#nor").css('color','#E0E0E0');
				$('#urdate_option,#urtime_option').show();
			}else{
				$('#normal').prop('checked', true);
				$("#emg").css('color','#E0E0E0');
				$("#nor").css('color','black');
				$('#urdate').val(null);
				$('#urdate_option,#urtime_option').hide();
			}
		});
		
		$('#order_copy').click(function () {
			if ($(this).is(":checked")) {
				if(confirm("আপনি কি Settings পরিবর্তন করতে চান?")){
					// 1
					$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						set_print_val:1
					},
					
					 success: function (response) {
						console.log(response);
					 }
					});
				}
			}else{
				if(confirm("আপনি কি Settings পরিবর্তন করতে চান?")){
					// 0
					$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						set_print_val:0
					},
					
					 success: function (response) {
						console.log(response);
					 }
					});
				}
			}
		});
		
		$('#ref_chk').click(function () {
			if ($(this).is(":checked")) {
				var due_tk=parseFloat($('#due_tk').val());
				var earn_point=parseFloat($("#tot_remaining_point").text());
				if(due_tk>=earn_point){
					var advance_tk=($("#advance_tk").val()=="")? '0' : $("#advance_tk").val();
					$("#backup_advance").val(advance_tk);
					var total=parseFloat(advance_tk)+earn_point;
					$("#advance_tk").val(total);
					$("#ref_point_check").val(1);
					getAdvance();
				}else{
					alert("Present Due এর চেয়ে আপনার পয়েন্ট বেশি !!");
					$('#ref_chk').prop('checked', false);
				}
				
			}else{
					$("#ref_point_check").val(0);
					$("#advance_tk").val(parseFloat($("#backup_advance").val()));
					getAdvance();
				}
		});
		
		
	
	});
	
	$(function() {
		$( "#date1" ).datepicker({
			dateFormat: 'dd/mm/yy' 
		});
	
	});
	
	
	
	function printOrder(id){
		var print_type=id;//$("#print_type").val();
		if(print_type==1){
			printDiv("getOrderDetails");
			//printDiv("print_area");
		}else{
		printDiv("print_main_body");
		}
	}
	
	function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

    window.print();
	
	  
	document.body.innerHTML = originalContents;
	location.reload();
	 
}
	
</script>

<style>
.chkbox{
	 -ms-transform: scale(2); /* IE */
  -moz-transform: scale(2); /* FF */
  -webkit-transform: scale(2); /* Safari and Chrome */
  -o-transform: scale(2); /* Opera */
  transform: scale(2);
  padding: 10px;
}

.checkboxtext
{
  /* Checkbox text */
  font-size: 120%;
  display: inline;
  padding-left: 6px;
  padding-right: 40px;
}
#emergency{
	margin-left: -22px;
}
#tblhight{
			overflow-y: scroll;
		overflow-x: hidden;
}
.txt_color{
	color: black;
}
#auto_mobile{
	overflow-y: scroll;
	overflow-x: hidden;
}
a:hover {
  background-color: yellow;
}
</style>

<?php
	}else{
		header("location:index.php?id=1");
	}
?>
