
 function sendMonthlyBill(){
   var bill_tk=$("#bill_tk").val();
   var security_code=$("#security_code").val();
   var sender_number=$("#sender_numbers").val();
   var m="";
   if(sender_number=="" || sender_number.length<11 || sender_number.length>11){
			$("#sender_numbers").css("border-color","red");
			$("#sender_numbers").focus();
			m=1;
		}else{
			$("#sender_numbers").css("border-color","#CCCCCC");
		}
		if(m==1){
			exit();
		}else{
			if(confirm("আপনি কি PIN নম্বর এর জন্য Request পাঠাতে চান?")){
				document.getElementById("bill_btn").disabled = true;
				$.ajax({
						type: 'post',
						url: 'sql.php',
						data: {
							sender_number:sender_number,
							bill_tk:bill_tk,
							security_code:security_code,
							sendMonthlyBill:1
						},
							beforeSend: function () {
								$("#bsms").html('<img src="img/loading.gif"/>');
							},
							success: function (response) {
								console.log(response);
								if(response==10000000){
									$("#bsms").html("<span style='font-size:11px'>অপেক্ষা করুন! আপনার মোবাইল নম্বর এ দুইটি PIN SMS করা হবে.</span>").css("color","green");
									$("#sender_numbers").val(null);
								}else if(response==20000000){
									$("#bsms").html("Warning! Alreay Inserted.").css("color","red");
									$("#sender_numbers").val(null);
									document.getElementById("bill_btn").disabled = false;
								}else if(response==30000000){
									$("#bsms").html("Warning! Security Code Not Match.").css("color","red");
									document.getElementById("bill_btn").disabled = false;
								}
								else{
									$("#bsms").html("No Internet Connection!").css("color","red");
									document.getElementById("bill_btn").disabled = false;
									}
									
							}
				});
			}
		}
  }
  
  
  
  function verificationChk(){
	var pina=$("#pina").val();
	var pinb=$("#pinb").val();
	var bill_save=$("#bill_save").val();
	var month_year=$("#month_year").val();
	var security_save=$("#security_save").val();
	var p1="",p2="";
	 if(pina==""){
			$("#pina").css("border-color","red");
			$("#pina").focus();
			p1=1;
		}else{
			$("#pina").css("border-color","#CCCCCC");
		}
		 if(pinb==""){
			$("#pinb").css("border-color","red");
			$("#pinb").focus();
			p2=1;
		}else{
			$("#pinb").css("border-color","#CCCCCC");
		}
		if(p1==1 || p2==1){
			exit();
		}else{
			document.getElementById("verify_btn").disabled = true;
		    $.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						pina:pina,
						pinb:pinb,
						bill_save:bill_save,
						security_save:security_save,
						month_year:month_year,
						verification:1
					},
						beforeSend: function () {
							$("#vsms").html('<img src="img/loading.gif"/>');
						},
						success: function (response) {
							console.log(response);
							if(response==10000000){
								$("#vsms").html("Warning! Wrong PIN1 or PIN2.").css("color","red");
								document.getElementById("verify_btn").disabled = false;
							}else if(response==20000000){
								$("#vsms").html("Success!").css("color","green");
								document.getElementById("verify_btn").disabled = true;
								$("#pina").val(null);
								$("#pinb").val(null);
								setTimeout(function() {
									window.location.href = "signout.php";
								}, 1500);
							}else if(response==30000000){
								$("#vsms").html("Warning! Try again correctly.").css("color","red");
								document.getElementById("verify_btn").disabled = false;
							}
							
						}
			});
		}
  }
  
  function clickToSelect(txtboxid){
		
	if(txtboxid=="discount_tk"){
		const txtbox= document.getElementById(txtboxid);
		txtbox.focus();
		txtbox.select();
	}
	if(txtboxid=="discount_percentage"){
		const txtbox = document.getElementById(txtboxid);
		txtbox.focus();
		txtbox.select();
	}
	if(txtboxid=="others_tk"){
		const txtbox = document.getElementById(txtboxid);
		txtbox.focus();
		txtbox.select();
	}
	if(txtboxid=="advance_tk"){
		const txtbox = document.getElementById(txtboxid);
		txtbox.focus();
		txtbox.select();
	}
	if(txtboxid=="adjust_tk"){
		const txtbox = document.getElementById(txtboxid);
		txtbox.focus();
		txtbox.select();
	}
		
}
  
  