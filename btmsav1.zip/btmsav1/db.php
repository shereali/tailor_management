<?php 

$conn = new mysqli("localhost","root","","btmsav1");
        // Check connection
        if ($conn -> connect_errno) {
          echo "Failed to connect to MySQL: " . $conn -> connect_error;
          exit();
        }
		
		$conn->query('SET CHARACTER SET utf8');
		$conn->query("SET SESSION collation_connection ='utf8_general_ci'");