<?php 
$scom_name=$conn->query("select * from company where is_active=1");

?>
<div class="login-form">
    <form action="#" method="post">
       
		<div class="form-group">
			<!--<select name="com_ids" class="form-control">
			<option value="">No Branch</option>
            <?php 
				while($rows=mysqli_fetch_array($scom_name)){
					?>		
					<option value="<?php echo $rows['id']; ?>"><?php echo $rows['com_name']; ?></option>
				<?php 
				}
			?>
			</select>-->
			<div class="form-group">
            <input type="text" name="com_ids" autocomplete="off" class="form-control" placeholder="Company ID" required="required">
        </div>
        </div>
		<div class="form-group">
            <input type="text" name="com_name" autocomplete="off" class="form-control" placeholder="Company Name/Branch" required="required">
        </div>
		<div class="form-group">
            <input type="text" name="daddress" autocomplete="off" class="form-control" placeholder="Company Detail Address" required="required">
        </div>
		<div class="form-group">
            <input type="text" name="address" autocomplete="off" class="form-control" placeholder="Company SMS Address" required="required">
        </div>
		<div class="form-group">
            <input type="text" name="user" autocomplete="off" class="form-control" placeholder="Proprietor Name" required="required">
        </div>
        <div class="form-group">
            <input type="text" name="email" autocomplete="off" class="form-control" placeholder="Proprietor Email">
        </div>
		<div class="form-group">
            <input type="text" name="mobile" autocomplete="off" maxlength="11" class="form-control" placeholder="Proprietor Mobile" required="required">
        </div>
		<div class="form-group">
            <input type="text" name="soft_charge" autocomplete="off" maxlength="11" class="form-control" placeholder="Software Charge" required="required">
        </div>	
		<div class="form-group">
            <input type="text" name="sms_charge" autocomplete="off" maxlength="11" class="form-control" placeholder="SMS Charge" required="required">
        </div>	
		<div class="form-group">
            <input type="text" name="sms_qty" autocomplete="off" maxlength="11" class="form-control" placeholder="SMS Qty" required="required">
        </div>		
        <div class="form-group">
            <input type="text" name="log_user" class="form-control" placeholder="login user" required="required">
        </div>
        <div class="form-group">
            <input type="password" name="pass" class="form-control" placeholder="Password" required="required">
        </div>
        <div class="form-group">
            <button type="submit" name="btn" value="btn" class="btn btn-primary btn-block">Submit</button>
        </div>
		</form>
		
		<?php 
		
			if(isset($_REQUEST['btn'])){
				$com_name=trim($_REQUEST['com_name']);
				$address=trim($_REQUEST['address']);
				$user=trim($_REQUEST['user']);
				$mobile=trim($_REQUEST['mobile']);
				$log_user=trim($_REQUEST['log_user']);
				$pass=trim($_REQUEST['pass']);
				$sms_qty=trim($_REQUEST['sms_qty']);
				@$com_ids=trim($_REQUEST['com_ids']);
				@$daddress=trim($_REQUEST['daddress']);
				@$soft_charge=trim($_REQUEST['soft_charge']);
				@$sms_charge=trim($_REQUEST['sms_charge']);
				@$email=trim($_REQUEST['email']);
				$api="http://bmmsbd.com/";
			}
			
		?>
        <div class="clearfix">
            <label class="pull-left checkbox-inline">
			<?php 
			if(isset($_REQUEST['btn'])){
				$chk_pass=$conn->query("select * from user where log_user='$log_user' and pass='$pass' and is_active=1");
			if(mysqli_num_rows($chk_pass)>0){
				echo "Duplicate Password! <a href='home.php?loc=registration'>Back</a>";
			}else{
			if($com_ids==""){
				$com_ids=0;
			}
			if($conn->query("insert into company(id,com_name,address,com_head_id,daddress,soft_charge,sms_charge,mobile_num,status,soft_type,sms_service,api,email) values($com_ids,'$com_name','$address',0,'$daddress','$soft_charge','$sms_charge','$mobile',1,2,1,'$api','$email')")){
				//@$top_id = $conn->insert_id;
				$usersql=$conn->query("insert into user(com_id,user_name,mobile,log_user,pass,address) values('$com_ids','$user','$mobile','$log_user','$pass','$address')");
				//$conn->query("insert into set_text(sms_text,com_id,is_active) values('Dear sir, your valuable dress has been completed to deliver. Thank you.','$top_id',1)");
				if($usersql){
					//$conn->query("insert into purchase_sms(com_id,purchase_sms_qty) values($top_id,'$sms_qty')");
					//$conn->query("insert into rem_sms(com_id,rem_sms) values('$top_id','$sms_qty')");
					$conn->query("insert into tag_tbl(com_id) values('$com_ids')");
					$conn->query("insert into order_num(com_id) values('$com_ids')");
					mysqli_close($conn);
					echo "Success!";
				}
				
			}
			}
			}
			?>
			</label>
            <!--<a href="#" class="pull-right">Forgot Password?</a>-->
        </div>        
    
	
	
   
</div>
