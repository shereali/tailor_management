<?php 
session_start();
ob_start();
ini_set('max_execution_time', 600); //300 seconds = 5
include'db.php';
include'library.php';
if(isset($_SESSION['USER']) && isset($_SESSION['COM'])){
	
  
  
	if(isset($_REQUEST['sms_id'])){
		$sms_id=$_REQUEST['sms_id'];
		$sqltext=$conn->query("select * from dsms where id=$sms_id and is_active=1");
		$trow=mysqli_fetch_array($sqltext);
		$stxt=$trow['txt_sms'];
		
		$sqlmobile=$conn->query("select * from dsms_mobile where sms_id=$sms_id");
		mysqli_close($conn);
		while($row=mysqli_fetch_array($sqlmobile)){
			$mobile[]=$row['umobile'];
		}
		
		echo implode(",",$mobile)."#sep#".$stxt;
		
	}
	
	if(isset($_REQUEST['combo'])){
		$com_id=$_SESSION['COM_ID'];
		$psmsquery=$conn->query("select * from dsms where is_active=1 and com_id='$com_id' order by id desc limit 0,5");
			echo '<option value="">Select One</option>';
					while($row=mysqli_fetch_array($psmsquery)){
				?>
				 <option value="<?php echo $row['id'] ?>"><?php echo $row['insert_date'] ?></option>
				<?php
			}	
			
		
	}
	
	if(isset($_REQUEST['page_btn'])){
		
		if($_REQUEST['page']=="set_sms"){
			

	$com_id=$_SESSION['COM_ID'];
	
	@$textsql=$conn->query("select * from set_text where com_id=$com_id order by id desc limit 0,15");
	mysqli_close($conn);
	echo "<h5>Set SMS Text(<b>$_SESSION[COM]</b>)</h5>";
?>


  <div class="panel-group">
   <div class="panel panel-info">
      <div class="panel-heading">Set Text For SMS</div>
      <div class="panel-body">
		
				
			<div class="form-group">
			  <label for="comment">Message(English/Bangla):</label>
			  <textarea class="form-control" rows="5" name="txt_sms" id="txt_sms" required></textarea>
			</div>
			
			<button onclick="setSms();" name="btn" value="sub" class="btn btn-success">Set</button>
			<span id="sms"></span><br/><br/>
			
			<div id="setpanel">
			<?php 
				$m=1;
				while($row=mysqli_fetch_array($textsql)){
					if($row['is_active']==1){
					?>
					<div class="panel panel-success">
					  <div class="panel-heading"><?php echo $m++; ?></div>
					  <div class="panel-body"><?php echo $row['sms_text']; ?></div>
					  
					   <a href="javascript:void(0)" style="margin:15px" class="btn btn-success">Active</a>
					  
					</div>
					<?php 
					}else{
						?>
						<div class="panel panel-warning">
						  <div class="panel-heading"><?php echo $m++; ?></div>
						  <div class="panel-body"><?php echo $row['sms_text']; ?></div>
						   <a href="javascript:void(0)" onclick="activeInactive('<?php echo $row['id']; ?>','1')" style="margin:15px" class="btn btn-warning">In Active</a>
						</div>
					<?php 
					}
				}
				?>
			</div>
	  </div>
    </div>

  </div>
  
  <script>
	

	
</script>
<?php 
		}else if($_REQUEST['page']=="history"){
			

		$com_id=$_SESSION['COM_ID'];
	
		$last_id=intval($_POST['last_id']);
		$date=date("Y-m-d");
		$count=$last_id+5;
		$i=$last_id+1;
	
	    $psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,ds.cus_mobile umobile,ds.phy_ord_num,ds.amount,ds.cus_name,ds.discount,ds.factory_status from dsms ds where ds.is_active=1 and ds.phy_dv_date IS NULL and ds.occasion=0 and ds.com_id='$com_id' order by ds.id desc limit $last_id,5");
		
			if(mysqli_num_rows($psmsquery)>0){
				while($row=mysqli_fetch_array($psmsquery)){
					$j=$i++;
					$sms_id=$row['id'];
					$sms_status=$row['sms_status'];
					$dv_date=explode("-",$row['dv_date']);
					$dv_date=$dv_date[2]."/".$dv_date[1]."/".$dv_date[0];
					@$txt_sms=$row['txt_sms'];
					@$tagnum=$row['tagnum'];
					@$order_type=$row['order_type'];
					
					@$amount=$row['amount'];
					@$discount=$row['discount'];
					
					@$umobile=$row['umobile']; //implode(",",$mobiles);
					$chk_com_p=$conn->query("SELECT (select product_name from product where id=sd.item_id) pname,sd.item_qty pqty,sd.order_number,sd.receive_qty FROM `order_record` sd WHERE sd.com_id=$com_id and sd.dsms_id=$sms_id");
					
					if($date==$row['indate']){
						echo "<div class='panel panel-info' style='margin-top:5px'>";
						
					}else{
						
						echo "<div class='panel panel-success' style='margin-top:5px'>";
					}
				if(mysqli_num_rows($chk_com_p)<=0){
					$conn->query("update dsms set is_active=0 where id=$sms_id");
				}
			?>
	
  
      <div class="panel-heading"><?php  echo $j.". (".date('d/m/Y',strtotime($row['indate'])).")"; if($sms_status==0) echo " pending"; else echo " sent"; ?></div>
	 
      <div class="panel-body">
			
			<div class="row">
			<div class="col-xs-12 col-sm-6">
				<p for="comment">Serial: <span style='cursor: pointer;color:red;font-weight:bold' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$row['phy_ord_num']; ?>')">
					<?php echo $row['phy_ord_num']; ?>
				</span></p>
				<label for="comment">Delivery Date:</label>
					<input type="text" style="font-weight: bold;font-size:18px;font-style: italic;color:green" name="date1" id="date1<?php echo $j; ?>" value="<?php echo $dv_date; ?>" class="form-control" data-select="date">
				<label for="comment">Customer Name: <span style="color:green"></span></label>
					<input type="text" class="form-control" value="<?php echo $row['cus_name']; ?>" style="font-weight: bold;font-size:18px;font-style: italic;color:green"  name="cus_name" id="cus_name<?php echo $j; ?>" />		
				<input type="hidden" class="form-control" name="sms_id" id="sms_id<?php echo $j; ?>" value="<?php echo $sms_id; ?>" />
				<input type="hidden"  name="org_dv_date" id="org_dv_date<?php echo $j; ?>" value="<?php echo $dv_date; ?>" />
				
				
				<label for="comment">Mobile Number:</label>
				<input type="text" class="form-control" value="<?php echo $umobile; ?>" maxlength="11" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;color:green" name="mobile" id="mobile<?php echo $j; ?>" />
				<p for="comment" style="color:blue">Production Receive: <b><?php echo ($row['factory_status']==1 || $row['factory_status']==2)? "Yes" : "No"; ?></b></p>
			</div>
			<div class="col-xs-12 col-sm-6">
				<span for="">Dress Details:</span>
				<table id="example" class="table table-striped table-bordered">
				
					<thead>
						<tr>
							<th>SL</th>
							<th>Dress/Order Number</th>
							<th>Qty</th>
						</tr>
					</thead>
					<tbody>
					<?php 
					$jj=1;
					while($rrows=mysqli_fetch_array($chk_com_p)){
						$pname=$rrows['pname'];
						$pqty=$rrows['pqty'];
						$order_number=$rrows['order_number'];
						$receive_qty=$rrows['receive_qty'];
						if($receive_qty<$pqty){
							$rd="<span id='dqty$jj$j'>($receive_qty)</span>";
						}else{
							$rd="<span style='color:blue' id='dqty$jj$j'>($receive_qty)</span>";
						}
						?>
						<tr>
							<td>
								<b><?php echo $jj++; ?></b>
							</td>
							<td><b>
								<?php echo $pname." ".$rd; ?>
							</b>
							</td>
							<td><b>
								<?php echo $pqty; ?>
							</b>
							</td>
						
						</tr>
						<?php  
					}
					
					?>
					</tbody>
				</table>
				<button onclick="updateOrder('<?php echo $j; ?>');" name="btn" value="sub" id="updatebtn<?php echo $j; ?>" class="btn btn-success">Update</button>
				<span id="sms<?php echo $j; ?>"></span>
			</div>
		</div>
	  </div>
	 
    </div>
	
	
	
 <?php
 
 } 
 ?>
  <script type="text/javascript" src="cal/js/apiajax.js"></script>
	
	<script type="text/javascript" src="cal/js/mousewheel.js"></script>
	<script type="text/javascript" src="cal/js/jquery.dateselect.js"></script> 
 <?php 
 mysqli_close($conn);
		}else{
			echo 2;
		}
	}else if($_REQUEST['page']=="more_urgent"){
		$com_id=$_SESSION['COM_ID'];
	
		$last_id=intval($_POST['last_id']);
		$date=date("Y-m-d");
		$i=$last_id+1;
	
	    $psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,ds.cus_mobile umobile,ds.phy_ord_num,ds.amount,ds.cus_name,ds.factory_status,ds.fddate from dsms ds where ds.is_active=1 and ds.phy_dv_date IS NULL and ds.occasion=0 and ds.order_type=1 and ds.factory_status not in(1,2) and ds.com_id='$com_id' order by ds.id asc limit $last_id,10");
		
			if(mysqli_num_rows($psmsquery)>0){
				while($row=mysqli_fetch_array($psmsquery)){
					$j=$i++;
					$sms_id=$row['id'];
					$sms_status=$row['sms_status'];
					$dv_date=explode("-",$row['dv_date']);
					$dv_date=$dv_date[2]."/".$dv_date[1]."/".$dv_date[0];
					$dv_date=$row['fddate'];
					@$txt_sms=$row['txt_sms'];
					@$tagnum=$row['tagnum'];
					@$order_type=$row['order_type'];
					@$phy_ord_num=$row['phy_ord_num'];
					
					@$amount=$row['amount'];
					
					@$umobile=$row['umobile']; //implode(",",$mobiles);
					$chk_com_p=$conn->query("SELECT (select product_name from product where id=sd.item_id) pname,sd.item_qty pqty,sd.order_number FROM `order_record` sd WHERE sd.com_id=$com_id and sd.dsms_id=$sms_id");
					
					
			?>
	<div class='panel panel-info'>
  
      <div class="panel-heading"><?php  echo $j.". (".date('d/m/Y',strtotime($row['indate'])).")"; if($sms_status==0) echo " pending"; else echo " sent"; ?></div>
	 
      <div class="panel-body">
			
			<div class="row">
			<div class="col-xs-12 col-sm-6">
				<p for="comment">Serial: <span style='cursor: pointer;color:red;font-weight:bold' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$row['phy_ord_num']; ?>')">
					<?php echo $row['phy_ord_num']; ?>
				</span></p>
				 <p for="comment">Customer Name: <b><?php echo $row['cus_name']; ?></b></p>
				 <p for="comment">Mobile Number: <b><?php echo $umobile; ?></b></p>
				<p for="comment" style="color:blue">Production Receive: <b><?php echo ($row['factory_status']==1 || $row['factory_status']==2)? "Yes" : "No"; ?></b></p>
				<p for="comment">Factory Delivery Date:</p>
					<input type="text" style="font-weight: bold;font-size:18px;font-style: italic;" name="date1" id="date1<?php echo $j; ?>" value="<?php echo $dv_date; ?>" class="form-control" data-select="date">
				<input type="hidden"  name="sms_id" id="sms_id<?php echo $j; ?>" value="<?php echo $sms_id; ?>" />
				<input type="hidden"  name="org_dv_date" id="org_dv_date<?php echo $j; ?>" value="<?php echo $dv_date; ?>" />
				<input type="hidden"  name="cus_name" id="cus_name<?php echo $j; ?>" value="<?php echo $row['cus_name']; ?>" />
				<input type="hidden" name="mobile"  id="mobile<?php echo $j; ?>" value="<?php echo $umobile; ?>" />
				
			</div>
			<div class="col-xs-12 col-sm-6">
				<span for="">Dress Details:</span>
				<table id="example" class="table table-striped table-bordered">
				
					<thead>
						<tr>
							<th>SL</th>
							<th>Dress/Order Number</th>
							<th>Qty</th>
						</tr>
					</thead>
					<tbody>
					<?php 
					$jj=1;
					while($rrows=mysqli_fetch_array($chk_com_p)){
						$pname=$rrows['pname'];
						$pqty=$rrows['pqty'];
						$order_number=$rrows['order_number'];
						?>
						<tr>
							<td>
								<b><?php echo $jj++; ?></b>
							</td>
							<td><b>
								<?php echo $pname; ?>(<?php echo $order_number; ?>)
							</b>
							</td>
							<td><b>
								<?php echo $pqty; ?>
							</b>
							</td>
						
						</tr>
						<?php  
					}
					
					?>
					</tbody>
				</table>
				<!--<button onclick="sendUrgent('<?php echo $j; ?>');" name="btn" value="sub" id="urg_btn<?php echo $j; ?>" class="btn btn-success">Update</button>-->
				<span id="urgsms<?php echo $j; ?>"></span>
			</div>
		</div>
	  </div>
	 
    </div>
	
	
	
 <?php
 
 } 
 ?>
 
  <script type="text/javascript" src="cal/js/apiajax.js"></script>
	
	<script type="text/javascript" src="cal/js/mousewheel.js"></script>
	<script type="text/javascript" src="cal/js/jquery.dateselect.js"></script> 
 <?php 
 mysqli_close($conn);
		}else{
			echo 2;
		}
	}else if($_REQUEST['page']=="more_today"){
		$com_id=$_SESSION['COM_ID'];
	
		$last_id=intval($_POST['last_id']);
		$i=$last_id+1;
	
	    $com_id=$_SESSION['COM_ID'];
		@$dv_date =date('Y-m-d'); // and ds.sms_status=0
		@$dv_date =date('d/m/Y'); // and ds.sms_status=0
		$psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,ds.cus_mobile umobile,ds.phy_dv_date,ds.phy_ord_num,ds.amount,ds.cus_name,ds.discount,ds.factory_status,ds.fddate from dsms ds where ds.is_active=1 and ds.occasion=0 and ds.factory_status not in(1,2) and ds.com_id='$com_id' and ds.fddate='$dv_date' and ds.phy_dv_date IS NULL order by ds.id asc limit $last_id,10");
		
		if(mysqli_num_rows($psmsquery)>0){
		?>
		<div class="panel-group">
 
   <?php 
		
				while($row=mysqli_fetch_array($psmsquery)){
					$j=$i++;
					$sms_id=$row['id'];
					$sms_status=$row['sms_status'];
					$dv_date=explode("-",$row['dv_date']);
					$dv_date=$dv_date[2]."/".$dv_date[1]."/".$dv_date[0];
					$dv_date=$row['fddate'];
					@$txt_sms=$row['txt_sms'];
					@$tagnum=$row['tagnum'];
					@$phy_ord_num=$row['phy_ord_num'];
					
					@$umobile=$row['umobile'];
					
				
				
			?>
	
   <div class='panel panel-info'>
      <div class="panel-heading"><?php  echo $j.". (".date('d/m/Y',strtotime($row['indate'])).")"; if($sms_status==0) echo " pending "; else echo " sent "; ?></div>
	 
      <div class="panel-body">
			
			<div class="row">
			<div class="col-xs-12 col-sm-6">
				<p for="comment">Serial: <span style='cursor: pointer;color:red;font-weight:bold' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$row['phy_ord_num']; ?>')">
					<?php echo $row['phy_ord_num']; ?>
				</span></p>
				<p for="comment">Customer Name: <b><?php echo $row['cus_name']; ?></b></p>
				<p for="comment">Mobile Number: <b><?php echo $umobile; ?></b></p>
				<p for="comment" style="color:blue">Production Receive: <b><?php echo ($row['factory_status']==1 || $row['factory_status']==2)? "Yes" : "No"; ?></b></p>
				<p for="comment">Factory Delivery Date: <b><?php echo $dv_date; ?></b></p>
				<input type="hidden" class="form-control" name="txt_sms" id="txt_sms<?php echo $j; ?>" />
				<input type="hidden" class="form-control" name="sms_id" id="sms_id<?php echo $j; ?>" value="<?php echo $sms_id; ?>" />
			
			
			
			<!----------------------------------------->
			<?php
			
			$total_tk=$row['amount'];
			$discount=$row['discount'];
			$total_tk1=intval($total_tk)-((intval($total_tk)*intval($row['discount']))/100);
			$chk_com_p=$conn->query("SELECT (select product_name from product where id=sd.item_id) pname,sd.item_qty pqty,sd.order_number,sd.id ord_id,sd.receive_qty FROM `order_record` sd WHERE sd.com_id=$com_id and sd.dsms_id=$sms_id");
			$payment_detail=$conn->query("SELECT * FROM `accounting` WHERE `com_id`=$com_id and is_active=1 and `dsms_id`=$sms_id");
			
			$ptbl='<table id="example" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>SL</th>
						<th>Dres/Order Number</th>
						<th>Qty</th>
					</tr>
				</thead>
				<tbody>';
				$ptbl2="";	
				$m=1;
				while($rrows=mysqli_fetch_array($chk_com_p)){
					$n=$m++;
					$pname=$rrows['pname'];
					$pqty=$rrows['pqty'];
					$order_number=$rrows['order_number'];
					$receive_qty=$rrows['receive_qty'];
					if($receive_qty<$pqty){
						$rd="<span id='dqty$n$j'>($receive_qty)</span>";
					}else{
						$rd="<span style='color:blue' id='dqty$n$j'>($receive_qty)</span>";
					}
					$ptbl2.="<tr>
						<td>
							<b>$n</b>
						</td>
						<td><b>
							$pname $rd
						</b>
						</td>
						<td><b>
							$pqty
						</b>
						</td>
					
					</tr>";
				}
				
					
				$ptbl3='</tbody>
				</table>';
			$ptblf=$ptbl.$ptbl2.$ptbl3;
			
			$payspan="<span id='payment_tbl$j'>";
			$paytbl='<table id="example" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>Description</th>
						<th style="text-align:right">Taka</th>
					</tr>
				</thead>
				<tbody id="payable">';
				@$paytblhead.="<tr>
						<td>
							<b>Total</b>
						</td>
						<td><b>
							<input style='text-align:right;border: 1px solid #F9F9F9;background: #F9F9F9;width:100%' type='text' readonly value='$total_tk'/>
						</b>
						</td>
						</tr><tr><td>
							<b>Discount(%)</b>
						</td><td style='text-align:right'>$discount</td></tr>";
				$paytbl2="";	
				$sum=0;
				while($payrows=mysqli_fetch_array($payment_detail)){
					$due_tk=$payrows['amount'];
					$accounting_tbl_id=$payrows['id'];
					$sum+=intval($due_tk);
					if(isset($row['phy_dv_date'])){
						$del="";
						$paid="(<span style='color:blue'>Paid</span>)";
					}else{
						$del="(<a href='javascript:void(0)' onclick='delPay($accounting_tbl_id,$j);'>Del</a>)";
						$paid="";
					}
					if($payrows['pay_status']==1){
						$paytbl2.="<tr>
						<td>
							Advance $del
						</td>
						<td style='text-align:right'>
							$due_tk
						</td>
						</tr>";
					}else{
						$paytbl2.="<tr>
						<td>
							Pay $del
						</td>
						<td style='text-align:right'>
							$due_tk
						</td>
						</tr>";
					}
				
				}
				$due=intval($total_tk1)-$sum;
				@$paytbldue.="<input type='hidden' value='$due' id='hide_due$j'/><tr>
						<td>
							<b>Due $paid</b>
						</td>
						<td style='text-align:right'><b>
							$due
						</b>
						</td>
						</tr>";
				if($due!=0){
					if(isset($row['phy_dv_date'])){
						@$paytblpay.="<input type='hidden' value='$sms_id' id='dsms_ids$j'/>
						<input type='hidden' value='$total_tk' id='total_tk$j'/>
						<span id='stksms$j'></span>";
					}else{ //<button onclick='payTk($j);' name='btn' id='paybtns$j' value='sub' class='btn btn-success'>Pay</button>
				@$paytblpay.="<tr>
						<td>
							---
						</td>
						<td>
						<input style='text-align:right;width:100%' type='text' id='paytxt$j'/>
						<input type='hidden' value='$sms_id' id='dsms_ids$j'/>
						<input type='hidden' value='$total_tk' id='total_tk$j'/>
						<span id='stksms$j'></span>
						</td>
						</tr>";
					}
				}else{
					$paytblpay="<input type='hidden' value='$total_tk' id='total_tk$j'/><input type='hidden' value='$sms_id' id='dsms_ids$j'/>";
				}
					
				$paytbl3='</tbody>
					</table>';
				$payspan_end="</span>";
				echo "<input type='hidden' id='discount$j' value='$discount' />
				<input type='hidden' id='discount_tot$j' value='$total_tk1' /><hr/>";
			$paytblf=$payspan.$paytbl.$paytblhead.$paytbl2.$paytbldue.$paytblpay.$paytbl3.$payspan_end;
			
			?>
				
				
					<span for="">Dress Details:</span>
					<span id="pdetail">
					 <?php echo $ptblf; ?>
					</span>
				</div>
			<div class="col-xs-12 col-sm-6">
					<span for="">Payment Details:</span>
					<span id="paydetail">
						<?php echo $paytblf; ?>
					</span>
			
			<!----------------------------------------->
				<!--<button onclick="orderDeliveryBtn(<?php echo $j; ?>);" name="btn" id="order_delivery<?php echo $j; ?>" value="sub" class="btn btn-warning">Delivery</button>&nbsp;&nbsp;-->
				<span id="order_delivery_sms<?php echo $j; ?>"></span>
				<input type="hidden" id="hide_sms_id<?php echo $j; ?>" value="<?php echo $row['id']; ?>" />
			</div>
		</div>
	  </div>
	 
    </div>
	
 <?php 
 $paytblf=$payspan=$paytbl=$paytblhead=$paytbl2=$paytbldue=$paytblpay=$paytbl3=$payspan_end="";
			$ptblf=$ptbl=$ptbl2=$ptbl3="";
		echo "<hr/>";	
 }
 ?>
 </div>

	
 <?php 
 mysqli_close($conn);
		}else{
			echo 2;
		}
	}else if($_REQUEST['page']=="more_tomorrow"){
		
		$last_id=intval($_POST['last_id']);
		$i=$last_id+1;
		$com_id=$_SESSION['COM_ID'];
		@$dv_date =date('d/m/Y', strtotime(date('Y-m-d'). ' + 1 days'));
		$psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,ds.cus_mobile umobile,ds.phy_ord_num,ds.cus_name,ds.factory_status,ds.fddate from dsms ds where ds.is_active=1 and ds.occasion=0 and ds.factory_status not in(1,2) and ds.com_id='$com_id' and ds.fddate='$dv_date' and ds.phy_dv_date IS NULL order by ds.id asc limit $last_id,10");
		
		if(mysqli_num_rows($psmsquery)>0){
		?>
		
		<div class="panel-group">
 
   <?php 
		
				while($row=mysqli_fetch_array($psmsquery)){
					$j=$i++;
					$sms_id=$row['id'];
					$sms_status=$row['sms_status'];
					$dv_date=explode("-",$row['dv_date']);
					$dv_date=$dv_date[2]."/".$dv_date[1]."/".$dv_date[0];
					$dv_date=$row['fddate'];
					@$txt_sms=$row['txt_sms'];
					@$tagnum=$row['tagnum'];
					@$phy_ord_num=$row['phy_ord_num'];
					
					@$umobile=$row['umobile'];
					$chk_com_p=$conn->query("SELECT (select product_name from product where id=sd.item_id) pname,sd.item_qty pqty,sd.order_number,sd.receive_qty FROM `order_record` sd WHERE sd.com_id=$com_id and sd.dsms_id=$sms_id");
				
				
			?>
	
   <div class='panel panel-info'>
      <div class="panel-heading"><?php  echo $j.". (".date('d/m/Y',strtotime($row['indate'])).")"; if($sms_status==0) echo " pending "; else echo " sent "; ?></div>
	 
      <div class="panel-body">
			
			<div class="row">
			<div class="col-xs-12 col-sm-6">
				<p for="comment">Serial: <span style='cursor: pointer;color:red;font-weight:bold' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$row['phy_ord_num']; ?>')">
					<?php echo $row['phy_ord_num']; ?>
				</span></p>
				<p for="comment">Customer Name: <b><?php echo $row['cus_name']; ?></b></p>
				<p for="comment">Mobile Number: <b><?php echo $umobile; ?></b></p>
				<p for="comment" style="color:blue">Production Receive: <b><?php echo ($row['factory_status']==1 || $row['factory_status']==2)? "Yes" : "No"; ?></b></p>
				<p for="comment">Factory Delivery Date: <span > <b><?php echo $dv_date; ?></b></span></p>
				<input type="hidden" style="font-weight: bold;font-size:18px;font-style: italic;" name="date1" id="date2<?php echo $j; ?>" value="<?php echo $dv_date; ?>" class="form-control" data-select="date">
				<input type="hidden" style="" name="date1" id="date_org<?php echo $j; ?>" value="<?php echo @$dv_date; ?>" />
				<input type="hidden" style="" name="mobile" id="mobilet<?php echo $j; ?>" value="<?php echo @$umobile; ?>" />
				
			</div>
			<div class="col-xs-12 col-sm-6">
			<span for="">Dress Details:</span>
			<table id="example" class="table table-striped table-bordered">
			
				<thead>
					<tr>
						<th>SL</th>
						<th>Dress/Order Number</th>
						<th>Qty</th>
					</tr>
				</thead>
				<tbody>
				<?php 
				$jj=1;
				while($rrows=mysqli_fetch_array($chk_com_p)){
					$m=$jj++;
					$pname=$rrows['pname'];
					$pqty=$rrows['pqty'];
					$order_number=$rrows['order_number'];
					$receive_qty=$rrows['receive_qty'];
					if($receive_qty<$pqty){
						$rd="<span id='dqty$m$j'>($receive_qty)</span>";
					}else{
						$rd="<span style='color:blue' id='dqty$m$j'>($receive_qty)</span>";
					}
					?>
					<tr>
						<td>
							<b><?php echo $m; ?></b>
						</td>
						<td><b>
							<?php echo $pname; ?>(<?php echo $order_number; ?>)
						</b>
						</td>
						<td><b>
							<?php echo $pqty; ?>
						</b>
						</td>
					
					</tr>
					<?php  
				}
				
				?>
				</tbody>
			</table>
			
			<!--<button onclick="onlyDateUpdateBtn(<?php echo $j; ?>);" name="btn" id="only_dateupdate<?php echo $j; ?>" value="sub" class="btn btn-success">Update</button>&nbsp;&nbsp;-->
				<span id="only_date_update_sms<?php echo $j; ?>"></span>
				<input type="hidden" id="hide_sms_ids<?php echo $j; ?>" value="<?php echo $row['id']; ?>" />
			</div>
		</div>
	  </div>
	 
    </div>
	
 <?php } ?>
 </div>
<script type="text/javascript" src="cal/js/apiajax.js"></script>
	<script type="text/javascript" src="cal/js/mousewheel.js"></script>
	<script type="text/javascript" src="cal/js/jquery.dateselect.js"></script> 
 <?php 
 mysqli_close($conn);
		}else{
			echo 2;
		}
		
	}else if($_REQUEST['page']=="more_expired"){
		
		$last_id=intval($_POST['last_id']);
		$i=$last_id+1;
		$com_id=$_SESSION['COM_ID'];
		@$dv_date =date('d/m/Y');
		$psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,ds.cus_mobile umobile,ds.phy_ord_num,ds.cus_name,ds.factory_status,ds.fddate from dsms ds where ds.is_active=1 and ds.occasion=0 and ds.com_id='$com_id' and str_to_date(ds.fddate,'%d/%m/%Y') <= str_to_date('$dv_date','%d/%m/%Y') and ds.factory_status not in(1,2) and ds.phy_dv_date IS NULL order by ds.id asc limit $last_id,10");
		
		if(mysqli_num_rows($psmsquery)>0){
		?>
		
		<div class="panel-group">
 
   <?php 
		
				while($row=mysqli_fetch_array($psmsquery)){
					$j=$i++;
					$sms_id=$row['id'];
					$sms_status=$row['sms_status'];
					$dv_date=explode("-",$row['dv_date']);
					$dv_date=$dv_date[2]."/".$dv_date[1]."/".$dv_date[0];
					@$txt_sms=$row['txt_sms'];
					@$tagnum=$row['tagnum'];
					@$phy_ord_num=$row['phy_ord_num'];
					
					@$umobile=$row['umobile'];
					//$chk_com_p=$conn->query("SELECT (select product_name from product where id=sd.item_id) pname,sd.item_qty pqty,sd.order_number,sd.receive_qty FROM `order_record` sd WHERE sd.com_id=$com_id and sd.dsms_id=$sms_id");
				$chk_com_p=$conn->query("SELECT (select product_name from product where id=sd.item_id) pname,sd.item_qty pqty,sd.order_number,sd.id ord_id,sd.receive_qty FROM `order_record` sd WHERE sd.com_id=$com_id and sd.is_active=1 and sd.dsms_id=$sms_id");
				if(mysqli_num_rows($chk_com_p)<=0){
					$conn->query("update dsms set is_active=0 where id=$sms_id");
				}
				
			?>
	
   <div class='panel panel-info'>
      <div class="panel-heading"><?php  echo $j.". (".date('d/m/Y',strtotime($row['indate'])).")"; if($sms_status==0) echo " pending "; else echo " sent "; ?></div>
	 
      <div class="panel-body">
			
			<div class="row">
			<div class="col-xs-12 col-sm-6">
				<p for="comment">Serial: <span style='cursor: pointer;color:red;font-weight:bold' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$row['phy_ord_num']; ?>')">
					<?php echo $row['phy_ord_num']; ?>
				</span></p>
				<p for="comment">Customer Name: <b><?php echo $row['cus_name']; ?></b></p>
				<p for="comment">Mobile Number: <b><?php echo $umobile; ?></b></p>
				<p for="comment" style="color:blue">Production Receive: <b><?php echo ($row['factory_status']==1 || $row['factory_status']==2)? "Yes" : "No"; ?></b></p>
				<p for="comment" style="">Factory Delivery Date: <b><?php echo $row['fddate']; ?></b></p>
				<p for="comment">Delivery Date: <span > <b><?php echo $dv_date; ?></b></span></p>
				<input type="hidden" style="font-weight: bold;font-size:18px;font-style: italic;" name="date1" id="date2<?php echo $j; ?>" value="<?php echo $dv_date; ?>" class="form-control" data-select="date">
				<input type="hidden" style="" name="date1" id="date_org<?php echo $j; ?>" value="<?php echo @$dv_date; ?>" />
				<input type="hidden" style="" name="mobile" id="mobilet<?php echo $j; ?>" value="<?php echo @$umobile; ?>" />
				
			</div>
			<div class="col-xs-12 col-sm-6">
			<span for="">Dress Details:</span>
			<table id="example" class="table table-striped table-bordered">
			
				<thead>
					<tr>
						<th>SL</th>
						<th>Dress/Order Number</th>
						<th>Qty</th>
					</tr>
				</thead>
				<tbody>
				<?php 
				$jj=1;
				while($rrows=mysqli_fetch_array($chk_com_p)){
					$m=$jj++;
					$pname=$rrows['pname'];
					$pqty=$rrows['pqty'];
					$order_number=$rrows['order_number'];
					$receive_qty=$rrows['receive_qty'];
					if($receive_qty<$pqty){
						$rd="<span id='dqty$m$j'>($receive_qty)</span>";
					}else{
						$rd="<span style='color:blue' id='dqty$m$j'>($receive_qty)</span>";
					}
					?>
					<tr>
						<td>
							<b><?php echo $m; ?></b>
						</td>
						<td><b>
							<?php echo $pname; ?><?php echo $rd; ?>
						</b>
						</td>
						<td><b>
							<?php echo $pqty; ?>
						</b>
						</td>
					
					</tr>
					<?php  
				}
				
				?>
				</tbody>
			</table>
			
			<!--<button onclick="onlyDateUpdateBtn(<?php echo $j; ?>);" name="btn" id="only_dateupdate<?php echo $j; ?>" value="sub" class="btn btn-success">Update</button>-->&nbsp;&nbsp;
				<span id="only_date_update_sms<?php echo $j; ?>"></span>
				<input type="hidden" id="hide_sms_ids<?php echo $j; ?>" value="<?php echo $row['id']; ?>" />
			</div>
		</div>
	  </div>
	 
    </div>
	
 <?php } ?>
 </div>
<script type="text/javascript" src="cal/js/apiajax.js"></script>
	<script type="text/javascript" src="cal/js/mousewheel.js"></script>
	<script type="text/javascript" src="cal/js/jquery.dateselect.js"></script> 
 <?php 
 mysqli_close($conn);
		}else{
			echo 2;
		}
		
	}else if($_REQUEST['page']=="more_n3d"){

		$last_id=intval($_POST['last_id']);
		$i=$last_id+1;
		$com_id=$_SESSION['COM_ID'];
		@$dv_date =date('d/m/Y', strtotime(date('Y-m-d'). ' + 2 days'));
		$psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,ds.cus_mobile umobile,ds.phy_ord_num,ds.cus_name,ds.factory_status,ds.fddate from dsms ds where ds.is_active=1 and ds.occasion=0 and ds.factory_status not in(1,2) and ds.com_id='$com_id' and ds.fddate='$dv_date' and ds.phy_dv_date IS NULL order by ds.id asc limit $last_id,10");
		
		if(mysqli_num_rows($psmsquery)>0){
		?>
		
		<div class="panel-group">
 
   <?php 
		
				while($row=mysqli_fetch_array($psmsquery)){
					$j=$i++;
					$sms_id=$row['id'];
					$sms_status=$row['sms_status'];
					$dv_date=explode("-",$row['dv_date']);
					$dv_date=$dv_date[2]."/".$dv_date[1]."/".$dv_date[0];
					$dv_date=$row['fddate'];
					@$txt_sms=$row['txt_sms'];
					@$tagnum=$row['tagnum'];
					@$phy_ord_num=$row['phy_ord_num'];
					
					@$umobile=$row['umobile'];
					
				$chk_com_p=$conn->query("SELECT (select product_name from product where id=sd.item_id) pname,sd.item_qty pqty,sd.receive_qty,sd.order_number FROM `order_record` sd WHERE sd.com_id=$com_id and sd.dsms_id=$sms_id");
				
			?>
	
   <div class='panel panel-info'>
      <div class="panel-heading"><?php  echo $j.". (".date('d/m/Y',strtotime($row['indate'])).")"; if($sms_status==0) echo " pending "; else echo " sent "; ?></div>
	 
      <div class="panel-body">
			<div class="row">
			<div class="col-xs-12 col-sm-6">
				<p for="comment">Serial: <span style='cursor: pointer;color:red;font-weight:bold' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$row['phy_ord_num']; ?>')">
					<?php echo $row['phy_ord_num']; ?>
				</span></p>
				<p for="comment">Customer Name: <b><?php echo $row['cus_name']; ?></b></p>
				<p for="comment">Mobile Number: <b><?php echo $umobile; ?></b></p>
				<p for="comment" style="color:blue">Production Receive: <b><?php echo ($row['factory_status']==1 || $row['factory_status']==2)? "Yes" : "No"; ?></b></p>
				<p for="comment">Factory Delivery Date: <b><?php echo $dv_date; ?></b></p>
			</div>
			<div class="col-xs-12 col-sm-6">
			<span for="">Dress Details:</span>
			<table id="example" class="table table-striped table-bordered">
			
				<thead>
					<tr>
						<th>SL</th>
						<th>Dress/Order Number</th>
						<th>Qty</th>
					</tr>
				</thead>
				<tbody>
				<?php 
				$jj=1;
				while($rrows=mysqli_fetch_array($chk_com_p)){
					$pname=$rrows['pname'];
					$pqty=$rrows['pqty'];
					$order_number=$rrows['order_number'];
					$receive_qty=$rrows['receive_qty'];
					if($receive_qty<$pqty){
						$rd="<span id='dqty'>($receive_qty)</span>";
					}else{
						$rd="<span style='color:blue' id='dqty'>($receive_qty)</span>";
					}
					?>
					<tr>
						<td>
							<b><?php echo $jj++; ?></b>
						</td>
						<td><b>
							<?php echo $pname." ".$rd; ?>
						</b>
						</td>
						<td><b>
							<?php echo $pqty; ?>
						</b>
						</td>
					
					</tr>
					<?php  
				}
				
				?>
				</tbody>
			</table>
			</div>
		</div>
		
	  </div>
	 
    </div>
	
 <?php } ?>
 </div>


 <?php 
 mysqli_close($conn);
		}else{
			echo 2;
		}
	}
	}
	
	if(isset($_REQUEST['more_srch'])){
		
		$mobile=trim($_REQUEST['mobile']);
		$com_id=($_SESSION['COM_ID']);
		
		$last_id=intval($_POST['last_id']);
		$date=date("Y-m-d");
			$chk_com=$conn->query("select DISTINCT(ds.id),date(ds.insert_date) order_date,ds.sms_status,ds.order_type,ds.dv_date,ds.sent_time,ds.tagnum,ds.phy_dv_date,ds.phy_ord_num,ds.amount,ds.cus_name,ds.cus_mobile,ds.discount,ds.factory_status,ds.factory_receive_date,ds.box_number from dsms ds,order_record ord where ds.id=ord.dsms_id and ds.is_active=1 and ds.occasion=0 and ord.com_id=$com_id and (ord.order_number='$mobile' or ds.cus_mobile='$mobile' or ds.phy_ord_num='$mobile') and ord.is_active=1 order by ds.id desc limit $last_id,3");
		
		if(mysqli_num_rows($chk_com)>0){
			$si=$last_id+1;
			while($rrow=mysqli_fetch_array($chk_com)){
			$s=$si++;
			$sid=$rrow['id'];
			$total_tk=$rrow['amount'];
			$discount=$rrow['discount'];
			$box_number=$rrow['box_number'];
			$phy_ord_num=$rrow['phy_ord_num'];
			if($discount>0){
				$total_tk=round(($total_tk+$discount));
			}
			$total_tk1=intval($total_tk-$discount);
			$chk_com_p=$conn->query("SELECT (select product_name from product where id=sd.item_id) pname,sd.item_qty pqty,sd.order_number,sd.receive_qty,sd.id ord_id,sd.delivery_qty,sd.master_cutting_qty FROM `order_record` sd WHERE sd.com_id=$com_id and sd.is_active=1 and sd.dsms_id=$sid");
			$payment_detail=$conn->query("SELECT * FROM `accounting` WHERE `com_id`=$com_id and is_active=1 and `dsms_id`=$sid");
			$fab_taka_sql=$conn->query("SELECT f_total,total_receive FROM direct_sale_head dsh,`direct_sale` ds WHERE dsh.id=ds.`dstid` and ds.`order_number`='$phy_ord_num'");
			if(mysqli_num_rows($fab_taka_sql)>0){
			$fab_taka_row=mysqli_fetch_array($fab_taka_sql);
			$f_total_taka=$fab_taka_row['f_total'];
			}else{
				$f_total_taka=0;
			}
			echo "<div class='row'><div class='col-xs-12 col-sm-12'>";
			$ptbl='<table id="example" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>SL</th>
						<th>Dress/Order Number</th>
						<th>Qty</th>
					</tr>
				</thead>
				<tbody>';
				$ptbl2="";	
				$i=1;
				//$all_measurement=array();
				while($rrows=mysqli_fetch_array($chk_com_p)){
					$j=$i++;
					$code_no=$rrows['ord_id'];
					$pname=$rrows['pname'];
					$pqty=$rrows['pqty'];
					$order_number=$rrows['order_number']."#sep#".$rrows['ord_id']."#sep#".$s;
					$receive_qty=$rrows['receive_qty'];
					$delivery_qty=$rrows['delivery_qty'];
					$master_cutting_qty=$rrows['master_cutting_qty'];
					
					if($master_cutting_qty<$pqty){
						$cutting="<input type='number' style='width:45px;text-align:center' id='cdressQtys$j$s'/>
							<input type='hidden' value='$order_number' id='chidebtn$j$s'/>
							<button style='background: #0000ff42;color: #000000c4;' onclick='recCuttingBtn($j$s);' name='btn' id='dressCuttingBtn$j$s' value='sub'>Cutting Done</button>
							<span style='color:#0000ff' id='cqty$j$s'>($master_cutting_qty)</span>";
					}else{
						$cutting="<span style='color:#0000ff' id='cqty$j$s'>($master_cutting_qty)</span>";
					}
					
					if($receive_qty<$pqty){
						$rd="<input type='number' style='width:45px;text-align:center' id='dressQtys$j$s'/>
							<input type='hidden' value='$order_number' id='hidebtn$j$s'/>
							<button style='background: #0e9a8421;color: #000000bd;' onclick='recDressBtn($j$s);' name='btn' id='dressReceiveBtn$j$s' value='sub'>Making Done</button>
							<span style='color:#0e9a84' id='dqty$j$s'>($receive_qty)</span>";
					}else{
						$rd="<span style='color:#0e9a84' id='dqty$j$s'>($receive_qty)</span>";
					}
					
					if($delivery_qty<$pqty){
						$pdelivery="<input type='hidden' value='$order_number' id='pdelivery$j$s'/>
							<input type='number' style='width:45px;text-align:center' id='pdeliveryQtys$j$s'/>
							<button style='background: #c041f559;color: #000000c2;' onclick='pdeliveryBtn($j$s);' name='btn' id='pdeliveryBtn$j$s' value='sub'>Delivery</button>
							<span style='color:#c041f5' id='ddqty$j$s'>($delivery_qty)</span>";
					}else{
						$pdelivery="<span style='color:#c041f5' id='ddqty$j$s'>($delivery_qty)</span>";
					}
					
					//$all_measurement[]=$rrows['order_number'];
					$ptbl2.="<tr>
						<td>
							<b>$j</b>
						</td>
						<td><b style='font-size: 12px;'>
							[$code_no] $pname $cutting | $rd | $pdelivery
						</b>
						</td>
						<td><b>
							$pqty
						</b>
						</td>
					
					</tr>";
				}
				
				//$all_measurement=implode(",",$all_measurement);		
				$ptbl3="<input type='hidden' id='totid$s' value='$j'/></tbody>
				</table>";
			$ptblf=$ptbl.$ptbl2.$ptbl3;
			
			$payspan="<span id='payment_tbl$s'>";
			$paytbl='<table id="example" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>Description</th>
						<th style="text-align:right;width: 32%;">Taka</th>
					</tr>
				</thead>
				<tbody id="payable">';
				@$paytblhead.="<tr>
						<td>
							<b>Total</b>
						</td>
						<td><b>
							<input style='text-align:right;border: 1px solid #F9F9F9;background: #F9F9F9;width: 100%' type='text' readonly value='$total_tk'/>
						</b>
						</td>
						</tr><tr><td>
							<b>Discount(%)</b>
						</td><td style='text-align:right'>$discount</td></tr>";
				$paytbl2="";	
				$i=1;$sum=0;
				while($payrows=mysqli_fetch_array($payment_detail)){
					$due_tk=$payrows['amount'];
					$accounting_tbl_id=$payrows['id'];
					$sum+=intval($due_tk);
					if(isset($rrow['phy_dv_date'])){
						$del="";
						$paid="(<span style='color:blue'>Paid</span>)";
					}else{
						$del="(<a href='javascript:void(0)' onclick='delPay($accounting_tbl_id,$s);'>Del</a>)";
						$paid="";
					}
					if($payrows['pay_status']==1){
						$paytbl2.="<tr>
						<td>
							Advance $del
						</td>
						<td style='text-align:right'>
							$due_tk
						</td>
						</tr>";
					}else{
						$paytbl2.="<tr>
						<td>
							Pay $del
						</td>
						<td style='text-align:right'>
							$due_tk
						</td>
						</tr>";
					}
				
				}
				$due=intval($total_tk1)-$sum;
				@$paytbldue.="<input type='hidden' value='$due' id='hide_due$s'/><tr>
						<td>
							<b>Due $paid</b>
						</td>
						<td style='text-align:right'><b>
							$due
						</b>
						</td>
						</tr>";
				if($due!=0){
					if(isset($rrow['phy_dv_date'])){
						@$paytblpay.="<input type='hidden' value='$sid' id='dsms_ids$s'/>
						<input type='hidden' value='$total_tk' id='total_tk$s'/>
						<span id='stksms$s'></span><tr>
						<td style='color:red'>
							Discount <span style='color:black;cursor:pointer' onclick='setDiscountTk($s)' id='discount_tks$s'></span>
						</td>
						<td>
						<input style='text-align: right;width: 100%;background: #61c5cf87;' type='text' id='exdiscount$s'/>
						</td>
						</tr>
						<tr>
						<tr>
						
						<td>
							<button onclick='payTk($s);' name='btn' id='paybtns$s' value='sub' class='btn btn-success'>Pay</button>
							<select style='height: 30px;' id='payment_type$s'>
								<option value='Cash'>Cash</option>
								<option value='Bkash'>Bkash</option>
								<option value='Rocket'>Rocket</option>
								<option value='Nagad'>Nagad</option>
								<option value='Upay'>Upay</option>
								<option value='Sure Cash'>Sure Cash</option>
								<option value='Tap'>Tap</option>
								<option value='POS Machine'>POS Machine</option>
								<option value='Bank'>Bank</option>
							</select>
						</td>
						<td>
						<input style='text-align:right;width: 100%;' type='text' onkeyup='showLiveDiscount($s)' onclick='clickToSelect(paytxt$s)' id='paytxt$s'/>
						</td>
						</tr>";
					}else{
				@$paytblpay.="<tr>
					<td style='color:red'>
							Discount <span style='color:black;cursor:pointer' onclick='setDiscountTk($s)' id='discount_tks$s'></span>
						</td>
						<td>
						<input style='text-align: right;width: 100%;background: #61c5cf87;' type='text' id='exdiscount$s'/>
						</td>
				</tr><tr>
						<td>
							<button onclick='payTk($s);' name='btn' id='paybtns$s' value='sub' class='btn btn-success'>Pay</button>
							<select style='height: 30px;' id='payment_type$s'>
								<option value='Cash'>Cash</option>
								<option value='Bkash'>Bkash</option>
								<option value='Rocket'>Rocket</option>
								<option value='Nagad'>Nagad</option>
								<option value='Upay'>Upay</option>
								<option value='Sure Cash'>Sure Cash</option>
								<option value='Tap'>Tap</option>
								<option value='POS Machine'>POS Machine</option>
								<option value='Bank'>Bank</option>
							</select>
						</td>
						<td>
						<input style='text-align:right;width: 100%;' onkeyup='showLiveDiscount($s)' onclick='clickToSelect(paytxt$s)' type='text' id='paytxt$s'/>
						<input type='hidden' value='$sid' id='dsms_ids$s'/>
						<input type='hidden' value='$total_tk' id='total_tk$s'/>
						<span id='stksms$s'></span>
						</td>
						</tr>";
					}
				}else{
					$paytblpay="<input type='hidden' value='$total_tk' id='total_tk$s'/><input type='hidden' value='$sid' id='dsms_ids$s'/>";
				}
					
				$paytbl3='</tbody>
					</table>';
				$payspan_end="</span>";
			$paytblf=$payspan.$paytbl.$paytblhead.$paytbl2.$paytbldue.$paytblpay.$paytbl3.$payspan_end;
			
			if(isset($rrow['phy_dv_date'])){
				$phy_dv_date=date('d/m/Y',strtotime($rrow['phy_dv_date']));
			}else{
				$phy_dv_date=2;
			}
			?>
			<div class="row">
				<div class="col-xs-12 col-sm-8">
						<div style="overflow: hidden;">
							<p style="float: left;" for="">Serial: <b><input type="text" onclick="copyOrderNumber('<?php echo $s; ?>');" style="width: 70px;color:red;cursor: pointer;" id="copying<?php echo $s; ?>" value="<?php echo @$rrow['phy_ord_num']; ?>"/></b></p>
							<p style="float:right" for="">SL: <span  id="tag_num"><?php echo $s; ?></span></p>
						</div>	
					<p for="">Customer Name: <b><span style="color:green" id="phy_ord_no"><?php echo @$rrow['cus_name']; ?></span></b></p>
					<p for="">Mobile: <b><span style="color:green" id="phy_ord_no"><?php echo $rrow['cus_mobile']; ?></span></b></p>
					<p for="">Order Date: <b><span id="ord_date"><?php echo date('d/m/Y',strtotime($rrow['order_date'])); ?></span></b></p>
					<p for="">Production Receive: <b><?php echo ($rrow['factory_status']==1 || $rrow['factory_status']==2)? "Yes" : "No"; ?></b></p>
					<p for="">Production Receive Date: <b><?php if(@$rrow['factory_receive_date']!="") echo date('d/m/Y',strtotime(@$rrow['factory_receive_date'])); ?></b></p>
					<p for="">Delivery Date: <b><span id="dv_date<?php echo $s; ?>"><?php echo date('d/m/Y',strtotime($rrow['dv_date'])); ?></span></b></p>
					<p for="">Physical Delivery Date: <b><span id="phy_dv_date<?php echo $s; ?>"><?php echo ($phy_dv_date==2)? "N/A" : $phy_dv_date; ?></span></b></p>
					<p for="">Order Type: <b><span id="ord_type"><?php echo ($rrow['order_type']==0)? "Normal": "Urgent"; ?></span></b></p>
					<p for="">Sms: <b><span id="chksms"><?php echo ($rrow['sms_status']==0)? "Pending": "Sent" ?></span></b></p>
					
					<div class="row">	
						<div class="col-xs-12 col-sm-12">
							<div class="row">
								<div class="col-xs-12 col-sm-9">
								<label for="comment" class="txt_color">Box Number: </label><br/>
								<input style="width: 80%;height: 30px;text-align:center;font-weight:bold;color:red" type="text" id="box_number<?php echo $s; ?>" value="<?php echo @$box_number; ?>"/> 
								<button style="" onclick="onlyBoxUpdateBtn('<?php echo $s; ?>','<?php echo @$rrow['phy_ord_num']; ?>');" name="btn" id="only_boxupdate<?php echo $s; ?>" value="sub" class="btn btn-info">Update</button>&nbsp;&nbsp;<br/>
								<span id="box_update_sms<?php echo $s; ?>"></span>
								</div>
							</div>
							<input type="hidden" value="<?php echo $f_total_taka; ?>" id="fab_total_tk<?php echo $s; ?>"/>
						</div>
					</div>
					
					<span for="">Dress Details:(<span style='color:#ec68d0;cursor: pointer;' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('<?php echo $s; ?>','<?php echo @$rrow['phy_ord_num']; ?>')"><b>Measurement</b></span>)</span>
						<span id="pdetail">
						 <?php echo $ptblf; ?>
						</span>
				</div>
			<div class="col-xs-12 col-sm-4">
					<span for="">Payment Details:</span>
					<span id="paydetail">
						<?php echo $paytblf; ?>
					</span>
					<p></p>	
				<?php if($phy_dv_date==2){
					//if($rrow['factory_status']==0){
				?>
				<!--<button onclick="productionReceiveBtn(<?php echo $s; ?>);" name="btn" id="order_receive<?php echo $s; ?>" value="sub" class="btn btn-success">Receive</button>&nbsp;&nbsp;
					<?php // } ?>-->
				<button onclick="orderDeliveryBtn(<?php echo $s; ?>);" name="btn" id="order_delivery<?php echo $s; ?>" value="sub" class="btn btn-warning">Delivery</button>&nbsp;&nbsp;
				<span id="order_delivery_sms<?php echo $s; ?>"></span>
				<!--<button onclick="orderDenyBtn(<?php echo $s; ?>);" name="btn" id="order_deny<?php echo $s; ?>" value="sub" class="btn btn-info">Cancel</button>&nbsp;&nbsp;-->
				<input type="hidden" id="hide_sms_id<?php echo $s; ?>" value="<?php echo $rrow['id']; ?>" />
				<span id="order_deny_sms<?php echo $s; ?>"></span>
				
				<div class="row" style="margin-top: 15px;">
					<div class="col-xs-12 col-sm-6">	
						Date(calendar)
						<input type="date" id="date3<?php echo $s; ?>" data-format="dd/mm/YYYY" class="form-control" name="bday">
						<input type="hidden" id="hide_sms_ids<?php echo $s; ?>" value="<?php echo $rrow['id']; ?>" />
						<input type="hidden" id="mobile3<?php echo $s; ?>" value="<?php echo $rrow['cus_mobile']; ?>" />
						<input type="hidden" style="" name="date1" id="date_org3<?php echo $s; ?>" value="<?php echo date('d/m/Y',strtotime($rrow['dv_date'])); ?>" />
					</div>
					<div class="col-xs-12 col-sm-6">
						<button style="margin-top: 19px;" onclick="onlyDateUpdateBtn(<?php echo $s; ?>);" name="btn" id="only_dateupdate<?php echo $s; ?>" value="sub" class="btn btn-success">Send SMS</button>&nbsp;&nbsp;
						<span id="only_date_update_sms<?php echo $s; ?>"></span>
					</div>
				</div>
			</div>
		</div>
				<?php } ?>
			<input type="hidden" id="mobile3<?php echo $s; ?>" value="<?php echo $rrow['cus_mobile']; ?>" />
			<?php 
			echo "<input type='hidden' id='discount$s' value='$discount' />
				<input type='hidden' id='discount_tot$s' value='$total_tk1' /></div></div><hr/>";
			$paytblf=$payspan=$paytbl=$paytblhead=$paytbl2=$paytbldue=$paytblpay=$paytbl3=$payspan_end="";
			$ptblf=$ptbl=$ptbl2=$ptbl3="";
			}
			
			
		}else{
			echo 2;
		}
		
	}
	
	
	
	if(isset($_REQUEST['get_item_detail'])){
		$ex=explode("#sep#",$_REQUEST['item_id']);
		$item_type=$_REQUEST['item_type'];
		$increment_number=$_REQUEST['increment_number'];
		$item_id=$ex[0];
		$group_id=$ex[1];
		$item_name=$ex[2];
		$com_id=($_SESSION['COM_ID']);
		$item_details=$conn->query("SELECT mh.title,mh.mtype,mh.id,mh.group_id,mh.amount FROM `measurement_head` mh WHERE mh.is_active=1 and mh.ptype=$item_type and mh.group_id=$group_id order by mh.steps asc"); // and mh.com_id=$com_id
			mysqli_close($conn);
			if(mysqli_num_rows($item_details)>0){
			while($rows=mysqli_fetch_array($item_details)){
				if($rows['mtype']==1){
				$txtf[]=$rows['title'];
				$txtfid[]=$rows['id'];
				}
				if($rows['mtype']==2){
				@$txtselect[]=$rows['title'];
				@$txtselectid[]=$rows['id'];
				@$txtselectgfid[]=$rows['group_id'];
				@$txtselectamountid[]=$rows['amount'];
				}
				if($rows['mtype']==3){
				$txtchk[]=$rows['title'];
				$txtchkid[]=$rows['id'];
				$txtchkamountid[]=$rows['amount'];
				}
				if($rows['mtype']==4){
				$txtarea[]=$rows['title'];
				$txtareaid=$rows['id'];
				}
			}
		?>
		<div id="delete_measurement<?php echo $increment_number; ?>" style="color: black;box-shadow: inset 0 0 1em gray;padding: 15px;margin-top: 10px;">
		<div class="row">
			
				
				<?php 
					if($_SESSION['SVERSION']==0){ //0= correcnt, 1=old order
				?>
				<input type="hidden" id="phy_ord_num" value="0"/>
				<input type="hidden" id="tbl_ord_num" value="0"/>
				<?php 
					}
				?>
				
			
			<input type="hidden" id="item_id<?php echo $increment_number; ?>" value="<?php echo $item_id; ?>"/>
			<input type="hidden" id="item_id_info<?php echo $increment_number; ?>" value="<?php echo $_REQUEST['item_id']; ?>"/>
			
			<div class="col-xs-12 col-sm-1">
				<label for="comment">Qty:</label>
				<input class="form-control" onkeyup="itemAmountChange('<?php echo $increment_number; ?>');" style="background: #ffc107;font-weight:bold;text-align: center;" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="" type="text" value="1" id="item_qty<?php echo $increment_number; ?>"/>
			</div>
			<div class="col-xs-12 col-sm-1">
				<label for="comment">Rate:</label>
				<input class="form-control" readonly onkeyup="itemAmountChange('<?php echo $increment_number; ?>');" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="text-align: right;" type="text" value="<?php echo getItemPrice($item_id); ?>" id="item_rate<?php echo $increment_number; ?>"/>
			</div>
			<div class="col-xs-12 col-sm-1">
				<label for="comment">Others:</label>
				<input class="form-control" readonly onkeyup="itemAmountChange('<?php echo $increment_number; ?>');" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="text-align: right;" type="text" value="0" id="item_others<?php echo $increment_number; ?>"/>
				
			</div>
			
			<div class="col-xs-12 col-sm-1">
				<label for="comment">Amount:</label>
				<input class="form-control" readonly autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="text-align: right;color: blue;font-weight: bold;" type="text" id="item_amount<?php echo $increment_number; ?>"/>
			</div>
			
			<div class="col-xs-12 col-sm-2">
			<!--<input type="hidden" id="master_id<?php echo $increment_number; ?>" value=""/>-->
			<input type="hidden" id="item_type<?php echo $increment_number; ?>" value="<?php echo $item_type; ?>"/>
				<label for="comment">Item:</label>
				
				<input class="form-control" readonly type="text" id="item_name<?php echo $increment_number; ?>" value="<?php echo $item_name; ?>"/>
			</div>
			<div class="col-xs-12 col-sm-2" style="width: 12%;">
				<label for="comment">Master: <span id="pending_master<?php echo $increment_number; ?>"></span></label>
				<select id="master_id<?php echo $increment_number; ?>" onchange="getPendingTask('1','master_id','pending_master','<?php echo $increment_number; ?>');" class="form-control">
					<option value="">Select One</option>
						<?php 
							echo getEmpname('1','');
						?>
				</select>
			</div>
			<div class="col-xs-12 col-sm-2" style="width: 13%;">
				<label for="comment">Karigor: <span id="pending_karigor<?php echo $increment_number; ?>"></span></label>
				<select id="karigor_id<?php echo $increment_number; ?>" onchange="getPendingTask('2','karigor_id','pending_karigor','<?php echo $increment_number; ?>');" class="form-control">
					<option value="">Select One</option>
						<?php 
							echo getEmpname('2','');
						?>
				</select>
			</div>
			
			<div class="col-xs-12 col-sm-2">
			<!--<input type="hidden" id="karigor_id<?php echo $increment_number; ?>" value=""/>-->
				<label for="comment">Group Name:</label>
				
				<input class="form-control" type="text" id="group_name<?php echo $increment_number; ?>" value=""/>
			</div>
			<div>
				<label for="comment" style="color: blue;cursor: pointer;float: right;padding-right: 16px;"><i onclick="copyOnlyMeasurement('<?php echo $item_id; ?>','<?php echo $increment_number; ?>');">Paste</i><input type="radio" style="margin-left: 5px;cursor: pointer;" name="paste_id" onclick="selectedItem('<?php echo $increment_number; ?>')" value="<?php echo $increment_number; ?>"/></label>
				<button onclick="deleteMeasurement('<?php echo $increment_number; ?>');" name="btn" style="" value="sub" id="" class="btn btn-danger">Remove</button><span style="margin-top:20px;position: fixed; margin-left: 6px;" id="dtls_load"></span>
			</div>
		</div>
		<hr style="border-top: 1px solid #d8c3c3;"> </hr>
		<div class="row">
		
			<?php
				if($group_id==1 && $item_type==1){
			?>
			
				<?php 
				for($i=0;$i<10;$i++){
				?>
				<div class='col-xs-12 col-sm-2'>
					<p style='font-size: 10px;text-align: center; line-height: 0px;'><?php echo $txtf[$i]; ?></p>
					<p style='font-weight: bold;'>
					<input class="form-control" onkeydown="enterEvent('size<?php echo $increment_number; ?>','<?php echo $i; ?>')" autocomplete="off" style="text-align: center;" type="text" id="size<?php echo $increment_number; ?><?php echo $i; ?>"/>
					<input type="hidden" id="sizetxt<?php echo $increment_number; ?><?php echo $i; ?>" value="<?php echo $txtfid[$i]; ?>" />
					</p>
				</div>
				
				<?php
				}
				?>
				
				<?php 
				for($i=10;$i<count($txtf);$i++){
				?>
				<div class='col-xs-12 col-sm-2'>
					<p style='font-size: 10px;text-align: center; line-height: 0px;'><?php echo $txtf[$i]; ?></p>
					<p style='font-weight: bold'>
					<input class="form-control" onkeydown="enterEvent('size<?php echo $increment_number; ?>','<?php echo $i; ?>')" autocomplete="off" style="text-align: center;" type="text" id="size<?php echo $increment_number; ?><?php echo $i; ?>"/>
					<input type="hidden" id="sizetxt<?php echo $increment_number; ?><?php echo $i; ?>" value="<?php echo $txtfid[$i]; ?>" />
					</p>
				</div>
				<?php
				}
				 }else{ 
				for($i=0;$i<count($txtf);$i++){
				?>
				<div class='col-xs-12 col-sm-2'>
					<p style='font-size: 10px;text-align: center; line-height: 0px;'><?php echo $txtf[$i]; ?></p>
					<p style='font-weight: bold;'>
					<input class="form-control" onkeydown="enterEvent('size<?php echo $increment_number; ?>','<?php echo $i; ?>')" autocomplete="off" style="text-align: center;" type="text" id="size<?php echo $increment_number; ?><?php echo $i; ?>"/>
					<input type="hidden" id="sizetxt<?php echo $increment_number; ?><?php echo $i; ?>" value="<?php echo $txtfid[$i]; ?>" />
					</p>
				</div>
				<?php
				}
			} ?>
			<input type="hidden" id="sizetot<?php echo $increment_number; ?>" value="<?php echo count($txtfid); ?>" />
			
		</div>
		<div class="row" style="overflow:hidden">
			<div class="col-xs-12 col-sm-4" style="margin-top:6px;">
			<table style="width: 100%;">
				<?php 
				if(isset($txtselect)){
				for($i=0;$i<count($txtselect);$i++){
				?>
				<input type="hidden" id="propertice_title<?php echo $increment_number; ?><?php echo $i; ?>" value="<?php echo $txtselectid[$i]; ?>" />
				<input type="hidden" id="select_amount<?php echo $increment_number; ?><?php echo $i; ?>" value="<?php echo $txtselectamountid[$i]; ?>" />
				<tr>
					<td>
						<select id="propertice<?php echo $increment_number; ?><?php echo $i; ?>" onchange="calculateSelectAmount('<?php echo $increment_number; ?>','<?php echo $i; ?>');" class="form-control" style="margin-bottom: 10px;float: left;width: 89% !important;">
							<option value=""><?php echo $txtselect[$i]; ?></option>
							<?php 
								echo getSelectDetail_Sh($txtselect[$i],$txtselectgfid[$i],$item_type); //$item_type
							?>
						</select>
						<span>&nbsp;[<span style="color:blue"><?php echo $txtselectamountid[$i]; ?></span>]</span>
					</td>
				</tr>				
				
				
				<?php
				
				}
			
				?>
			
			<input type="hidden" id="propertice_title_tot<?php echo $increment_number; ?>" value="<?php echo count($txtselectid); ?>" />
			<?php } ?>
			</table>
			</div>
			<div class="col-xs-12 col-sm-4" style="margin-top:6px;">
				<?php 
				if(isset($txtchk)){
				for($i=0;$i<count($txtchk);$i++){
				?>
				<div class="col-xs-12 col-sm-12">
				<input type="hidden" id="check_amount<?php echo $increment_number; ?><?php echo $i; ?>" value="<?php echo $txtchkamountid[$i]; ?>" />
				<input style="margin-right: 10px;margin-bottom: 10px;" onclick="getCheckBoxAmount('<?php echo $increment_number; ?>')" type="checkbox" class="chkbox" id="expropertice<?php echo $increment_number; ?><?php echo $i; ?>" value="<?php echo $txtchkid[$i]; ?>" /><?php echo $txtchk[$i]; ?>-[<span style="color:blue"><?php echo $txtchkamountid[$i]; ?></span>]
				</div>
				<?php
				}
				}
				?>
				<input type="hidden" id="expropertice_tot<?php echo $increment_number; ?>" value="<?php echo count(@$txtchkid); ?>" />
			</div>
			<div class="col-xs-12 col-sm-4" style="margin-top:6px;">
				<?php
					if($item_type==1){ //For gents
					if($_SESSION['SHOW_DESIGN']==1){
						if($item_name=="Shirt"){
							?>
							<img src="img/1.png" style="width:150px"/>
							<?php 
						}else if($item_name=="Fatua"){
							?>
							<img src="img/2.png" style="width:150px"/>
							<?php 
						}else if($item_name=="Pant"){
							?>
							<img src="img/3.png" style="width:150px;height: 215px;"/>
							<?php 
						}else if($item_name=="Panjabi"){
							?>
							<img src="img/4.png" style="width:180px;height: 215px;"/>
							<?php 
						}else if($item_name=="Mujib Coat"){
							?>
							<img src="img/5.png" style="width:150px"/>
							<?php 
						}else if($item_name=="Coat"){
							?>
							<img src="img/6.png" style="width:180px;height: 180px;"/>
							<?php 
						}else if($item_name=="Jubbah"){
							?>
							<img src="img/7.png" style="width: 180px;height: 215px;"/>
							<?php 
						}else if($item_name=="Sherwani"){
							?>
							<img src="img/8.png" style="width:180px"/>
							<?php 
						}else if($item_name=="Prince Coat"){
							?>
							<img src="img/9.png" style="width:150px;height: 180px;"/>
							<?php 
						}else if($item_name=="Waistcoat"){
							?>
							<img src="img/10.png" style="width:150px"/>
							<?php 
						}else if($item_name=="Kabli"){
							?>
							<img src="img/11.png" style="width:180px;height: 180px;"/>
							<?php 
						}else if($item_name=="Pajama"){
							?>
							<img src="img/12.png" style="width:150px;height: 215px;"/>
							<?php 
						}
					}
					}else{
						
					}
				?>
			</div>
		</div>
		<div class="row" style="overflow:hidden">
			<?php 
				if(isset($txtarea)){
				?>
				<div class="col-xs-12 col-sm-12">
					<textarea style="margin-bottom: 10px;" id="extra_remarks<?php echo $increment_number; ?>" rows="2" cols="5" class="form-control"></textarea>
				</div>
				<?php
				
				}
				?>
				<input type="hidden" id="txtareaid<?php echo $increment_number; ?>" value="<?php if(isset($txtareaid)) echo @$txtareaid; else echo 0; ?>" />
		</div>
	</div>
		<?php 
			}else{
				echo 2;
			}
		
	}
	
	if(isset($_REQUEST['showPurchaseDetails'])){
		$com_id=($_SESSION['COM_ID']);
		@$tbl_id=trim($_REQUEST['tbl_id']);
		$sales_head=$conn->query("select f_total,discount_tk,others_tk,total_receive
			FROM `direct_sale_head` ds WHERE ds.is_order=0 and is_active=1 and id=$tbl_id");
		$item_details=$conn->query("select (select product_name from product where id=ds.item_id) item,ds.item_qty
			FROM `direct_sale` ds WHERE ds.dstid=$tbl_id and is_active=1");
			mysqli_close($conn);
			$sales_head_rows=mysqli_fetch_array($sales_head);
			
				?>
				<div class="row">
				<div class="col-xs-12 col-sm-12">
				
					<table id="dynamic-table" class="table table-striped table-bordered table-hover">
						<thead>
							<tr>
								<th style="width: 5%;text-align: center;">Sl</th>
								<th style="width:35%;">Item</th>
								<th style="width:20%;text-align: center;">Qty (গজ)</th>
							</tr>
						</thead>
						<tbody>
							<?php 
								$sl3=1;$order_tk3=0;$qty=0;
								if(mysqli_num_rows($item_details)>0){
									while($row=mysqli_fetch_array($item_details)){
										?>
										<tr>
											<td style="width: 5%;text-align: center;"><?php echo $sl3++; ?></td>
											<td><?php echo $row['item']; ?></td>
											<td style="text-align: center;"><?php echo $row['item_qty']; ?></td>
										</tr>
										
										<?php 
									}
								}
							?>
						</tbody>
						
					</table>
					<h3>Payment Details</h3>
					<table id="dynamic-table" class="table table-striped table-bordered table-hover">
						<thead>
							<tr>
								<th style="width: 85%;text-align: right;">Total</th><th style="text-align:right"><?php echo $sales_head_rows['f_total']; ?>/=</th>
							</tr>
							<tr>							
								<td style="text-align: right;">Others</td><th style="text-align:right"><?php echo $sales_head_rows['others_tk']; ?>/=</th>
							</tr>
							<tr>							
								<td style="text-align: right;">Discount</td><th style="text-align:right">(-)<?php echo $sales_head_rows['discount_tk']; ?>/=</th>
							</tr>	
							<tr>
								<th style="text-align: right;">Advance</th><th style="text-align:right">(-)<?php echo $sales_head_rows['total_receive']; ?>/=</th>
							</tr>
							<tr>							
								<th style="text-align: right;">Due</th><th style="text-align:right"><?php echo ($sales_head_rows['f_total']+$sales_head_rows['others_tk']-$sales_head_rows['discount_tk']-$sales_head_rows['total_receive']); ?>/=</th>
							</tr>
						</thead>
						
					</table>
								
				</div>
				</div>
				<?php 
		
	}
	
	if(isset($_REQUEST['showOnlyFabricsPrice'])){
		$com_id=($_SESSION['COM_ID']);
		@$todays_date=trim($_REQUEST['todays_date']);
		@$total_tk=trim($_REQUEST['total_tk']);
		$fabrics_taka1=$conn->query("SELECT CASE WHEN `taka`>0 THEN `taka` ELSE 0 END ord_tk,ord_number as order_number,insert_date FROM `only_febrics_tk` WHERE `is_active`=1 and date(`insert_date`)='$todays_date'");
		$fabrics_taka2=$conn->query("SELECT CASE WHEN `total_receive`>0 THEN `total_receive` ELSE 0 END ord_tk,tax as order_number,insert_date FROM `direct_sale_head` WHERE `is_active`=1 and `is_order`=0 and date(`insert_date`)='$todays_date'");
		$fabrics_taka3=$conn->query("SELECT case when `total_receive`<=`f_total` THEN total_receive ELSE f_total END ord_tk,(select DISTINCT(direct_sale.order_number) from direct_sale where direct_sale.dstid=direct_sale_head.id) order_number,insert_date FROM `direct_sale_head` WHERE `is_active`=1 and `is_order`=1 and date(`insert_date`)='$todays_date'");
			mysqli_close($conn);
			
				?>
				<div class="row">
				<div class="col-xs-12 col-sm-12">
				
					<table id="dynamic-table" class="table table-striped table-bordered table-hover">
						<thead>
							<tr>
								<th style="width: 5%;text-align: center;">Sl</th>
								<th style="width:35%;text-align: center;">Date</th>
								<th style="width:20%;text-align: center;">Order Number</th>
								<th style="width:20%;text-align: right;">Taka</th>
							</tr>
						</thead>
						<tbody>
							<?php 
								$sl3=1;$order_tk3=0;$qty=0;
								if(mysqli_num_rows($fabrics_taka1)>0){
									while($row=mysqli_fetch_array($fabrics_taka1)){
										?>
										<tr>
											<td style="width: 5%;text-align: center;"><?php echo $sl3++; ?></td>
											<td style="text-align: center;"><?php echo $row['insert_date']; ?></td>
											<td style="text-align: center;"><?php echo $row['order_number']; ?></td>
											<td style="text-align: right;"><?php echo $row['ord_tk']; ?></td>
										</tr>
										<?php 
									}
								}
								if(mysqli_num_rows($fabrics_taka2)>0){
									while($row=mysqli_fetch_array($fabrics_taka2)){
										?>
										<tr>
											<td style="width: 5%;text-align: center;"><?php echo $sl3++; ?></td>
											<td style="text-align: center;"><?php echo $row['insert_date']; ?></td>
											<td style="text-align: center;"><?php echo $row['order_number']; ?></td>
											<td style="text-align: right;"><?php echo $row['ord_tk']; ?></td>
										</tr>
										<?php 
									}
								}
								if(mysqli_num_rows($fabrics_taka3)>0){
									while($row=mysqli_fetch_array($fabrics_taka3)){
										?>
										<tr>
											<td style="width: 5%;text-align: center;"><?php echo $sl3++; ?></td>
											<td style="text-align: center;"><?php echo $row['insert_date']; ?></td>
											<td style="text-align: center;"><?php echo $row['order_number']; ?></td>
											<td style="text-align: right;"><?php echo $row['ord_tk']; ?></td>
										</tr>
										<?php 
									}
								}
							?>
						</tbody>
						<tr>
							<td colspan="3" style="text-align: right;font-weight:bold">Total: </td>
							<td style="text-align: right;font-weight:bold"><?php echo $total_tk; ?></td>
						</tr>
					</table>
					
								
				</div>
				</div>
				<?php 
		
	}
	
	if(isset($_REQUEST['showOnlyFabricsPriceTotal'])){
		$com_id=($_SESSION['COM_ID']);
		@$todays_date=trim($_REQUEST['todays_date']);
		@$end_date=trim($_REQUEST['end_date']);
		@$total_tk=trim($_REQUEST['total_tk']);
		$fabrics_taka1=$conn->query("SELECT CASE WHEN `taka`>0 THEN `taka` ELSE 0 END ord_tk,ord_number as order_number,insert_date FROM `only_febrics_tk` WHERE `is_active`=1 and date(`insert_date`) between '$todays_date' and '$end_date'");
		$fabrics_taka2=$conn->query("SELECT CASE WHEN `total_receive`>0 THEN `total_receive` ELSE 0 END ord_tk,tax as order_number,insert_date FROM `direct_sale_head` WHERE `is_active`=1 and `is_order`=0 and date(`insert_date`) between '$todays_date' and '$end_date'");
		$fabrics_taka3=$conn->query("SELECT case when `total_receive`<=`f_total` THEN total_receive ELSE f_total END ord_tk,(select DISTINCT(direct_sale.order_number) from direct_sale where direct_sale.dstid=direct_sale_head.id) order_number,insert_date FROM `direct_sale_head` WHERE `is_active`=1 and `is_order`=1 and date(`insert_date`) between '$todays_date' and '$end_date'");
			mysqli_close($conn);
			
				?>
				<div class="row">
				<div class="col-xs-12 col-sm-12">
				
					<table id="dynamic-table" class="table table-striped table-bordered table-hover">
						<thead>
							<tr>
								<th style="width: 5%;text-align: center;">Sl</th>
								<th style="width:35%;text-align: center;">Date</th>
								<th style="width:20%;text-align: center;">Order Number</th>
								<th style="width:20%;text-align: right;">Taka</th>
							</tr>
						</thead>
						<tbody>
							<?php 
								$sl3=1;$order_tk3=0;$qty=0;
								if(mysqli_num_rows($fabrics_taka1)>0){
									while($row=mysqli_fetch_array($fabrics_taka1)){
										?>
										<tr>
											<td style="width: 5%;text-align: center;"><?php echo $sl3++; ?></td>
											<td style="text-align: center;"><?php echo $row['insert_date']; ?></td>
											<td style="text-align: center;"><?php echo $row['order_number']; ?></td>
											<td style="text-align: right;"><?php echo $row['ord_tk']; ?></td>
										</tr>
										<?php 
									}
								}
								if(mysqli_num_rows($fabrics_taka2)>0){
									while($row=mysqli_fetch_array($fabrics_taka2)){
										?>
										<tr>
											<td style="width: 5%;text-align: center;"><?php echo $sl3++; ?></td>
											<td style="text-align: center;"><?php echo $row['insert_date']; ?></td>
											<td style="text-align: center;"><?php echo $row['order_number']; ?></td>
											<td style="text-align: right;"><?php echo $row['ord_tk']; ?></td>
										</tr>
										<?php 
									}
								}
								if(mysqli_num_rows($fabrics_taka3)>0){
									while($row=mysqli_fetch_array($fabrics_taka3)){
										?>
										<tr>
											<td style="width: 5%;text-align: center;"><?php echo $sl3++; ?></td>
											<td style="text-align: center;"><?php echo $row['insert_date']; ?></td>
											<td style="text-align: center;"><?php echo $row['order_number']; ?></td>
											<td style="text-align: right;"><?php echo $row['ord_tk']; ?></td>
										</tr>
										<?php 
									}
								}
							?>
						</tbody>
						<tr>
							<td colspan="3" style="text-align: right;font-weight:bold">Total: </td>
							<td style="text-align: right;font-weight:bold"><?php echo $total_tk; ?></td>
						</tr>
					</table>
					
								
				</div>
				</div>
				<?php 
		
	}
	
	if(isset($_REQUEST['showEmployeesDetails'])){
	$com_id=($_SESSION['COM_ID']);
		@$d1=trim($_REQUEST['d1']);
		@$d2=trim($_REQUEST['d2']);
		@$search_type=trim($_REQUEST['search_type']);
		@$emp_id=trim($_REQUEST['emp_id']);
		@$emp_name=trim($_REQUEST['emp_name']);
		//@$tbl_id=trim($_REQUEST['tbl_id']);
		if($d1!=""){
			$con="and date(insert_date) between '$d1' and '$d2'";
		}else{
			$con="and date(insert_date)<='$d2'";
		}
		
		if($search_type=='earning'){
			$status=0;
			$balance=$conn->query("SELECT * FROM `wages_head` WHERE `emp_id`=$emp_id");
		
		$sales_head=$conn->query("SELECT date(`insert_date`) idate FROM `wages_details` WHERE 
		`is_active`=1 and status=$status $con and `emp_id`=$emp_id GROUP BY date(`insert_date`)");
		
				?>
				<div class="row">
				<div class="col-xs-12 col-sm-12">
					<h3><?php echo $emp_name; ?></h3>
					<table id="dynamic-table" class="table table-striped table-bordered table-hover">
						<thead>
							<tr>
								<th style="width: 5%;text-align: center;">সিরিয়াল</th>
								<th style="">তারিখ</th>
								<th style="width:40%;">
									<table border='0' style="width:100%">
										<tr>
											<td style="width: 60%;">আইটেম</td>
											<td style="text-align: center;width: 15%;">সংখ্যা</td>
											<td style="text-align: right;">টাকা</td>
										</tr>
									</table>
								</th>
							</tr>
						</thead>
						<tbody>
							<?php 
								$sl3=1;$order_tk3=0;$qty=0;$tk=0;
								if(mysqli_num_rows($sales_head)>0){
									
									while($row=mysqli_fetch_array($sales_head)){
										$idate=$row['idate'];
										$sales_head_earning=$conn->query("SELECT sum(`item_qty`) item_qty,sum(`taka`) taka,`item_name` FROM `wages_details` WHERE 
										`is_active`=1 and status=$status and date(insert_date)='$idate' and `emp_id`=$emp_id group by item_name");
										?>
									<tr>
									<td style="width: 5%;text-align: center;"><?php echo $sl3++; ?></td>
										<td><?php echo $idate; ?></td>
										<td>
										<table border='0' style="width:100%">
										<?php 
										while($rows=mysqli_fetch_array($sales_head_earning)){
										$tk+=$rows['taka'];
										$qty+=$rows['item_qty'];
										?>
										<tr>
											<td style="width: 60%;"><?php echo $rows['item_name']; ?></td>
											<td style="text-align: center;width: 15%;"><?php echo $rows['item_qty']; ?></td>
											<td style="text-align: right;"><?php echo $rows['taka']; ?></td>
										</tr>
										
										<?php 
										}
										?>
										
										</table>
										</td>
									</tr>
										<?php 
									}
								}
							?>
							<tr>
								<th colspan="2" style="text-align: right;">আইটেম সংখ্যা/মজুরি(জমা): </th>
								<th><span style="padding-left: 191px;"><?php echo $qty; ?></span><span style="float:right"><?php echo $tk; ?></span> </th>
							</tr>
						</tbody>
						
					</table>
						<?php
						if(mysqli_num_rows($balance)>0){
							$row=mysqli_fetch_array($balance);
							$total_balance=$row['taka'];		
						}
						?>
					
					<table border='1' style="width: 40%; margin-left: 60%;">
						<caption style="color: black;"><?php echo $emp_name; ?></caption>
						<tr style="color:red">
							<td style="width: 60%; text-align: right; padding: 5px;font-weight:bold">মোট ব্যালান্স (টাকা)</td>
							<td style="width: 25%;text-align: right;padding: 5px;font-weight:bold;font-size: 18px;">
							<i id="set_balance"><?php echo $total_balance; ?></i>
							<input type="hidden" value="<?php echo $total_balance; ?>" id="total_balance_taka"/>
							<input type="hidden" value="<?php echo $emp_id; ?>" id="payment_emp_id"/>
							</td>
						</tr>
						<tr>
							<td style="width: 60%; text-align: right; padding: 5px;font-weight:bold">পরিশোধ (টাকা)</td>
							<td style="width: 25%;text-align: right;padding: 5px;font-weight:bold">
							<input type="text" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;text-align:right" autocomplete="off" name="total_item_qty" onkeyup="autoCalculator();" id="payment_taka" required/>
							</td>
						</tr>
						<tr>
							<td style="width: 60%;padding: 5px;font-weight:bold">
								<input type="text" class="form-control" style="font-weight: bold;font-size:18px;font-style: italic;" autocomplete="off" name="total_item_qty" id="payemnt_remarks" required/>
							</td>
							<td style="width: 25%; text-align: right; padding: 5px;font-weight:bold">
							মন্তব্য
							</td>
							
						</tr>
						<tr>
							<td style="width: 60%; text-align: right; padding: 5px;font-weight:bold;color:blue">
							জের: <span id="due_taka"></span>
							</td>
							<td style="width: 25%;text-align: right;padding: 5px;font-weight:bold">
							<button onclick="savePaymentLive();" style="margin-top: 12px;margin-right:5px" name="btn" value="sub" id="save_order" class="btn btn-success">Save</button>
							</td>
						</tr>
					</table>
					<span style="color:green;margin-left: 60%;" id="blnc_success"></span>
				</div>
				</div>
				<?php 
				mysqli_close($conn);
	}else{
		date_default_timezone_set("Asia/Dhaka");
		$date=date("Y-m-d");
		$status=1;
		$sales_head=$conn->query("SELECT id,`taka`,`item_name`,`item_qty`,`order_num`,`remarks`,date(`insert_date`) idate,ord_record_tblid,status FROM `wages_details` WHERE 
		`is_active`=1 and status=$status $con and `emp_id`=$emp_id order by date(insert_date) desc");
		mysqli_close($conn);
		?>
		<div class="row">
				<div class="col-xs-12 col-sm-12">
					<h3><?php echo $emp_name; ?> | <span style="color:green;font-weight:bold" id="payment_sms"></span></h3>
					<table id="dynamic-table" class="table table-striped table-bordered table-hover">
						<thead>
							<tr>
								<th style="width: 5%;text-align: center;">Sl</th>
								<th style="">Date</th>
								<th style="">Remarks</th>
								<th style="width:15%;text-align: right;">Payment (Tk.)</th>
							</tr>
						</thead>
						<tbody>
							<?php 
								$sl3=1;$order_tk3=0;$qty=0;$tk=0;
								if(mysqli_num_rows($sales_head)>0){
									while($row=mysqli_fetch_array($sales_head)){
										$tk+=$row['taka'];
										?>
										<tr>
											<td style="width: 5%;text-align: center;">
											<?php 
											if($date==$row['idate']){
											?>
											<button onclick="delItemPayment('<?php echo $row['id']; ?>','3','<?php echo $row['taka']; ?>','<?php echo $emp_id; ?>','<?php echo $row['status']; ?>','<?php echo $row['ord_record_tblid']; ?>');" name='btn' id='delpaybtns<?php echo $row['id']; ?>' class="btn btn-danger form-control"><?php echo $sl3++; ?></button>
											<?php }else{
												 echo $sl3++; 
											} ?>
											
											</td>
											<td><?php echo $row['idate']; ?></td>
											<td><?php echo $row['remarks']; ?></td>
											<td style="text-align: right;"><?php echo $row['taka']; ?></td>
										</tr>
										
										<?php 
									}
								}
							?>
						</tbody>
						<tr>
							<th colspan="3" style="text-align: right;">Total: </th>
							<th style="text-align: right;"><?php echo $tk; ?></th>
						</tr>
					</table>
								
				</div>
				</div>
		<?php 
	}
		
		
	}
	
	if(isset($_REQUEST['savePaymentLive'])){
		$due_tk="";
		$com_id=($_SESSION['COM_ID']);
		$user_id=($_SESSION['USER_ID']);
		$emp_id=($_REQUEST['emp_id']);
		$total_balance_taka=($_REQUEST['total_balance_taka']);
		$payment_taka=($_REQUEST['payment_taka']);
		@$payemnt_remarks=($_REQUEST['payemnt_remarks']);
		
		$emp_info=$conn->query("SELECT id,taka from wages_head where emp_id=$emp_id and com_id=$com_id");
		if(mysqli_num_rows($emp_info)>0){
			$row=mysqli_fetch_array($emp_info);
			$id=$row['id'];
			$utaka=($row['taka']-$payment_taka);
			$due_tk=$utaka;
			$last_insert_head=$conn->query("update wages_head set taka='$utaka' where id=$id");
		}else{
			$last_insert_head=$conn->query("insert into wages_head(com_id,emp_id,taka) values ($com_id,$emp_id,'$payment_taka')");
		}
		$last_insert=$conn->query("insert into wages_details(com_id,
			emp_id,
			taka,
			remarks,
			status,
			insert_by
			) values($com_id,
			$emp_id,
			'$payment_taka',
			'$payemnt_remarks',
			'1',
			$user_id)");
			
			
		
		if($last_insert){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	
	if(isset($_REQUEST['smeasurement'])){
		$com_id=($_SESSION['COM_ID']);
		@$order_number=trim($_REQUEST['ord_num']);
		$order_details=$conn->query("SELECT ord.id,ord.item_id,ord.ptype,(select cus_price from product where id=ord.item_id) item_price,
			(select artisan_price from product where id=ord.item_id) karigor_price,ds.cus_name,ds.cus_mobile,ds.insert_date,ds.phy_ord_num,
			(select product_name from product where id=ord.item_id) product,ord.group_name,
			ord.order_number,ord.master_id,ord.group_id,date(ord.insert_date) insert_date,ds.dv_date,ds.fddate,ds.fdtime,
			(select user_name from user where id=ord.master_id) masters,ord.karigor_id,(select user_name from user where id=ord.maker) karigor,(select user_name from user where id=ord.karigor_id) fkarigor,
			(select user_name from user where id=ord.master_emp_id) master,(select user_name from user where id=ord.master_id) fmaster,ord.item_qty
			FROM `order_record` ord,dsms ds WHERE ds.id=ord.dsms_id and ord.com_id=$com_id and ord.order_number='$order_number' and ord.is_active=1");
			//mysqli_close($conn);
		
			$i=1;
			while($rows=mysqli_fetch_array($order_details)){
				@$master=$rows['master'];
				@$fmaster=$rows['fmaster'];
				@$karigor=$rows['karigor'];
				@$fkarigor=$rows['fkarigor'];
				@$item_id=$rows['item_id'];
				@$ord_id=$rows['id'];
				
				$karigor_details=$conn->query("SELECT (select user_name from user where id=wages_details.emp_id) karigor,item_qty,emp_type from wages_details where order_num='$order_number' and is_active=1 and ord_record_tblid=$ord_id");
				//$karigor_details=$conn->query("SELECT (select user_name from user where id=wages_details.emp_id) karigor,item_qty,emp_type from wages_details where order_num='$order_number' and is_active=1 and item_ids=$item_id");
					$kname="";
					$mname="";
					if(mysqli_num_rows($karigor_details)>0){
						$kname=array();
						$mname=array();
						while($rows_karigor=mysqli_fetch_array($karigor_details)){
							if($rows_karigor['emp_type']==2 || $rows_karigor['emp_type']==0){ //2=karigor 
								$kname[]=$rows_karigor['karigor']."(".$rows_karigor['item_qty'].")";
							}else{ // master=1
								$mname[]=$rows_karigor['karigor']."(".$rows_karigor['item_qty'].")";
							}
						}
						$kname=(count($kname)>0)? implode(', ',$kname) : $fkarigor;
						$mname=(count($mname)>0)? implode(', ',$mname) : $fmaster;
						
				}
		
				$mname=($master=="")? $fmaster : $mname;
				$kname=($karigor=="")? $fkarigor : $kname;
				?>
				<div class="row" style="overflow: hidden;border-bottom: 1px solid #e2e2ead1;margin: 0 auto;margin-bottom: 10px;">
					<?php if($i==1){ ?>
					<p style="font-size: 15px;margin-right: 25px;color:#f22ee0;"><b>Order No- </b><?php echo $rows['phy_ord_num']; ?></p>
					<p style="font-size: 12px;margin-right: 25px;color:#000000c4"><b>কাস্টমার- </b><?php echo $rows['cus_name']; ?> [<?php echo $rows['cus_mobile']; ?>] | <b>Order Date:</b> <?php echo date_format(date_create($rows['insert_date']),"d/m/Y"); ?> | <b>Delivery Date:</b> <?php echo date_format(date_create($rows['dv_date']),"d/m/Y"); ?> | <b>Delivered Date:</b> <?php echo @$rows['fddate']; ?></p>
					<?php } ?>
					<p style="font-size: 12px;float: left;margin-right: 25px;"><b><?php echo $i++; ?>)</b> <span style='color: #4444d1b8;'><b><?php echo $rows['product']; ?>[<?php echo $rows['id']; ?>]</b> (<?php echo $rows['item_qty']; ?>)</span></p>
					<p style="font-size: 12px;float: left;margin-right: 25px;"><b>গ্রুপ নাম- </b><?php echo $rows['group_name']; ?></p>
					<p style="font-size: 12px;float: left;margin-right: 25px;"><b>মাস্টার- </b><?php echo $mname; ?></p>
					<p style="font-size: 12px;"><b>কারিগর- </b><?php echo $kname; ?></p>
						<div style="margin-left: 0px;margin-right: 0px;overflow: hidden;padding-top: 14px;">
							<?php echo getMeasurement2($rows['id'],1); //1=measurement ?>
						
						</div>
							<div class="" style="margin-top:8px;padding-left:15px;padding-right:15px;float:left !important">
								<?php 
								echo getMeasurement2($rows['id'],2); // selected data
								?>
								
							</div>
							<div class="" style="margin-top:8px;padding-left:15px;padding-right:20px;float:left !important">
								<?php 
								echo getMeasurement2($rows['id'],3); // checkbox data
								?>
							</div>
							<div class="" style="margin-top:0px;padding-left:15px;padding-right:15px;float:left !important">
								<?php
								if($rows['ptype']==1){
								if($_SESSION['SHOW_DESIGN']==1){
									if($rows['product']=="Shirt"){
									?>
										<img src="img/1.png" style="width: 80px;margin-top: -9px;height: 110px;"/>
									<?php 
									}else if($rows['product']=="Fatua"){
										?>
										<img src="img/1.png" style="width:80px;margin-top:-9px;height:110px;"/>
										<?php 
									}else if($rows['product']=="Pant"){
										?>
										<img src="img/3.png" style="width: 100px;height: 110px;"/>
										<?php 
									}else if($rows['product']=="Panjabi"){
										?>
										<img src="img/4.png" style="width: 128px;height: 130px;"/>
										<?php 
									}else if($rows['product']=="Mujib Coat"){
										?>
										<img src="img/5.png" style="width:110px;height: 136px;"/>
										<?php 
									}else if($rows['product']=="Coat"){
										?>
										<img src="img/6.png" style="width: 130px;height: 125px;"/>
										<?php 
									}else if($rows['product']=="Jubbah"){
										?>
										<img src="img/7.png" style="width: 115px;height: 114px; margin-top: -11px;"/>
										<?php 
									}else if($rows['product']=="Sherwani"){
										?>
										<img src="img/8.png" style="width: 120px;height: 135px;"/>
										<?php 
									}else if($rows['product']=="Prince Coat"){
										?>
										<img src="img/9.png" style="width: 105px;height: 130px;"/>
										<?php 
									}else if($rows['product']=="Waistcoat"){
										?>
										<img src="img/10.png" style="width:85px"/>
										<?php 
									}else if($rows['product']=="Kabli"){
										?>
										<img src="img/11.png" style="width: 115px;height:120px;"/>
										<?php 
									}else if($rows['product']=="Pajama"){
										?>
										<img src="img/12.png" style="width:92px;height: 120px;"/>
										<?php 
									}
								}
								}else{
									
								}
								?>
							</div>
						<div class="row" style="overflow:hidden;padding-top: 10px;padding-left: 15px;">
							<?php 
								echo getMeasurement2($rows['id'],4); // Txtarea data
							?>
						</div>
				</div>
				
				<?php 
			}
			?>
			<div class="row" style="overflow: hidden;border-bottom: 1px solid #e2e2ead1;margin: 0 auto;margin-bottom: 10px;">
					
					<?php 
						$item_details=$conn->query("select (select product_name from product where id=direct_sale.item_id) item_name,item_qty from direct_sale where order_number='$order_number' and is_active=1");
						
					?>
					
						
			</div>
			<label style="font-weight: bold;text-decoration: underline;">ফ্যাব্রিক্স আইটেম:</label>
				<table id="dynamic-table" class="table table-striped table-bordered table-hover">
					<thead>
						<thead>
						<tr>
							<th style="text-align:center">Sl</th>
							<th style="">Item</th>
							<th style="text-align:center">Item Qty (গজ)</th>
							</tr>
					</thead>
					<tbody>
						<?php 
							$sl2=1;
							if(mysqli_num_rows($item_details)>0){
								while($rows=mysqli_fetch_array($item_details)){
								?>
									<tr>
									<td style="text-align:center"><?php echo $sl2++; ?></td>
									<td>
										<?php echo $rows['item_name']; ?>
									</td>
									<td style="text-align:center">
										<?php echo $rows['item_qty']; ?>
									</td>
									
									</tr>
									<?php 
								}
							}
						?>
					</tbody>
					
				</table>
				</div>
			<?php 
			$i++;
			mysqli_close($conn);
	}
	
	if(isset($_REQUEST['showExpenseBreakdown'])){
		$com_id=($_SESSION['COM_ID']);
		$expense_title=$_REQUEST['expense_title'];
		$expense_type=$_REQUEST['expense_type'];
		$d1=$_REQUEST['sdate'];
		$d2=$_REQUEST['tdate'];
		$expense_type_sql=$conn->query("SELECT expense extk,expense_type,insert_date,remarks,(select et.expense from expense_type et where et.id=expenses.expense_type) expense_title FROM `expenses` WHERE `is_active`=1 and `expense_type`=$expense_type and date(`insert_date`) BETWEEN '$d1' and '$d2'");
		
				?>
					<div class="row" style="background:white">
					<div class="col-xs-12 col-sm-12">
								
								<?php 
							$tprofit=0;
							if(mysqli_num_rows($expense_type_sql)>0){
								?>
								<label><?php echo $expense_title; ?></label>
								<table id="dynamic-table" class="table table-striped table-bordered table-hover">
									<thead>
										<tr>
											<th style="width:5%;text-align: center;">Sl</th>
											<th style="width:20%;">Date</th>
											<th style="width:55%;">Remarks</th>
											<th style="width:20%;text-align:right">Taka/=</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl=1;$tot_qty=0;
											while($rows=mysqli_fetch_array($expense_type_sql)){
													$c=$sl++;
													$tot_qty+=$rows['extk'];
													?>
													<tr>
														<td style="text-align: center;"><?php echo $c; ?></td>
														<td>
															<?php echo $rows['insert_date']; ?>
														</td>
														<td>
															<?php echo $rows['remarks']; ?>
														</td>
														<td style="text-align: right;"><?php echo $rows['extk']; ?>/=</td>
													</tr>
													<?php 
												}
										?>
										<tr>
											<td colspan="3" style="text-align: right;font-weight:bold">Total</td>
											<td style="text-align: right;font-weight:bold"><?php echo $tot_qty; ?>/=</td>
										</tr>
									</tbody>
									
								</table>
								<?php 
							}else{
								echo "No Item Found!";
							}
							?>	
	
					</div>
							
					</div>
					<?php 
	}
	
	if(isset($_REQUEST['get_selected_item'])){
		$com_id=($_SESSION['COM_ID']);
		$item_type=$_REQUEST['item_type'];
		$order_details=$conn->query("SELECT * FROM `product` WHERE com_id=$com_id and is_active=1 and ptype=$item_type order by steps asc");
		if(mysqli_num_rows($order_details)>0){
			$ic=1;
			while($rows=mysqli_fetch_array($order_details)){
				$jj=$ic++;
				if($rows['ptype']==1){
				?>
				<button  onclick="itemIdWiseDetails('<?php echo $rows['id']."#sep#".$rows['group_id']."#sep#".$rows['product_name']."#sep#".$jj; ?>');" name="btn" value="sub" id="item_btn<?php echo $jj; ?>" class="btn btn-primary"><?php echo $rows['product_name']; ?></button>
				<?php 
				}else{
					?>
					<button  onclick="itemIdWiseDetails('<?php echo $rows['id']."#sep#".$rows['group_id']."#sep#".$rows['product_name']."#sep#".$jj; ?>');" name="btn" value="sub" id="item_btn<?php echo $jj; ?>" class="btn btn-success"><?php echo $rows['product_name']; ?></button>
					<?php 
				}
			}
		}else{
			
		}
	}
	
	if(isset($_REQUEST['select_item_type'])){
		$com_id=($_SESSION['COM_ID']);
		$item_type=$_REQUEST['item_type'];
		$order_details=$conn->query("SELECT * FROM `product` WHERE com_id=$com_id and is_active=1 and ptype=$item_type order by steps asc");
		if(mysqli_num_rows($order_details)>0){
			echo '<option value="">Select Any Item</option>';
			while($rows=mysqli_fetch_array($order_details)){
				?>
				<option value='<?php echo $rows['id']."#sep#".$rows['group_id']."#sep#".$rows['product_name']; ?>'><?php echo $rows['product_name']."(".$rows['group_id'].")"; ?></option>
				<?php 
			}
		}else{
			?>
			<option value=''></option>
			<?php 
		}
	}
	
	if(isset($_REQUEST['setOrdNum'])){
		$com_id=($_SESSION['COM_ID']);
		if($_SESSION['SVERSION']==0){ //0= current, 1=old order
			$ex=explode("#sep#",getOrderNumber($com_id)); 
			echo "A".$ex[0];
		}else if($_SESSION['SVERSION']==1){
			//echo getOrderNumber($com_id); 
			echo "<input type='text' maxlength='15' class='form-control' onkeyup='checkPreviousOrder()' style='width:15%;font-weight: bold;font-size:25px;font-style: italic; background:#0e924f;;color: white;float: left;margin-right: 5px;text-transform:uppercase' autocomplete='off' id='phy_ord_num'/><span id='ord_success'></span>"; 
		}else if($_SESSION['SVERSION']==2){
			echo "<input type='text' maxlength='15' class='form-control' onkeyup='checkPreviousOrderAndMearge()' style='width:15%;font-weight: bold;font-size:25px;font-style: italic; background:#1066ad;color: white;float: left;margin-right: 5px;text-transform:uppercase' autocomplete='off' id='phy_ord_num'/><span id='ord_success'></span>"; 
		}
	}
	
	if(isset($_REQUEST['checkPreviousOrder'])){
		$manual_book_ord=$_REQUEST['phy_ord_num'];
		$com_id=($_SESSION['COM_ID']);
		$duplicate_order=$conn->query("SELECT cus_mobile,cus_name,(select id from customer where cus_mobile=dsms.cus_mobile) cus_id from dsms where phy_ord_num='$manual_book_ord' and com_id=$com_id and is_active=1"); 
		if(mysqli_num_rows($duplicate_order)>0){
			$rows=mysqli_fetch_array($duplicate_order);
			echo 1; // duplicate order number
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['checkPreviousOrder2'])){
		$manual_book_ord=$_REQUEST['phy_ord_num'];
		$com_id=($_SESSION['COM_ID']);
		$duplicate_order=$conn->query("SELECT cus_mobile,cus_name,(select id from customer where cus_mobile=dsms.cus_mobile and is_active=1 limit 0,1) cus_id from dsms where phy_ord_num='$manual_book_ord' and com_id=$com_id and is_active=1"); 
		if(mysqli_num_rows($duplicate_order)>0){
			$rows=mysqli_fetch_array($duplicate_order);
			echo $rows['cus_mobile']."#sep#".$rows['cus_id']."#sep#".$rows['cus_name']; // duplicate order number
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['newMeasurement'])){
		$ord_tbl_id=$_REQUEST['ord_tbl_id'];
		$design_cost=$_REQUEST['design_cost'];
		$amount_cost=$_REQUEST['amount_cost'];
		$item_qty=$_REQUEST['item_qty'];
		$item_type=$_REQUEST['ptye'];
		$item_id=$_REQUEST['item_id'];
		$group_id=$_REQUEST['group_id'];
		$item_name=$_REQUEST['item_name'];
		$master_id=$_REQUEST['master_id'];
		$karigor_id=$_REQUEST['karigor_id'];
		$orderinfo=explode("_",$_REQUEST['orderinfo']);
		$increment_number=$_REQUEST['increment_number'];
		$com_id=($_SESSION['COM_ID']);
		$item_details=$conn->query("SELECT mh.title,mh.mtype,mh.id,mh.group_id,mh.amount FROM `measurement_head` mh WHERE mh.is_active=1 and mh.ptype=$item_type and mh.group_id=$group_id order by mh.steps asc"); // and mh.com_id=$com_id
			mysqli_close($conn);
			if(mysqli_num_rows($item_details)>0){
			while($rows=mysqli_fetch_array($item_details)){
				if($rows['mtype']==1){
				$txtf[]=$rows['title'];
				$txtfid[]=$rows['id'];
				}
				if($rows['mtype']==2){
				$txtselect[]=$rows['title'];
				$txtselectid[]=$rows['id'];
				$txtselectgfid[]=$rows['group_id'];
				$txtselectamountid[]=$rows['amount'];
				}
				if($rows['mtype']==3){
				$txtchk[]=$rows['title'];
				$txtchkid[]=$rows['id'];
				$txtchkamountid[]=$rows['amount'];
				}
				if($rows['mtype']==4){
				$txtarea=$rows['title'];
				$txtareaid=$rows['id'];
				}
			}
			$item_rate=getItemPrice($item_id);
			@$group_name=getGoupName($ord_tbl_id);
		?>
		<div id="delete_measurement<?php echo $increment_number; ?>" style="color: black;box-shadow: inset 0 0 1em gray;padding: 15px;margin-top: 10px;">
		<div class="row">
		<input type="hidden" id="item_id<?php echo $increment_number; ?>" value="<?php echo $item_id; ?>"/>
		<input type="hidden" id="item_id_info<?php echo $increment_number; ?>" value="<?php echo $item_id."#sep#".$group_id."#sep#".$item_name; ?>"/>
		<div class="col-xs-12 col-sm-1">
				<label for="comment">Qty:</label>
				<input class="form-control" onkeyup="itemAmountChange('<?php echo $increment_number; ?>');" style="background: #ffc107;font-weight:bold;text-align: center;" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="" type="text" value="<?php echo $item_qty; ?>" id="item_qty<?php echo $increment_number; ?>"/>
			</div>
			<div class="col-xs-12 col-sm-1">
				<label for="comment">Rate:</label>
				<input class="form-control" readonly onkeyup="itemAmountChange('<?php echo $increment_number; ?>');" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="text-align: right;" type="text" value="<?php echo $item_rate; ?>" id="item_rate<?php echo $increment_number; ?>"/>
			</div>
			<div class="col-xs-12 col-sm-1">
				<label for="comment">Others:</label>
				<input class="form-control" readonly onkeyup="itemAmountChange('<?php echo $increment_number; ?>');" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="text-align: right;" type="text" value="<?php echo @$design_cost; ?>" id="item_others<?php echo $increment_number; ?>"/>
				
			</div>
			
			<div class="col-xs-12 col-sm-1">
				<label for="comment">Amount:</label>
				<input class="form-control" readonly autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="text-align: right;color: blue;font-weight: bold;" type="text" value="<?php echo @$amount_cost; ?>" id="item_amount<?php echo $increment_number; ?>"/>
			</div>
			
			<div class="col-xs-12 col-sm-2">
				<label for="comment">Item:</label>
				
				<input class="form-control" readonly type="text" id="item_name<?php echo $increment_number; ?>" value="<?php echo $item_name; ?>"/>
					
				
			</div>
			<div class="col-xs-12 col-sm-2" style="width: 12%;">
				<label for="comment">Master: <span id="pending_master<?php echo $increment_number; ?>"></span></label>
				<select id="master_id<?php echo $increment_number; ?>"  onchange="getPendingTask('1','master_id','pending_master','<?php echo $increment_number; ?>');" class="form-control">
					<option value="">Select One</option>
						<?php 
							echo getEmpname('1',$master_id);
						?>
				</select>
			</div>
			<div class="col-xs-12 col-sm-2" style="width: 13%;">
				<label for="comment">Karigor: <span id="pending_karigor<?php echo $increment_number; ?>"></span></label>
				<select id="karigor_id<?php echo $increment_number; ?>"  onchange="getPendingTask('2','karigor_id','pending_karigor','<?php echo $increment_number; ?>');" class="form-control">
					<option value="">Select One</option>
						<?php 
							echo getEmpname('2',$karigor_id);
						?>
				</select>
			</div>
			<div class="col-xs-12 col-sm-2">
			<input type="hidden" id="item_type<?php echo $increment_number; ?>" value="<?php echo $item_type; ?>"/>
				<label for="comment">Group Name:</label>
				
				<input class="form-control" type="text" id="group_name<?php echo $increment_number; ?>" value="<?php echo $group_name; ?>"/>
			</div>
			<div>
				<label for="comment" style="color: blue;cursor: pointer;float: right;padding-right: 16px;"><i onclick="copyOnlyMeasurement('<?php echo $item_id; ?>','<?php echo $increment_number; ?>');">Paste</i><input type="radio" style="margin-left: 5px;cursor: pointer;" name="paste_id" onclick="selectedItem('<?php echo $increment_number; ?>')" value="<?php echo $increment_number; ?>"/></label>
				<button onclick="deleteMeasurement('<?php echo $increment_number; ?>');" name="btn" style="" value="sub" id="" class="btn btn-danger">Remove</button><span style="margin-top:20px;position: fixed; margin-left: 6px;" id="dtls_load"></span>
			</div>
		</div>
		<hr style="border-top: 1px solid #d8c3c3;"> </hr>
		<div class="row">
			
			
			<?php
				if($group_id==1 && $item_type==1){
			?>
			
				<?php 
				for($i=0;$i<10;$i++){
				?>
				<div class='col-xs-12 col-sm-2'>
					<p style='font-size: 10px;text-align: center; line-height: 0px;'><?php echo $txtf[$i]; ?></p>
					<p style='font-weight: bold;'>
					<input class="form-control" onkeyup="enterEvent('size<?php echo $increment_number; ?>','<?php echo $i; ?>')" autocomplete="off" style="text-align: center;" value="<?php echo getEditMeasurement($ord_tbl_id,$txtfid[$i],1); ?>" type="text" id="size<?php echo $increment_number; ?><?php echo $i; ?>"/>
					<input type="hidden" id="sizetxt<?php echo $increment_number; ?><?php echo $i; ?>" value="<?php echo $txtfid[$i]; ?>" />
					</p>
				</div>
				
				<?php
				}
				?>
				
				<?php 
				for($i=10;$i<count($txtf);$i++){
				?>
				<div class='col-xs-12 col-sm-2'>
					<p style='font-size: 10px;text-align: center; line-height: 0px;'><?php echo $txtf[$i]; ?></p>
					<p style='font-weight: bold'>
					<input class="form-control" onkeyup="enterEvent('size<?php echo $increment_number; ?>','<?php echo $i; ?>')" autocomplete="off" style="text-align: center;" value="<?php echo getEditMeasurement($ord_tbl_id,$txtfid[$i],1); ?>" type="text" id="size<?php echo $increment_number; ?><?php echo $i; ?>"/>
					<input type="hidden" id="sizetxt<?php echo $increment_number; ?><?php echo $i; ?>" value="<?php echo $txtfid[$i]; ?>" />
					</p>
				</div>
				<?php
				}
				 }else{ 
				for($i=0;$i<count($txtf);$i++){
				?>
				<div class='col-xs-12 col-sm-2'>
					<p style='font-size: 10px;text-align: center; line-height: 0px;'><?php echo $txtf[$i]; ?></p>
					<p style='font-weight: bold;'>
					<input class="form-control" onkeyup="enterEvent('size<?php echo $increment_number; ?>','<?php echo $i; ?>')" autocomplete="off" style="text-align: center;" value="<?php echo getEditMeasurement($ord_tbl_id,$txtfid[$i],1); ?>" type="text" id="size<?php echo $increment_number; ?><?php echo $i; ?>"/>
					<input type="hidden" id="sizetxt<?php echo $increment_number; ?><?php echo $i; ?>" value="<?php echo $txtfid[$i]; ?>" />
					</p>
				</div>
				<?php
				}
			} ?>
			<input type="hidden" id="sizetot<?php echo $increment_number; ?>" value="<?php echo count($txtfid); ?>" />
			
		</div>
		<div class="row" style="overflow:hidden">
			<div class="col-xs-12 col-sm-4" style="margin-top:6px;">
			<table style="width: 100%;">
				<?php 
				for($i=0;$i<count($txtselect);$i++){
				?>
				<input type="hidden" id="propertice_title<?php echo $increment_number; ?><?php echo $i; ?>" value="<?php echo $txtselectid[$i]; ?>" />
				<input type="hidden" id="select_amount<?php echo $increment_number; ?><?php echo $i; ?>" value="<?php echo $txtselectamountid[$i]; ?>" />
				<tr>
					<td>
						<select id="propertice<?php echo $increment_number; ?><?php echo $i; ?>" onchange="calculateSelectAmount('<?php echo $increment_number; ?>','<?php echo $i; ?>');" class="form-control" style="margin-bottom: 10px;float: left;width: 89% !important;">
							<option value=""><?php echo $txtselect[$i]; ?></option>
							<?php 
								echo getSelectDetail_ShEdit($txtselect[$i],$txtselectgfid[$i],$item_type,$ord_tbl_id); //$item_type
							?>
						</select><span>&nbsp;[<span style="color:blue"><?php echo $txtselectamountid[$i]; ?></span>]</span>
					</td>
				</tr>
				<?php
				
				}
				?>
			
			<input type="hidden" id="propertice_title_tot<?php echo $increment_number; ?>" value="<?php echo count($txtselectid); ?>" />
			</table>
			</div>
			<div class="col-xs-12 col-sm-4" style="margin-top:6px;">
				<?php 
				if(isset($txtchk)){
				for($i=0;$i<count($txtchk);$i++){
				?>
				<div class="col-xs-12 col-sm-12">
				<input type="hidden" id="check_amount<?php echo $increment_number; ?><?php echo $i; ?>" value="<?php echo $txtchkamountid[$i]; ?>" />
				<input style="margin-right: 10px;margin-bottom: 10px;" <?php if(getEditMeasurement($ord_tbl_id,$txtchkid[$i],3)==$txtchkid[$i]) echo "checked"; else echo ""; ?> type="checkbox" onclick="getCheckBoxAmount('<?php echo $increment_number; ?>')" class="chkbox" id="expropertice<?php echo $increment_number; ?><?php echo $i; ?>" value="<?php echo $txtchkid[$i]; ?>" /><?php echo $txtchk[$i]; ?>-[<span style="color:blue"><?php echo $txtchkamountid[$i]; ?></span>]
				</div>
				<?php
				}
				}
				?>
				<input type="hidden" id="expropertice_tot<?php echo $increment_number; ?>" value="<?php echo count(@$txtchkid); ?>" />
			</div>
			
		</div>
		<div class="row" style="overflow:hidden;padding-top: 10px;">
			<?php 
				if(isset($txtarea)){
				?>
				<div class="col-xs-12 col-sm-12">
					<textarea style="margin-bottom: 10px;" id="extra_remarks<?php echo $increment_number; ?>" rows="2" cols="5" class="form-control"><?php echo getEditMeasurement($ord_tbl_id,$txtareaid,4); ?></textarea>
				</div>
				<?php
				}
				?>
				<input type="hidden" id="txtareaid<?php echo $increment_number; ?>" value="<?php if(isset($txtareaid)) echo @$txtareaid; else echo 0; ?>" />
		</div>
		</div>
		<?php 
			}else{
				echo 2;
			}
		
	}
	
	if(isset($_REQUEST['get_item_detail_edit'])){
		$master_id=$_REQUEST['master_id'];
		$karigor_id=$_REQUEST['karigor_id'];
		$ord_tbl_id=$_REQUEST['ord_tbl_id'];
		$design_cost=$_REQUEST['design_cost'];
		$amount_cost=$_REQUEST['amount_cost'];
		$item_qty=$_REQUEST['item_qty'];
		$item_type=$_REQUEST['ptye'];
		$item_id=$_REQUEST['item_id'];
		$group_id=$_REQUEST['group_id'];
		$item_name=$_REQUEST['item_name'];
		$orderinfo=$_REQUEST['orderinfo'];
		$com_id=($_SESSION['COM_ID']);
		$item_details=$conn->query("SELECT mh.title,mh.mtype,mh.id,mh.group_id,mh.amount FROM `measurement_head` mh WHERE mh.is_active=1 and mh.ptype=$item_type and mh.group_id=$group_id order by mh.steps asc"); // and mh.com_id=$com_id
			mysqli_close($conn);
			if(mysqli_num_rows($item_details)>0){
			while($rows=mysqli_fetch_array($item_details)){
				if($rows['mtype']==1){
				$txtf[]=$rows['title'];
				$txtfid[]=$rows['id'];
				}
				if($rows['mtype']==2){
				@$txtselect[]=$rows['title'];
				$txtselectid[]=$rows['id'];
				$txtselectgfid[]=$rows['group_id'];
				$txtselectamountid[]=$rows['amount'];
				}
				if($rows['mtype']==3){
				$txtchk[]=$rows['title'];
				$txtchkid[]=$rows['id'];
				$txtchkamountid[]=$rows['amount'];
				}
				if($rows['mtype']==4){
				$txtarea=$rows['title'];
				$txtareaid=$rows['id'];
				}
			}
			$item_rate=getItemPrice($item_id);
			@$group_name=getGoupName($ord_tbl_id);
		?>
		<div style="">
		<div class="row">
		<input type="hidden" id="previous_item_qty" value="<?php echo $item_qty; ?>"/>
		<input type="hidden" id="previous_item_rate" value="<?php echo $item_rate; ?>"/>
		<input type="hidden" id="previous_design_cost" value="<?php echo $design_cost; ?>"/>
		<input type="hidden" id="previous_amount_cost" value="<?php echo $amount_cost; ?>"/>
		<input type="hidden" id="previous_group_name" value="<?php echo $group_name; ?>"/>
		<input type="hidden" id="previous_orderinfo" value="<?php echo $orderinfo; ?>"/>
		<input type="hidden" id="calculate_item_id" value="<?php echo $item_id; ?>"/>
		<input type="hidden" id="item_sl_no" value="<?php echo @$_REQUEST['sl_no']; ?>"/>
		<input type="hidden" id="ord_tbl_id" value="<?php echo $ord_tbl_id; ?>"/>
		<div class="col-xs-12 col-sm-1">
				<label for="comment">Qty:</label>
				<input class="form-control" onkeyup="itemAmountChangeEdit('<?php echo $item_id; ?>');" style="background: #ffc107;font-weight:bold;text-align: center;" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="" type="text" value="<?php echo $item_qty; ?>" id="item_qtye<?php echo $item_id; ?>"/>
			</div>
			<div class="col-xs-12 col-sm-1">
				<label for="comment">Rate:</label>
				<input class="form-control" readonly onkeyup="itemAmountChangeEdit('<?php echo $item_id; ?>');" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="text-align: right;" type="text" value="<?php echo $item_rate; ?>" id="item_ratee<?php echo $item_id; ?>"/>
			</div>
			<div class="col-xs-12 col-sm-1">
				<label for="comment">Others:</label>
				<input class="form-control" readonly onkeyup="itemAmountChangeEdit('<?php echo $item_id; ?>');" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="text-align: right;" type="text" value="<?php echo @$design_cost; ?>" id="item_otherse<?php echo $item_id; ?>"/>
				
			</div>
			
			<div class="col-xs-12 col-sm-1">
				<label for="comment">Amount:</label>
				<input class="form-control" readonly autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="text-align: right;color: blue;font-weight: bold;" type="text" value="<?php echo @$amount_cost; ?>" id="item_amounte<?php echo $item_id; ?>"/>
			</div>
			
			<div class="col-xs-12 col-sm-2">
				<label for="comment">Item:</label>
				
				<input class="form-control" readonly type="text" id="item_namee<?php echo $item_id; ?>" value="<?php echo $item_name; ?>"/>
					
				
			</div>
			<div class="col-xs-12 col-sm-2" style="width: 12%;">
				<label for="comment">Master: <span id="pending_mastere<?php echo $item_id; ?>"></span></label>
				<select id="master_ide<?php echo $item_id; ?>"  onchange="getPendingTask('1','master_ide','pending_mastere','<?php echo $item_id; ?>');" class="form-control">
					<option value="">Select One</option>
						<?php 
							echo getEmpname('1',$master_id);
						?>
				</select>
			</div>
			<div class="col-xs-12 col-sm-2" style="width: 13%;">
				<label for="comment">Karigor: <span id="pending_karigore<?php echo $item_id; ?>"></span></label>
				<select id="karigor_ide<?php echo $item_id; ?>"  onchange="getPendingTask('2','karigor_ide','pending_karigore','<?php echo $item_id; ?>');" class="form-control">
					<option value="">Select One</option>
						<?php 
							echo getEmpname('2',$karigor_id);
						?>
				</select>
			</div>
			<div class="col-xs-12 col-sm-2">
				<label for="comment">Group Name:</label>
				
				<input class="form-control" type="text" id="group_namee<?php echo $item_id; ?>" value="<?php echo $group_name; ?>"/>
			</div>
		</div>
		<hr style="border-top: 1px solid #d8c3c3;"> </hr>
		<div class="row">
			
			
			<?php
				if($group_id==1 && $item_type==1){
			?>
			
				<?php 
				for($i=0;$i<10;$i++){
				?>
				<div class='col-xs-12 col-sm-2'>
					<p style='font-size: 10px;text-align: center; line-height: 0px;'><?php echo $txtf[$i]; ?></p>
					<p style='font-weight: bold;'>
					<input class="form-control" onkeydown="enterEvent('sizee','<?php echo $i; ?>')" autocomplete="off" style="text-align: center;" value="<?php echo getEditMeasurement($ord_tbl_id,$txtfid[$i],1); ?>" type="text" id="sizee<?php echo $i; ?>"/>
					<input type="hidden" id="sizetxte<?php echo $i; ?>" value="<?php echo $txtfid[$i]; ?>" />
					</p>
				</div>
				
				<?php
				}
				?>
				
				<?php 
				for($i=10;$i<count($txtf);$i++){
				?>
				<div class='col-xs-12 col-sm-2'>
					<p style='font-size: 10px;text-align: center; line-height: 0px;'><?php echo $txtf[$i]; ?></p>
					<p style='font-weight: bold'>
					<input class="form-control" onkeydown="enterEvent('sizee','<?php echo $i; ?>')" autocomplete="off" style="text-align: center;" value="<?php echo getEditMeasurement($ord_tbl_id,$txtfid[$i],1); ?>" type="text" id="sizee<?php echo $i; ?>"/>
					<input type="hidden" id="sizetxte<?php echo $i; ?>" value="<?php echo $txtfid[$i]; ?>" />
					</p>
				</div>
				<?php
				}
				 }else{ 
				for($i=0;$i<count($txtf);$i++){
				?>
				<div class='col-xs-12 col-sm-2'>
					<p style='font-size: 10px;text-align: center; line-height: 0px;'><?php echo $txtf[$i]; ?></p>
					<p style='font-weight: bold;'>
					<input class="form-control" onkeydown="enterEvent('sizee','<?php echo $i; ?>')" autocomplete="off" style="text-align: center;" value="<?php echo getEditMeasurement($ord_tbl_id,$txtfid[$i],1); ?>" type="text" id="sizee<?php echo $i; ?>"/>
					<input type="hidden" id="sizetxte<?php echo $i; ?>" value="<?php echo $txtfid[$i]; ?>" />
					</p>
				</div>
				<?php
				}
			} ?>
			<input type="hidden" id="sizetote" value="<?php echo count($txtfid); ?>" />
			
		</div>
		<div class="row" style="overflow:hidden">
			<div class="col-xs-12 col-sm-4" style="margin-top:6px;">
			<table style="width: 100%;">
				<?php 
				if(count($txtselect)>0){
				for($i=0;$i<count($txtselect);$i++){
				?>
				<input type="hidden" id="propertice_titlee<?php echo $i; ?>" value="<?php echo $txtselectid[$i]; ?>" />
				<input type="hidden" id="select_amounte<?php echo $i; ?>" value="<?php echo $txtselectamountid[$i]; ?>" />
				<tr>
					<td>
						<select id="properticee<?php echo $i; ?>" onchange="calculateSelectAmountEdit('<?php echo $item_id; ?>','<?php echo $i; ?>');" class="form-control" style="margin-bottom: 10px;float: left;width: 89% !important;">
							<option value=""><?php echo $txtselect[$i]; ?></option>
							<?php 
								echo getSelectDetail_ShEdit($txtselect[$i],$txtselectgfid[$i],$item_type,$ord_tbl_id); //$item_type
							?>
						</select><span>&nbsp;[<span style="color:blue"><?php echo $txtselectamountid[$i]; ?></span>]</span>
					</td>
				</tr>
				<?php
				}
				}
				?>
			
			<input type="hidden" id="propertice_title_tote" value="<?php echo count($txtselectid); ?>" />
			</table>
			</div>
			<div class="col-xs-12 col-sm-4" style="margin-top:6px;">
				<?php 
				if(isset($txtchk)){
				for($i=0;$i<count($txtchk);$i++){
				?>
				<div class="col-xs-12 col-sm-12">
				<input type="hidden" id="check_amounte<?php echo $i; ?>" value="<?php echo $txtchkamountid[$i]; ?>" />
				<input style="margin-right: 10px;margin-bottom: 10px;" <?php if(getEditMeasurement($ord_tbl_id,$txtchkid[$i],3)==$txtchkid[$i]) echo "checked"; else echo ""; ?> type="checkbox" onclick="getCheckBoxAmountEdit('<?php echo $item_id; ?>')" class="chkbox" id="exproperticee<?php echo $i; ?>" value="<?php echo $txtchkid[$i]; ?>" /><?php echo $txtchk[$i]; ?>-[<span style="color:blue"><?php echo $txtchkamountid[$i]; ?></span>]
				</div>
				<?php
				}
				}
				?>
				<input type="hidden" id="expropertice_tote" value="<?php echo count(@$txtchkid); ?>" />
			</div>
			
		</div>
		<div class="row" style="overflow:hidden;padding-top: 10px;">
			<?php 
				if(isset($txtarea)){
				?>
				<div class="col-xs-12 col-sm-12">
					<textarea style="margin-bottom: 10px;" id="extra_remarkse" rows="2" cols="5" class="form-control"><?php echo getEditMeasurement($ord_tbl_id,$txtareaid,4); ?></textarea>
				</div>
				<?php
				}
				?>
				<input type="hidden" id="txtareaide" value="<?php if(isset($txtareaid)) echo @$txtareaid; else echo 0; ?>" />
		</div>
		</div>
		<?php 
			}else{
				echo 2;
			}
		
	}
	
	
	if(isset($_REQUEST['get_order_details'])){
		$com_id=($_SESSION['COM_ID']);
		$order_details=$conn->query("SELECT ord.id,ord.item_id,ord.ptype,(select cus_price from product where id=ord.item_id) item_price,
		(select artisan_price from product where id=ord.item_id) karigor_price,
		(select product_name from product where id=ord.item_id) product,
		ord.order_number,ord.master_id,ord.group_id,(select user_name from user where id=ord.insert_by) insert_by,
		(select user_name from user where id=ord.master_id) masters,ord.karigor_id,(select user_name from user where id=ord.karigor_id) karigor,ord.item_qty
		FROM `order_record` ord WHERE ord.com_id=$com_id and ord.is_active=0");
			$c=0;$j=0;@$cus_price=0;
			if(mysqli_num_rows($order_details)>0){
			echo '<div id="print_main_body">';
			while($rows=mysqli_fetch_array($order_details)){
				$j=$c++;
				$cus_price+=(intval($rows['item_qty'])*intval($rows['item_price']));
				if($_SESSION['MEASURE_TYPE']==0){
				?>
				<button onclick="delOrderFnc('<?php echo $rows['id']; ?>',<?php echo $j; ?>);" style="margin: 12px;" name="btn" value="sub" id="delOrder<?php echo $j; ?>" class="btn btn-danger">Delete</button>
				
				<div style="border: 1px solid gray;padding-left:5px;padding-right: 5px;padding-top:3px;margin-bottom: 12px;width:604px;height:349px;display: block; page-break-before: always;">
					<div style="border-bottom: 1px solid gray;overflow:hidden">
						<div class="" style="width: 25%;padding-right:15px;line-height: 9px; margin-top: 8px;float:left !important">
							<p style="font-size: 13px;">অর্ডার নম্বর- <b><span id="ord_one<?php echo $j; ?>"></span></b></p>
							<p style="width: 259px;font-size: 12px;">মাস্টার- <?php echo $rows['masters']; ?></p>
							<p style="width: 259px;font-size: 12px;">কারিগর- <?php echo $rows['karigor']; ?></p>
							<input type="hidden" value="<?php echo $rows['product']; ?>" id="item<?php echo $j; ?>"/>
							<input type="hidden" value="<?php echo $rows['item_qty']; ?>" id="item_qty<?php echo $j; ?>"/>
						</div>
						<div style="width: 47%;padding-left:15px;padding-right:15px;text-align: center;line-height: 9px;margin-top: 8px;float:left !important">
							<p style=""><b><?php echo $_SESSION['COM']; ?></b></p>
							<p style="font-size: 13px;"><?php echo $_SESSION['COM_MOBILE']; ?></p>
							<p style="font-size: 12px;text-decoration: underline;font-weight: bold;"><?php echo "Production Copy";//$_SESSION['COM_ADDRESS']; ?></p>
						</div>
						<div class="" style="width: 28%;padding-left:15px;padding-right:15px;line-height: 9px;margin-top: 8px;float:left !important">
							<p style="font-size: 12px;">অর্ডার তা.- <span id="ord_date<?php echo $j; ?>"></span></p>
							<p style="font-size: 12px;">ডেলিভারি তা.- <span id="del_date<?php echo $j; ?>"></span></p>
							<p style="font-size: 11px;">আইটেম- <?php echo $rows['product']."-".$rows['item_qty']." পিছ"; ?></p>
						</div>
					</div>
					
					
					
					<div style="height: 225px;border-bottom: 1px solid gray;">
						<div style="margin-left: 0px;margin-right: 0px;overflow: hidden;padding-top: 14px;">
							<?php echo getMeasurement($rows['id'],1); //1=measurement ?>
						
						</div>
					<div class="row" style="overflow:hidden;">
						<div class="" style="margin-top:8px;padding-left:15px;padding-right:15px;float:left !important">
							<?php 
							echo getMeasurement($rows['id'],2); // selected data
							?>
							
						</div>
						<div class="" style="margin-top:8px;padding-left:15px;padding-right:20px;float:left !important">
							<?php 
							echo getMeasurement($rows['id'],3); // checkbox data
							?>
						</div>
						<div class="" style="margin-top:6px;padding-left:15px;padding-right:15px;float: left; !important">
							<?php
							if($rows['ptype']==1){ //For Gents
							if($_SESSION['SHOW_DESIGN']==1){
								if($rows['product']=="Shirt"){
									?>
										<img src="img/1.png" style="width: 80px;margin-top: -9px;height: 110px;"/>
									<?php 
									}else if($rows['product']=="Fatua"){
										?>
										<img src="img/1.png" style="width:80px;margin-top:-9px;height:110px;"/>
										<?php 
									}else if($rows['product']=="Pant"){
										?>
										<img src="img/3.png" style="width: 100px;height: 110px;"/>
										<?php 
									}else if($rows['product']=="Panjabi"){
										?>
										<img src="img/4.png" style="width: 128px;height: 130px;"/>
										<?php 
									}else if($rows['product']=="Mujib Coat"){
										?>
										<img src="img/5.png" style="width:110px;height: 136px;"/>
										<?php 
									}else if($rows['product']=="Coat"){
										?>
										<img src="img/6.png" style="width: 130px;height: 125px;"/>
										<?php 
									}else if($rows['product']=="Jubbah"){
										?>
										<img src="img/7.png" style="width: 115px;height: 114px; margin-top: -11px;"/>
										<?php 
									}else if($rows['product']=="Sherwani"){
										?>
										<img src="img/8.png" style="width: 120px;height: 135px;"/>
										<?php 
									}else if($rows['product']=="Prince Coat"){
										?>
										<img src="img/9.png" style="width: 105px;height: 130px;"/>
										<?php 
									}else if($rows['product']=="Waistcoat"){
										?>
										<img src="img/10.png" style="width:85px"/>
										<?php 
									}else if($rows['product']=="Kabli"){
										?>
										<img src="img/11.png" style="width: 115px;height:120px;"/>
										<?php 
									}else if($rows['product']=="Pajama"){
										?>
										<img src="img/12.png" style="width:92px;height: 120px;"/>
										<?php 
									}
							}
							}else{
								
							}
							?>
						</div>
					</div>
					<div class="row" style="overflow:hidden;padding-top: 10px;padding-left:15px">
						<?php 
							echo getMeasurement($rows['id'],4); // Txtarea data
						?>
					</div>
				</div>
					
					<div class="row" style="line-height: 11px; margin-top: 12px;margin-bottom: 5px;">
						<div class="" style="width: 26%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 13px;">অর্ডার নম্বর- <b><span id="ord_two<?php echo $j; ?>"></span></b></p>
						<p style="width: 259px;font-size: 12px;">টাকা- <span id="taka<?php echo $j; ?>"><?php echo @$rows['karigor_price']; ?>/=</span></p>
						</div>
						<div class="" style="width: 22%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 12px;">আইটেম- <?php echo $rows['product']; ?></p>
						<p style="font-size: 12px;">সংখ্যা- <?php echo $rows['item_qty']."  পিছ"; ?></p>
						</div>
						<div class="" style="width: 25%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="width: 259px;font-size: 12px;">কারিগর- <span id="karigors<?php echo $j; ?>"><?php echo $rows['karigor']; ?></span></p>
						<p style="width: 259px;font-size: 12px;">মাস্টার- <span id="masters<?php echo $j; ?>"><?php echo $rows['masters']; ?></span></p>
						</div>
						<div class="" style="width: 27%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 12px;">অর্ডার তা.-  <span id="ord_date2<?php echo $j; ?>"></span></p>
						<p style="font-size: 12px;">ডেলিভারি তা.- <span  id="del_date2<?php echo $j; ?>"></span></p>
						</div>
						
					</div>
				</div>
			
				<?php 
			}else{
				
				?>
				<button onclick="delOrderFnc('<?php echo $rows['id']; ?>',<?php echo $j; ?>);" style="margin: 12px;" name="btn" value="sub" id="delOrder<?php echo $j; ?>" class="btn btn-danger">Delete</button>
				<div style="margin-left:50px;margin-top: -5px;padding-left:30px;padding-right: 15px;margin-bottom: 12px;width:604px;height:684px;display: block; page-break-before: always;">
					<div style="overflow:hidden">
						<div class="" style="width: 25%;padding-right:15px;line-height: 9px; margin-top: 8px;float:left !important">
							<p style="font-size: 13px;"> <b><span id="ord_one<?php echo $j; ?>"></span></b></p>
							<p style="width: 259px;font-size: 12px;">মাস্টার- <?php echo $rows['masters']; ?></p>
							<input type="hidden" value="<?php echo $rows['product']; ?>" id="item<?php echo $j; ?>"/>
							<input type="hidden" value="<?php echo $rows['item_qty']; ?>" id="item_qty<?php echo $j; ?>"/>
							
						</div>
						<div style="width: 47%;padding-left:15px;padding-right:15px;text-align: center;line-height: 9px;margin-top: 8px;float:left !important">
							<p style=""><b><?php echo $_SESSION['COM']; ?></b></p>
							<p style="font-size: 13px;"><?php echo $_SESSION['COM_ADDRESS']; ?></p>
							<p style="font-size: 13px;"><?php echo $_SESSION['COM_MOBILE']; ?></p>
							<p style="font-size: 12px;text-decoration: underline;font-weight: bold;"><?php echo "Production Copy";//$_SESSION['COM_ADDRESS']; ?></p>
						</div>
						<div class="" style="width: 28%;padding-left:15px;padding-right:15px;line-height: 9px;margin-top: 8px;float:left !important">
							<!--<p style="font-size: 12px;">অর্ডার তা.- <span id="ord_date<?php //echo $j; ?>"></span></p>-->
							<p style="font-size: 12px;"> <span id="del_date<?php echo $j; ?>"></span></p>
							<p style="font-size: 11px;"> <?php echo $rows['product']."-".$rows['item_qty'].""; ?></p>
						</div>
					</div>
					
					
					
					<div style="height:385px;padding-left: 40px;">
						<span style="float: left;font-size: 11px;font-style: italic;">Received By- <?php echo $rows['insert_by']; ?></span>
						<span style="float: right;font-size: 11px;font-style: italic;">EasyTech24</span>
						<div style="margin-left: 0px;margin-right: 0px;overflow: hidden;padding-top: 60px;width: 555px;">
							<?php echo getMeasurement($rows['id'],1); //1=measurement ?>
						
						</div>
					<div class="row" style="overflow:hidden;">
						<div class="" style="margin-top:8px;padding-left:15px;padding-right:15px;float:left !important">
							<?php 
							echo getMeasurement($rows['id'],2); // selected data
							?>
							
						</div>
						<div class="" style="margin-top:8px;padding-left:15px;padding-right:20px;float:left !important">
							<?php 
							echo getMeasurement($rows['id'],3); // checkbox data
							?>
						</div>
						<div class="" style="margin-top:6px;padding-left:15px;padding-right:15px;float: left; !important">
							<?php
							if($rows['ptype']==1){ //For Gents
							if($_SESSION['SHOW_DESIGN']==1){
								if($rows['product']=="Shirt"){
									?>
										<img src="img/1.png" style="width: 80px;margin-top: -9px;height: 110px;"/>
									<?php 
									}else if($rows['product']=="Fatua"){
										?>
										<img src="img/1.png" style="width:80px;margin-top:-9px;height:110px;"/>
										<?php 
									}else if($rows['product']=="Pant"){
										?>
										<img src="img/3.png" style="width: 100px;height: 110px;"/>
										<?php 
									}else if($rows['product']=="Panjabi"){
										?>
										<img src="img/4.png" style="width: 128px;height: 130px;"/>
										<?php 
									}else if($rows['product']=="Mujib Coat"){
										?>
										<img src="img/5.png" style="width:110px;height: 136px;"/>
										<?php 
									}else if($rows['product']=="Coat"){
										?>
										<img src="img/6.png" style="width: 130px;height: 125px;"/>
										<?php 
									}else if($rows['product']=="Jubbah"){
										?>
										<img src="img/7.png" style="width: 115px;height: 114px; margin-top: -11px;"/>
										<?php 
									}else if($rows['product']=="Sherwani"){
										?>
										<img src="img/8.png" style="width: 120px;height: 135px;"/>
										<?php 
									}else if($rows['product']=="Prince Coat"){
										?>
										<img src="img/9.png" style="width: 105px;height: 130px;"/>
										<?php 
									}else if($rows['product']=="Waistcoat"){
										?>
										<img src="img/10.png" style="width:85px"/>
										<?php 
									}else if($rows['product']=="Kabli"){
										?>
										<img src="img/11.png" style="width: 115px;height:120px;"/>
										<?php 
									}else if($rows['product']=="Pajama"){
										?>
										<img src="img/12.png" style="width:92px;height: 120px;"/>
										<?php 
									}
								}
							}else{
								
							}
							?>
						</div>
					</div>
					<div class="row" style="overflow:hidden;padding-top: 10px;">
						<?php 
							echo getMeasurement($rows['id'],4); // Txtarea data
						?>
					</div>
				</div>
					
					<span style="float: right;font-size: 15px;font-weight: bold;padding-top: 25px;">Job Slip</span>
					<div class="row" style="line-height: 11px; margin-top:50px;margin-bottom: 5px;">
						<div class="" style="width: 26%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 13px;"> <b><span id="ord_two<?php echo $j; ?>"></span></b></p>
						<!--<p style="width: 259px;font-size: 12px;">টাকা- <span id="taka<?php //echo $j; ?>"><?php //echo @$rows['karigor_price']; ?>/=</span></p>-->
						</div>
						<div class="" style="width: 22%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 12px;"> <?php echo $rows['product']; ?></p>
						<p style="font-size: 12px;"> <?php echo $rows['item_qty']." "; ?></p>
						</div>
						<div class="" style="width: 25%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="width: 259px;font-size: 12px;">কারিগর- <span id="karigors<?php echo $j; ?>"><?php echo $rows['karigor']; ?></span></p>
						<!--<p style="width: 259px;font-size: 12px;">মাস্টার- <span id="masters<?php //echo $j; ?>"><?php //echo $rows['masters']; ?></span></p>-->
						</div>
						<div class="" style="width: 27%;padding-left:15px;padding-right:15px;float:left !important">
						<!--<p style="font-size: 12px;">অর্ডার তা.-  <span id="ord_date2<?php //echo $j; ?>"></span></p>-->
						<p style="font-size: 12px;"> <span  id="del_date2<?php echo $j; ?>"></span></p>
						</div>
						
					</div>
				</div>
				<?php 
				}
			}
			echo "</div><input type='hidden' value='$c' id='last_ids'/>";
			echo "<input type='hidden' value='$cus_price' id='tot_cus_price'/>";
			}else{
				echo 2;
			}
	}
	
	if(isset($_REQUEST['del_get_order_details'])){
		$com_id=($_SESSION['COM_ID']);
		$date=date("Y-m-d");
		
		$order_details=$conn->query("SELECT ord.id,ord.item_id,ord.ptype,(select cus_price from product where id=ord.item_id) item_price,
		(select artisan_price from product where id=ord.item_id) karigor_price,
		(select product_name from product where id=ord.item_id) product,
		ord.order_number,ord.master_id,ord.group_id,
		(select user_name from user where id=ord.master_id) masters,ord.karigor_id,(select user_name from user where id=ord.karigor_id) karigor,ord.item_qty
		FROM `order_record` ord WHERE ord.com_id=$com_id and ord.is_active=2 and date(insert_date)='$date' order by ord.id desc");
			$c=0;$j=0;@$cus_price=0;
			echo '<div id="print_main_body_del">';
			if(mysqli_num_rows($order_details)>0){
			while($rows=mysqli_fetch_array($order_details)){
				$j=$c++;
				$cus_price+=(intval($rows['item_qty'])*intval($rows['item_price']));
				?>
				<button onclick="activeOrderFnc('<?php echo $rows['id']; ?>',<?php echo $j; ?>);" style="margin: 12px;" name="btn" value="sub" id="actOrder<?php echo $j; ?>" class="btn btn-info">Active</button>
				<div style="border: 1px solid gray;padding-left:5px;padding-right: 5px;padding-top:5px;margin-bottom: 12px;width:604px;height:716px;display: block; page-break-before: always;">
					<div style="border-bottom: 1px solid gray;overflow:hidden">
						<div class="" style="width: 25%;padding-right:15px;line-height: 9px; margin-top: 8px;float:left !important">
							<p style="font-size: 13px;">অর্ডার নম্বর- <b><?php //echo $rows['order_number']; ?></b></p>
							<p style="width: 259px;font-size: 12px;">মাস্টার- <?php echo $rows['masters']; ?></p>
							<p style="width: 259px;font-size: 12px;">কারিগর- <?php echo $rows['karigor']; ?></p>
							<input type="hidden" value="<?php echo $rows['product']; ?>" id="item<?php echo $j; ?>"/>
							<input type="hidden" value="<?php echo $rows['item_qty']; ?>" id="item_qty<?php echo $j; ?>"/>
						</div>
						<div style="width: 47%;padding-left:15px;padding-right:15px;text-align: center;line-height: 9px;margin-top: 8px;float:left !important">
							<p style=""><b><?php echo $_SESSION['COM']; ?></b></p>
							<p style="font-size: 13px;"><?php echo $_SESSION['COM_MOBILE']; ?></p>
							<p style="font-size: 12px;text-decoration: underline;font-weight: bold;"><?php echo "Production Copy";//$_SESSION['COM_ADDRESS']; ?></p>
						</div>
						<div class="" style="width: 28%;padding-left:15px;padding-right:15px;line-height: 9px;margin-top: 8px;float:left !important">
							<p style="font-size: 12px;">অর্ডার তা.- <span id="ord_date<?php echo $j; ?>"></span></p>
							<p style="font-size: 12px;">ডেলিভারি তা.- <span id="del_date<?php echo $j; ?>"></span></p>
							<p style="font-size: 11px;">আইটেম- <?php echo $rows['product']."-".$rows['item_qty']." পিছ"; ?></p>
						</div>
					</div>
					
					
					
					<div style="height: 400px;border-bottom: 1px solid gray;">
						<span style="float: right;font-size: 11px;font-style: italic;">EasyTech24</span>
						<div style="margin-left: 0px;margin-right: 0px;overflow: hidden;padding-top: 14px;">
							<?php echo getMeasurementDel($rows['id'],1); //1=measurement ?>
						
						</div>
					<div class="row" style="overflow:hidden;">
						<div class="" style="margin-top:8px;padding-left:15px;padding-right:15px;float:left !important">
							<?php 
							echo getMeasurementDel($rows['id'],2); // selected data
							?>
							
						</div>
						<div class="" style="margin-top:8px;padding-left:15px;padding-right:20px;float:left !important">
							<?php 
							echo getMeasurementDel($rows['id'],3); // checkbox data
							?>
						</div>
						<div class="" style="margin-top:6px;padding-left:15px;padding-right:15px;float: left; !important">
							<?php
							if($rows['ptype']==1){ //For Gents
								if($_SESSION['SHOW_DESIGN']==1){
									if($rows['product']=="Shirt"){
										?>
											<img src="img/1.png" style="width: 80px;margin-top: -9px;height: 110px;"/>
										<?php 
										}else if($rows['product']=="Fatua"){
											?>
											<img src="img/1.png" style="width:80px;margin-top:-9px;height:110px;"/>
											<?php 
										}else if($rows['product']=="Pant"){
											?>
											<img src="img/3.png" style="width: 100px;height: 110px;"/>
											<?php 
										}else if($rows['product']=="Panjabi"){
											?>
											<img src="img/4.png" style="width: 128px;height: 130px;"/>
											<?php 
										}else if($rows['product']=="Mujib Coat"){
											?>
											<img src="img/5.png" style="width:110px;height: 136px;"/>
											<?php 
										}else if($rows['product']=="Coat"){
											?>
											<img src="img/6.png" style="width: 130px;height: 125px;"/>
											<?php 
										}else if($rows['product']=="Jubbah"){
											?>
											<img src="img/7.png" style="width: 115px;height: 114px; margin-top: -11px;"/>
											<?php 
										}else if($rows['product']=="Sherwani"){
											?>
											<img src="img/8.png" style="width: 120px;height: 135px;"/>
											<?php 
										}else if($rows['product']=="Prince Coat"){
											?>
											<img src="img/9.png" style="width: 105px;height: 130px;"/>
											<?php 
										}else if($rows['product']=="Waistcoat"){
											?>
											<img src="img/10.png" style="width:85px"/>
											<?php 
										}else if($rows['product']=="Kabli"){
											?>
											<img src="img/11.png" style="width: 115px;height:120px;"/>
											<?php 
										}else if($rows['product']=="Pajama"){
											?>
											<img src="img/12.png" style="width:92px;height: 120px;"/>
											<?php 
										}
									}
							}else{
								
							}
							?>
						</div>
					</div>
					<div class="row" style="overflow:hidden;padding-top: 10px;padding-left: 15px;">
						<?php 
							echo getMeasurementDel($rows['id'],4); // Txtarea data
						?>
					</div>
				</div>
					
					<span style="float: right;font-size: 15px;font-weight: bold;padding-top: 3px;">Job Slip</span>
					<div class="row" style="line-height: 11px; margin-top: 25px;margin-bottom: 5px;">
						<div class="" style="width: 26%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 13px;">অর্ডার নম্বর- <b><?php echo $rows['order_number']; ?></b></p>
						<p style="width: 259px;font-size: 12px;">টাকা- <span id="taka<?php echo $j; ?>"><?php echo @$rows['karigor_price']; ?>/=</span></p>
						</div>
						<div class="" style="width: 22%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 12px;">আইটেম- <?php echo $rows['product']; ?></p>
						<p style="font-size: 12px;">সংখ্যা- <?php echo $rows['item_qty']."  পিছ"; ?></p>
						</div>
						<div class="" style="width: 25%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="width: 259px;font-size: 12px;">কারিগর- <span id="karigors<?php echo $j; ?>"><?php echo $rows['karigor']; ?></span></p>
						<p style="width: 259px;font-size: 12px;">মাস্টার- <span id="masters<?php echo $j; ?>"><?php echo $rows['masters']; ?></span></p>
						</div>
						<div class="" style="width: 27%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 12px;">অর্ডার তা.-  <span id="ord_date2<?php echo $j; ?>"></span></p>
						<p style="font-size: 12px;">ডেলিভারি তা.- <span  id="del_date2<?php echo $j; ?>"></span></p>
						</div>
						
					</div>
				</div>
			
				<?php 
			}
			}
			
	}
	
	if(isset($_REQUEST['showMasterMemo'])){
		$com_id=($_SESSION['COM_ID']);
		$memo_id=$_REQUEST['memo_id'];
		$emp_type=($_REQUEST['emp_type']==1)? 'মাস্টার' : 'কারিগর';
		$emp_name=$_REQUEST['emp_name'];
		$mdate=$_REQUEST['mdate'];
		
		$memo_details=$conn->query("SELECT ds.*,(select product_name from product where id=ds.item_ids) item_name FROM `wages_details` ds WHERE ds.`is_active`=1 and ds.`memo_id`=$memo_id");
		
				?>
					<div class="row" style="background:white">
					<div class="col-xs-12 col-sm-12">
								
								<?php 
							$tprofit=0;
							if(mysqli_num_rows($memo_details)>0){
								?>
								<label>Memo No: <?php echo $memo_id; ?> <br/> <span style="color:blue"><?php echo $emp_type.': '.$emp_name; ?></span> <br/> তারিখ: <?php echo $mdate; ?></label>
								<table id="dynamic-table" class="table table-striped table-bordered table-hover">
									<thead>
										<tr>
											<th style="width:5%;text-align: center;">Sl</th>
											<th style="width:15%;text-align:center">Order</th>
											<th style="width:55%;">Item</th>
											<th style="width:20%;text-align:center">Qty</th>
											<th style="width:20%;text-align:right">Taka/=</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl=1;$tot_qty=0;
											while($rows=mysqli_fetch_array($memo_details)){
													$c=$sl++;
													$tot_qty+=$rows['taka'];
													?>
													<tr>
														<td style="text-align: center;"><?php echo $c; ?></td>
														<td style="text-align:center">
															<?php echo $rows['order_num']; ?>
														</td>
														<td>
															<?php echo $rows['item_name']; ?>
														</td>
														<td style="text-align:center">
															<?php echo $rows['item_qty']; ?>
														</td>
														<td style="text-align: right;"><?php echo $rows['taka']; ?>/=</td>
													</tr>
													<?php 
												}
										?>
										<tr>
											<td colspan="3" style="text-align: right;font-weight:bold">Total</td>
											<td style="text-align: right;font-weight:bold"><?php echo $tot_qty; ?>/=</td>
										</tr>
									</tbody>
									
								</table>
								<?php 
							}else{
								echo "No Item Found!";
							}
							?>	
	
					</div>
							
					</div>
					<?php 
	}
	
	if(isset($_REQUEST['updateAnyColumn'])){
		$mobile=$_REQUEST['mobile'];
		$cus_id=$_REQUEST['cus_id'];
		$id=$_REQUEST['id'];
		?>
		<input style="text-align: center;width: 100%;" onkeyup="updateFabMobile('<?php echo $id; ?>','<?php echo $cus_id; ?>');" type="text" value="<?php echo $mobile; ?>" id="cus_mobile_edit_field<?php echo $id; ?>" class="form-control"/>
		<?php 
	}
	
	if(isset($_REQUEST['updateFabMobile'])){
		$mobile=trim($_REQUEST['mobile']);
		$id=$_REQUEST['id'];
		$cus_id=$_REQUEST['cus_id'];
		$conn->query("update customer set cus_mobile='$mobile' where id=$cus_id");
		$last_insert_head=$conn->query("update direct_sale_head set cus_mobile='$mobile' where id=$id");
		if($last_insert_head){
			echo 1;
		}
	}
	
	if(isset($_REQUEST['showMasterDayWise'])){
		
		$com_id=($_SESSION['COM_ID']);
		$emp_id=$_REQUEST['emp_id'];
		$start_date=$_REQUEST['start_date'];
		$end_date=$_REQUEST['end_date'];
		$emp_type=($_REQUEST['emp_type']==1)? 'মাস্টার' : 'কারিগর';
		$emp_name=$_REQUEST['emp_name'];
		$emp_mobile=$_REQUEST['emp_mobile'];
		//$mdate=$_REQUEST['mdate'];
		
		$mstart_dates=explode("-",$start_date);
		$mend_dates=explode("-",$end_date);
		@$mstart_date=$mstart_dates[2].'/'.$mstart_dates[1].'/'.$mstart_dates[0];
		@$mend_date=$mend_dates[2].'/'.$mend_dates[1].'/'.$mend_dates[0];
		
		$memo_details=$conn->query("SELECT sum(`taka`) taka,sum(`item_qty`) item_qty,(select product_name from product where id=wages_details.item_ids limit 0,1) item_name,GROUP_CONCAT(`order_num`) order_num FROM `wages_details` WHERE `is_active`=1 and `status`=0 and `emp_type`=1 and date(insert_date) between '$start_date' and '$end_date' and emp_id=$emp_id GROUP by wages_details.`item_ids`");
		
				?>
					<div style="background:white">
								
								<?php 
							$tprofit=0;
							if(mysqli_num_rows($memo_details)>0){
								?>
								<div class="panel-body">
			
							<div class="row">
							<button onclick="printOrder('summery_report2');" style="margin-right:15px" name="btn" id="printBtns" value="sub" class="btn btn-info">Print</button>
								
								<span id="summery_report2">
								<div id='print_area' style='overflow:hidden;margin-top:5px;margin-bottom: 6px; width:290px;display: block; page-break-before: always;'>
									<div style='overflow:hidden;padding-top:25px;'>	
										<div style='line-height: 5px;padding-top:15px;text-align:center;'>	
											<p style='font-size: 15px;font-weight: bold;padding-top:0px;'><?php echo $_SESSION['COM']; ?></p>
											<p style='font-size: 12px; font-weight: bold;padding-top: 0px;'><?php echo $_SESSION['COM_ADDRESS']; ?></p>
											<p style='font-size: 11px; font-weight: bold;padding-top: 0px;'><?php echo $_SESSION['EMAIL']; ?></p>
											<p style='font-size: 11px; font-weight: bold;padding-top: 0px;'><?php echo $_SESSION['COM_MOBILE']; ?></p>
										</div>
										
									</div>
									
									<div style='overflow:hidden;margin-top: 20px;'>	
										<div style='float:left; padding-left: 6px;'>	
											<p style='font-size: 10px;'><b>Date:</b> <?php echo $mstart_date.' to '.$mend_date; ?></span>
										</div>
										<div style='float:right; padding-right: 6px;'>	
											<p style='font-size: 10px;'><?php //echo $dates; ?></p>
										</div>
									</div>
									<div style='overflow:hidden;margin-top: 0px;'>	
										<div style='float:left; padding-left: 6px;width: 50%;'>	
											<p style='font-size: 10px;'><b><?php echo $emp_type; ?>:</b> <?php echo $emp_name; ?></span>
										</div>
										<div style='float:left; padding-right: 6px;width:50%;text-align:right;'>	
											<p style='font-size: 10px;'><?php echo $emp_mobile; ?></p>
										</div>
									</div>
									<div style='overflow:hidden;margin-top: -3px;margin-left: 6px;
											margin-right: 6px;'>	
									<div style='width: 100%;margin-bottom: -6px;'>	
											-----------------------------------------------------------
									</div>
										<div style='overflow:hidden;font-size: 10px;
											font-weight: bold;text-align:center;margin-bottom: -7px;'>	
											<div style='float:left;width: 7%;'>	
												Sl
											</div>
											<div style='float:left;width:20%;text-align:left'>	
												Order
											</div>
											<div style='float:left;width: 33%;text-align:left'>	
												Item
											</div>
											<div style='float:left;width: 20%;text-align: center;'>	
												Qty
											</div>
											<div style='float:left;width: 20%;text-align: right;padding-right: 5px;'>	
												Taka
											</div>
										</div>
									<div style='width: 100%;margin-bottom: -6px;'>	
											-----------------------------------------------------------
									</div>
									<div style=''>
										<div style='overflow:hidden;font-size: 9px;
											font-weight: bold;text-align:center;
											padding-bottom: 15px;'>	
											<?php 
												$sl=1;$tot_qty=0;
												while($rows=mysqli_fetch_array($memo_details)){
														$c=$sl++;
														$tot_qty+=$rows['taka'];
														$ord=explode(',',$rows['order_num']);
														$onum=implode(' ',$ord);
														?>
														<div style="overflow:hidden;margin-bottom: 8px;border-bottom: 1px dotted gray;">
															<div style='float:left;width: 7%;'>	
																<?php echo $c; ?>
															</div>
															<div style='float:left;width: 20%;text-align:left;font-size:8px'>	
																<?php echo $onum; ?>
															</div>
															<div style='float:left;width: 33%;text-align:left'>	
																<?php echo $rows['item_name']; ?>
															</div>
															<div style='float:left;width: 20%;text-align: center;'>	
																<?php echo $rows['item_qty']; ?>
															</div>
															<div style='float:left;width: 20%;text-align: right;padding-right: 5px;'>	
																<?php echo $rows['taka']; ?>/=
															</div>
														</div>
														
														<?php 
													}
											?>
										</div>
									</div>
									<div style='width: 100%;margin-bottom: -6px;'>	
											-----------------------------------------------------------
									</div>
										<div style='overflow:hidden;font-size: 10px;
											font-weight: bold;text-align:center;
											
											padding-bottom: 3px;
											'>	
											<div style='float: left;text-align: right;width: 204px;'>	
												Total: 
											</div>
											<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 10px;'>	
												<?php echo $tot_qty; ?>
											</div>
											
										</div>
										
									<div style='width: 100%;margin-bottom: -6px;'>	
											-----------------------------------------------------------
									</div>
									
									</div>
									<div style='width: 100%;text-align: center;padding-top: 65px;padding-bottom: 8px;'>	
											Print By: <?php echo $_SESSION['USER']; ?>
									</div>
									<div style='width: 100%;text-align: center;padding-top: 15px;padding-bottom: 50px;'>	
											Print Date: <?php echo date('d/m/Y'); ?>
									</div>
									<div style='width: 100%;text-align: center;padding-top: 65px;padding-bottom: 50px;'>	
											*** Thank You ***
									</div>
									
								</div>
							</span>
							</div>
					 </div>
								<?php 
							}else{
								echo "No Item Found!";
							}
							?>	
	
					
							
					</div>
					<?php 
	}
	
	if(isset($_REQUEST['dateWisePrint'])){
		$com_id=($_SESSION['COM_ID']);
		$print_type=trim($_REQUEST['print_type']);
		@$mobile=trim($_REQUEST['mobile']);
		@$order_number=trim($_REQUEST['order_number']);
		if($_REQUEST['date1']!=""){
			$date1=trim($_REQUEST['date1']);
			$ex=explode("/",$date1);
			$date1=$ex[2]."-".$ex[1]."-".$ex[0];
		}
		if($print_type==2){
			if($_SESSION['MEASURE_TYPE']==0){ //stardard
				echo printMoneyReceipt2($order_number);
				
			}else{ //local copy and normal copy
				if($_REQUEST['date1']!=""){
			
					$order_details=$conn->query("SELECT ord.id,ord.item_id,ord.ptype,(select cus_price from product where id=ord.item_id) item_price,
				(select artisan_price from product where id=ord.item_id) karigor_price,
				(select product_name from product where id=ord.item_id) product,(select user_name from user where id=ord.insert_by) insert_by,
				ord.order_number,ord.master_id,ord.group_id,date(ord.insert_date) insert_date,ds.dv_date,ds.fddate,ds.fdtime,
				(select user_name from user where id=ord.master_id) masters,ord.karigor_id,(select user_name from user where id=ord.karigor_id) karigor,ord.item_qty
				FROM `order_record` ord,dsms ds WHERE ds.id=ord.dsms_id and ord.com_id=$com_id and date(ds.insert_date)='$date1' and ord.is_active=1");
				}
				
				if($_REQUEST['mobile']!=""){
					
					$order_details=$conn->query("SELECT ord.id,ord.item_id,ord.ptype,(select cus_price from product where id=ord.item_id) item_price, 
					(select artisan_price from product where id=ord.item_id) karigor_price,
					(select product_name from product where id=ord.item_id) product,(select user_name from user where id=ord.insert_by) insert_by,
					ord.order_number,ord.master_id,ord.group_id,date(ds.insert_date) insert_date,
					(select user_name from user where id=ord.master_id) masters,ds.dv_date,
					ord.karigor_id,(select user_name from user where id=ord.karigor_id) karigor,ds.fddate,ds.fdtime,
					ord.item_qty FROM `order_record` ord,dsms ds WHERE ds.id=ord.dsms_id and ord.com_id=$com_id and ds.cus_mobile='$mobile' and ds.is_active=1 and ord.is_active=1 limit 0,10");
				}
				
				if(@$_REQUEST['serial_no']!=""){
					$serial_no=trim($_REQUEST['serial_no']);
					$order_details=$conn->query("SELECT ord.id,ord.item_id,ord.ptype,(select cus_price from product where id=ord.item_id) item_price, 
					(select artisan_price from product where id=ord.item_id) karigor_price,
					(select product_name from product where id=ord.item_id) product,(select user_name from user where id=ord.insert_by) insert_by,
					ord.order_number,ord.master_id,ord.group_id,date(ds.insert_date) insert_date,
					(select user_name from user where id=ord.master_id) masters,ds.dv_date,
					ord.karigor_id,(select user_name from user where id=ord.karigor_id) karigor,ds.fddate,ds.fdtime,
					ord.item_qty FROM `order_record` ord,dsms ds WHERE ds.id=ord.dsms_id and ord.com_id=$com_id and ds.phy_ord_num='$serial_no' and ds.is_active=1 and ord.is_active=1 limit 0,10");
				}
		
				if($_REQUEST['order_number']!=""){
					
					$order_number=explode(",",$_REQUEST['order_number']);
					for($i=0;$i<count($order_number);$i++){
						@$all_ord.="'".$order_number[$i]."',";
					}
					@$all_ord=substr($all_ord,0,-1);
					
					$order_details=$conn->query("SELECT ord.id,ord.item_id,ord.ptype,(select cus_price from product where id=ord.item_id) item_price,
					(select artisan_price from product where id=ord.item_id) karigor_price,
					(select product_name from product where id=ord.item_id) product,(select user_name from user where id=ord.insert_by) insert_by,
					ord.order_number,ord.master_id,ord.group_id,date(ord.insert_date) insert_date,ds.dv_date,ds.fddate,ds.fdtime,
					(select user_name from user where id=ord.master_id) masters,ord.karigor_id,(select user_name from user where id=ord.karigor_id) karigor,ord.item_qty
					FROM `order_record` ord,dsms ds WHERE ds.id=ord.dsms_id and ord.com_id=$com_id and ord.order_number in($all_ord) and ord.is_active=1");
				}
		
		mysqli_close($conn);
		if(mysqli_num_rows($order_details)>0){
			$c=0;$j=0;@$cus_price=0;
			$dday=$_SESSION['FAC_DELIVERY'];
			while($rows=mysqli_fetch_array($order_details)){
				$j=$c++;
				@$karigor_dv_date =date('Y-m-d', strtotime($rows['dv_date']. " - $dday days"));
				if($_SESSION['MEASURE_TYPE']==2){ //border: 1px solid gray;
				?>
				<div id="main_body" style="margin-left: 160px;padding-left:5px;padding-right: 5px;padding-top:3px;margin-bottom: 12px;width:395px;height:550px;display: block; page-break-before: always;">
					<div style="border-bottom: 1px solid gray;overflow:hidden">
						<!--<div class="" style="width: 25%;padding-right:15px;line-height: 9px; margin-top: 8px;float:left !important">
							<p style="font-size: 13px;">অর্ডার নম্বর- <b><?php echo $rows['order_number']; ?></b></p>
							<p style="width: 259px;font-size: 12px;">মাস্টার- <span id="master<?php echo $j; ?>" onclick="setEmployee2(<?php echo $j; ?>);"><?php if($rows['masters']=="") echo "---"; else echo $rows['masters']; ?></span><span id="master_select_box<?php echo $j; ?>"></span></p>
							<input type="hidden" value="<?php echo @$rows['master_id']."#sep#1#sep#".$rows['id']; ?>" id="master_hidden_id<?php echo $j; ?>"/>
							<p style="width: 259px;font-size: 12px;">কারিগর- <span id="karigor<?php echo $j; ?>" onclick="setEmployee(<?php echo $j; ?>)"><?php if($rows['karigor']=="") echo "---"; else echo $rows['karigor']; ?></span><span id="karigor_select_box<?php echo $j; ?>"></span></p>
							<input type="hidden" value="<?php echo @$rows['karigor_id']."#sep#2#sep#".$rows['id']; ?>" id="karigor_hidden_id<?php echo $j; ?>"/>
						</div>-->
						<div style="text-align: center;line-height: 9px; margin-top: 8px;">
							<p style=""><b><?php echo $_SESSION['COM']; ?></b></p>
							<p style="font-size: 13px;"><?php echo $_SESSION['COM_MOBILE']; ?></p>
							<p style="font-size: 12px;text-decoration: underline;font-weight: bold;"><?php echo "Production Copy";//$_SESSION['COM_ADDRESS']; ?></p>
						</div>
						<!--<div class="" style="width: 28%;padding-left:15px;padding-right:15px;line-height: 9px;margin-top: 8px;float:left !important">
							<p style="font-size: 12px;">অর্ডার তা.- <span id="ord_date<?php echo $j; ?>"><?php echo date('d/m/Y',strtotime($rows['insert_date'])); ?></span></p>
							<p style="font-size: 12px;">ডেলিভারি তা.- <span id="del_date<?php echo $j; ?>"><?php echo (@$rows['fddate']=="")? date('d/m/Y',strtotime($karigor_dv_date)) : $rows['fddate']." ".$rows['fdtime']; ?></span></p>
							<p style="font-size: 11px;">আইটেম- <?php echo $rows['product']."-".$rows['item_qty']." পিছ"; ?></p>
						</div>-->
					</div>
					
					<div style="padding-top:5px;overflow:hidden">
						<div style="float:left;">
							<p style=""><b>SL: <?php echo $rows['order_number']; ?></b></p>
						</div>
						<div style="float: right;">
							<p style=""><b><?php echo $rows['product']."-".$rows['item_qty']." পিছ"; ?></b></p>
						</div>
					</div>
					
					<div style="height: 400px;border-bottom: 1px solid gray;">
						<div style="margin-left: 0px;margin-right: 0px;overflow: hidden;padding-top: 14px;">
								<?php echo getMeasurement2($rows['id'],1); //1=measurement ?>
							
						</div>
						<div class="row" style="overflow:hidden;">
							<div class="" style="margin-top:8px;padding-left:15px;padding-right:15px;float:left !important">
								<?php 
								echo getMeasurement2($rows['id'],2)." ".getMeasurement2($rows['id'],3)." ".getMeasurement2($rows['id'],4); // selected data
								?>
								
							</div>
							<!--<div class="" style="margin-top:8px;padding-left:15px;padding-right:20px;float:left !important">
								<?php 
								//echo getMeasurement2($rows['id'],3); // checkbox data
								?>
							</div>-->
							<div class="" style="margin-top:-10px;padding-left:15px;padding-right:15px;float:left !important">
								<?php
								if($_SESSION['SHOW_DESIGN']==1){
									if($rows['ptype']==1){
										if($rows['product']=="Shirt"){
										?>
											<img src="img/1.png" style="width: 80px;margin-top: -9px;height: 110px;"/>
										<?php 
										}else if($rows['product']=="Fatua"){
											?>
											<img src="img/1.png" style="width:80px;margin-top:-9px;height:110px;"/>
											<?php 
										}else if($rows['product']=="Pant"){
											?>
											<img src="img/3.png" style="width: 100px;height: 110px;"/>
											<?php 
										}else if($rows['product']=="Panjabi"){
											?>
											<img src="img/4.png" style="width: 128px;height: 130px;"/>
											<?php 
										}else if($rows['product']=="Mujib Coat"){
											?>
											<img src="img/5.png" style="width:110px;height: 136px;"/>
											<?php 
										}else if($rows['product']=="Coat"){
											?>
											<img src="img/6.png" style="width: 130px;height: 125px;"/>
											<?php 
										}else if($rows['product']=="Jubbah"){
											?>
											<img src="img/7.png" style="width: 115px;height: 114px; margin-top: -11px;"/>
											<?php 
										}else if($rows['product']=="Sherwani"){
											?>
											<img src="img/8.png" style="width: 120px;height: 135px;"/>
											<?php 
										}else if($rows['product']=="Prince Coat"){
											?>
											<img src="img/9.png" style="width: 105px;height: 130px;"/>
											<?php 
										}else if($rows['product']=="Waistcoat"){
											?>
											<img src="img/10.png" style="width:85px"/>
											<?php 
										}else if($rows['product']=="Kabli"){
											?>
											<img src="img/11.png" style="width: 115px;height:120px;"/>
											<?php 
										}else if($rows['product']=="Pajama"){
											?>
											<img src="img/12.png" style="width:92px;height: 120px;"/>
											<?php 
										}
									}else{
										
									}
								}
								?>
							</div>
						</div>
						<!--<div class="row" style="overflow:hidden;padding-top: 10px;padding-left: 15px;">
						<?php 
							//echo getMeasurement2($rows['id'],4); // Txtarea data
						?>
						</div>-->
					</div>
					<div style="padding-top:5px;overflow:hidden">
						<div style="float:left;">
							<p style=""><b>অর্ডার তা.-  <span><?php echo date('d/m/Y',strtotime($rows['insert_date'])); ?></b></p>
						</div>
						<div style="float: right;">
							<p style=""><b>ডেলিভারি তা.- <span><?php echo (@$rows['fddate']=="")? date('d/m/Y',strtotime($karigor_dv_date)) : $rows['fddate']." ".$rows['fdtime']; ?></b></p>
						</div>
					</div>
					<!--<div class="row" style="line-height: 11px; margin-top: 12px;margin-bottom: 5px;">
						<div class="" style="width: 26%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 13px;">অর্ডার নম্বর- <b><?php echo $rows['order_number']; ?></b></p>
						<p style="width: 259px;font-size: 12px;">টাকা- <span id="taka<?php echo $j; ?>"><?php echo @$rows['karigor_price']; ?>/=</span></p>
						</div>
						<div class="" style="width: 22%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 12px;">আইটেম- <?php echo $rows['product']; ?></p>
						<p style="font-size: 12px;">সংখ্যা- <?php echo $rows['item_qty']."  পিছ"; ?></p>
						</div>
						<div class="" style="width: 25%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="width: 259px;font-size: 12px;">কারিগর- <span id="karigors<?php echo $j; ?>"><?php echo $rows['karigor']; ?></span></p>
						<p style="width: 259px;font-size: 12px;">মাস্টার- <span id="masters<?php echo $j; ?>"><?php echo $rows['masters']; ?></span></p>
						</div>
						<div class="" style="width: 27%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 12px;">অর্ডার তা.-  <span id="ord_date2<?php echo $j; ?>"><?php echo date('d/m/Y',strtotime($rows['insert_date'])); ?></span></p>
						<p style="font-size: 12px;">ডেলিভারি তা.- <span  id="del_date2<?php echo $j; ?>"><?php echo (@$rows['fddate']=="")? date('d/m/Y',strtotime($karigor_dv_date)) : $rows['fddate']." ".$rows['fdtime']; ?></span></p>
						</div>
						
					</div>-->
				</div>
				<?php 
				}else if($_SESSION['MEASURE_TYPE']==1){ //Normal Copy
					?>
					<div id="main_body" style="margin-left:50px;margin-top: 0px;padding-left:30px;padding-right: 15px;padding-top:5px;margin-bottom: 12px;width:604px;height:684px;display: block; page-break-before: always;">
					<div style="overflow:hidden">
						<div class="" style="width: 25%;padding-right:15px;line-height: 9px; margin-top: 8px;float:left !important">
							<p style="font-size: 13px;"> <b><?php echo $rows['order_number']; ?></b></p>
							<p style="width: 259px;font-size: 12px;">মাস্টার- <span id="master<?php echo $j; ?>" onclick="setEmployee2(<?php echo $j; ?>);"><?php if($rows['masters']=="") echo "---"; else echo $rows['masters']; ?></span><span id="master_select_box<?php echo $j; ?>"></span></p>
							<input type="hidden" value="<?php echo @$rows['master_id']."#sep#1#sep#".$rows['id']; ?>" id="master_hidden_id<?php echo $j; ?>"/>
							
							<input type="hidden" value="<?php echo @$rows['karigor_id']."#sep#2#sep#".$rows['id']; ?>" id="karigor_hidden_id<?php echo $j; ?>"/>
						</div>
						<div style="width: 47%;padding-left:15px;padding-right:15px;text-align: center;line-height: 9px;margin-top: 8px;float:left !important">
							<p style=""><b><?php echo $_SESSION['COM']; ?></b></p>
							<p style="font-size: 13px;"><?php echo $_SESSION['COM_ADDRESS']; ?></p>
							<p style="font-size: 13px;"><?php echo $_SESSION['COM_MOBILE']; ?></p>
							<p style="font-size: 12px;text-decoration: underline;font-weight: bold;"><?php echo "Production Copy";//$_SESSION['COM_ADDRESS']; ?></p>
						</div>
						<div class="" style="width: 28%;padding-left:15px;padding-right:15px;line-height: 9px;margin-top: 8px;float:left !important">
							<!--<p style="font-size: 12px;">অর্ডার তা.- <span id="ord_date<?php //echo $j; ?>"><?php //echo date('d/m/Y',strtotime($rows['insert_date'])); ?></span></p>-->
							<p style="font-size: 11px;"> <span id="del_date<?php echo $j; ?>"><?php echo date('d/m/Y',strtotime($karigor_dv_date)); ?></span></p>
							<p style="font-size: 11px;"><?php echo $rows['product']."-".$rows['item_qty'].""; ?></p>
						</div>
					</div>
					
					<div style="height:385px;padding-left: 40px;">
						<span style="float: left;font-size: 11px;font-style: italic;">Received By- <?php echo $rows['insert_by']; ?></span>
						<span style="float: right;font-size: 11px;font-style: italic;">Atompac Limited</span>
						<div style="margin-left: 0px;margin-right: 0px;overflow: hidden;padding-top: 60px;width: 555px;">
								<?php echo getMeasurement2($rows['id'],1); //1=measurement ?>
							
						</div>
						<div class="row" style="overflow:hidden;">
							<div class="" style="margin-top:8px;padding-left:15px;padding-right:15px;float:left !important">
								<?php 
								echo getMeasurement2($rows['id'],2); // selected data
								?>
								
							</div>
							<div class="" style="margin-top:8px;padding-left:15px;padding-right:20px;float:left !important">
								<?php 
								echo getMeasurement2($rows['id'],3); // checkbox data
								?>
							</div>
							<div class="" style="margin-top:6px;padding-left:15px;padding-right:15px;float:left !important">
								<?php
								if($_SESSION['SHOW_DESIGN']==1){
									if($rows['ptype']==1){
										if($rows['product']=="Shirt"){
										?>
											<img src="img/1.png" style="width: 80px;margin-top: -9px;height: 110px;"/>
										<?php 
										}else if($rows['product']=="Fatua"){
											?>
											<img src="img/1.png" style="width:80px;margin-top:-9px;height:110px;"/>
											<?php 
										}else if($rows['product']=="Pant"){
											?>
											<img src="img/3.png" style="width: 100px;height: 110px;"/>
											<?php 
										}else if($rows['product']=="Panjabi"){
											?>
											<img src="img/4.png" style="width: 128px;height: 130px;"/>
											<?php 
										}else if($rows['product']=="Mujib Coat"){
											?>
											<img src="img/5.png" style="width:110px;height: 136px;"/>
											<?php 
										}else if($rows['product']=="Coat"){
											?>
											<img src="img/6.png" style="width: 130px;height: 125px;"/>
											<?php 
										}else if($rows['product']=="Jubbah"){
											?>
											<img src="img/7.png" style="width: 115px;height: 114px; margin-top: -11px;"/>
											<?php 
										}else if($rows['product']=="Sherwani"){
											?>
											<img src="img/8.png" style="width: 120px;height: 135px;"/>
											<?php 
										}else if($rows['product']=="Prince Coat"){
											?>
											<img src="img/9.png" style="width: 105px;height: 130px;"/>
											<?php 
										}else if($rows['product']=="Waistcoat"){
											?>
											<img src="img/10.png" style="width:85px"/>
											<?php 
										}else if($rows['product']=="Kabli"){
											?>
											<img src="img/11.png" style="width: 115px;height:120px;"/>
											<?php 
										}else if($rows['product']=="Pajama"){
											?>
											<img src="img/12.png" style="width:92px;height: 120px;"/>
											<?php 
										}
									
									}else{
										
									}
								}
								?>
							</div>
						</div>
						<div class="row" style="overflow:hidden;padding-top: 10px;padding-left: 15px;">
						<?php 
							echo getMeasurement2($rows['id'],4); // Txtarea data
						?>
						</div>
					</div>
					<span style="float: right;font-size: 15px;font-weight: bold;padding-top: 25px;">Job Slip</span>
					<div class="row" style="line-height: 11px; margin-top: 50px;margin-bottom: 5px;">
					
						<div class="" style="width: 26%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 13px;"> <b><?php echo $rows['order_number']; ?></b></p>
						<!--<p style="width: 259px;font-size: 12px;">টাকা- <span id="taka<?php echo $j; ?>"><?php echo @$rows['karigor_price']; ?>/=</span></p>-->
						</div>
						<div class="" style="width: 22%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 12px;"> <?php echo $rows['product']; ?></p>
						<p style="font-size: 12px;">Qty- <?php echo $rows['item_qty']." "; ?></p>
						</div>
						<div class="" style="width: 25%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="width: 259px;font-size: 12px;">কারিগর- <span id="karigor<?php echo $j; ?>" onclick="setEmployee(<?php echo $j; ?>)"><?php if($rows['karigor']=="") echo "---"; else echo $rows['karigor']; ?></span><span id="karigor_select_box<?php echo $j; ?>"></span></p>
							<input type="hidden" value="<?php echo @$rows['karigor_id']."#sep#2#sep#".$rows['id']; ?>" id="karigor_hidden_id<?php echo $j; ?>"/>
						</div>
						<div class="" style="width: 27%;padding-left:15px;padding-right:15px;float:left !important">
						<!--<p style="font-size: 12px;">অর্ডার তা.-  <span id="ord_date2<?php //echo $j; ?>"><?php //echo date('d/m/Y',strtotime($rows['insert_date'])); ?></span></p>-->
						<p style="font-size: 12px;"><span  id="del_date2<?php echo $j; ?>"><b><?php echo date('d/m/Y',strtotime($karigor_dv_date)); ?></b></span></p>
						</div>
						
					</div>
				</div>
				<?php
				}				
			}
			}else{
				echo 2;
			}
				
			}
		}else if($print_type==20){
			if($_SESSION['MEASURE_TYPE']==0){ //stardard
				echo printMoneyReceiptOnlyCustomer2($order_number);
			}else{ //local copy and normal copy
				if($_REQUEST['date1']!=""){
			
					$order_details=$conn->query("SELECT ord.id,ord.item_id,ord.ptype,(select cus_price from product where id=ord.item_id) item_price,
				(select artisan_price from product where id=ord.item_id) karigor_price,
				(select product_name from product where id=ord.item_id) product,(select user_name from user where id=ord.insert_by) insert_by,
				ord.order_number,ord.master_id,ord.group_id,date(ord.insert_date) insert_date,ds.dv_date,ds.fddate,ds.fdtime,
				(select user_name from user where id=ord.master_id) masters,ord.karigor_id,(select user_name from user where id=ord.karigor_id) karigor,ord.item_qty
				FROM `order_record` ord,dsms ds WHERE ds.id=ord.dsms_id and ord.com_id=$com_id and date(ds.insert_date)='$date1' and ord.is_active=1");
				}
				
				if($_REQUEST['mobile']!=""){
					
					$order_details=$conn->query("SELECT ord.id,ord.item_id,ord.ptype,(select cus_price from product where id=ord.item_id) item_price, 
					(select artisan_price from product where id=ord.item_id) karigor_price,
					(select product_name from product where id=ord.item_id) product,(select user_name from user where id=ord.insert_by) insert_by,
					ord.order_number,ord.master_id,ord.group_id,date(ds.insert_date) insert_date,
					(select user_name from user where id=ord.master_id) masters,ds.dv_date,
					ord.karigor_id,(select user_name from user where id=ord.karigor_id) karigor,ds.fddate,ds.fdtime,
					ord.item_qty FROM `order_record` ord,dsms ds WHERE ds.id=ord.dsms_id and ord.com_id=$com_id and ds.cus_mobile='$mobile' and ds.is_active=1 and ord.is_active=1 limit 0,10");
				}
				
				if(@$_REQUEST['serial_no']!=""){
					$serial_no=trim($_REQUEST['serial_no']);
					$order_details=$conn->query("SELECT ord.id,ord.item_id,ord.ptype,(select cus_price from product where id=ord.item_id) item_price, 
					(select artisan_price from product where id=ord.item_id) karigor_price,
					(select product_name from product where id=ord.item_id) product,(select user_name from user where id=ord.insert_by) insert_by,
					ord.order_number,ord.master_id,ord.group_id,date(ds.insert_date) insert_date,
					(select user_name from user where id=ord.master_id) masters,ds.dv_date,
					ord.karigor_id,(select user_name from user where id=ord.karigor_id) karigor,ds.fddate,ds.fdtime,
					ord.item_qty FROM `order_record` ord,dsms ds WHERE ds.id=ord.dsms_id and ord.com_id=$com_id and ds.phy_ord_num='$serial_no' and ds.is_active=1 and ord.is_active=1 limit 0,10");
				}
		
				if($_REQUEST['order_number']!=""){
					
					$order_number=explode(",",$_REQUEST['order_number']);
					for($i=0;$i<count($order_number);$i++){
						@$all_ord.="'".$order_number[$i]."',";
					}
					@$all_ord=substr($all_ord,0,-1);
					
					$order_details=$conn->query("SELECT ord.id,ord.item_id,ord.ptype,(select cus_price from product where id=ord.item_id) item_price,
					(select artisan_price from product where id=ord.item_id) karigor_price,
					(select product_name from product where id=ord.item_id) product,(select user_name from user where id=ord.insert_by) insert_by,
					ord.order_number,ord.master_id,ord.group_id,date(ord.insert_date) insert_date,ds.dv_date,ds.fddate,ds.fdtime,
					(select user_name from user where id=ord.master_id) masters,ord.karigor_id,(select user_name from user where id=ord.karigor_id) karigor,ord.item_qty
					FROM `order_record` ord,dsms ds WHERE ds.id=ord.dsms_id and ord.com_id=$com_id and ord.order_number in($all_ord) and ord.is_active=1");
				}
		
		mysqli_close($conn);
		if(mysqli_num_rows($order_details)>0){
			$c=0;$j=0;@$cus_price=0;
			$dday=$_SESSION['FAC_DELIVERY'];
			while($rows=mysqli_fetch_array($order_details)){
				$j=$c++;
				@$karigor_dv_date =date('Y-m-d', strtotime($rows['dv_date']. " - $dday days"));
				if($_SESSION['MEASURE_TYPE']==2){ //border: 1px solid gray;
				?>
				<div id="main_body" style="margin-left: 160px;padding-left:5px;padding-right: 5px;padding-top:3px;margin-bottom: 12px;width:395px;height:550px;display: block; page-break-before: always;">
					<div style="border-bottom: 1px solid gray;overflow:hidden">
						<!--<div class="" style="width: 25%;padding-right:15px;line-height: 9px; margin-top: 8px;float:left !important">
							<p style="font-size: 13px;">অর্ডার নম্বর- <b><?php echo $rows['order_number']; ?></b></p>
							<p style="width: 259px;font-size: 12px;">মাস্টার- <span id="master<?php echo $j; ?>" onclick="setEmployee2(<?php echo $j; ?>);"><?php if($rows['masters']=="") echo "---"; else echo $rows['masters']; ?></span><span id="master_select_box<?php echo $j; ?>"></span></p>
							<input type="hidden" value="<?php echo @$rows['master_id']."#sep#1#sep#".$rows['id']; ?>" id="master_hidden_id<?php echo $j; ?>"/>
							<p style="width: 259px;font-size: 12px;">কারিগর- <span id="karigor<?php echo $j; ?>" onclick="setEmployee(<?php echo $j; ?>)"><?php if($rows['karigor']=="") echo "---"; else echo $rows['karigor']; ?></span><span id="karigor_select_box<?php echo $j; ?>"></span></p>
							<input type="hidden" value="<?php echo @$rows['karigor_id']."#sep#2#sep#".$rows['id']; ?>" id="karigor_hidden_id<?php echo $j; ?>"/>
						</div>-->
						<div style="text-align: center;line-height: 9px; margin-top: 8px;">
							<p style=""><b><?php echo $_SESSION['COM']; ?></b></p>
							<p style="font-size: 13px;"><?php echo $_SESSION['COM_MOBILE']; ?></p>
							<p style="font-size: 12px;text-decoration: underline;font-weight: bold;"><?php echo "Production Copy";//$_SESSION['COM_ADDRESS']; ?></p>
						</div>
						<!--<div class="" style="width: 28%;padding-left:15px;padding-right:15px;line-height: 9px;margin-top: 8px;float:left !important">
							<p style="font-size: 12px;">অর্ডার তা.- <span id="ord_date<?php echo $j; ?>"><?php echo date('d/m/Y',strtotime($rows['insert_date'])); ?></span></p>
							<p style="font-size: 12px;">ডেলিভারি তা.- <span id="del_date<?php echo $j; ?>"><?php echo (@$rows['fddate']=="")? date('d/m/Y',strtotime($karigor_dv_date)) : $rows['fddate']." ".$rows['fdtime']; ?></span></p>
							<p style="font-size: 11px;">আইটেম- <?php echo $rows['product']."-".$rows['item_qty']." পিছ"; ?></p>
						</div>-->
					</div>
					
					<div style="padding-top:5px;overflow:hidden">
						<div style="float:left;">
							<p style=""><b>SL: <?php echo $rows['order_number']; ?></b></p>
						</div>
						<div style="float: right;">
							<p style=""><b><?php echo $rows['product']."-".$rows['item_qty']." পিছ"; ?></b></p>
						</div>
					</div>
					
					<div style="height: 400px;border-bottom: 1px solid gray;">
						<div style="margin-left: 0px;margin-right: 0px;overflow: hidden;padding-top: 14px;">
								<?php echo getMeasurement2($rows['id'],1); //1=measurement ?>
							
						</div>
						<div class="row" style="overflow:hidden;">
							<div class="" style="margin-top:8px;padding-left:15px;padding-right:15px;float:left !important">
								<?php 
								echo getMeasurement2($rows['id'],2)." ".getMeasurement2($rows['id'],3)." ".getMeasurement2($rows['id'],4); // selected data
								?>
								
							</div>
							<!--<div class="" style="margin-top:8px;padding-left:15px;padding-right:20px;float:left !important">
								<?php 
								//echo getMeasurement2($rows['id'],3); // checkbox data
								?>
							</div>-->
							<div class="" style="margin-top:-10px;padding-left:15px;padding-right:15px;float:left !important">
								<?php
								if($_SESSION['SHOW_DESIGN']==1){
									if($rows['ptype']==1){
										if($rows['product']=="Shirt"){
										?>
											<img src="img/1.png" style="width: 80px;margin-top: -9px;height: 110px;"/>
										<?php 
										}else if($rows['product']=="Fatua"){
											?>
											<img src="img/1.png" style="width:80px;margin-top:-9px;height:110px;"/>
											<?php 
										}else if($rows['product']=="Pant"){
											?>
											<img src="img/3.png" style="width: 100px;height: 110px;"/>
											<?php 
										}else if($rows['product']=="Panjabi"){
											?>
											<img src="img/4.png" style="width: 128px;height: 130px;"/>
											<?php 
										}else if($rows['product']=="Mujib Coat"){
											?>
											<img src="img/5.png" style="width:110px;height: 136px;"/>
											<?php 
										}else if($rows['product']=="Coat"){
											?>
											<img src="img/6.png" style="width: 130px;height: 125px;"/>
											<?php 
										}else if($rows['product']=="Jubbah"){
											?>
											<img src="img/7.png" style="width: 115px;height: 114px; margin-top: -11px;"/>
											<?php 
										}else if($rows['product']=="Sherwani"){
											?>
											<img src="img/8.png" style="width: 120px;height: 135px;"/>
											<?php 
										}else if($rows['product']=="Prince Coat"){
											?>
											<img src="img/9.png" style="width: 105px;height: 130px;"/>
											<?php 
										}else if($rows['product']=="Waistcoat"){
											?>
											<img src="img/10.png" style="width:85px"/>
											<?php 
										}else if($rows['product']=="Kabli"){
											?>
											<img src="img/11.png" style="width: 115px;height:120px;"/>
											<?php 
										}else if($rows['product']=="Pajama"){
											?>
											<img src="img/12.png" style="width:92px;height: 120px;"/>
											<?php 
										}
									}else{
										
									}
								}
								?>
							</div>
						</div>
						<!--<div class="row" style="overflow:hidden;padding-top: 10px;padding-left: 15px;">
						<?php 
							//echo getMeasurement2($rows['id'],4); // Txtarea data
						?>
						</div>-->
					</div>
					<div style="padding-top:5px;overflow:hidden">
						<div style="float:left;">
							<p style=""><b>অর্ডার তা.-  <span><?php echo date('d/m/Y',strtotime($rows['insert_date'])); ?></b></p>
						</div>
						<div style="float: right;">
							<p style=""><b>ডেলিভারি তা.- <span><?php echo (@$rows['fddate']=="")? date('d/m/Y',strtotime($karigor_dv_date)) : $rows['fddate']." ".$rows['fdtime']; ?></b></p>
						</div>
					</div>
					<!--<div class="row" style="line-height: 11px; margin-top: 12px;margin-bottom: 5px;">
						<div class="" style="width: 26%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 13px;">অর্ডার নম্বর- <b><?php echo $rows['order_number']; ?></b></p>
						<p style="width: 259px;font-size: 12px;">টাকা- <span id="taka<?php echo $j; ?>"><?php echo @$rows['karigor_price']; ?>/=</span></p>
						</div>
						<div class="" style="width: 22%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 12px;">আইটেম- <?php echo $rows['product']; ?></p>
						<p style="font-size: 12px;">সংখ্যা- <?php echo $rows['item_qty']."  পিছ"; ?></p>
						</div>
						<div class="" style="width: 25%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="width: 259px;font-size: 12px;">কারিগর- <span id="karigors<?php echo $j; ?>"><?php echo $rows['karigor']; ?></span></p>
						<p style="width: 259px;font-size: 12px;">মাস্টার- <span id="masters<?php echo $j; ?>"><?php echo $rows['masters']; ?></span></p>
						</div>
						<div class="" style="width: 27%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 12px;">অর্ডার তা.-  <span id="ord_date2<?php echo $j; ?>"><?php echo date('d/m/Y',strtotime($rows['insert_date'])); ?></span></p>
						<p style="font-size: 12px;">ডেলিভারি তা.- <span  id="del_date2<?php echo $j; ?>"><?php echo (@$rows['fddate']=="")? date('d/m/Y',strtotime($karigor_dv_date)) : $rows['fddate']." ".$rows['fdtime']; ?></span></p>
						</div>
						
					</div>-->
				</div>
				<?php 
				}else if($_SESSION['MEASURE_TYPE']==1){ //Normal Copy
					?>
					<div id="main_body" style="margin-left:50px;margin-top: 0px;padding-left:30px;padding-right: 15px;padding-top:5px;margin-bottom: 12px;width:604px;height:684px;display: block; page-break-before: always;">
					<div style="overflow:hidden">
						<div class="" style="width: 25%;padding-right:15px;line-height: 9px; margin-top: 8px;float:left !important">
							<p style="font-size: 13px;"> <b><?php echo $rows['order_number']; ?></b></p>
							<p style="width: 259px;font-size: 12px;">মাস্টার- <span id="master<?php echo $j; ?>" onclick="setEmployee2(<?php echo $j; ?>);"><?php if($rows['masters']=="") echo "---"; else echo $rows['masters']; ?></span><span id="master_select_box<?php echo $j; ?>"></span></p>
							<input type="hidden" value="<?php echo @$rows['master_id']."#sep#1#sep#".$rows['id']; ?>" id="master_hidden_id<?php echo $j; ?>"/>
							
							<input type="hidden" value="<?php echo @$rows['karigor_id']."#sep#2#sep#".$rows['id']; ?>" id="karigor_hidden_id<?php echo $j; ?>"/>
						</div>
						<div style="width: 47%;padding-left:15px;padding-right:15px;text-align: center;line-height: 9px;margin-top: 8px;float:left !important">
							<p style=""><b><?php echo $_SESSION['COM']; ?></b></p>
							<p style="font-size: 13px;"><?php echo $_SESSION['COM_ADDRESS']; ?></p>
							<p style="font-size: 13px;"><?php echo $_SESSION['COM_MOBILE']; ?></p>
							<p style="font-size: 12px;text-decoration: underline;font-weight: bold;"><?php echo "Production Copy";//$_SESSION['COM_ADDRESS']; ?></p>
						</div>
						<div class="" style="width: 28%;padding-left:15px;padding-right:15px;line-height: 9px;margin-top: 8px;float:left !important">
							<!--<p style="font-size: 12px;">অর্ডার তা.- <span id="ord_date<?php //echo $j; ?>"><?php //echo date('d/m/Y',strtotime($rows['insert_date'])); ?></span></p>-->
							<p style="font-size: 11px;"> <span id="del_date<?php echo $j; ?>"><?php echo date('d/m/Y',strtotime($karigor_dv_date)); ?></span></p>
							<p style="font-size: 11px;"><?php echo $rows['product']."-".$rows['item_qty'].""; ?></p>
						</div>
					</div>
					
					<div style="height:385px;padding-left: 40px;">
						<span style="float: left;font-size: 11px;font-style: italic;">Received By- <?php echo $rows['insert_by']; ?></span>
						<span style="float: right;font-size: 11px;font-style: italic;">Atompac Limited</span>
						<div style="margin-left: 0px;margin-right: 0px;overflow: hidden;padding-top: 60px;width: 555px;">
								<?php echo getMeasurement2($rows['id'],1); //1=measurement ?>
							
						</div>
						<div class="row" style="overflow:hidden;">
							<div class="" style="margin-top:8px;padding-left:15px;padding-right:15px;float:left !important">
								<?php 
								echo getMeasurement2($rows['id'],2); // selected data
								?>
								
							</div>
							<div class="" style="margin-top:8px;padding-left:15px;padding-right:20px;float:left !important">
								<?php 
								echo getMeasurement2($rows['id'],3); // checkbox data
								?>
							</div>
							<div class="" style="margin-top:6px;padding-left:15px;padding-right:15px;float:left !important">
								<?php
								if($_SESSION['SHOW_DESIGN']==1){
									if($rows['ptype']==1){
										if($rows['product']=="Shirt"){
										?>
											<img src="img/1.png" style="width: 80px;margin-top: -9px;height: 110px;"/>
										<?php 
										}else if($rows['product']=="Fatua"){
											?>
											<img src="img/1.png" style="width:80px;margin-top:-9px;height:110px;"/>
											<?php 
										}else if($rows['product']=="Pant"){
											?>
											<img src="img/3.png" style="width: 100px;height: 110px;"/>
											<?php 
										}else if($rows['product']=="Panjabi"){
											?>
											<img src="img/4.png" style="width: 128px;height: 130px;"/>
											<?php 
										}else if($rows['product']=="Mujib Coat"){
											?>
											<img src="img/5.png" style="width:110px;height: 136px;"/>
											<?php 
										}else if($rows['product']=="Coat"){
											?>
											<img src="img/6.png" style="width: 130px;height: 125px;"/>
											<?php 
										}else if($rows['product']=="Jubbah"){
											?>
											<img src="img/7.png" style="width: 115px;height: 114px; margin-top: -11px;"/>
											<?php 
										}else if($rows['product']=="Sherwani"){
											?>
											<img src="img/8.png" style="width: 120px;height: 135px;"/>
											<?php 
										}else if($rows['product']=="Prince Coat"){
											?>
											<img src="img/9.png" style="width: 105px;height: 130px;"/>
											<?php 
										}else if($rows['product']=="Waistcoat"){
											?>
											<img src="img/10.png" style="width:85px"/>
											<?php 
										}else if($rows['product']=="Kabli"){
											?>
											<img src="img/11.png" style="width: 115px;height:120px;"/>
											<?php 
										}else if($rows['product']=="Pajama"){
											?>
											<img src="img/12.png" style="width:92px;height: 120px;"/>
											<?php 
										}
									
									}else{
										
									}
								}
								?>
							</div>
						</div>
						<div class="row" style="overflow:hidden;padding-top: 10px;padding-left: 15px;">
						<?php 
							echo getMeasurement2($rows['id'],4); // Txtarea data
						?>
						</div>
					</div>
					<span style="float: right;font-size: 15px;font-weight: bold;padding-top: 25px;">Job Slip</span>
					<div class="row" style="line-height: 11px; margin-top: 50px;margin-bottom: 5px;">
					
						<div class="" style="width: 26%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 13px;"> <b><?php echo $rows['order_number']; ?></b></p>
						<!--<p style="width: 259px;font-size: 12px;">টাকা- <span id="taka<?php echo $j; ?>"><?php echo @$rows['karigor_price']; ?>/=</span></p>-->
						</div>
						<div class="" style="width: 22%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 12px;"> <?php echo $rows['product']; ?></p>
						<p style="font-size: 12px;">Qty- <?php echo $rows['item_qty']." "; ?></p>
						</div>
						<div class="" style="width: 25%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="width: 259px;font-size: 12px;">কারিগর- <span id="karigor<?php echo $j; ?>" onclick="setEmployee(<?php echo $j; ?>)"><?php if($rows['karigor']=="") echo "---"; else echo $rows['karigor']; ?></span><span id="karigor_select_box<?php echo $j; ?>"></span></p>
							<input type="hidden" value="<?php echo @$rows['karigor_id']."#sep#2#sep#".$rows['id']; ?>" id="karigor_hidden_id<?php echo $j; ?>"/>
						</div>
						<div class="" style="width: 27%;padding-left:15px;padding-right:15px;float:left !important">
						<!--<p style="font-size: 12px;">অর্ডার তা.-  <span id="ord_date2<?php //echo $j; ?>"><?php //echo date('d/m/Y',strtotime($rows['insert_date'])); ?></span></p>-->
						<p style="font-size: 12px;"><span  id="del_date2<?php echo $j; ?>"><b><?php echo date('d/m/Y',strtotime($karigor_dv_date)); ?></b></span></p>
						</div>
						
					</div>
				</div>
				<?php
				}				
			}
			}else{
				echo 2;
			}
				
			}
		}else if($print_type==22){ //only code printing area
			
				if(@$_REQUEST['order_number']!=""){
					$serial_no=trim($_REQUEST['order_number']);
				?>
				<div id="main_body" style="margin-left: 15px;padding-left:5px;padding-right: 5px;padding-top:3px;margin-bottom: 12px;display: block; page-break-before: always;">
					<?php echo onlyCodePrint($serial_no); ?>
				</div>
				<?php 
				}else{
					echo 2;
				}
		
		
		}else if($print_type==21){
			if($_SESSION['MEASURE_TYPE']==0){ //stardard
				echo printMoneyReceiptOnlyMeasurment2($order_number);
			}else{ //local copy and normal copy
				if($_REQUEST['date1']!=""){
			
					$order_details=$conn->query("SELECT ord.id,ord.item_id,ord.ptype,(select cus_price from product where id=ord.item_id) item_price,
				(select artisan_price from product where id=ord.item_id) karigor_price,
				(select product_name from product where id=ord.item_id) product,(select user_name from user where id=ord.insert_by) insert_by,
				ord.order_number,ord.master_id,ord.group_id,date(ord.insert_date) insert_date,ds.dv_date,ds.fddate,ds.fdtime,
				(select user_name from user where id=ord.master_id) masters,ord.karigor_id,(select user_name from user where id=ord.karigor_id) karigor,ord.item_qty
				FROM `order_record` ord,dsms ds WHERE ds.id=ord.dsms_id and ord.com_id=$com_id and date(ds.insert_date)='$date1' and ord.is_active=1");
				}
				
				if($_REQUEST['mobile']!=""){
					
					$order_details=$conn->query("SELECT ord.id,ord.item_id,ord.ptype,(select cus_price from product where id=ord.item_id) item_price, 
					(select artisan_price from product where id=ord.item_id) karigor_price,
					(select product_name from product where id=ord.item_id) product,(select user_name from user where id=ord.insert_by) insert_by,
					ord.order_number,ord.master_id,ord.group_id,date(ds.insert_date) insert_date,
					(select user_name from user where id=ord.master_id) masters,ds.dv_date,
					ord.karigor_id,(select user_name from user where id=ord.karigor_id) karigor,ds.fddate,ds.fdtime,
					ord.item_qty FROM `order_record` ord,dsms ds WHERE ds.id=ord.dsms_id and ord.com_id=$com_id and ds.cus_mobile='$mobile' and ds.is_active=1 and ord.is_active=1 limit 0,10");
				}
				
				if(@$_REQUEST['serial_no']!=""){
					$serial_no=trim($_REQUEST['serial_no']);
					$order_details=$conn->query("SELECT ord.id,ord.item_id,ord.ptype,(select cus_price from product where id=ord.item_id) item_price, 
					(select artisan_price from product where id=ord.item_id) karigor_price,
					(select product_name from product where id=ord.item_id) product,(select user_name from user where id=ord.insert_by) insert_by,
					ord.order_number,ord.master_id,ord.group_id,date(ds.insert_date) insert_date,
					(select user_name from user where id=ord.master_id) masters,ds.dv_date,
					ord.karigor_id,(select user_name from user where id=ord.karigor_id) karigor,ds.fddate,ds.fdtime,
					ord.item_qty FROM `order_record` ord,dsms ds WHERE ds.id=ord.dsms_id and ord.com_id=$com_id and ds.phy_ord_num='$serial_no' and ds.is_active=1 and ord.is_active=1 limit 0,10");
				}
		
				if($_REQUEST['order_number']!=""){
					
					$order_number=explode(",",$_REQUEST['order_number']);
					for($i=0;$i<count($order_number);$i++){
						@$all_ord.="'".$order_number[$i]."',";
					}
					@$all_ord=substr($all_ord,0,-1);
					
					$order_details=$conn->query("SELECT ord.id,ord.item_id,ord.ptype,(select cus_price from product where id=ord.item_id) item_price,
					(select artisan_price from product where id=ord.item_id) karigor_price,
					(select product_name from product where id=ord.item_id) product,(select user_name from user where id=ord.insert_by) insert_by,
					ord.order_number,ord.master_id,ord.group_id,date(ord.insert_date) insert_date,ds.dv_date,ds.fddate,ds.fdtime,
					(select user_name from user where id=ord.master_id) masters,ord.karigor_id,(select user_name from user where id=ord.karigor_id) karigor,ord.item_qty
					FROM `order_record` ord,dsms ds WHERE ds.id=ord.dsms_id and ord.com_id=$com_id and ord.order_number in($all_ord) and ord.is_active=1");
				}
		
		mysqli_close($conn);
		if(mysqli_num_rows($order_details)>0){
			$c=0;$j=0;@$cus_price=0;
			$dday=$_SESSION['FAC_DELIVERY'];
			while($rows=mysqli_fetch_array($order_details)){
				$j=$c++;
				@$karigor_dv_date =date('Y-m-d', strtotime($rows['dv_date']. " - $dday days"));
				if($_SESSION['MEASURE_TYPE']==2){ //border: 1px solid gray;
				?>
				<div id="main_body" style="margin-left: 160px;padding-left:5px;padding-right: 5px;padding-top:3px;margin-bottom: 12px;width:395px;height:550px;display: block; page-break-before: always;">
					<div style="border-bottom: 1px solid gray;overflow:hidden">
						<!--<div class="" style="width: 25%;padding-right:15px;line-height: 9px; margin-top: 8px;float:left !important">
							<p style="font-size: 13px;">অর্ডার নম্বর- <b><?php echo $rows['order_number']; ?></b></p>
							<p style="width: 259px;font-size: 12px;">মাস্টার- <span id="master<?php echo $j; ?>" onclick="setEmployee2(<?php echo $j; ?>);"><?php if($rows['masters']=="") echo "---"; else echo $rows['masters']; ?></span><span id="master_select_box<?php echo $j; ?>"></span></p>
							<input type="hidden" value="<?php echo @$rows['master_id']."#sep#1#sep#".$rows['id']; ?>" id="master_hidden_id<?php echo $j; ?>"/>
							<p style="width: 259px;font-size: 12px;">কারিগর- <span id="karigor<?php echo $j; ?>" onclick="setEmployee(<?php echo $j; ?>)"><?php if($rows['karigor']=="") echo "---"; else echo $rows['karigor']; ?></span><span id="karigor_select_box<?php echo $j; ?>"></span></p>
							<input type="hidden" value="<?php echo @$rows['karigor_id']."#sep#2#sep#".$rows['id']; ?>" id="karigor_hidden_id<?php echo $j; ?>"/>
						</div>-->
						<div style="text-align: center;line-height: 9px; margin-top: 8px;">
							<p style=""><b><?php echo $_SESSION['COM']; ?></b></p>
							<p style="font-size: 13px;"><?php echo $_SESSION['COM_MOBILE']; ?></p>
							<p style="font-size: 12px;text-decoration: underline;font-weight: bold;"><?php echo "Production Copy";//$_SESSION['COM_ADDRESS']; ?></p>
						</div>
						<!--<div class="" style="width: 28%;padding-left:15px;padding-right:15px;line-height: 9px;margin-top: 8px;float:left !important">
							<p style="font-size: 12px;">অর্ডার তা.- <span id="ord_date<?php echo $j; ?>"><?php echo date('d/m/Y',strtotime($rows['insert_date'])); ?></span></p>
							<p style="font-size: 12px;">ডেলিভারি তা.- <span id="del_date<?php echo $j; ?>"><?php echo (@$rows['fddate']=="")? date('d/m/Y',strtotime($karigor_dv_date)) : $rows['fddate']." ".$rows['fdtime']; ?></span></p>
							<p style="font-size: 11px;">আইটেম- <?php echo $rows['product']."-".$rows['item_qty']." পিছ"; ?></p>
						</div>-->
					</div>
					
					<div style="padding-top:5px;overflow:hidden">
						<div style="float:left;">
							<p style=""><b>SL: <?php echo $rows['order_number']; ?></b></p>
						</div>
						<div style="float: right;">
							<p style=""><b><?php echo $rows['product']."-".$rows['item_qty']." পিছ"; ?></b></p>
						</div>
					</div>
					
					<div style="height: 400px;border-bottom: 1px solid gray;">
						<div style="margin-left: 0px;margin-right: 0px;overflow: hidden;padding-top: 14px;">
								<?php echo getMeasurement2($rows['id'],1); //1=measurement ?>
							
						</div>
						<div class="row" style="overflow:hidden;">
							<div class="" style="margin-top:8px;padding-left:15px;padding-right:15px;float:left !important">
								<?php 
								echo getMeasurement2($rows['id'],2)." ".getMeasurement2($rows['id'],3)." ".getMeasurement2($rows['id'],4); // selected data
								?>
								
							</div>
							<!--<div class="" style="margin-top:8px;padding-left:15px;padding-right:20px;float:left !important">
								<?php 
								//echo getMeasurement2($rows['id'],3); // checkbox data
								?>
							</div>-->
							<div class="" style="margin-top:-10px;padding-left:15px;padding-right:15px;float:left !important">
								<?php
								if($_SESSION['SHOW_DESIGN']==1){
									if($rows['ptype']==1){
										if($rows['product']=="Shirt"){
										?>
											<img src="img/1.png" style="width: 80px;margin-top: -9px;height: 110px;"/>
										<?php 
										}else if($rows['product']=="Fatua"){
											?>
											<img src="img/1.png" style="width:80px;margin-top:-9px;height:110px;"/>
											<?php 
										}else if($rows['product']=="Pant"){
											?>
											<img src="img/3.png" style="width: 100px;height: 110px;"/>
											<?php 
										}else if($rows['product']=="Panjabi"){
											?>
											<img src="img/4.png" style="width: 128px;height: 130px;"/>
											<?php 
										}else if($rows['product']=="Mujib Coat"){
											?>
											<img src="img/5.png" style="width:110px;height: 136px;"/>
											<?php 
										}else if($rows['product']=="Coat"){
											?>
											<img src="img/6.png" style="width: 130px;height: 125px;"/>
											<?php 
										}else if($rows['product']=="Jubbah"){
											?>
											<img src="img/7.png" style="width: 115px;height: 114px; margin-top: -11px;"/>
											<?php 
										}else if($rows['product']=="Sherwani"){
											?>
											<img src="img/8.png" style="width: 120px;height: 135px;"/>
											<?php 
										}else if($rows['product']=="Prince Coat"){
											?>
											<img src="img/9.png" style="width: 105px;height: 130px;"/>
											<?php 
										}else if($rows['product']=="Waistcoat"){
											?>
											<img src="img/10.png" style="width:85px"/>
											<?php 
										}else if($rows['product']=="Kabli"){
											?>
											<img src="img/11.png" style="width: 115px;height:120px;"/>
											<?php 
										}else if($rows['product']=="Pajama"){
											?>
											<img src="img/12.png" style="width:92px;height: 120px;"/>
											<?php 
										}
									}else{
										
									}
								}
								?>
							</div>
						</div>
						<!--<div class="row" style="overflow:hidden;padding-top: 10px;padding-left: 15px;">
						<?php 
							//echo getMeasurement2($rows['id'],4); // Txtarea data
						?>
						</div>-->
					</div>
					<div style="padding-top:5px;overflow:hidden">
						<div style="float:left;">
							<p style=""><b>অর্ডার তা.-  <span><?php echo date('d/m/Y',strtotime($rows['insert_date'])); ?></b></p>
						</div>
						<div style="float: right;">
							<p style=""><b>ডেলিভারি তা.- <span><?php echo (@$rows['fddate']=="")? date('d/m/Y',strtotime($karigor_dv_date)) : $rows['fddate']." ".$rows['fdtime']; ?></b></p>
						</div>
					</div>
					<!--<div class="row" style="line-height: 11px; margin-top: 12px;margin-bottom: 5px;">
						<div class="" style="width: 26%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 13px;">অর্ডার নম্বর- <b><?php echo $rows['order_number']; ?></b></p>
						<p style="width: 259px;font-size: 12px;">টাকা- <span id="taka<?php echo $j; ?>"><?php echo @$rows['karigor_price']; ?>/=</span></p>
						</div>
						<div class="" style="width: 22%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 12px;">আইটেম- <?php echo $rows['product']; ?></p>
						<p style="font-size: 12px;">সংখ্যা- <?php echo $rows['item_qty']."  পিছ"; ?></p>
						</div>
						<div class="" style="width: 25%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="width: 259px;font-size: 12px;">কারিগর- <span id="karigors<?php echo $j; ?>"><?php echo $rows['karigor']; ?></span></p>
						<p style="width: 259px;font-size: 12px;">মাস্টার- <span id="masters<?php echo $j; ?>"><?php echo $rows['masters']; ?></span></p>
						</div>
						<div class="" style="width: 27%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 12px;">অর্ডার তা.-  <span id="ord_date2<?php echo $j; ?>"><?php echo date('d/m/Y',strtotime($rows['insert_date'])); ?></span></p>
						<p style="font-size: 12px;">ডেলিভারি তা.- <span  id="del_date2<?php echo $j; ?>"><?php echo (@$rows['fddate']=="")? date('d/m/Y',strtotime($karigor_dv_date)) : $rows['fddate']." ".$rows['fdtime']; ?></span></p>
						</div>
						
					</div>-->
				</div>
				<?php 
				}else if($_SESSION['MEASURE_TYPE']==1){ //Normal Copy
					?>
					<div id="main_body" style="margin-left:50px;margin-top: 0px;padding-left:30px;padding-right: 15px;padding-top:5px;margin-bottom: 12px;width:604px;height:684px;display: block; page-break-before: always;">
					<div style="overflow:hidden">
						<div class="" style="width: 25%;padding-right:15px;line-height: 9px; margin-top: 8px;float:left !important">
							<p style="font-size: 13px;"> <b><?php echo $rows['order_number']; ?></b></p>
							<p style="width: 259px;font-size: 12px;">মাস্টার- <span id="master<?php echo $j; ?>" onclick="setEmployee2(<?php echo $j; ?>);"><?php if($rows['masters']=="") echo "---"; else echo $rows['masters']; ?></span><span id="master_select_box<?php echo $j; ?>"></span></p>
							<input type="hidden" value="<?php echo @$rows['master_id']."#sep#1#sep#".$rows['id']; ?>" id="master_hidden_id<?php echo $j; ?>"/>
							
							<input type="hidden" value="<?php echo @$rows['karigor_id']."#sep#2#sep#".$rows['id']; ?>" id="karigor_hidden_id<?php echo $j; ?>"/>
						</div>
						<div style="width: 47%;padding-left:15px;padding-right:15px;text-align: center;line-height: 9px;margin-top: 8px;float:left !important">
							<p style=""><b><?php echo $_SESSION['COM']; ?></b></p>
							<p style="font-size: 13px;"><?php echo $_SESSION['COM_ADDRESS']; ?></p>
							<p style="font-size: 13px;"><?php echo $_SESSION['COM_MOBILE']; ?></p>
							<p style="font-size: 12px;text-decoration: underline;font-weight: bold;"><?php echo "Production Copy";//$_SESSION['COM_ADDRESS']; ?></p>
						</div>
						<div class="" style="width: 28%;padding-left:15px;padding-right:15px;line-height: 9px;margin-top: 8px;float:left !important">
							<!--<p style="font-size: 12px;">অর্ডার তা.- <span id="ord_date<?php //echo $j; ?>"><?php //echo date('d/m/Y',strtotime($rows['insert_date'])); ?></span></p>-->
							<p style="font-size: 11px;"> <span id="del_date<?php echo $j; ?>"><?php echo date('d/m/Y',strtotime($karigor_dv_date)); ?></span></p>
							<p style="font-size: 11px;"><?php echo $rows['product']."-".$rows['item_qty'].""; ?></p>
						</div>
					</div>
					
					<div style="height:385px;padding-left: 40px;">
						<span style="float: left;font-size: 11px;font-style: italic;">Received By- <?php echo $rows['insert_by']; ?></span>
						<span style="float: right;font-size: 11px;font-style: italic;">Atompac Limited</span>
						<div style="margin-left: 0px;margin-right: 0px;overflow: hidden;padding-top: 60px;width: 555px;">
								<?php echo getMeasurement2($rows['id'],1); //1=measurement ?>
							
						</div>
						<div class="row" style="overflow:hidden;">
							<div class="" style="margin-top:8px;padding-left:15px;padding-right:15px;float:left !important">
								<?php 
								echo getMeasurement2($rows['id'],2); // selected data
								?>
								
							</div>
							<div class="" style="margin-top:8px;padding-left:15px;padding-right:20px;float:left !important">
								<?php 
								echo getMeasurement2($rows['id'],3); // checkbox data
								?>
							</div>
							<div class="" style="margin-top:6px;padding-left:15px;padding-right:15px;float:left !important">
								<?php
								if($_SESSION['SHOW_DESIGN']==1){
									if($rows['ptype']==1){
										if($rows['product']=="Shirt"){
										?>
											<img src="img/1.png" style="width: 80px;margin-top: -9px;height: 110px;"/>
										<?php 
										}else if($rows['product']=="Fatua"){
											?>
											<img src="img/1.png" style="width:80px;margin-top:-9px;height:110px;"/>
											<?php 
										}else if($rows['product']=="Pant"){
											?>
											<img src="img/3.png" style="width: 100px;height: 110px;"/>
											<?php 
										}else if($rows['product']=="Panjabi"){
											?>
											<img src="img/4.png" style="width: 128px;height: 130px;"/>
											<?php 
										}else if($rows['product']=="Mujib Coat"){
											?>
											<img src="img/5.png" style="width:110px;height: 136px;"/>
											<?php 
										}else if($rows['product']=="Coat"){
											?>
											<img src="img/6.png" style="width: 130px;height: 125px;"/>
											<?php 
										}else if($rows['product']=="Jubbah"){
											?>
											<img src="img/7.png" style="width: 115px;height: 114px; margin-top: -11px;"/>
											<?php 
										}else if($rows['product']=="Sherwani"){
											?>
											<img src="img/8.png" style="width: 120px;height: 135px;"/>
											<?php 
										}else if($rows['product']=="Prince Coat"){
											?>
											<img src="img/9.png" style="width: 105px;height: 130px;"/>
											<?php 
										}else if($rows['product']=="Waistcoat"){
											?>
											<img src="img/10.png" style="width:85px"/>
											<?php 
										}else if($rows['product']=="Kabli"){
											?>
											<img src="img/11.png" style="width: 115px;height:120px;"/>
											<?php 
										}else if($rows['product']=="Pajama"){
											?>
											<img src="img/12.png" style="width:92px;height: 120px;"/>
											<?php 
										}
									
									}else{
										
									}
								}
								?>
							</div>
						</div>
						<div class="row" style="overflow:hidden;padding-top: 10px;padding-left: 15px;">
						<?php 
							echo getMeasurement2($rows['id'],4); // Txtarea data
						?>
						</div>
					</div>
					<span style="float: right;font-size: 15px;font-weight: bold;padding-top: 25px;">Job Slip</span>
					<div class="row" style="line-height: 11px; margin-top: 50px;margin-bottom: 5px;">
					
						<div class="" style="width: 26%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 13px;"> <b><?php echo $rows['order_number']; ?></b></p>
						<!--<p style="width: 259px;font-size: 12px;">টাকা- <span id="taka<?php echo $j; ?>"><?php echo @$rows['karigor_price']; ?>/=</span></p>-->
						</div>
						<div class="" style="width: 22%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="font-size: 12px;"> <?php echo $rows['product']; ?></p>
						<p style="font-size: 12px;">Qty- <?php echo $rows['item_qty']." "; ?></p>
						</div>
						<div class="" style="width: 25%;padding-left:15px;padding-right:15px;float:left !important">
						<p style="width: 259px;font-size: 12px;">কারিগর- <span id="karigor<?php echo $j; ?>" onclick="setEmployee(<?php echo $j; ?>)"><?php if($rows['karigor']=="") echo "---"; else echo $rows['karigor']; ?></span><span id="karigor_select_box<?php echo $j; ?>"></span></p>
							<input type="hidden" value="<?php echo @$rows['karigor_id']."#sep#2#sep#".$rows['id']; ?>" id="karigor_hidden_id<?php echo $j; ?>"/>
						</div>
						<div class="" style="width: 27%;padding-left:15px;padding-right:15px;float:left !important">
						<!--<p style="font-size: 12px;">অর্ডার তা.-  <span id="ord_date2<?php //echo $j; ?>"><?php //echo date('d/m/Y',strtotime($rows['insert_date'])); ?></span></p>-->
						<p style="font-size: 12px;"><span  id="del_date2<?php echo $j; ?>"><b><?php echo date('d/m/Y',strtotime($karigor_dv_date)); ?></b></span></p>
						</div>
						
					</div>
				</div>
				<?php
				}				
			}
			}else{
				echo 2;
			}
				
			}
		}else if($print_type==13){
			echo printMoneyReceipt32($order_number);
		}else if($print_type==1){
			
			if($_REQUEST['mobile']!=""){
				echo getCustomerRecept2($_REQUEST['mobile']);
			}else if($_REQUEST['order_number']!=""){
				echo getCustomerReceptNormal($_REQUEST['order_number']);
			}
			else if($_REQUEST['date1']!=""){
				$date1=trim($_REQUEST['date1']);
				$ex=explode("/",$date1);
				$date1=$ex[2]."-".$ex[1]."-".$ex[0];
				echo getCustomerRecept2($date1);
			}
			
		}else if($print_type==4){
			
			echo getCustomerRecept3();
			
		}else if($print_type==3){
			date_default_timezone_set("Asia/Dhaka");
			if($date1!=""){
				$order_listsql="SELECT ds.id,ds.phy_ord_num,ds.paymentType,(select sum(amount) from accounting where dsms_id=ds.id and date(insert_date)=date(ds.insert_date) and is_active=1 and pay_status in(1)) taka FROM dsms ds WHERE ds.is_active=1 and com_id=$com_id and ds.phy_dv_date is null and date(ds.insert_date)='$date1'";
				$order_list=$conn->query($order_listsql);
				 $order_delsql="SELECT ds.id,ds.phy_ord_num,(select sum(amount) from accounting where dsms_id=ds.id and date(insert_date)=date(ds.phy_dv_date) and is_active=1 and delivery_status in(1)) taka,(select payment_type from accounting where dsms_id=ds.id and date(insert_date)=date(ds.phy_dv_date) and is_active=1 and delivery_status in(1) limit 0,1) payment_type FROM dsms ds WHERE ds.is_active=1 and com_id=$com_id and ds.phy_dv_date='$date1'";
				$order_del=$conn->query($order_delsql);
				
					
			  $method_listsql="SELECT sum(`amount`) method_tk,method_name FROM `transaction` WHERE `com_id`=$com_id and is_active=1 and date(insert_date)='$date1' and `status`=1 group by method_name";
			  $method_list=$conn->query($method_listsql);
			  $receivable_listsql="SELECT `amount` receive_tk,remarks FROM `transaction` WHERE `com_id`=$com_id and is_active=1 and date(insert_date)='$date1' and `status`=1 and transaction_type in(1,2)";
					
				
				
				$receivable_list=$conn->query($receivable_listsql);
				$direct_salesql="SELECT ds.total_receive,ds.cus_mobile,ds.payment_type,(select cus_name from customer where cus_mobile=ds.cus_mobile and is_active=1 limit 0,1) cus_name,ds.id FROM direct_sale_head ds WHERE ds.is_active=1 and ds.is_order=0 and ds.in_out_status=0 and ds.com_id=$com_id and date(ds.insert_date)='$date1'";
				$direct_sale=$conn->query($direct_salesql);
				$expensesql="SELECT ex.expense,ex.expense_type,ex.remarks,method,(select expense from expense_type where id=ex.expense_type) ex_type FROM expenses ex WHERE ex.is_active=1 and com_id=$com_id and date(insert_date)='$date1'";
				$expense=$conn->query($expensesql);
				$wasessql="SELECT ex.taka expense,(select user_name from user where id=ex.emp_id) emp_name FROM wages_details ex WHERE ex.is_active=1 and ex.com_id=$com_id and ex.status=1 and date(ex.insert_date)='$date1'";
				$wases=$conn->query($wasessql);
				
				$only_fab_sql="select (pay_tbl.pay_only_fab+dsale_tbl.only_fab+dsale_tbl_ord.ord_tk) fab_total_taka from (SELECT CASE WHEN sum(`taka`)>0 THEN sum(`taka`) ELSE 0 END  pay_only_fab FROM `only_febrics_tk` WHERE `is_active`=1 and date(`insert_date`)='$date1') pay_tbl,
					(SELECT CASE WHEN sum(`total_receive`)>0 THEN sum(`total_receive`) ELSE 0 END only_fab FROM `direct_sale_head` WHERE `is_active`=1 and `is_order`=0 and date(`insert_date`)='$date1') dsale_tbl,
					(SELECT CASE WHEN sum(CASE WHEN `total_receive`<=`f_total` THEN total_receive ELSE f_total END)>0 THEN sum(CASE WHEN `total_receive`<=`f_total` THEN total_receive ELSE f_total END) ELSE 0 END ord_tk FROM `direct_sale_head` WHERE `is_active`=1 and `is_order`=1 and date(`insert_date`)='$date1') dsale_tbl_ord";
				$only_fab_row=$conn->query($only_fab_sql);
				
				$dis=0;
				$exdate=explode("-",$date1);
				$paymentDate = $exdate[0]."/".$exdate[1]."/".$exdate[2];
				$day = date('l', strtotime($paymentDate));
				?>
				<input type="hidden" id="order_sql" value="<?php echo $order_listsql; ?>"/>
				<input type="hidden" id="order_del" value="<?php echo $order_delsql; ?>"/>
				<input type="hidden" id="receivable_list" value="<?php echo $receivable_listsql; ?>"/>
				<input type="hidden" id="direct_sale" value="<?php echo $direct_salesql; ?>"/>
				<input type="hidden" id="expense" value="<?php echo $expensesql; ?>"/>
				<div class="row" style="background:white">
					<div class="col-xs-12 col-sm-12">
						<div style="overflow: hidden;">
							<div style="float: left;width: 37%;padding-top: 4px;">
								<p style="">তারিখ: <b><?php echo Converter::en2bn(date($exdate[2]."/".$exdate[1]."/".$exdate[0])); ?></b></p>
								<p style="line-height: 0px;">বার: <b><?php echo Converter::en2bn($day); ?></b></p>
							</div>
							<div style="float: left;margin-top: 11px;margin-bottom: 6px;">
								<p style="text-align: center;line-height: 1px;margin-left: 37px;"><b><?php echo $_SESSION['COM']; ?></b></p>
								<p style="text-align: center;line-height: 11px;margin-left: 37px;"><?php echo $_SESSION['COM_ADDRESS']; ?></p>
								<p style="text-align: center;line-height: 0px;margin-bottom: 16px;margin-left: 37px;"><?php echo $_SESSION['COM_MOBILE']; ?></p>
								<span style="font-weight: bold;text-align: center;border: 1px solid gray; padding: 4px 6px 4px 6px; border-radius: 9px; margin-left: 75px;">Daily Report</span>
							</div>
							<div style="">
								
							</div>
						</div>
						<div style="overflow: hidden;">
							<div style="float: left;width: 48%;margin-right:5px">
								<label>অর্ডার লিস্ট</label>
								<table border="1" style="width:100%">
									<thead>
										<tr>
											<th style="text-align:center">Sl</th>
											<th style="width:40%;padding-left:5px">Order No.</th>
											<th style="width:40%;text-align:right;padding-right:5px;">টাকা</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl=1;$order_tk=0;
											if(mysqli_num_rows($order_list)>0){
												while($row=mysqli_fetch_array($order_list)){
													$order_tk+=$row['taka'];
													?>
													<tr>
													<td style="text-align:center"><?php echo $sl++; ?></td>
													<td style="padding-left:5px"><?php echo $row['phy_ord_num']; ?> (<span style="color:blue"><?php echo ($row['paymentType']=='Cash')? '' : $row['paymentType']; ?></span>)</td>
													<td style="width:40%;text-align:right;padding-right:5px;"><?php echo Converter::en2bn($row['taka']); ?>/=</td>
													</tr>
													<?php 
												}
											}
										?>
									</tbody>
									<tr>
										<th colspan="2"  style="text-align:right">মোট: </th>
										<th style="width:40%;text-align:right;padding-right:5px;"><?php echo Converter::en2bn($order_tk); ?>/=</th>
									</tr>
								</table>
								<label>বাকি গ্রহণ</label>
								<table border="1" style="width:100%">
									<thead>
										<tr>
											<th style="text-align:center">Sl</th>
											<th style="width:40%;padding-left:5px">Remarks</th>
											<th style="width:40%;text-align:right;padding-right:5px;">টাকা</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl=1;$receivable_tk=0;
											if(mysqli_num_rows($receivable_list)>0){
												while($row=mysqli_fetch_array($receivable_list)){
												$receivable_tk+=$row['receive_tk'];
												$ex=explode("-",$row['remarks']);
												if(count($ex)>0){
													$remarks=$ex[0];
													@$payment_type=$ex[1];
												}else{
													$remarks=$row['remarks'];
												}
													?>
													<tr>
													<td style="text-align:center"><?php echo $sl++; ?></td>
													<td style="padding-left:5px"><?php echo @$remarks; ?>(<span style="color:blue"><?php echo (@$payment_type=='Cash')? '' : @$payment_type; ?></span>)</td>
													<td style="width:40%;text-align:right;padding-right:5px;"><?php echo Converter::en2bn($row['receive_tk']); ?>/=</td>
													</tr>
													<?php 
												}
											}
										?>
									</tbody>
									<tr>
										<th colspan="2"  style="text-align:right">মোট: </th>
										<th style="width:40%;text-align:right;padding-right:5px;"><?php echo Converter::en2bn($receivable_tk); ?>/=</th>
									</tr>
								</table>
								<label>খরচ(ব্যয়)</label>
								<table border="1" style="width:100%">
									<thead>
										<tr>
											<th style="text-align:center">Sl</th>
											<th style="width:40%;padding-left:5px">খরচের ধরন</th>
											<th style="width:40%;text-align:right;padding-right:5px;">টাকা</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl3=1;$order_tk4=0;$textk=0;$bk=0;$ng=0;$ro=0;$up=0;
											if(mysqli_num_rows($expense)>0){
												while($row=mysqli_fetch_array($expense)){
													$order_tk4+=$row['expense'];
													if($row['expense_type']=='14'){
														$textk+=$row['expense'];
													}
													$bk+=($row['method']=="Bkash")? $row['expense'] : 0;
													$ng+=($row['method']=="Nagad")? $row['expense'] : 0;
													$ro+=($row['method']=="Rocket")? $row['expense'] : 0;
													$up+=($row['method']=="Upay")? $row['expense'] : 0;
													?>
													<tr>
													<td style="text-align:center"><?php echo $sl3++; ?></td>
													<td style="padding-left:5px"><?php echo $row['ex_type']; ?><span style="font-size:10px;color:blue"> (<?php echo $row['remarks'].' '.$row['method']; ?>)</span></td>
													<td style="width:35%;text-align:right;padding-right:5px;"><?php echo Converter::en2bn($row['expense']); ?>/=</td>
													</tr>
													<?php 
												}
											}
										?>
									</tbody>
									<tbody>
										<?php 
											$order_tk5=0;
											if(mysqli_num_rows($wases)>0){
												while($row=mysqli_fetch_array($wases)){
													$order_tk5+=$row['expense'];
													?>
													<tr>
													<td style="text-align:center"><?php echo $sl3++; ?></td>
													<td style="padding-left:5px"><?php echo $row['emp_name']; ?>(Wages)</td>
													<td style="width:35%;text-align:right;padding-right:5px;"><?php echo Converter::en2bn($row['expense']); ?>/=</td>
													</tr>
													<?php 
												}
											}
										?>
									</tbody>
									
									<tr>
										<th colspan="2"  style="text-align:right">মোট: </th>
										<th style="width:40%;text-align:right;padding-right:5px;"><?php echo Converter::en2bn($order_tk4+$order_tk5); ?>/=</th>
									</tr>
								</table>
								<label style="color:#1b998d;">ফ্যাব্রিক্স এর টাকা (Order+Pay+Delivery+Only Fabrics)</label>
								<table border="1" style="width:100%;color: #12a598;">
									<thead>
										<tr>
											<th style="width:40%;padding-left:5px;">ফ্যাব্রিক্স (টাকা)</th>
											<th style="width:40%;text-align:right;padding-right:5px;">টাকা</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											if(mysqli_num_rows($only_fab_row)>0){
												$row=mysqli_fetch_array($only_fab_row);
													?>
													<tr>
													<td data-toggle="modal" data-target="#myModal" onclick="showOnlyFabricsPrice('<?php echo $date1; ?>','<?php echo $row['fab_total_taka']; ?>')" style="padding-left:5px;cursor:pointer">Order+Pay+Delivery+Only Fabrics</td>
													<td data-toggle="modal" data-target="#myModal" onclick="showOnlyFabricsPrice('<?php echo $date1; ?>','<?php echo $row['fab_total_taka']; ?>')" style="width:35%;text-align:right;padding-right:5px;cursor:pointer"><?php echo Converter::en2bn($row['fab_total_taka']); ?>/=</td>
													</tr>
													<?php 
											}
										?>
									</tbody>
									
								</table>
							</div>
							<div style="float: left;width: 49%;">
								<label>ডেলিভারি লিস্ট</label>
								<table border="1" style="width:100%">
									<thead>
										<tr>
											<th style="text-align:center">Sl</th>
											<th style="width: 40%;padding-left:5px">Order No.</th>
											<th style="width:40%;text-align:right;padding-right:5px;">টাকা</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl2=1;$order_tk2=0;
											if(mysqli_num_rows($order_del)>0){
												while($row=mysqli_fetch_array($order_del)){
													$order_tk2+=$row['taka'];
													?>
													<tr>
													<td style="text-align:center"><?php echo $sl2++; ?></td>
													<td style="padding-left:5px"><?php echo $row['phy_ord_num']; ?> (<span style="color:blue"><?php echo ($row['payment_type']=='Cash')? '' : $row['payment_type']; ?>)</td>
													<td style="width:40%;text-align:right;padding-right:5px;"><?php echo Converter::en2bn($row['taka']); ?>/=</td>
													</tr>
													<?php 
												}
											}
										?>
									</tbody>
									
									<tr>
										<th colspan="2"  style="text-align:right">মোট: </th>
										<th style="width:40%;text-align:right;padding-right:5px;"><?php echo Converter::en2bn($order_tk2); ?>/=</th>
									</tr>
									<tr style="color:#808080a8;">
										<th colspan="2"  style="text-align:right">ডিসকাউন্ট বাদে মোট টাকা: </th>
										<th style="width:40%;text-align:right;padding-right:5px;"><?php 
										@$dttak=($order_tk2-$textk);
										echo Converter::en2bn($dttak); 
										?>/=</th>
									</tr>
								</table>
								<label>শুধু ফ্যাব্রিক্স এর টাকা</label>
								<table border="1" style="width:100%">
									<thead>
										<tr>
											<th style="text-align:center">Sl</th>
											<th style="width:35%;padding-left:5px">Customer</th>
											<th style="width:20%;padding-left:5px">Mobile</th>
											<th style="width:35%;text-align:right;padding-right:5px;">টাকা</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl3=1;$order_tk3=0;$qty=0;
											if(mysqli_num_rows($direct_sale)>0){
												while($row=mysqli_fetch_array($direct_sale)){
													$order_tk3+=($row['total_receive']);
													?>
													<tr style="cursor:pointer" data-toggle="modal" data-target="#myModal" onclick="showPurchaseDetails('<?php echo $row['id']; ?>')">
													<td style="text-align:center"><?php echo $sl3++; ?></td>
													<td style="padding-left:5px"><?php echo $row['cus_name']; ?> (<span style="color:blue"><?php echo ($row['payment_type']=='Cash')? '' : $row['payment_type']; ?></span>)</td>
													<td style="padding-left:5px"><?php echo $row['cus_mobile']; ?></td>
													<td style="width:35%;text-align:right;padding-right:5px;"><?php echo Converter::en2bn($row['total_receive']); ?>/=</td>
													</tr>
													<?php 
												}
											}
										?>
									</tbody>
									<tr>
										<th colspan="3"  style="text-align:right">মোট: </th>
										<th style="width:40%;text-align:right;padding-right:5px;"> <?php 
										echo Converter::en2bn($order_tk3); 
										
										?>/=</th>
									</tr>
									<!--<tr>
										<th colspan="3" style="text-align:right" >Discount(-)</th>
										<th style="width:40%;text-align:right"><?php //echo @$dis; ?>/=</th>
									</tr>-->
									
								</table>
								
								<label style="padding-left:10px;padding-top: 5px; padding-bottom: 5px;">Summary Report</label>
								<table border="1" style="width:100%;background: lightgray;">
										<thead>
											<tr>
												<th style="text-align:right">---</th>
												<th style="text-align:right;padding-right:5px;">টাকা</th>
											</tr>
											<tr>
												<th style="text-align:right;padding-right:5px;">অর্ডার(টেইলারিং): </th>
												<th style="text-align:right;padding-right:5px;"><?php echo Converter::en2bn($order_tk); ?>/=</th>
											</tr>
											<tr>
												<th style="text-align:right;padding-right:5px;">ডেলিভারি(টেইলারিং): </th>
												<th style="text-align:right;padding-right:5px;"><?php echo Converter::en2bn($order_tk2); ?>/=</th>
											</tr>
											<tr>
												<th style="text-align:right;padding-right:5px;">ফ্যাব্রিক্স: </th>
												<th style="text-align:right;padding-right:5px;"><?php echo Converter::en2bn($order_tk3); ?>/=</th>
											</tr>
											<tr>
												<th style="text-align:right;padding-right:5px;">বাকি গ্রহণ: </th>
												<th style="text-align:right;padding-right:5px;"><?php echo Converter::en2bn($receivable_tk); ?>/=</th>
											</tr>
											<tr style="background:#F5F5F5;color: #b93333;">
												<th style="text-align:right;padding-right:5px;">মোট: </th>
												<th style="text-align:right;padding-right:5px;"><?php echo Converter::en2bn(($order_tk+$order_tk2+$order_tk3+$receivable_tk)); ?>/=</th>
											</tr>
											<tr>
												<th style="text-align:right;padding-right:5px;">খরচ(ব্যয়)(-): </th>
												<th style="text-align:right;padding-right:5px;"><?php echo Converter::en2bn($order_tk4+$order_tk5); ?>/=</th>
											</tr>
											<tr style="background:#F5F5F5;color: #b61ed2;">
												<th style="text-align:right;padding-right:5px;">সর্ব মোট: </th>
												<th style="text-align:right;padding-right:5px;"><?php echo Converter::en2bn(($order_tk+$order_tk2+$order_tk3+$receivable_tk)-$order_tk4-$order_tk5); ?>/=</th>
											</tr>
										</thead>
										
									</table>
									
							<label style="margin-top:20px">Payment Type wise summery</label>
								<table border="1" style="width:100%">
									<thead>
										<tr>
											<th style="text-align:center">Sl</th>
											<th style="width: 40%;padding-left:5px">মেথড নাম</th>
											<th style="width:40%;text-align:right;padding-right:5px;">টাকা</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl6=1;$method_tk=0;
											if(mysqli_num_rows($method_list)>0){
												while($row=mysqli_fetch_array($method_list)){
													if($row['method_name']!='Cash'){
														if($row['method_name']=="Bkash"){
															$method_tk+=$row['method_tk']-$bk;
														}else if($row['method_name']=="Nagad"){
															$method_tk+=$row['method_tk']-$ng;
														}else if($row['method_name']=="Rocket"){
															$method_tk+=$row['method_tk']-$ro;
														}else if($row['method_name']=="Upay"){
															$method_tk+=$row['method_tk']-$up;
														}else{
															$method_tk+=$row['method_tk'];
														}
														
													//$method_tk+=$row['method_tk'];
													
													if($row['method_name']=="Bkash"){
															$method_tks=$row['method_tk']-$bk;
														}else if($row['method_name']=="Nagad"){
															$method_tks=$row['method_tk']-$ng;
														}else if($row['method_name']=="Rocket"){
															$method_tks=$row['method_tk']-$ro;
														}else if($row['method_name']=="Upay"){
															$method_tks=$row['method_tk']-$up;
														}else{
															$method_tks=$row['method_tk'];
														}
													?>
													<tr>
													<td style="text-align:center"><?php echo $sl6++; ?></td>
													<td style="padding-left:5px"><?php echo $row['method_name']; ?></td>
													<td style="width:40%;text-align:right;padding-right:5px;"><?php echo Converter::en2bn($method_tks); ?>/=</td>
													</tr>
													<?php 
													}
												}
											}
										?>
									</tbody>
									<tr>
										<th colspan="2"  style="text-align:right">মোট (মেথড): </th>
										<th style="width:40%;text-align:right;padding-right:5px;"><?php echo Converter::en2bn($method_tk); ?>/=</th>
									</tr>
								</table>
								
							</div>
							
						</div>
						
					</div>
					
				</div>
				<?php 
			}else{
				echo "";// plz date select
			}
		}else if($print_type==5){
			/* $date=date("F-Y", strtotime("-1 months")); 
			$mnt=date("m", strtotime("-1 months")); 
			$ex=explode("-",$date); */
			$month=$_REQUEST['month'];
			$year=$_REQUEST['year'];
			$order=$conn->query("select count(phy_ord_num) ord_num,date(insert_date) dates from dsms where is_active=1 and com_id=$com_id and month(insert_date)=$month and year(insert_date)=$year group by date(insert_date) order by date(insert_date) asc");
			
			?>
			<div class="row" style="background:white">
					<div class="col-xs-12 col-sm-12">
						<div style="overflow: hidden;">
							<div style="float: left;width: 37%;">
								<p style="">Search Date: <b><?php echo date("d/m/Y"); ?></b></p>
								<p style="line-height: 0px;">Month: <b><?php echo getMonth($month); ?></b></p>
							</div>
							<div style="float: left;margin-top: 11px;margin-bottom: 6px;">
								<p style="text-align: center;line-height: 1px;margin-left: 37px;"><b><?php echo $_SESSION['COM']; ?></b></p>
								<p style="text-align: center;line-height: 11px;margin-left: 37px;"><?php echo $_SESSION['COM_ADDRESS']; ?></p>
								<p style="text-align: center;line-height: 0px;margin-bottom: 16px;margin-left: 37px;"><?php echo $_SESSION['COM_MOBILE']; ?></p>
								<span style="font-weight: bold;text-align: center;border: 1px solid gray; padding: 4px 6px 4px 6px; border-radius: 9px; margin-left: 14px;">Monthly Order Report</span>
							</div>
							<div style="">
								
							</div>
						</div>
						<div style="overflow: hidden;">
							<div style="float: left;width: 48%;margin-right:5px">
								<label>Order Summary</label>
								<table id="dynamic-table" class="table table-striped table-bordered table-hover">
									<thead>
										<tr>
											<th>Sl</th>
											<th style="width:40%;">Date</th>
											<th style="width:40%;text-align:right">No. of Order</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl=1;$order_tk=0;
											if(mysqli_num_rows($order)>0){
												while($row=mysqli_fetch_array($order)){
													$order_tk+=$row['ord_num'];
													$ol=$sl++;
													?>
													<tr>
													<td><?php echo $ol; ?></td>
													<td><a href="javascript:void(0)" id="dvdate<?php echo $ol; ?>" onclick="getOrdList('<?php echo $row['dates']; ?>','<?php echo $ol; ?>','1');"><?php echo $row['dates']; ?></a></td>
													<td style="width:40%;text-align:right"><a href="javascript:void(0)" id="dvcount<?php echo $ol; ?>" onclick="getOrdList('<?php echo $row['dates']; ?>','<?php echo $ol; ?>','1');"><?php echo $row['ord_num']; ?></a></td>
													</tr>
													<?php 
												}
											}
										?>
									</tbody>
									<tr>
										<th colspan="2"  style="text-align:right">Total Order</th>
										<th style="width:40%;text-align:right"><?php echo $order_tk; ?></th>
									</tr>
								</table>
								
							</div>
							<input type="hidden" id="dvid" value="0"/>
							<div style="float: left;width: 49%;" id="ord_list">
								
							</div>
							
						</div>
						
					</div>
					
				</div>
			<?php 
		}else if($print_type==6){
			/* $date=date("F-Y", strtotime("-1 months")); 
			$mnt=date("m", strtotime("-1 months")); 
			$ex=explode("-",$date); */
			$month=$_REQUEST['month'];
			$year=$_REQUEST['year'];
			$order=$conn->query("select count(phy_ord_num) ord_num,phy_dv_date dates from dsms where is_active=1 and com_id=$com_id and phy_dv_date is not null and month(phy_dv_date)=$month and year(phy_dv_date)=$year group by phy_dv_date order by phy_dv_date asc");
			
			?>
			<div class="row" style="background:white">
					<div class="col-xs-12 col-sm-12">
						<div style="overflow: hidden;">
							<div style="float: left;width: 37%;">
								<p style="">Search Date: <b><?php echo date("d/m/Y"); ?></b></p>
								<p style="line-height: 0px;">Month: <b><?php echo getMonth($month); ?></b></p>
							</div>
							<div style="float: left;margin-top: 11px;margin-bottom: 6px;">
								<p style="text-align: center;line-height: 1px;"><b><?php echo $_SESSION['COM']; ?></b></p>
								<p style="text-align: center;line-height: 11px;"><?php echo $_SESSION['COM_ADDRESS']; ?></p>
								<p style="text-align: center;line-height: 0px;margin-bottom: 16px;"><?php echo $_SESSION['COM_MOBILE']; ?></p>
								<span style="font-weight: bold;text-align: center;border: 1px solid gray; padding: 4px 6px 4px 6px; border-radius: 9px; margin-left: 14px;">Monthly Delivery Report</span>
							</div>
							<div style="">
								
							</div>
						</div>
						<div style="overflow: hidden;">
							<div style="float: left;width: 48%;margin-right:5px">
								<label>Order Summary</label>
								<table id="dynamic-table" class="table table-striped table-bordered table-hover">
									<thead>
										<tr>
											<th>Sl</th>
											<th style="width:40%;">Date</th>
											<th style="width:40%;text-align:right">No. of Order</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl=1;$order_tk=0;
											if(mysqli_num_rows($order)>0){
												while($row=mysqli_fetch_array($order)){
													$order_tk+=$row['ord_num'];
													$ol=$sl++;
													?>
													<tr>
													<td><?php echo $ol; ?></td>
													<td><a href="javascript:void(0)" id="dvdate<?php echo $ol; ?>" onclick="getOrdList('<?php echo $row['dates']; ?>','<?php echo $ol; ?>','2');"><?php echo $row['dates']; ?></a></td>
													<td style="width:40%;text-align:right"><a href="javascript:void(0)" id="dvcount<?php echo $ol; ?>" onclick="getOrdList('<?php echo $row['dates']; ?>','<?php echo $ol; ?>','2');"><?php echo $row['ord_num']; ?></a></td>
													</tr>
													<?php 
												}
											}
										?>
									</tbody>
									<tr>
										<th colspan="2"  style="text-align:right">Total Order</th>
										<th style="width:40%;text-align:right"><?php echo $order_tk; ?></th>
									</tr>
								</table>
								
							</div>
							<input type="hidden" id="dvid" value="0"/>
							<div style="float: left;width: 49%;" id="ord_list">
								
							</div>
							
						</div>
						
					</div>
					
				</div>
			<?php
		}else if($print_type==7){
			$month=$_REQUEST['month'];
			$year=$_REQUEST['year'];
			$order=$conn->query("SELECT es.master_id empid,(select concat(user_name,'(','Master',')') from user where id=es.master_id) name,(select emp_type from user where id=es.master_id) emp_type,sum(p.master_price*es.item_qty) tk FROM `order_record` es,product p WHERE es.item_id=p.id and es.is_active=1 and es.com_id=$com_id and month(es.insert_date)=$month and year(es.insert_date)=$year and es.master_id!=0 GROUP by es.master_id union (SELECT es.karigor_id empid,(select concat(user_name,'(','Karigor',')') from user where id=es.karigor_id) name,(select emp_type from user where id=es.karigor_id) emp_type,sum(p.artisan_price*es.item_qty) tk FROM `order_record` es,product p WHERE es.item_id=p.id and es.is_active=1 and es.com_id=$com_id and month(es.insert_date)=$month and year(es.insert_date)=$year and es.karigor_id!=0 GROUP by es.karigor_id)");
			
			?>
			<div class="row" style="background:white">
					<div class="col-xs-12 col-sm-12">
						<div style="overflow: hidden;">
							<div style="float: left;width: 37%;">
								<p style="">Search Date: <b><?php echo date("d/m/Y"); ?></b></p>
								<p style="line-height: 0px;">Month: <b><?php echo getMonth($month); ?></b></p>
							</div>
							<div style="float: left;margin-top: 11px;margin-bottom: 6px;">
								<p style="text-align: center;line-height: 1px;"><b><?php echo $_SESSION['COM']; ?></b></p>
								<p style="text-align: center;line-height: 11px;"><?php echo $_SESSION['COM_ADDRESS']; ?></p>
								<p style="text-align: center;line-height: 0px;margin-bottom: 16px;"><?php echo $_SESSION['COM_MOBILE']; ?></p>
								<span style="font-weight: bold;text-align: center;border: 1px solid gray; padding: 4px 6px 4px 6px; border-radius: 9px; margin-left: 14px;">Monthly Employee Salary Report</span>
							</div>
							<div style="">
								
							</div>
						</div>
						<div style="overflow: hidden;">
							<div style="float: left;width: 48%;margin-right:5px">
								<label>Employee Monthly Salary</label>
								<table id="dynamic-table" class="table table-striped table-bordered table-hover">
									<thead>
										<tr>
											<th>Sl</th>
											<th style="width:40%;">Name</th>
											<th style="width:40%;text-align:right">Taka</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl=1;$tot_tk=0;
											if(mysqli_num_rows($order)>0){
												while($row=mysqli_fetch_array($order)){
													$tot_tk+=$row['tk'];
													$ol=$sl++;
													?>
													<input type="hidden" value="<?php echo $row['emp_type']; ?>" id="emp_type<?php echo $ol; ?>"/>
													<input type="hidden" value="<?php echo $month."#sep#".$year; ?>" id="month_year<?php echo $ol; ?>"/>
													<tr>
													<td><?php echo $ol; ?></td>
													<td><a href="javascript:void(0)" id="dvdate<?php echo $ol; ?>" onclick="getOrdList('<?php echo $row['empid']; ?>','<?php echo $ol; ?>','3');"><?php echo $row['name']; ?></a></td>
													<td style="width:40%;text-align:right"><a href="javascript:void(0)" id="dvcount<?php echo $ol; ?>" onclick="getOrdList('<?php echo $row['empid']; ?>','<?php echo $ol; ?>','3');"><?php echo $row['tk']; ?></a></td>
													</tr>
													<?php 
												}
											}
										?>
									</tbody>
									<tr>
										<th colspan="2"  style="text-align:right">Total Taka</th>
										<th style="width:40%;text-align:right"><?php echo $tot_tk; ?></th>
									</tr>
								</table>
								
							</div>
							<input type="hidden" id="dvid" value="0"/>
							<div style="float: left;width: 49%;" id="ord_list">
								
							</div>
							
						</div>
						
					</div>
					
				</div>
			<?php
		}else if($print_type==8){
			date_default_timezone_set("Asia/Dhaka");
			$date1=$_REQUEST['date1'];
			$date2=$_REQUEST['date2'];
			$exdate=explode("/",$date1);
				$sdate = $exdate[2]."-".$exdate[1]."-".$exdate[0];
			$exdate2=explode("/",$date2);
				$tdate = $exdate2[2]."-".$exdate2[1]."-".$exdate2[0];
			if($date1!=""){
				$order_listsql="SELECT ds.id,ds.phy_ord_num,(select sum(amount) from accounting where dsms_id=ds.id and date(insert_date)=date(ds.insert_date) and is_active=1 and pay_status in(1)) taka FROM dsms ds WHERE ds.is_active=1 and com_id=$com_id and ds.phy_dv_date is null and date(ds.insert_date) between '$sdate' and '$tdate'";
				$order_list=$conn->query($order_listsql);
				$order_delsql="SELECT ds.id,ds.phy_ord_num,(select sum(amount) from accounting where dsms_id=ds.id and date(insert_date)=date(ds.phy_dv_date) and is_active=1 and delivery_status in(1)) taka FROM dsms ds WHERE ds.is_active=1 and com_id=$com_id and date(phy_dv_date) between '$sdate' and '$tdate'";
				$order_del=$conn->query($order_delsql);
				
				
			  $receivable_listsql="SELECT `amount` receive_tk,remarks FROM `transaction` WHERE `com_id`=$com_id and is_active=1 and date(insert_date) between '$sdate' and '$tdate' and `status`=1 and transaction_type in(1,2)";
					
				
				$receivable_list=$conn->query($receivable_listsql);
				$direct_salesql="SELECT ds.total_receive,ds.cus_mobile,(select cus_name from customer where cus_mobile=ds.cus_mobile and is_active=1 limit 0,1) cus_name,ds.id FROM direct_sale_head ds WHERE ds.is_active=1 and ds.is_order=0 and ds.in_out_status=0 and ds.com_id=$com_id and date(ds.insert_date) between '$sdate' and '$tdate'";
				$direct_sale=$conn->query($direct_salesql);
				$expensesql="SELECT ex.expense,ex.remarks,(select expense from expense_type where id=ex.expense_type) ex_type FROM expenses ex WHERE ex.is_active=1 and com_id=$com_id and date(ex.insert_date) between '$sdate' and '$tdate'";
				$expense=$conn->query($expensesql);
				$wasessql="SELECT ex.taka expense,(select user_name from user where id=ex.emp_id) emp_name FROM wages_details ex WHERE ex.is_active=1 and ex.com_id=$com_id and ex.status=1 and date(ex.insert_date) between '$sdate' and '$tdate'";
				$wases=$conn->query($wasessql);
				$dis=0;
				
				$only_fab_sql="select (pay_tbl.pay_only_fab+dsale_tbl.only_fab+dsale_tbl_ord.ord_tk) fab_total_taka from (SELECT CASE WHEN sum(`taka`)>0 THEN sum(`taka`) ELSE 0 END  pay_only_fab FROM `only_febrics_tk` WHERE `is_active`=1 and date(`insert_date`) BETWEEN '$sdate' and '$tdate') pay_tbl,
					(SELECT CASE WHEN sum(`total_receive`)>0 THEN sum(`total_receive`) ELSE 0 END only_fab FROM `direct_sale_head` WHERE `is_active`=1 and `is_order`=0 and date(`insert_date`) BETWEEN '$sdate' and '$tdate') dsale_tbl,
					(SELECT CASE WHEN sum(CASE WHEN `total_receive`<=`f_total` THEN total_receive ELSE f_total END)>0 THEN sum(CASE WHEN `total_receive`<=`f_total` THEN total_receive ELSE f_total END) ELSE 0 END ord_tk FROM `direct_sale_head` WHERE `is_active`=1 and `is_order`=1 and date(`insert_date`) BETWEEN '$sdate' and '$tdate') dsale_tbl_ord";
				$only_fab_row=$conn->query($only_fab_sql);
				
				//$exdate=explode("-",$date1);
				//$paymentDate = $exdate[0]."/".$exdate[1]."/".$exdate[2];
				//$day = date('l', strtotime($paymentDate));
				?>
				<input type="hidden" id="order_sql" value="<?php echo $order_listsql; ?>"/>
				<input type="hidden" id="order_del" value="<?php echo $order_delsql; ?>"/>
				<input type="hidden" id="receivable_list" value="<?php echo $receivable_listsql; ?>"/>
				<input type="hidden" id="direct_sale" value="<?php echo $direct_salesql; ?>"/>
				<input type="hidden" id="expense" value="<?php echo $expensesql; ?>"/>
				<div class="row" style="background:white">
					<div class="col-xs-12 col-sm-12">
						<div style="overflow: hidden;">
							<div style="float: left;width: 37%;padding-top: 4px;">
								<p style="">Date: <b><?php echo $date1." to ".$date2; //Converter::en2bn(date($exdate[2]."/".$exdate[1]."/".$exdate[0])); ?></b></p>
							</div>
							<div style="float: left;margin-top: 11px;margin-bottom: 6px;">
								<p style="text-align: center;line-height: 1px;margin-left: 37px;"><b><?php echo $_SESSION['COM']; ?></b></p>
								<p style="text-align: center;line-height: 11px;margin-left: 37px;"><?php echo $_SESSION['COM_ADDRESS']; ?></p>
								<p style="text-align: center;line-height: 0px;margin-bottom: 16px;margin-left: 37px;"><?php echo $_SESSION['COM_MOBILE']; ?></p>
								<span style="font-weight: bold;text-align: center;border: 1px solid gray; padding: 4px 6px 4px 6px; border-radius: 9px; margin-left: 75px;">Report</span>
							</div>
							<div style="">
								
							</div>
						</div>
						<div style="overflow: hidden;">
							
										<?php 
											$sl=1;$order_tk=0;
											if(mysqli_num_rows($order_list)>0){
												while($row=mysqli_fetch_array($order_list)){
													$order_tk+=$row['taka'];
												}
											}
										?>

								
										<?php 
											$sl=1;$receivable_tk=0;
											if(mysqli_num_rows($receivable_list)>0){
												while($row=mysqli_fetch_array($receivable_list)){
												$receivable_tk+=$row['receive_tk'];
													
												}
											}
										?>
									
							
										<?php 
											$sl2=1;$order_tk2=0;
											if(mysqli_num_rows($order_del)>0){
												while($row=mysqli_fetch_array($order_del)){
													$order_tk2+=$row['taka'];
													
												}
											}
										?>
									
										<?php 
											$sl3=1;$order_tk3=0;$qty=0;
											if(mysqli_num_rows($direct_sale)>0){
												while($row=mysqli_fetch_array($direct_sale)){
													$order_tk3+=($row['total_receive']);
													
												}
											}
										?>
							
										<?php 
											$sl3=1;$order_tk4=0;;
											if(mysqli_num_rows($expense)>0){
												while($row=mysqli_fetch_array($expense)){
													$order_tk4+=$row['expense'];
													
												}
											}
										?>
									
										<?php 
											$order_tk5=0;
											if(mysqli_num_rows($wases)>0){
												while($row=mysqli_fetch_array($wases)){
													$order_tk5+=$row['expense'];
													
												}
											}
										?>
										
										<?php 
											$order_tk6=0;
											if(mysqli_num_rows($only_fab_row)>0){
												while($row=mysqli_fetch_array($only_fab_row)){
													$order_tk6+=$row['fab_total_taka'];
													
												}
											}
										?>
									
							
							<div style="width: 100%;background:#eaeef1;">
								<label style="padding-left:10px;padding-top: 5px; padding-bottom: 5px;">Summary Report</label>
								<table border="1" style="width:100%">
										<thead>
											<tr>
												<th style="text-align:right">---</th>
												<th style="text-align:right;padding-right:5px;">টাকা</th>
											</tr>
											<tr>
												<th style="text-align:right;padding-right:5px;">অর্ডার(টেইলারিং): </th>
												<th style="text-align:right;padding-right:5px;"><?php echo Converter::en2bn($order_tk); ?>/=</th>
											</tr>
											<tr>
												<th style="text-align:right;padding-right:5px;">ডেলিভারি(টেইলারিং): </th>
												<th style="text-align:right;padding-right:5px;"><?php echo Converter::en2bn($order_tk2); ?>/=</th>
											</tr>
											<tr>
												<th style="text-align:right;padding-right:5px;">ফ্যাব্রিক্স: </th>
												<th style="text-align:right;padding-right:5px;"><?php echo Converter::en2bn($order_tk3); ?>/=</th>
											</tr>
											<tr>
												<th style="text-align:right;padding-right:5px;">বাকি গ্রহণ: </th>
												<th style="text-align:right;padding-right:5px;"><?php echo Converter::en2bn($receivable_tk); ?>/=</th>
											</tr>
											<tr style="background:#F5F5F5;color: #b93333;">
												<th style="text-align:right;padding-right:5px;">মোট: </th>
												<th style="text-align:right;padding-right:5px;"><?php echo Converter::en2bn(($order_tk+$order_tk2+$order_tk3+$receivable_tk)); ?>/=</th>
											</tr>
											<tr>
												<th style="text-align:right;padding-right:5px;">খরচ(ব্যয়)(-): </th>
												<th style="text-align:right;padding-right:5px;"><?php echo Converter::en2bn($order_tk4+$order_tk5); ?>/=</th>
											</tr>
											<tr style="background:#F5F5F5;color: #b61ed2;">
												<th style="text-align:right;padding-right:5px;">সর্ব মোট: </th>
												<th style="text-align:right;padding-right:5px;"><?php echo Converter::en2bn(($order_tk+$order_tk2+$order_tk3+$receivable_tk)-$order_tk4-$order_tk5); ?>/=</th>
											</tr>
										</thead>
										
									</table>
									<table border="1" style="width:100%">
										<thead>
											<tr>
												<th data-toggle="modal" data-target="#myModal" onclick="showOnlyFabricsPriceTotal('<?php echo $sdate; ?>','<?php echo $tdate; ?>','<?php echo $order_tk6; ?>')" style="text-align:right;padding-right:5px;cursor:pointer">ফ্যাব্রিক্স এর টাকা (Order+Pay+Delivery+Only Fabrics): </th>
												<th data-toggle="modal" data-target="#myModal" onclick="showOnlyFabricsPriceTotal('<?php echo $sdate; ?>','<?php echo $tdate; ?>','<?php echo $order_tk6; ?>')" style="text-align:right;padding-right:5px;cursor:pointer"><?php echo Converter::en2bn($order_tk6); ?>/=</th>
											</tr>
										</thead>
										
									</table>
							</div>
						</div>
					</div>
					
				</div>
				<?php 
			}else{
				echo "";// plz date select
			}
		}else if($print_type==10){
			$order_number=trim($_REQUEST['order_number']); // fabrics ord no 
			$idetails="";$dis="";
			$monthly_report_sql=$conn->query("select insert_date pdate,id,f_total,discount,discount_tk,cus_mobile,(select cus_name from customer where cus_mobile=direct_sale_head.cus_mobile and is_active=1 limit 0,1) customer_name,others_tk,total_receive,
				(select update_due.last_due from update_due where update_due.cus_id=(select customer.id from customer where customer.cus_mobile=direct_sale_head.cus_mobile limit 0,1) and update_due.is_active=1 order by update_due.id desc limit 0,1) total_due FROM `direct_sale_head` WHERE `com_id`=$com_id and is_active=1 and is_order=0 and id='$order_number'");
			if(mysqli_num_rows($monthly_report_sql)>0){
				$rows=mysqli_fetch_array($monthly_report_sql);
				$customer_name=$rows['customer_name'];
				$cus_mobile=$rows['cus_mobile'];
				$fab_total=$rows['f_total'];
				$discount=$rows['discount'];
				$discount_tk=$rows['discount_tk'];
				$others_tk=$rows['others_tk'];
				$total_receive=$rows['total_receive'];
				$dates=$rows['pdate'];
				$total_due=$rows['total_due'];
				
				if($discount>0){
					$dis="<div style='overflow:hidden;font-size: 10px;
							font-weight: bold;text-align:center;
							padding-top: 3px;
							padding-bottom: 3px;
							'>	
							<div style='float: left;text-align: right;width: 204px;'>	
								Discount($discount%): 
							</div>
							<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 5px;'>	
								$discount_tk
							</div>
							
						</div>";
				}
				
				
				$fabrics_sql=$conn->query("select item_id,item_qty,price,(select product_name from product where id=direct_sale.item_id) item_name FROM `direct_sale` WHERE is_active=1 and dstid='$order_number'");
				$sl=0;$c=1;
			if($_SESSION['MEASURE_TYPE']==0){ //0=standerd,1=Local,2=Normal
				while($rows=mysqli_fetch_array($fabrics_sql)){
					$sl=$c++;
					$item_name=$rows['item_name'];
					$item_qty=$rows['item_qty'];
					$item_price=$rows['price'];
					if($discount_tk>0){
						$item_price=(($item_price*100)/(100-$discount));
					}
					$tprice=($item_qty*$item_price);
					
					$idetails.="<div style='float:left;width: 7%;'>	
						$sl.
					</div>
					<div style='float:left;width: 53%;text-align:left'>	
						$item_name
					</div>
					<div style='float:left;width: 10%;'>	
						$item_qty
					</div>
					<div style='float:left;width: 15%;text-align: right;'>	
						$item_price
					</div>
					<div style='float:left;width: 15%;text-align: right;padding-right: 5px;'>	
						$tprice
					</div>";
				}
				$sl=$sl+1;
				if($others_tk>0){
					$otaka=$others_tk;
					$fab_total+=$otaka;
					$otaka_title="Others ";
					$idetails.="<div style='float:left;width: 7%;'>	
						$sl.
					</div>
					<div style='float:left;width: 53%;text-align:left'>	
						Others
					</div>
					<div style='float:left;width: 10%;'>	
						---
					</div>
					<div style='float:left;width: 15%;text-align: right;'>	
						$otaka
					</div>
					<div style='float:left;width: 15%;text-align: right;padding-right: 5px;'>	
						$otaka
					</div>";
				}
				
				if($discount_tk>0){
					$fab_totald=($fab_total-$discount_tk);
					$remaining=($fab_totald-$total_receive);
				}else{
					$remaining=($fab_total-$total_receive);
				}
				
			?>
			
<div id='print_area' style='overflow:hidden;margin-top:5px;margin-bottom: 6px; width:290px;display: block; page-break-before: always;'>
	<div style='overflow:hidden;padding-top:25px;'>	
		<div style='line-height: 5px;padding-top:15px;text-align:center;'>	
			<p style='font-size: 15px;font-weight: bold;padding-top:0px;'><?php echo $_SESSION['COM']; ?></p>
			<p style='font-size: 12px; font-weight: bold;padding-top: 0px;'><?php echo $_SESSION['COM_ADDRESS']; ?></p>
			<p style='font-size: 11px; font-weight: bold;padding-top: 0px;'><?php echo $_SESSION['EMAIL']; ?></p>
			<p style='font-size: 11px; font-weight: bold;padding-top: 0px;'><?php echo $_SESSION['COM_MOBILE']; ?></p>
		</div>
		
	</div>
	
	<div style='overflow:hidden;margin-top: 20px;'>	
		<div style='float:left; padding-left: 6px;'>	
			<p style='font-size: 10px;'><b>Order No:</b> <?php echo $order_number; ?></span>
		</div>
		<div style='float:right; padding-right: 6px;'>	
			<p style='font-size: 10px;'><?php echo $dates; ?></p>
		</div>
	</div>
	<div style='overflow:hidden;margin-top: 0px;'>	
		<div style='float:left; padding-left: 6px;width: 50%;'>	
			<p style='font-size: 10px;'><b>Customer:</b> <?php echo $customer_name; ?></span>
		</div>
		<div style='float:left; padding-right: 6px;width:50%;text-align:right;'>	
			<p style='font-size: 10px;'><?php echo $cus_mobile; ?></p>
		</div>
	</div>
	<div style='overflow:hidden;margin-top: -3px;margin-left: 6px;
			margin-right: 6px;'>	
	<div style='width: 100%;margin-bottom: -6px;'>	
			-----------------------------------------------------------
	</div>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;margin-bottom: -7px;'>	
			<div style='float:left;width: 7%;'>	
				Sl
			</div>
			<div style='float:left;width: 53%;text-align:left'>	
				Description
			</div>
			<div style='float:left;width: 10%;'>	
				Qty
			</div>
			<div style='float:left;width: 15%;text-align: right;'>	
				Rate
			</div>
			<div style='float:left;width: 15%;text-align: right;padding-right: 5px;'>	
				Taka
			</div>
		</div>
	<div style='width: 100%;margin-bottom: -6px;'>	
			-----------------------------------------------------------
	</div>
	<div style=''>
		<div style='overflow:hidden;font-size: 9px;
			font-weight: bold;text-align:center;
			padding-bottom: 15px;'>	
			<?php echo $idetails; ?>
		</div>
	</div>
	<div style='width: 100%;margin-bottom: -6px;'>	
			-----------------------------------------------------------
	</div>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;
			
			padding-bottom: 3px;
			'>	
			<div style='float: left;text-align: right;width: 204px;'>	
				Total: 
			</div>
			<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 5px;'>	
				<?php echo $fab_total; ?>
			</div>
			
		</div>
		<?php echo $dis; ?>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;
			padding-top: 3px;
			padding-bottom: 3px;
			'>	
			<div style='float: left;text-align: right;width: 204px;'>	
				Receive: 
			</div>
			<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 5px;'>	
				<?php echo $total_receive; ?>
			</div>
			
		</div>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;
			padding-top: 3px;
			padding-bottom: 3px;'>	
			<div style='float: left;text-align: right;width: 204px;'>	
				Present Due: 
			</div>
			<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 5px;'>	
				<?php echo $remaining; ?>
			</div>
			
		</div>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;
			padding-top: 3px;
			padding-bottom: 3px;'>	
			<div style='float: left;text-align: right;width: 204px;'>	
				Total Due: 
			</div>
			<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 5px;'>	
				<?php echo $total_due; ?>
			</div>
			
		</div>
	<div style='width: 100%;margin-bottom: -6px;'>	
			-----------------------------------------------------------
	</div>
	
	</div>
	
	<div style='width: 100%;text-align: center;padding-top: 65px;padding-bottom: 50px;'>	
			*** Thanks for your purchase ***
	</div>
	
</div>
		
			<?php
			}else{
				while($rows=mysqli_fetch_array($fabrics_sql)){
					$sl=$c++;
					$item_name=$rows['item_name'];
					$item_qty=$rows['item_qty'];
					$item_price=$rows['price'];
					if($discount_tk>0){
						$item_price=(($item_price*100)/(100-$discount));
					}
					$tprice=($item_qty*$item_price);
					
					$idetails.="<div style='float:left;width: 5%;'>	
						$sl.
					</div>
					<div style='float:left;width: 55%;'>	
						$item_name
					</div>
					<div style='float:left;width: 10%;'>	
						$item_qty
					</div>
					<div style='float:left;width: 15%;text-align: right;'>	
						$item_price
					</div>
					<div style='float:left;width: 15%;text-align: right;padding-right: 5px;'>	
						$tprice
					</div>";
				}
				$sl=$sl+1;
				if($others_tk>0){
					$otaka=$others_tk;
					$fab_total+=$otaka;
					$otaka_title="অন্যান্য ";
					$idetails.="<div style='float:left;width: 5%;'>	
						$sl.
					</div>
					<div style='float:left;width: 55%;'>	
						অন্যান্য
					</div>
					<div style='float:left;width: 10%;'>	
						---
					</div>
					<div style='float:left;width: 15%;text-align: right;'>	
						$otaka
					</div>
					<div style='float:left;width: 15%;text-align: right;padding-right: 5px;'>	
						$otaka
					</div>";
				}
				
				if($discount_tk>0){
					$fab_totald=($fab_total-$discount_tk);
					$remaining=($fab_totald-$total_receive);
				}else{
					$remaining=($fab_total-$total_receive);
				}
				
			?>
			
		<div id='print_area' style='overflow:hidden;margin-top:5px;margin-bottom: 6px;border: 1px solid gray; width:580px;height:600px;display: block; page-break-before: always;'>
	<div style='overflow:hidden;padding-top: 10px;'>	
		<div style='float:left; line-height: 3px;padding-left: 228px;'>	
			<p style='font-size: 10px;'>বিসমিল্লাহির রাহমানির রাহিম</p>
			<p style='font-size: 12px;font-weight: bold;padding-left: 28px;padding-top:0px;'>ক্যাশ মেমো</p>
			<p style='font-size: 14px; font-weight: bold;padding-left:6px;padding-top: 0px;'>MM Company Ltd.</p>
		</div>
		<div style='float:right;text-align: right;padding-right: 6px;line-height: 3px;'>	
			<p style='font-size: 10px;'>মুজিবর রহমান</p>
			<p style='font-size: 10px;'>প্রোপ্রাইটর</p>
			<p style='font-size: 10px;'>মোবা: ০১৭১৮৬৩৫৫৩৬</p>
		</div>
	</div>
	<div style='overflow:hidden; margin-top: -4px;'>	
		<div style='text-align:center'>	
			<p style='font-size: 10px;'>শিববাড়ি, জয়দেবপুর,গাজীপুর</span>
		</div>
	</div>
	<div style='overflow:hidden;margin-top: -3px;'>	
		<div style='float:left; padding-left: 6px;'>	
			<p style='font-size: 10px;'>ক্রমিক নং: <?php echo $order_number; ?></span>
		</div>
		<div style='float:right; padding-right: 6px;'>	
			<p style='font-size: 10px;'>তারিখ: <?php echo $dates; ?></p>
		</div>
	</div>
	<div style='overflow:hidden;margin-top: -7px;'>	
		<div style='float:left; padding-left: 6px;width: 30%;'>	
			<p style='font-size: 10px;'>নাম: <?php echo $customer_name; ?></span>
		</div>
		<div style='float:left; padding-right: 6px;width: 40%;'>	
			<p style='font-size: 10px;'>ঠিকানা:............................</p>
		</div>
		<div style='float:left; padding-right: 6px;width: 30%;'>	
			<p style='font-size: 10px;'>মোবা:  <?php echo $cus_mobile; ?></p>
		</div>
	</div>
	<div style='overflow:hidden;margin-top: -3px;margin-left: 6px;
			margin-right: 6px;border: 1px solid gray;'>	
	
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;background: lightgray;
			padding-top: 3px;
			padding-bottom: 3px;
			'>	
			<div style='float:left;width: 5%;'>	
				নং
			</div>
			<div style='float:left;width: 55%;'>	
				বিবরণ
			</div>
			<div style='float:left;width: 10%;'>	
				পরিমান
			</div>
			<div style='float:left;width: 15%;text-align: right;'>	
				দর
			</div>
			<div style='float:left;width: 15%;text-align: right;padding-right: 5px;'>	
				টাকা
			</div>
		</div>
	<div style='height:327px'>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;
			padding-top: 3px;
			padding-bottom: 3px;'>	
			<?php echo $idetails; ?>
		</div>
	
		
	</div>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;
			
			padding-bottom: 3px;
			'>	
			<div style='float: left;width: 490px;text-align: right;'>	
				মোট: 
			</div>
			<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 5px;'>	
				<?php echo $fab_total; ?>
			</div>
			
		</div>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;
			padding-top: 3px;
			padding-bottom: 3px;
			'>	
			<div style='float: left;width: 490px;text-align: right;'>	
				ছাড় ($discount%): 
			</div>
			<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 5px;'>	
				<?php echo $discount_tk; ?>
			</div>
			
		</div>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;
			padding-top: 3px;
			padding-bottom: 3px;
			'>	
			<div style='float: left;width: 490px;text-align: right;'>	
				জমা: 
			</div>
			<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 5px;'>	
				<?php echo $total_receive; ?>
			</div>
			
		</div>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;
			padding-top: 3px;
			padding-bottom: 3px;
			'>	
			<div style='float: left;width: 490px;text-align: right;'>	
				বকেয়া: 
			</div>
			<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 5px;'>	
				<?php echo $remaining; ?>
			</div>
			
		</div>
	
	</div>
	
	<div style='overflow:hidden;margin-top: 32px;'>	
	<div style='float:left; padding-left: 16px;font-size: 11px;'>	
		সাক্ষর
	</div>
	<div style='float: right;padding-right: 6px;font-size: 9px; padding-top: 14px;'>	
		EasyTech24
	</div>

	</div>
</div>
	<?php 
			}
			}else{
				echo "<span style='color:red'>Invalid Order/Serial No.</span>";
			}
		}else if($print_type==11){
			$date1=explode("/",$_REQUEST['date1']);
			$date2=explode("/",$_REQUEST['date2']);
			$total=0;
			$c=0;$sl=0;
			$d1=$date1[2]."-".$date1[1]."-".$date1[0];
			$d2=$date2[2]."-".$date2[1]."-".$date2[0];
			$monthly_report_sql=$conn->query("select item_id,sum(item_qty) qty,sum(price*item_qty) sprice,sum(purchase_price*item_qty) avg_price,(select product_name from product where id=direct_sale.item_id) item_name from direct_sale where `com_id`=$com_id and in_out_status=0 and is_active=1 and date(insert_date) between '$d1' and '$d2' and order_number is null group by item_id order by qty desc");
			$monthly_report_sql2=$conn->query("select item_id,sum(item_qty) qty,sum(price*item_qty) sprice,sum(purchase_price*item_qty) avg_price,(select product_name from product where id=direct_sale.item_id) item_name from direct_sale where `com_id`=$com_id and in_out_status=0 and is_active=1 and date(insert_date) between '$d1' and '$d2' and order_number is not null group by item_id order by qty desc");
			
				?>
					<div class="row" style="background:white">
					<div class="col-xs-12 col-sm-12">
								
								<?php 
							$tprofit=0;$tsprice=0;
							if(mysqli_num_rows($monthly_report_sql)>0){
								?>
								<label>Fabrics Direct Sales Item List</label>
								<table id="dynamic-table" class="table table-striped table-bordered table-hover">
									<thead>
										<tr>
											<th style="width:5%;text-align: center;">Sl</th>
											<th style="width:30%;">Item Name</th>
											<th style="width:10%;text-align:center">Qty(গজ)</th>
											<th style="width:10%;text-align:right">Sale Price</th>
											<th style="width:15%;text-align:right">Purchase Price</th>
											<th style="width:10%;text-align:right">Profit(Tk.)</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl=1;$tot_qty=0;
											while($rows=mysqli_fetch_array($monthly_report_sql)){
													$tot_qty+=$rows['qty'];
													//$tprofit+=($rows['sprice']-($rows['avg_price']*$rows['qty']));
													$tprofit+=($rows['sprice']-$rows['avg_price']);
													$tsprice+=$rows['sprice'];
													$c=$sl++;
													?>
													<tr>
													<td style="text-align: center;"><?php echo $c; ?></td>
													<td><?php echo $rows['item_name']; ?></td>
													<td style="text-align: center;"><?php echo round($rows['qty'],2); ?></td>
													<td style="text-align: right;"><?php echo round(($rows['sprice']),2); ?></td>
													<td style="text-align: right;"><?php echo round($rows['avg_price'],2); ?></td>
													<td style="text-align: right;"><?php echo round(($rows['sprice']-$rows['avg_price']),2); ?></td>
													</tr>
													<?php 
												}
										?>
									</tbody>
									<tr>
										<th colspan="2"  style="text-align:right">Total Item</th>
										<th style="width:40%;text-align:center"><?php echo round($tot_qty,2); ?></th>
										<th style="width:10%;text-align:right"><?php echo round($tsprice,2); ?></th>
										<th colspan="1"  style="text-align:right">Profit</th>
										<th style="width:10%;text-align:right"><?php echo round($tprofit,2); ?></th>
										
									</tr>
								</table>
								<?php 
							}
							?>	

						<?php 
						$tprofit2=0;$tsale=0;
							if(mysqli_num_rows($monthly_report_sql2)>0){
								?>
								<label>Fabrics Tailor Sales Item List</label>
								<table id="dynamic-table" class="table table-striped table-bordered table-hover">
									<thead>
										<tr>
											<th style="width:5%;text-align: center;">Sl</th>
											<th style="width:30%;">Item Name</th>
											<th style="width:10%;text-align:center">Qty(গজ)</th>
											<th style="width:10%;text-align:right">Sale Price</th>
											<th style="width:15%;text-align:right">Purchase Price</th>
											<th style="width:10%;text-align:right">Profit(Tk.)</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl=1;$tot_qty=0;
											while($rows=mysqli_fetch_array($monthly_report_sql2)){
													$tot_qty+=$rows['qty'];
													//$tprofit2+=(($rows['sprice'])-($rows['avg_price']*$rows['qty']));
													$tprofit2+=($rows['sprice']-$rows['avg_price']);
													$tsale+=$rows['sprice'];
													$c=$sl++;
													?>
													<tr>
													<td style="text-align: center;"><?php echo $c; ?></td>
													<td><?php echo $rows['item_name']; ?></td>
													<td style="text-align: center;"><?php echo round($rows['qty'],2); ?></td>
													<td style="text-align: right;"><?php echo round(($rows['sprice']),2); ?></td>
													<td style="text-align: right;"><?php echo round($rows['avg_price'],2); ?></td>
													<td style="text-align: right;"><?php echo round(($rows['sprice']-$rows['avg_price']),2); ?></td>
													</tr>
													<?php 
												}
										?>
									</tbody>
									<tr>
										<th colspan="2"  style="text-align:right">Total Item</th>
										<th style="width:40%;text-align:center"><?php echo $tot_qty; ?></th>
										<th style="width:10%;text-align:right"><?php echo round($tsale,2); ?></th>
										<th colspan="1"  style="text-align:right">Profit</th>
										<th style="width:10%;text-align:right"><?php echo round($tprofit2,2); ?></th>
										
									</tr>
								</table>
								<?php 
							}
							?>
							<h2> Total Fabrics Sales: <b><?php echo round(($tsprice+$tsale),2); ?></b> Taka <h2>
							<h2> Total Profit: <b><?php echo round(($tprofit2+$tprofit),2); ?></b> Taka <h2>
								
							</div>
							
					</div>
				
					<?php 
				
			
			}
			else if($print_type==12 || $print_type==17){
			$date1=explode("/",$_REQUEST['date1']);
			$date2=explode("/",$_REQUEST['date2']);
			$extra_item=$_REQUEST['extra_item'];
			if($extra_item=='all'){
				$con="";
			}else{
				$con="`item_id` =$extra_item and";
			}
			$total=0;
			$c=0;$sl=0;
			$d1=$date1[2]."-".$date1[1]."-".$date1[0];
			$d2=$date2[2]."-".$date2[1]."-".$date2[0];
			if($print_type==12){
				$monthly_report_sql=$conn->query("SELECT `item_id`,(select product_name from product where id=order_record.item_id) product_name, sum(`item_qty`) item_qty,sum(`receive_qty`) receive_qty FROM `order_record` WHERE $con `is_active`=1 and `com_id`=$com_id and date(insert_date) between '$d1' and '$d2' group by item_id");
			}else if($print_type==17){
				$d1=$date1[0].'/'.$date1[1].'/'.$date1[2];
				$d2=$date2[0].'/'.$date2[1].'/'.$date2[2];
				//echo "SELECT `item_id`,(select product_name from product where id=order_record.item_id) product_name, sum(`item_qty`) item_qty,sum(`delivery_qty`) receive_qty FROM `order_record` WHERE $con `receive_qty`>0 and `item_qty`!=`delivery_qty` and `is_active`=1 and `com_id`=$com_id and assign_date between '$d1' and '$d2' group by item_id";
				$monthly_report_sql=$conn->query("SELECT `item_id`,(select product_name from product where id=order_record.item_id) product_name, sum(`item_qty`) item_qty,sum(`delivery_qty`) receive_qty FROM `order_record` WHERE $con `receive_qty`>0 and `item_qty`!=`delivery_qty` and `is_active`=1 and `com_id`=$com_id and assign_date between '$d1' and '$d2' group by item_id");
			}
				?>
					<div class="row" style="background:white">
					<div class="col-xs-12 col-sm-12">
								
								<?php 
							$tprofit=0;
							if(mysqli_num_rows($monthly_report_sql)>0){
								?>
								<label>Item Not Making (Still Stay <?php echo ($print_type==12)? 'in Showroom' : 'in Factory'; ?>)</label>
								<table id="dynamic-table" class="table table-striped table-bordered table-hover">
									<thead>
										<tr>
											<th style="width:5%;text-align: center;">Sl</th>
											<th style="width:30%;">Item Name</th>
											<th style="width:10%;text-align:center">Qty</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl=1;$tot_qty=0;
											while($rows=mysqli_fetch_array($monthly_report_sql)){
													$tpending=($rows['item_qty']-$rows['receive_qty']);
													$item_id=$rows['item_id'];
													$c=$sl++;
													?>
													<tr>
													<td style="text-align: center;"><?php echo $c; ?></td>
													<td>
														<?php 
														if($print_type==17){
														?>
														<a href="javascript:void(0)" onclick="showOrderNumberItemWise('<?php echo $item_id; ?>','<?php echo $d1; ?>','<?php echo $d2; ?>')"><?php echo $rows['product_name']; ?></a> <span id="show_ord_num<?php echo $item_id; ?>"></span>
														<?php }else{ ?>
														<?php echo $rows['product_name']; } ?>
													</td>
													<td style="text-align: center;"><?php echo @$tpending; ?></td>
													</tr>
													<?php 
												}
										?>
									</tbody>
									
								</table>
								<?php 
							}
							?>	
	
					</div>
							
					</div>
				
					<?php 
				
			
			}else if($print_type==14){
			
			$extra_items=explode("#sep#",$_REQUEST['karigor_list']);
			$extra_item=$extra_items[0];
			$monthly_report_sql=$conn->query("SELECT `item_id`,order_number,(select product_name from product where id=order_record.item_id) product_name, receive_qty,assign_date FROM `order_record` WHERE `maker` =$extra_item and `is_active`=1 and receive_qty!=delivery_qty and `com_id`=$com_id");
			
				?>
					<div class="row" style="background:white">
					<div class="col-xs-12 col-sm-12">
								
								<?php 
							$tprofit=0;
							if(mysqli_num_rows($monthly_report_sql)>0){
								?>
								<label>Karigor Name wise Pending Status</label>
								<table id="dynamic-table" class="table table-striped table-bordered table-hover">
									<thead>
										<tr>
											<th style="width:5%;text-align: center;">Sl</th>
											<th style="width:30%;">Order Number</th>
											<th style="width:30%;">Item Name</th>
											<th style="width:10%;text-align:center">Assign Qty</th>
											<th style="width:10%;text-align:center">Assign Date</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl=1;$tot_qty=0;
											while($rows=mysqli_fetch_array($monthly_report_sql)){
													$c=$sl++;
													?>
													<tr>
													<td style="text-align: center;"><?php echo $c; ?></td>
													<td><?php echo $rows['order_number']; ?></td>
													<td><?php echo $rows['product_name']; ?></td>
													<td style="text-align: center;"><?php echo @$rows['receive_qty']; ?></td>
													<td style="text-align: center;"><?php echo @$rows['assign_date']; ?></td>
													</tr>
													<?php 
												}
										?>
									</tbody>
									
								</table>
								<?php 
							}else{
								echo "No Item Found!";
							}
							?>	
	
					</div>
							
					</div>
				
					<?php 
				
			
			}else if($print_type==23){
			
			$extra_items=explode("#sep#",$_REQUEST['karigor_list']);
			$user_id=$extra_items[0];
			$user_type=$extra_items[1];
			if($user_type==1){ // master id=1
			$item_sql=$conn->query("SELECT sum(item_qty) tot_iqty,sum(master_cutting_qty) tot_cqty from order_record where is_active=1 and master_id=$user_id");
			}else{ //karigor id=2
				$item_sql=$conn->query("SELECT sum(item_qty) tot_iqty,sum(receive_qty) tot_cqty  from order_record where is_active=1 and karigor_id=$user_id");
			}
			
				?>
				<div class="row" style="background:white">
					<div class="col-xs-12 col-sm-12">
								
						<?php 
						if(mysqli_num_rows($item_sql)>0){
							$row=mysqli_fetch_array($item_sql);
							?>
							<div style="cursor: pointer;font-size: 18px;" onclick="getDetailsPending('<?php echo $user_type; ?>','<?php echo $user_id; ?>')">
								<b>Total Pending:<?php echo ($row['tot_iqty']-$row['tot_cqty']); ?> </b>
							</div>
							<?php 
						}else{
							?>
							<div>
								<b>Total Pending:</b><?php echo '0'; ?> 
							</div>
							<?php 
						}
						?>
					</div>
					<div class="col-xs-12 col-sm-12" id="get_details_pending">
					</div>				
				</div>
				
					<?php 
				
			
			}else if($print_type==24){
			@$pdate =date('d/m/Y');
			$order_type=$_REQUEST['order_type'];
			$com_id=$_SESSION['COM_ID'];
			$list="";
			if($order_type=="urgent"){ // master id=1
			$psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,(select cus_name from customer where cus_mobile=ds.cus_mobile) cus_name,ds.cus_mobile umobile,ds.phy_ord_num,ds.amount,ds.cus_name,ds.factory_status,ds.fddate from dsms ds where ds.is_active=1 and ds.phy_dv_date IS NULL and ds.occasion=0 and ds.order_type=1 and ds.factory_status not in(1,2) and ds.com_id='$com_id' order by ds.id asc");
			$list="আর্জেন্ট অর্ডার লিস্ট";
			}
			if($order_type=="todays"){ // master id=1
			@$dv_date =date('d/m/Y'); // and ds.sms_status=0
			$psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,ds.cus_mobile umobile,ds.phy_dv_date,ds.phy_ord_num,ds.amount,ds.cus_name,ds.discount,ds.factory_status,ds.fddate from dsms ds where ds.is_active=1 and ds.factory_status not in(1,2) and ds.occasion=0 and ds.com_id='$com_id' and ds.fddate='$dv_date' and ds.phy_dv_date IS NULL order by ds.id asc");
			$list="আজকের অর্ডার লিস্ট";
			}
			if($order_type=="tomorrow"){
			@$dv_date =date('d/m/Y', strtotime(date('Y-m-d'). ' + 1 days'));
			$list="আগামী কালকের অর্ডার লিস্ট";
			$psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,ds.cus_mobile umobile,ds.phy_ord_num,ds.cus_name,ds.factory_status,ds.fddate from dsms ds where ds.is_active=1 and ds.occasion=0 and ds.factory_status not in(1,2) and ds.com_id='$com_id' and ds.fddate='$dv_date' and ds.phy_dv_date IS NULL order by ds.id asc");
			}
			
			if($order_type=="twodays"){
				$list="২ দিন পরের অর্ডার লিস্ট";
				@$dv_date =date('d/m/Y', strtotime(date('Y-m-d'). ' + 2 days'));
				$psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,ds.cus_mobile umobile,ds.phy_ord_num,ds.cus_name,ds.factory_status,ds.factory_receive_date,ds.fddate from dsms ds where ds.is_active=1 and ds.occasion=0 and ds.com_id='$com_id' and ds.factory_status not in(1,2) and ds.fddate='$dv_date' and ds.phy_dv_date IS NULL order by ds.id asc");
			}
			
			if($order_type=="expireddelivery"){
				$list="Expired ডেলিভারি অর্ডার লিস্ট";
				@$dv_date =date('d/m/Y');
				$psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,ds.cus_mobile umobile,ds.phy_ord_num,ds.cus_name,ds.factory_status,ds.fddate from dsms ds where ds.is_active=1 and ds.occasion=0 and ds.com_id='$com_id' and str_to_date(ds.fddate,'%d/%m/%Y') <= str_to_date('$dv_date','%d/%m/%Y') and ds.factory_status not in(1,2) and ds.phy_dv_date IS NULL order by ds.id asc");
			}
				?>
				<div class="row" style="background:white">
					<div class="col-xs-12 col-sm-12" style="text-align: center;">
						<span for="" style="font-size: 14px;font-weight: bold;"><?php echo $list; ?></span><br/>
						<span for="">As Said Panjabi Tailors & Fabrics</span><br/>
						
						<span for="">Printing Date: <?php echo $pdate; ?></span>
				<table id="example" border="1" style="border-collapse: collapse;width: 100%;">
				
					<thead>
						<tr>
							<th style="padding-left:5px">অর্ডার নম্বর</th>
							<th style="padding-left:5px">কাস্টমার</th>
							<th style="padding-left:5px">ডেলিভারি</th>
							<th style="padding-left:5px">আইটেম</th>
						</tr>
					</thead>
					<tbody>		
						<?php 
					while($row=mysqli_fetch_array($psmsquery)){
					
					$sms_id=$row['id'];
					$cus_name=$row['cus_name'];
					$dv_date=explode("-",$row['dv_date']);
					$dv_date=$dv_date[2]."/".$dv_date[1]."/".$dv_date[0];
					$dv_date=$row['fddate'];
					@$tagnum=$row['tagnum'];
					
					@$phy_ord_num=$row['phy_ord_num'];
					?>
					<tr>
						<td style="padding-left:5px">
							<span style='cursor: pointer;color:blue;font-weight:bold' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$row['phy_ord_num']; ?>')">
								<?php echo $phy_ord_num; ?>
							</span>
						</td>
						<td style="padding-left:5px">
							<?php echo $cus_name; ?>
						</td>
						<td style="padding-left:5px">
							<?php echo $dv_date; ?>
						
						</td>
						<td>
						<table id="example" class="">
				
					<tbody>
					<?php 
					
					$chk_com_p=$conn->query("SELECT (select product_name from product where id=sd.item_id) pname,sd.item_qty pqty,sd.order_number,sd.id ord_id,sd.receive_qty,(select user_name from user where id=sd.master_id) masters,(select user_name from user where id=sd.karigor_id) karigor,(select item_qty from wages_details where emp_type=2 and ord_record_tblid=sd.id) making_qty FROM `order_record` sd WHERE sd.com_id=$com_id and sd.is_active=1 and sd.dsms_id=$sms_id");
					while($rrows=mysqli_fetch_array($chk_com_p)){
						$pname=$rrows['pname'];
						$pqty=$rrows['pqty'];
						$order_number=$rrows['order_number'];
						$receive_qty=$rrows['receive_qty'];
						$ord_id=$rrows['ord_id'];
						@$masters=$rrows['masters'];
						@$karigor=$rrows['karigor'];
						@$making_qty=($rrows['making_qty']=="")? 0 : $rrows['making_qty'];
						@$making_qty="<span style='color:blue'>".$making_qty."</span>";
							?>
							<tr>
							<td style="padding-left:5px">
								<?php echo $pname; ?>(<?php echo $making_qty.'/'.$pqty; ?>)(<?php echo $ord_id; ?>)(<?php echo $masters; ?>)(<?php echo $karigor; ?>)
							</td>
						</tr>
							<?php 
					}
					
						?>
						</tbody>
					</table>
						</td>
					</tr>
			<?php } ?>
					</tbody>
				</table>
					</div>
					<div class="col-xs-12 col-sm-12" id="get_details_pending">
					</div>				
				</div>
				
					<?php 
				
			
			}else if($print_type==15){
			
		$order_type=$_REQUEST['order_type'];
			if($order_type=="pending"){
				$monthly_report_sql=$conn->query("SELECT DISTINCT(`order_number`) ord_number,(select user_name from user where id=order_record.maker) karigor,assign_date,date(insert_date) order_date FROM `order_record` WHERE `receive_qty`=0 and is_active=1 and `com_id`=$com_id limit 0,500");
			}else if($order_type=="inprogress"){
				$monthly_report_sql=$conn->query("SELECT DISTINCT(`order_number`) ord_number,(select user_name from user where id=order_record.maker) karigor,assign_date,date(insert_date) order_date FROM `order_record` WHERE `receive_qty`!=`delivery_qty` and is_active=1 and `com_id`=$com_id limit 0,500");
			}else{
				//echo "SELECT DISTINCT(`order_number`) ord_number,(select user_name from user where id=order_record.maker) karigor,assign_date,date(insert_date) order_date,delivery_date FROM `order_record` WHERE `receive_qty`>0 and `receive_qty`=`delivery_qty` and is_active=1 and `com_id`=$com_id limit 0,500";
				$monthly_report_sql=$conn->query("SELECT DISTINCT(order_record.`order_number`) ord_number,(select user_name from user where id=order_record.maker) karigor,order_record.assign_date,date(order_record.insert_date) order_date,order_record.delivery_date FROM `order_record`,dsms ds WHERE order_record.dsms_id=ds.id and ds.phy_dv_date is null and order_record.`receive_qty`>0 and order_record.`receive_qty`=`delivery_qty` and order_record.is_active=1 and order_record.`com_id`=$com_id");
			}
			
			
				?>
					<div class="row" style="background:white">
					<div class="col-xs-12 col-sm-12">
								
								<?php 
							$tprofit=0;
							if(mysqli_num_rows($monthly_report_sql)>0){
								?>
								<label>Karigor Name wise Pending Status</label>
								<table id="dynamic-table" class="table table-striped table-bordered table-hover">
									<thead>
										<tr>
											<th style="width:5%;text-align: center;">Sl</th>
											<th style="width:30%;">Order Number</th>
											<th style="width:30%;">Order Date</th>
											<th style="width:10%;text-align:center">Assign By</th>
											<th style="width:10%;text-align:center">Assign Date</th>
											<th style="width:10%;text-align:center;color:green">Delivery Date</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl=1;$tot_qty=0;
											while($rows=mysqli_fetch_array($monthly_report_sql)){
													$c=$sl++;
													?>
													<tr>
													<td style="text-align: center;"><?php echo $c; ?></td>
													<td>
													<span style='color:#ec68d0;cursor: pointer;' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$rows['ord_number']; ?>')"><b><?php echo @$rows['ord_number']; ?></b></span>
													</td>
													<td><?php echo $rows['order_date']; ?></td>
													<td style="text-align: center;"><?php echo @$rows['karigor']; ?></td>
													<td style="text-align: center;"><?php echo @$rows['assign_date']; ?></td>
													<td style="text-align: center;color:green"><?php echo @$rows['delivery_date']; ?></td>
													</tr>
													<?php 
												}
										?>
									</tbody>
									
								</table>
								<?php 
							}else{
								echo "No Item Found!";
							}
							?>	
	
					</div>
							
					</div>
				
					<?php 
				
			
			
		}else if($print_type==9){
			$com_id=($_SESSION['COM_ID']);
			$product=$conn->query("select * from product where is_active=2 and com_id=$com_id and ptype in(1,2) order by id asc limit 2500");
			$product2=$conn->query("select * from product where is_active=2 and com_id=$com_id and ptype in(1,2) order by id asc limit 2500");
			?>
			<div class="row">
				<div class="col-xs-12 col-sm-4" style="">
					<label for="comment" class="txt_color">Item Name</label>
					<select id="item_name" class="form-control select2">
						<option value="">Select One</option>
						<?php 
						if(mysqli_num_rows($product2)>0){
						
							while($rows2=mysqli_fetch_array($product2)){
								?>
								<option value="<?php echo $rows2['item_code']; ?>"><?php echo $rows2['product_name']; ?></option>
								<?php 
							}
						}
								?>
					</select>
				</div>	
				<div class="col-xs-12 col-sm-4" style="">
					<label for="comment" class="txt_color">Item Code</label>
					<input type="text" class="form-control" style="font-weight: bold;font-size:25px;font-style: italic;color: #4ba6a6;text-align: center;" autocomplete="off" name="tftotal_tk" id="item_code" required/>
				</div>	
				<button onclick="searchStockItem();" style="margin-top: 25px;;margin-right:5px" name="btn" value="sub" id="save_expense" class="btn btn-success">Search</button>
				<span id="expense_sms"></span>
			</div>
			<table style="width:100%" border="1">
				<tr>
					<th style="text-align:center">Sl</th>
					<th style="padding-left:4px">Item Name</th>
					<th style="text-align:center">Item Code</th>
					<th style="text-align:center">Present Stock</th>
					<th style="text-align:right;padding-right:4px">Purchase Price</th>
					<th style="text-align:right;padding-right:4px">Selling Price</th>
				</tr>
				<tbody id="stock_item">
			<?php 
			if(mysqli_num_rows($product)>0){
						$i=1;$tqty=0;$ttaka=0;
							while($rows=mysqli_fetch_array($product)){
								$j=$i++;
								$tqty+=$rows['stock_qty'];
								$ttaka+=round(($rows['stock_qty']*$rows['purchase_price']),2);
						?>
							<tr>
								<td style="text-align:center">
									<?php 
										echo $j;
									?>
								</td>
								<td style="padding-left:4px">
								<?php echo $rows['product_name']; ?>
								</td>
								
								<td style="text-align:center">
								<?php echo $rows['item_code']; ?>
								</td>
								<td style="text-align:center">
								<?php echo ($rows['stock_qty']<$_SESSION['SAFETY_STOCK'])? "<span style='color:red'>".$rows['stock_qty']."</sapn>" : $rows['stock_qty']; ?><p style="font-size:8px;color:blue"><?php echo $rows['uom']; ?></p>
								</td>
								<td style="text-align:right;padding-right:4px"><?php echo $rows['purchase_price']; ?></td>
								<td style="text-align:right;padding-right:4px">
								 <span style="<?php echo ($rows['purchase_price']>=$rows['selling_price'])? 'color:red': ''; ?>"><?php echo $rows['selling_price']; ?></span>
								</td>
								
							</tr>
						<?php 
							}
							?>
							<tr>
								<td colspan="3" style="text-align: right;font-weight: bold;">
									Total Stock Qty & Price: 
								</td>
								<td style="text-align: center;font-weight: bold;">
									<?php echo $tqty; ?>
								</td>
								<td style="text-align: right;font-weight: bold;">
									<?php echo $ttaka; ?>
								</td>
							</tr>
						</tbody>
						</table>
							<?php 
							echo "<input type='hidden' value='$j' id='ilast_id'/>";
			
			}else{
				echo "<input type='hidden' value='0' id='ilast_id'/>";
			}
			}else if($print_type==18){
			$date1=explode("/",$_REQUEST['date1']);
			$date2=explode("/",$_REQUEST['date2']);
			$extra_item=$_REQUEST['extra_item'];
			
			$total=0;
			$c=0;$sl=0;
			$d1=$date1[2]."-".$date1[1]."-".$date1[0];
			$d2=$date2[2]."-".$date2[1]."-".$date2[0];
			if($extra_item=='order'){
				$monthly_report_sql=$conn->query("SELECT `item_id`,(select product_name from product where id=order_record.item_id) product_name, sum(`item_qty`) item_qty,sum(`receive_qty`) receive_qty FROM `order_record` WHERE `is_active`=1 and `com_id`=$com_id and date(insert_date) between '$d1' and '$d2' group by item_id");
			}else if($extra_item=="receive"){
				$d1=$date1[0].'/'.$date1[1].'/'.$date1[2];
				$d2=$date2[0].'/'.$date2[1].'/'.$date2[2];
				//echo "SELECT `item_id`,(select product_name from product where id=order_record.item_id) product_name, sum(`receive_qty`) item_qty FROM `order_record` WHERE `receive_qty`>0 and `is_active`=1 and `com_id`=$com_id and assign_date between '$d1' and '$d2' group by item_id";
				$monthly_report_sql=$conn->query("SELECT `item_id`,(select product_name from product where id=order_record.item_id) product_name, sum(`receive_qty`) item_qty FROM `order_record` WHERE `receive_qty`>0 and `is_active`=1 and `com_id`=$com_id and assign_date between '$d1' and '$d2' group by item_id");
			}else if($extra_item=="delivery"){
				
				//echo "SELECT `item_id`,(select product_name from product where id=order_record.item_id) product_name,sum(`item_qty`) item_qty FROM `order_record` WHERE `is_active`=1 and `com_id`=$com_id and dsms_id in (select id from dsms where is_active=1 and phy_ord_num between '$d1' and '$d2') group by item_id";
				$monthly_report_sql=$conn->query("SELECT `item_id`,(select product_name from product where id=order_record.item_id) product_name,sum(`item_qty`) item_qty FROM `order_record` WHERE `is_active`=1 and `com_id`=$com_id and dsms_id in (select id from dsms where is_active=1 and phy_dv_date between '$d1' and '$d2') group by item_id");
			}else if($extra_item=="only_delivery"){
				
				//echo "SELECT `item_id`,(select product_name from product where id=order_record.item_id) product_name,sum(`item_qty`) item_qty FROM `order_record` WHERE `is_active`=1 and `com_id`=$com_id and dsms_id in (select id from dsms where is_active=1 and phy_ord_num between '$d1' and '$d2') group by item_id";
				$monthly_report_sql=$conn->query("SELECT `item_id`,(select product_name from product where id=order_record.item_id) product_name,sum(`item_qty`) item_qty FROM `order_record` WHERE `is_active`=1 and `com_id`=$com_id and dsms_id in (select id from dsms where is_active=1 and dv_date between '$d1' and '$d2' and phy_dv_date is null) group by item_id");
			}else if($extra_item=="factory_delivery"){
				$d1=$date1[0].'/'.$date1[1].'/'.$date1[2];
				$d2=$date2[0].'/'.$date2[1].'/'.$date2[2];
				$monthly_report_sql=$conn->query("SELECT `item_id`,(select product_name from product where id=order_record.item_id) product_name,sum(`item_qty`) item_qty FROM `order_record` WHERE `is_active`=1 and `com_id`=$com_id and delivery_date between '$d1' and '$d2' group by item_id");
			}
				?>
					<div class="row" style="background:white">
					<div class="col-xs-12 col-sm-12">
								
								<?php 
							$tprofit=0;
							if(mysqli_num_rows($monthly_report_sql)>0){
								?>
								<label>Item Status</label>
								<table id="dynamic-table" class="table table-striped table-bordered table-hover">
									<thead>
										<tr>
											<th style="width:5%;text-align: center;">Sl</th>
											<th style="width:30%;">Item Name</th>
											<th style="width:10%;text-align:center">Qty</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl=1;$tot_qty=0;
											while($rows=mysqli_fetch_array($monthly_report_sql)){
													//$tpending=($rows['item_qty']-$rows['receive_qty']);
													$item_id=$rows['item_id'];
													$tot_qty+=$rows['item_qty'];
													$c=$sl++;
													?>
													<tr>
													<td style="text-align: center;"><?php echo $c; ?></td>
													<td>
														<?php 
														/*if($print_type==17){
														?>
														<a href="javascript:void(0)" onclick="showOrderNumberItemWise('<?php echo $item_id; ?>','<?php echo $d1; ?>','<?php echo $d2; ?>')"><?php echo $rows['product_name']; ?></a> <span id="show_ord_num<?php echo $item_id; ?>"></span>
														<?php }else{*/ ?>
														<a href="javascript:void(0)" onclick="showOrderNumberItemWise('<?php echo $item_id; ?>','<?php echo $d1; ?>','<?php echo $d2; ?>','<?php echo $extra_item; ?>')"><?php echo $rows['product_name']; ?></a> <span id="show_ord_num<?php echo $item_id; ?>"></span>
														
													</td>
													<td style="text-align: center;"><?php echo @$rows['item_qty']; ?></td>
													</tr>
													<?php 
												}
										?>
										<tr>
											<td colspan="2" style="text-align: right;font-weight:bold">Total</td>
											
											<td style="text-align: center;font-weight:bold"><?php echo @$tot_qty; ?></td>
										</tr>
									</tbody>
									
								</table>
								<?php 
							}
							?>	
	
					</div>
							
					</div>
				
					<?php 
				
			
			}else if($print_type==19){
			$date1=explode("/",$_REQUEST['date1']);
			$date2=explode("/",$_REQUEST['date2']);
			$status=$_REQUEST['extra_item'];
			$emp_list=$_REQUEST['karigor_list'];
			$con="";$con2="";
			if($emp_list!=""){
				$con.=" and emp_id=$emp_list ";
			}
			$total=0;
			$c=0;$sl=0;
			//$d1=$date1[2]."-".$date1[1]."-".$date1[0];
			$d1="";
			$d2=$date2[2]."-".$date2[1]."-".$date2[0];
			if(@$_REQUEST['date1']!=""){
				$d1=$date1[2]."-".$date1[1]."-".$date1[0];
				$con.=" and date(insert_date) between '$d1' and '$d2'";
				$con2.=" and date(insert_date) between '$d1' and '$d2'";
			}else{
				$con.=" and date(insert_date)<='$d2'";
			}
			if($status=='earning'){
				$statuss=0;
				$monthly_report_sql=$conn->query("SELECT emp_id,(select user_name from user where user.id=wages_details.emp_id) emp_name,
					(select emp_type from user where user.id=wages_details.emp_id) emp_type,
					(select mobile from user where user.id=wages_details.emp_id) emp_mobile,

					(select sum(taka) from wages_details ws where ws.emp_id=wages_details.emp_id and `is_active`=1 and `com_id`=$com_id and status=0 $con2) earning,

					(select sum(taka) from wages_details ws where ws.emp_id=wages_details.emp_id and `is_active`=1 and `com_id`=$com_id and status=1 $con2) payment

					FROM `wages_details` WHERE `is_active`=1 and `com_id`=$com_id $con group by emp_id order by earning desc");
			}else if($status=="payable"){
				$statuss=1;
				$monthly_report_sql=$conn->query("SELECT (select user_name from user where user.id=wages_details.emp_id) emp_name,(select emp_type from user where user.id=wages_details.emp_id) emp_type,(select mobile from user where user.id=wages_details.emp_id) emp_mobile, sum(`taka`) emp_tk,emp_id FROM `wages_details` WHERE `is_active`=1 and `com_id`=$com_id and status=$statuss $con group by emp_id order by emp_tk desc");
			}
			
				?>
					<div class="row" style="background:white">
					<div class="col-xs-12 col-sm-12">
								
								<?php 
							$tprofit=0;
							if(mysqli_num_rows($monthly_report_sql)>0){
								?>
								<label>Employee Earning/Payable Report </label>
								<table id="dynamic-table" class="table table-striped table-bordered table-hover">
									<thead>
										<tr>
											<th style="width:5%;text-align: center;">Sl</th>
											<th style="width:30%;">Employee Name</th>
											<th style="width:30%;text-align:center">Employee Type</th>
											<th style="width:10%;text-align:right">মজুরি/জমা(Tk.)</th>
											<th style="width:10%;text-align:right">মজুরি প্রদান(Tk.)</th>
											<th style="width:10%;text-align:right">বকেয়া(Tk.)</th>
											
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl=1;$tot_qty=0;$tot_paymet=0;
											while($rows=mysqli_fetch_array($monthly_report_sql)){
													$emp_ids=$rows['emp_id'];
													$tot_qty+=$rows['earning'];
													$tot_paymet+=$rows['payment'];
													$c=$sl++;
													?>
													<tr style="color: <?php 
														if($rows['emp_type']==1){
															echo "blue";
														}else if($rows['emp_type']==3){
															echo "#b60bc1;";
														}
														?>">
														<td style="text-align: center;"><?php echo $c; ?></td>
														<td>
															<span style='cursor: pointer;' data-toggle="modal" data-target="#myModal" onclick="showEmployeesDetails('<?php echo $d1; ?>','<?php echo $d2; ?>','earning','<?php echo $emp_ids; ?>','<?php echo $rows['emp_name'].'('.$rows['emp_mobile'].')'; ?>')">
																<?php echo $rows['emp_name'].'('.$rows['emp_mobile'].')'; ?>
															</span>
														</td>
														<td style="text-align: center;">
															<?php if($rows['emp_type']==1){ echo "Master"; }else if($rows['emp_type']==2){ echo "Karigor"; }else{ echo "Staff";} ?>
														</td>
														<td style="text-align: right;">
															<span style='cursor: pointer;' data-toggle="modal" data-target="#myModal" onclick="showEmployeesDetails('<?php echo $d1; ?>','<?php echo $d2; ?>','earning','<?php echo $emp_ids; ?>','<?php echo $rows['emp_name'].'('.$rows['emp_mobile'].')'; ?>')">
																<?php echo @$rows['earning']; ?>/=
															</span>
														</td>
														<td style="text-align: right;">
															<span style='cursor: pointer;' data-toggle="modal" data-target="#myModal" onclick="showEmployeesDetails('<?php echo $d1; ?>','<?php echo $d2; ?>','payable','<?php echo $emp_ids; ?>','<?php echo $rows['emp_name'].'('.$rows['emp_mobile'].')'; ?>')">
																<?php echo @$rows['payment']; ?>/=
															</span>
														</td>
														<td style="text-align: right;"><?php echo (@$rows['earning']-@$rows['payment']); ?>/=</td>
													</tr>
													<?php 
												}
										?>
										<tr>
										<td colspan="3" style="text-align: right;font-weight:bold">
											মোট মজুরি | প্রদান | বকেয়া: 
										</td>
										<td style="text-align: right;font-weight:bold"><?php echo @$tot_qty; ?>/=</td>
										<td style="text-align: right;font-weight:bold"><?php echo @$tot_paymet; ?>/=</td>
										<td style="text-align: right;font-weight:bold"><?php echo ($tot_qty-$tot_paymet); ?>/=</td>
										</tr>
									</tbody>
									
								</table>
								<?php 
							}
							?>	
	
					</div>
							
					</div>
				
					<?php 
				
			
			}else if($print_type==16){
			
			echo $expense_type=$_REQUEST['expense_type'];
			$date1=explode("/",$_REQUEST['date1']);
			$date2=explode("/",$_REQUEST['date2']);
			
			$d1=$date1[2]."-".$date1[1]."-".$date1[0];
			$d2=$date2[2]."-".$date2[1]."-".$date2[0];
			if($expense_type==""){
				$expense_type_sql=$conn->query("SELECT sum(`expense`) extk,expense_type,(select et.expense from expense_type et where et.id=expenses.expense_type) expense_title FROM `expenses` WHERE `is_active`=1 and date(`insert_date`) BETWEEN '$d1' and '$d2' GROUP by `expense_type`");
			}else{
				$expense_type_sql=$conn->query("SELECT sum(`expense`) extk,expense_type,(select et.expense from expense_type et where et.id=expenses.expense_type) expense_title FROM `expenses` WHERE `is_active`=1 and `expense_type`=$expense_type and date(`insert_date`) BETWEEN '$d1' and '$d2'");
			}
			
			
				?>
					<div class="row" style="background:white">
					<div class="col-xs-12 col-sm-12">
								
								<?php 
							$tprofit=0;
							if(mysqli_num_rows($expense_type_sql)>0){
								?>
								<label>Expense Report</label>
								<table id="dynamic-table" class="table table-striped table-bordered table-hover">
									<thead>
										<tr>
											<th style="width:5%;text-align: center;">Sl</th>
											<th style="width:75%;">Expense Type</th>
											<th style="width:20%;text-align:right">Taka/=</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sl=1;$tot_qty=0;
											while($rows=mysqli_fetch_array($expense_type_sql)){
													$c=$sl++;
													$tot_qty+=$rows['extk'];
													?>
													<tr>
														<td style="text-align: center;"><?php echo $c; ?></td>
														<td style='cursor: pointer;font-weight:bold' data-toggle="modal" data-target="#myModal" onclick="showExpenseBreakdown('<?php echo $rows['expense_title']; ?>','<?php echo @$rows['expense_type']; ?>','<?php echo @$d1; ?>','<?php echo @$d2; ?>')">
															<?php echo $rows['expense_title']; ?>
														</td>
														<td style="text-align: right;"><?php echo $rows['extk']; ?>/=</td>
													</tr>
													<?php 
												}
										?>
										<tr>
											<td colspan="2" style="text-align: right;font-weight:bold">Total</td>
											<td style="text-align: right;font-weight:bold"><?php echo $tot_qty; ?>/=</td>
										</tr>
									</tbody>
									
								</table>
								<?php 
							}else{
								echo "No Item Found!";
							}
							?>	
	
					</div>
							
					</div>
				
					<?php 
				
			
			}else{
				echo "<span style='color:red'>Invalid Order/Serial No.</span>";
			}
		
	}
	
	if(isset($_REQUEST['typwWiseUser'])){
		$user_type=$_REQUEST['user_type'];
		$com_id=($_SESSION['COM_ID']);
		$product=$conn->query("select * from user where is_active=1 and com_id=$com_id and user_type=$user_type and emp_type is null order by id asc");
			if(mysqli_num_rows($product)>0){
						$i=1;
							while($rows=mysqli_fetch_array($product)){
								$j=$i++;
						?>
							<tr>
								<td><button onclick='delEmployee(<?php echo $rows['id']; ?>,<?php echo $j; ?>);' name='btn' id='delbtn<?php echo $j; ?>' class="btn btn-danger form-control"><?php echo $j; ?></button></td>
								<td>
								<input readonly type="text" class="form-control" onkeyup="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','5');" value="<?php echo $rows['user_name']; ?>" id="user_name<?php echo $j; ?>"/>
								</td>
								<td><input readonly type="text" class="form-control" onkeyup="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','1');" value="<?php echo $rows['mobile']; ?>" id="mobile<?php echo $j; ?>"/></td>
								<td><input readonly type="text" class="form-control" onkeyup="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','2');" value="<?php echo $rows['log_user']; ?>" id="log_user<?php echo $j; ?>"/></td>
								<td><input readonly type="text" class="form-control" onkeyup="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','3');" value="<?php echo $rows['pass']; ?>" id="pass<?php echo $j; ?>"/></td>
								<td><?php echo Converter::en2bn(getUserWiseSale($rows['id'],0))."/="; ?><br/><b><?php echo Converter::en2bn(getUserWiseSale($rows['id'],1))."/="; ?></b></td>
								
							</tr>
						<?php 
							}
							echo "<input type='hidden' value='$j' id='ilast_id'/>";
			
			}else{
				echo "<input type='hidden' value='0' id='ilast_id'/>";
			}
	}
	
	if(isset($_REQUEST['addEmpPrice'])){
		$user_id=$_SESSION['USER_ID'];
		$com_id=($_SESSION['COM_ID']);
		$item_id=$_REQUEST['item_id'];
		$emp_id=$_REQUEST['emp_id'];
		$emp_type=$_REQUEST['emp_type'];
		$emp_price=($_REQUEST['emp_price']=="")? '0' : trim($_REQUEST['emp_price']);
		$user_price=$conn->query("SELECT * FROM `employees_price_setup` WHERE item_id=$item_id and emp_id='$emp_id' and is_active=1 order by id desc limit 0,1");
		if(mysqli_num_rows($user_price)>0){
			$rows=mysqli_fetch_array($user_price);
			$old_price=$rows['price'];
			if($emp_price!=$old_price){
				$order_details=$conn->query("insert into employees_price_setup(item_id,emp_id,emp_type,price,insert_by) values('$item_id','$emp_id','$emp_type','$emp_price','$user_id')");
			}else{
				$order_details=1;
			}
		}else{
			$order_details=$conn->query("insert into employees_price_setup(item_id,emp_id,emp_type,price,insert_by) values('$item_id','$emp_id','$emp_type','$emp_price','$user_id')");
		}
		if($order_details){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['employeePriceSetup'])){
		$com_id=($_SESSION['COM_ID']);
		$item_id=$_REQUEST['item_id'];
		$item_name=$_REQUEST['item_name'];
		$order_details=$conn->query("SELECT user.*,(select price from employees_price_setup where emp_id=user.id and is_active=1 and item_id='$item_id' order by id desc limit 0,1) emp_price FROM `user` WHERE com_id=$com_id and is_active=1 and emp_type in(1,2) and salary_type=1 order by emp_type desc");
		
		?>
		<label>Item: <?php echo $item_name.'['.$item_id.']'; ?></label>
		<table id="dynamic-table" class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th style="width:5%;text-align: center;">Sl</th>
					<th style="width:25%;">Employee</th>
					<th style="width:10%;text-align:center">Type</th>
					<th style="width:20%;"><span style="float: left;color: blue;text-decoration: underline;font-size: 12px;cursor:pointer" onclick="fillOutAll();"><i>same</i></span><span style="float: right;">Wages (Tk.)</span></th>
					<th style="width:10%;text-align:center"><button onclick="addEmpPrice('<?php echo $item_id; ?>');" name="btn" id="asrcbtn" value="sub" class="btn btn-success">Save</button></th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$sl=1;$tot_qty=0;
				if(mysqli_num_rows($order_details)>0){
					while($rows=mysqli_fetch_array($order_details)){
							$c=$sl++;
						?>
							<tr style="<?php echo ($rows['emp_type']==1)? 'color:blue' : ''; ?>">
								<td style="text-align: center;"><?php echo $c; ?></td>
								<td>
									<?php echo $rows['user_name']; ?>
								</td>
								<td style="text-align:center">
									<?php echo ($rows['emp_type']==1)? '<span style="color:blue">Master</span>' : 'Karigor'; ?>
								</td>
								<td>
									<input style="text-align:right;font-weight:bold;" class="form-control" type="text" value="<?php echo $rows['emp_price'] ?>" id="emp_price<?php echo $c; ?>"/>
								</td>
								<td style="text-align: center;">
									<input type="hidden" value="<?php echo $rows['id']; ?>" id="emp_id<?php echo $c; ?>"/>
									<input type="hidden" value="<?php echo $rows['emp_type']; ?>" id="emp_type<?php echo $c; ?>"/>
								</td>
							</tr>
							<?php 
						}
					}
				?>
					<input type="hidden" value="<?php echo $c; ?>" id="total_emp"/>
								
			</tbody>
			
		</table>
		<?php 
		
	}
	
	
	if(isset($_REQUEST['typwWiseItem'])){
		$item_type=$_REQUEST['item_type'];
		$ptype=$_REQUEST['ptype'];
		$com_id=($_SESSION['COM_ID']);
		if($ptype==1){
			$product=$conn->query("select * from product where is_active=1 and com_id=$com_id and ptype=$item_type order by steps asc limit 0,2500");
			if(mysqli_num_rows($product)>0){
						$i=1;
							while($rows=mysqli_fetch_array($product)){
								$j=$i++;
						?>
							<tr>
								<td><button onclick='delItem(<?php echo $rows['id']; ?>,<?php echo $j; ?>);' name='btn' id='delbtn<?php echo $j; ?>' class="btn btn-danger form-control"><?php echo $j; ?></button></td>
								<td>
								<input type="text" class="form-control" onkeyup="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','5');" value="<?php echo $rows['product_name']; ?>" id="product_name<?php echo $j; ?>"/>
								</td>
								<td><input type="text" class="form-control" onkeyup="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','1');" value="<?php echo $rows['cus_price']; ?>" id="cus_price<?php echo $j; ?>"/></td>
								<td style="text-align:center;color:blue;cursor:pointer"><span data-toggle="modal" data-target="#myModal" onclick="employeePriceSetup('<?php echo @$rows['id']; ?>','<?php echo @$rows['product_name']; ?>')"><i>View</i></span></td>
								<!--<td><input type="text" class="form-control" onkeyup="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','2');" value="<?php echo $rows['master_price']; ?>" id="mas_price<?php echo $j; ?>"/></td>
								<td><input type="text" class="form-control" onkeyup="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','3');" value="<?php echo $rows['artisan_price']; ?>" id="kar_price<?php echo $j; ?>"/></td>-->
								<td><input type="text" class="form-control" onkeyup="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','4');" value="<?php echo $rows['steps']; ?>" id="order<?php echo $j; ?>"/></td>
							</tr>
						<?php 
							}
							echo "<input type='hidden' value='$j' id='ilast_id'/>";
			
			}else{
				echo "<input type='hidden' value='0' id='ilast_id'/>";
			}
		}else{
			$product=$conn->query("select * from product where is_active=2 and com_id=$com_id and ptype=$item_type order by id asc limit 2500");
			if(mysqli_num_rows($product)>0){
						$i=1;$tqty=0;$ttaka=0;
							while($rows=mysqli_fetch_array($product)){
								$j=$i++;
								$tqty+=$rows['stock_qty'];
								$ttaka+=round(($rows['stock_qty']*$rows['avg_price']),2);
						?>
							<tr>
								<td style="text-align: center;">
									<?php 
									if($rows['stock_qty']>0){
										echo $j;
									}else{
										if($_SESSION['LOG_USER']=='admin'){
										?>
										<button onclick='delItem(<?php echo $rows['id']; ?>,<?php echo $j; ?>);' name='btn' id='delbtn<?php echo $j; ?>' class="btn btn-danger form-control"><?php echo $j; ?></button>
										<?php 
										}else{
											echo $j;
										}
									}
									?>
								</td>
								<td>
									<?php 
									if($_SESSION['LOG_USER']=='admin'){
									?>
									<input type="text" class="form-control" onkeyup="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','5');" value="<?php echo $rows['product_name']; ?>" id="product_name<?php echo $j; ?>"/>
									<?php }else{
										echo $rows['product_name'];
									} ?>
								</td>
								<?php 
								if($_SESSION['IS_STOCK']==1){ // 1=means maintain stock
								?>
								<td style="text-align:center">
								 	<?php 
									if($_SESSION['LOG_USER']=='admin'){
									?>
									<input type="text" style="text-align:center" class="form-control" onblur="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','6')" value="<?php echo $rows['item_code']; ?>" id="product_code<?php echo $j; ?>"/>
									<?php }else{
										echo $rows['item_code'];
									} ?>
								</td>
								<td style="text-align:center;font-weight: bold;">
								<?php echo ($rows['stock_qty']<$_SESSION['SAFETY_STOCK'])? "<span style='color:red'>".$rows['stock_qty']."</sapn>" : $rows['stock_qty']; ?><p style="font-size:8px;color:blue"><?php echo $rows['uom']; ?></p>
								</td>
								<td style="text-align:right"><?php echo $rows['avg_price']; ?></td>
								<td style="text-align:right;font-weight: bold;">
									<?php 
									if($_SESSION['LOG_USER']=='admin'){
									?>
									<input type="text" style="text-align:right;font-weight: bold;<?php echo ($rows['avg_price']>=$rows['selling_price'])? 'color:red': ''; ?>" class="form-control" onclick="clickToSelect('selling_price<?php echo $j; ?>')" onkeyup="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','7')" value="<?php echo $rows['selling_price']; ?>" id="selling_price<?php echo $j; ?>"/>
									<?php }else{
										echo $rows['selling_price'];
									} ?>
								 
								</td>
								<!--<td>
									<img style="width: 80px;height: 50px;" src="item_img/pant.jpg"/>
								</td>-->
								<?php } ?>
							</tr>
						<?php 
							}
							?>
							<tr>
								<td colspan="3" style="text-align: right;font-weight: bold;">
									Total Stock Qty & Price: 
								</td>
								<td style="text-align: center;font-weight: bold;">
									<?php echo $tqty; ?>
								</td>
								<td style="text-align: right;font-weight: bold;">
									<?php echo $ttaka; ?>
								</td>
							</tr>
							<?php 
							echo "<input type='hidden' value='$j' id='ilast_id'/>";
			
			}else{
				echo "<input type='hidden' value='0' id='ilast_id'/>";
			}
		}
		
	}
	
	if(isset($_REQUEST['authCustomer'])){
		@$mobile=$_REQUEST['mobile'];
		$com_id=($_SESSION['COM_ID']);
		$mobile_sql=$conn->query("select c.id,c.cus_name,(select sum(point) from point_tbl where cus_id=c.id and is_active=1) getpoint from customer c where c.is_active=1 and c.com_id=$com_id and c.cus_mobile='$mobile'");
			if(mysqli_num_rows($mobile_sql)>0){
				$rows=mysqli_fetch_array($mobile_sql);
				echo trim($rows['cus_name']."#sep#".$rows['id']."#sep#".$rows['getpoint']); // find selected user
			}else{
				echo 2; // not found user
			}
	}
	
	if(isset($_REQUEST['selectItemName'])){
		@$item_name=$_REQUEST['item_name'];
		@$search_type=$_REQUEST['search_type'];
		$com_id=($_SESSION['COM_ID']);
		$search_item=$conn->query("select pn.id,pn.product_name,pn.item_code,pn.avg_price,pn.selling_price,pn.uom,pn.stock_qty,pn.total_price from product pn where pn.com_id=$com_id and pn.product_name like '%$item_name%' or pn.item_code like '%$item_name%' and pn.is_active=2");
			mysqli_close($conn);
			$i=1;
			if(mysqli_num_rows($search_item)>0){
				
				while($rows=mysqli_fetch_array($search_item)){
					$sl=$i++;
					?>
					<a style="text-decoration:none" href="javascript:void(0)"><p onclick="setItemId('<?php echo $rows['id']; ?>','<?php echo $rows['product_name']; ?>','<?php echo $rows['item_code']; ?>','<?php echo $rows['uom']; ?>','<?php echo $rows['selling_price']; ?>','<?php echo $rows['stock_qty']; ?>','<?php echo $rows['total_price']; ?>','<?php echo $rows['avg_price']; ?>','<?php echo $search_type; ?>');" style="color: #347909fc;
					border: 1px solid #8e898942;
					background: white;
					padding-left: 10px;
					cursor: pointer;
					margin-bottom: 0px !important;
					font-style: italic;
					font-weight: bold;
					border-radius: 5px;
					padding: 5px 3px 6px 10px;
					line-height: 16px;"><?php echo $rows['product_name']." (".$rows['item_code'].") Price: ".$rows['avg_price']; ?></p></a>
					<?php 
				}
				
			}else{
				echo "";
			}
	}
	
	if(isset($_REQUEST['get_update_due'])){
		echo getUpdateDue($_REQUEST['cus_id']);  // find selected user
	}
	
	if(isset($_REQUEST['set_delivery_date'])){
		@$delivery_day=$_REQUEST['delivery_day'];
		@$date1=$_REQUEST['date1'];
		if($delivery_day=="" || $delivery_day==0){
			echo $date1;
		}else{
			$exday=explode("-",date('d-m-Y', strtotime(date('d-m-Y'). " +$delivery_day day")));
			echo $exday[0]."/".$exday[1]."/".$exday[2];
		}
	}
	
	if(isset($_REQUEST['typwWiseItem2'])){
		$item_type=$_REQUEST['item_type'];
		$ex=explode("#sep#",$_REQUEST['item_id']);
		$group_id=$ex[1];
		$com_id=($_SESSION['COM_ID']);
		$measurement_type=$_REQUEST['measurement_type'];
			$product=$conn->query("select * from measurement_head where is_active=1 and group_id=$group_id and mtype=$measurement_type and ptype=$item_type order by steps asc");
			if(mysqli_num_rows($product)>0){
						$i=1;
							while($rows=mysqli_fetch_array($product)){
								$j=$i++;
						?>
							<tr>
								<td><button onclick='delItemTwo(<?php echo $rows['id']; ?>,<?php echo $j; ?>);' name='btn' id='delbtnTwo<?php echo $j; ?>' class="btn btn-danger form-control"><?php echo $j; ?></button></td>
								<td><input type="text" class="form-control" value="<?php echo $rows['title']; ?>" id="mheadordertitle<?php echo $j; ?>" onkeyup="setOrder('<?php echo $j; ?>','<?php echo $rows['id']; ?>','head','1')"/></td>
								<td><input type="number" <?php echo ($measurement_type==2 || $measurement_type==3)? "" : "readonly"  ?> class="form-control" value="<?php echo $rows['amount']; ?>" id="mheadamount<?php echo $j; ?>" onkeyup="setOrder('<?php echo $j; ?>','<?php echo $rows['id']; ?>','head','3')"/></td>
								<td><input type="text" class="form-control" value="<?php echo $rows['steps']; ?>" id="mheadorder<?php echo $j; ?>" onkeyup="setOrder('<?php echo $j; ?>','<?php echo $rows['id']; ?>','head','2')"/></td>
							</tr>
						<?php 
							}
							echo "<input type='hidden' value='$j' id='ilast_id'/>";
			
			}else{
				echo "<input type='hidden' value='0' id='ilast_id'/>";
			}
		}
		
		if(isset($_REQUEST['typwWiseItem3'])){
		$item_type=$_REQUEST['item_type'];
		$ex=explode("#sep#",$_REQUEST['item_id']);
		$group_id=$ex[1];
		$com_id=($_SESSION['COM_ID']);
		$measurement_type=$_REQUEST['measurement_type'];
			$product=$conn->query("select * from select_detail where is_active=1 and group_id=$group_id and select_type='$measurement_type' and ptype=$item_type order by steps asc");
			if(mysqli_num_rows($product)>0){
						$i=1;
							while($rows=mysqli_fetch_array($product)){
								$j=$i++;
						?>
							<tr>
								<td><button onclick='delItemThree(<?php echo $rows['id']; ?>,<?php echo $j; ?>);' name='btn' id='delbtnThree<?php echo $j; ?>' class="btn btn-danger form-control"><?php echo $j; ?></button></td>
								<td><input type="text" class="form-control" value="<?php echo $rows['title']; ?>" id="mheadordertitle<?php echo $j; ?>" onkeyup="setOrder('<?php echo $j; ?>','<?php echo $rows['id']; ?>','detail','1')"/></td>
								<td><input type="text" class="form-control" value="<?php echo $rows['steps']; ?>" id="mheadorder<?php echo $j; ?>" onkeyup="setOrder('<?php echo $j; ?>','<?php echo $rows['id']; ?>','detail','2')"/></td>
							</tr>
						<?php 
							}
							echo "<input type='hidden' value='$j' id='ilast_id'/>";
			
			}else{
				echo "<input type='hidden' value='0' id='ilast_id'/>";
			}
		}
		
		
	if(isset($_REQUEST['getMeasurementType'])){
		$option='<option value="">Select One</option>
					<option value="1">Measurement(Text Field)</option>
					<option value="2">Propertice(Select Box)</option>
					<option value="3">Extra propertice(Check Box)</option>
					<option value="4">Remarks(Textarea)</option>';
					echo $option;
	}
	
	if(isset($_REQUEST['settingsData'])){
		$id=$_REQUEST['id'];
		$com_id=($_SESSION['COM_ID']);
		if($id==1){
		?>
		<div class="col-xs-12 col-sm-3">
		<h5 style="text-align:center">Item</h5>
				<label for="comment">Item Type<sup style="color:red">*</sup>:</label>
				<select id="item_type" onchange="typwWiseItem(1);" class="form-control">
					<option value="">Select One</option>
					<option value="1">Gents</option>
					<option value="2">Lady</option>
				</select>
				<label for="comment">Item Name<sup style="color:red">*</sup>:</label>
				<input type="text" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="item_name" id="item_name" />
				<label for="comment">Group<sup style="color:red">*</sup>:</label>
				<select id="group_id" class="form-control">
					<option value="1">Shirt/Fatua/Safari (1)</option>
					<option value="2">Pant/Pajama/Kabli (2)</option>
					<option value="3">Coat/Mujib Coat/Prince Coat/Waistcoat/Sherwani (3)</option>
					<option value="4">Panjabi/Jubbah (4)</option>
					<option value="5">Ladies Group-1 (5)</option>
					<option value="6">Ladies Group-2 (6)</option>
					<option value="7">Ladies Group-3 (7)</option>
					<option value="8">Ladies Group-4 (8)</option>
					<option value="9">Ladies Group-5 (9)</option>
					<option value="11">Ladies Group-6 (11)</option>
					<option value="12">Group (12)</option>
					<option value="13">Group (13)</option>
					<option value="14">Group (14)</option>
					<option value="15">Group (15)</option>
					<option value="16">Group (16)</option>
					<option value="17">Group (17)</option>
					<option value="18">Group (18)</option>
					<option value="19">Group (19)</option>
					<option value="20">Group (20)</option>
					<option value="21">Group (21)</option>
					<option value="22">Group (22)</option>
					<option value="23">Group (23)</option>
					<option value="24">Group (24)</option>
					<option value="25">Group (25)</option>
					<option value="26">Group (26)</option>
					<option value="27">Group (27)</option>
					<option value="28">Group (28)</option>
					<option value="29">Group (29)</option>
					<option value="30">Group (30)</option>
					<option value="31">Group (31)</option>
					<option value="32">Group (32)</option>
				</select>
				<label for="comment">Customer's Price<sup style="color:red">*</sup>:</label>
				<input type="text" class="form-control" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="cus_price" />
				<label for="comment">Master's Price<sup style="color:red">*</sup>:</label>
				<input type="text" class="form-control" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" name="master_price" id="master_price" />
				<label for="comment">Karigor's Price<sup style="color:red">*</sup>:</label>
				<input type="text" class="form-control" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" name="karigor_price" id="karigor_price" />
				<button onclick="saveItem();" style="margin-top: 12px;" name="btn" value="sub" id="saveItemBtn" class="btn btn-success form-control">Save</button>
				<span id="save_load">
				
				</span>
				
				<p></p>
			</div>
			
			<div class="col-xs-12 col-sm-7" style="margin-top: 5px;">
				<table id="example" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>SL</th>
							<th>Item</th>
							<th>Customer Price</th>
							<th>Employee Price</th>
							<!--<th>Karigor Price</th>-->
							<th>Order</th>
						</tr>
					</thead>
					<tbody id="item_tbl">
						
					</tbody>
				</table>
			</div>
		<?php 
		}
		
		if($id==2){
		?>
		
		<div class="col-xs-12 col-sm-3">
		<h5 style="text-align:center">Propertice</h5>
				<label for="comment">Item Type<sup style="color:red">*</sup>:</label>
				<select id="item_type" onchange="changeType();" style="" class="form-control">
					<option value="">Select One</option>
					<option value="1">Gents</option>
					<option value="2">Lady</option>
				</select>
				<label for="comment">Item<sup style="color:red">*</sup>:</label>
				<select id="item_id" style="" class="form-control"  onchange="getMeasurementType();">
					
				</select>
				<label for="comment">Measurement Type<sup style="color:red">*</sup>:</label>
				<select id="measurement_type" onchange="getPropertice();" class="form-control">
					<option value="">Select One</option>
					<option value="1">Measurement(Text Field)</option>
					<option value="2">Propertice(Select Box)</option>
					<option value="3">Extra propertice(Check Box)</option>
					<option value="4">Remarks(Textarea)</option>
				</select>
				<label for="comment">Title<sup style="color:red">*</sup>:</label>
				<input type="text" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="propertice_title" id="propertice_title" />
				<button onclick="savePropertices();" style="margin-top: 12px;" name="btn" value="sub" id="saveProperticesBtn" class="btn btn-success form-control">Save</button>
				<span id="save_load">
				
				</span>
				<p></p>
			</div>
			
			<div class="col-xs-12 col-sm-7" style="margin-top: 5px;">
				<table id="example" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>SL</th>
							<!--<th>Item</th>-->
							<th>Propertice Head Title</th>
							<th>Amount</th>
							<th>Order</th>
						</tr>
					</thead>
					<tbody id="item_tbl">
						
					</tbody>
				</table>
			</div>
		<?php 
		}
		
		if($id==3){
		?>
		<div class="col-xs-12 col-sm-3">
		<h5 style="text-align:center">Propertice Details</h5>
				<label for="comment">Item Type<sup style="color:red">*</sup>:</label>
				<select id="item_type" onchange="changeType();" style="" class="form-control">
					<option value="">Select One</option>
					<option value="1">Gents</option>
					<option value="2">Lady</option>
				</select>
				<label for="comment">Item<sup style="color:red">*</sup>:</label>
				<select id="item_id" onchange="getSelectHead();" style="" class="form-control">
					
				</select>
				
				<label for="comment">Propertice(Select Box Details)<sup style="color:red">*</sup>:</label>
				<select id="measurement_type" onchange="getPropertice2();" class="form-control">
				</select>
				<label for="comment">Title<sup style="color:red">*</sup>:</label>
				<input type="text" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="chk_title" id="chk_title" />
				<button onclick="saveProperticesExtra();" style="margin-top: 12px;" name="btn" value="sub" id="saveProperticesExtraBtn" class="btn btn-success form-control">Save</button>
				<span id="save_load">
				
				</span>
				<p></p>
			</div>
			
			<div class="col-xs-12 col-sm-7" style="margin-top: 5px;">
				<table id="example" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>SL</th>
							<th>Propertice Title</th>
							<th>Order</th>
						</tr>
					</thead>
					<tbody id="item_tbl">
						
					</tbody>
				</table>
			</div>
		<?php 
		}else if($id==4){
			$com_id=($_SESSION['COM_ID']);
			$date=date("Y-m-d");
			$dsms=$conn->query("select dv_date,cus_mobile from dsms where is_active=1 and dv_date>='$date' and online_status=0 and com_id=$com_id");
			//$dsms_update=$conn->query("select dv_date,cus_mobile from dsms where is_active=1 and update_dv_status=1 and com_id=$com_id");
			//$order=$conn->query("select order_number from order_record where is_active=1 and online_status=0 and com_id=$com_id");
			$order=$conn->query("select id,factory_receive_date,dv_date,cus_mobile,online_status from dsms where is_active=1 and factory_status=1 and com_id=$com_id");
			?>
			<div class="col-xs-12 col-sm-3">
				<div class="alert alert-info">
				  <p><strong>Order History (<?php echo mysqli_num_rows($dsms); ?>)</strong></p>
				  <?php if(mysqli_num_rows($dsms)>0){ ?>
				  <span id="send_to_server_load"><button onclick="sendToServerOrder();" name="btn" id="send_to_server_order" value="sub" class="form-control btn btn-info">Send SMS</button></span>
				  <?php } ?>
				</div>
				
				<table id="example" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>SL</th>
							<th>Delivery Date</th>
							<th>Mobile</th>
						</tr>
					</thead>
					<tbody id="tbl_one">
						<?php 
						if(mysqli_num_rows($dsms)>0){
							$i=1;
							while($row=mysqli_fetch_array($dsms)){
								?>
									<tr>
										<td><?php echo $i++; ?></td>
										<th><?php echo $row['dv_date']; ?></th>
										<th><?php echo $row['cus_mobile']; ?></th>
									</tr>
								<?php 
							}
						}
						?>
						
					</tbody>
				</table>
			</div>
			<div class="col-xs-12 col-sm-3">
				<div class="alert alert-success">
				  <p><strong>Production Received Order (<?php echo mysqli_num_rows($order); ?>)</strong></p>
				</div>
				<table id="example" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>SL</th>
							<th>Delivery Date</th>
							<th>Mobile</th>
						</tr>
					</thead>
					<tbody id="tbl_two2">
						<?php 
						if(mysqli_num_rows($order)>0){
							$i=0;$k=0;
							while($row=mysqli_fetch_array($order)){
								if($row['online_status']==1){
									$k=++$i;
								?>
									<tr>
										<td><?php echo $k; ?></td>
										<th><?php echo $row['dv_date']; ?></th>
										<input type="hidden" value="<?php echo $row['id']."#sep#".$row['cus_mobile']."#sep#".$row['dv_date']."#sep#".$row['factory_receive_date']; ?>" id="factory_mobile<?php echo $k; ?>"/>
										<th><span id="send_to_server_load2<?php echo $k; ?>"><button onclick="sendToServerReceivedOrder(<?php echo $k; ?>);" name="btn" id="received_order" value="sub" class="form-control btn btn-success"><?php echo $row['cus_mobile']; ?></button></span></th>
									</tr>
								<?php
								}								
							}
						}
						?>
						
					</tbody>
				</table>
			</div>
			
			<?php 
		}else if($id==5){
			date_default_timezone_set("Asia/Dhaka");
			$mnt="0"; 
			$year="0";
			
			$bill_sql=$conn->query("select bill,sec_id,billing_month,billing_year,is_active,bill_pay_date from billing where com_id=$com_id order by id desc limit 1,1");
			if(mysqli_num_rows($bill_sql)>0){
				$bill_array=mysqli_fetch_array($bill_sql);
				$bmonth=date("F", mktime(0, 0, 0, $bill_array['billing_month'], 10)).'-'.$bill_array['billing_year'];
				if($bill_array['bill']!=0 && $bill_array['is_active']==1){
					$sataus='<span style="color:green">Paid</span>';
					$chk_sataus=1;
				}else{
					$sataus='<span style="color:red">Unpaid</span>';
					$chk_sataus=0;
				}
			}else{
				$bmonth="";
				$sataus='<span style="color:red">---</span>';
				$chk_sataus=0;
			}
			$order=$conn->query("select count(ds.id) tot from dsms ds where ds.is_active=1 and ds.com_id=$com_id and month(ds.insert_date)=$mnt and year(ds.insert_date)=$year");
			
			if(mysqli_num_rows($order)>0){
				$ord=mysqli_fetch_array($order);
				$order_num=$ord['tot'];
			}else{
				$order_num=0;
			}
			if($_SESSION['SOFT_CHARGE']>0 && $_SESSION['SMS_SERVICE']!=1){ // per order bill but not get sms service
				//only soft
				$soft=$_SESSION['SOFT_CHARGE'];
				$total=round(floatval($order_num)*$soft);
				$security=getSecurity($total);
				$tbl="<table id='example' class='table table-striped table-bordered'>
					<thead>
						<tr>
							<th>Total Order(qty)</th>
							<th>Per Order(tk)</th>
							<th>Total(round tk)</th>
							<th>Security Code</th>
							<th>Status</th>
						</tr>
					</thead>
					<tbody id='tbl_three'>
						<tr>
							<td>$order_num</td>
							<th>$soft</th>
							<th style='background:#73CEFB;color:white'>$total</th>
							<th>$security</th>
							<th>$sataus</th>
						</tr>
					</tbody>
				</table>";
			}
			if($_SESSION['SOFT_CHARGE']>0 && $_SESSION['SMS_SERVICE']==1){ // per order charge and per sms bill
				// soft and sms
				$soft=$_SESSION['SOFT_CHARGE'];
				//$sms=$_SESSION['SMS_CHARGE'];
				//$total=(floatval($order_num)*($soft+floatval($sms)));
				$total=round(floatval($order_num)*($soft));
				$security=getSecurity($total);
				$tbl="<table id='example' class='table table-striped table-bordered'>
					<thead>
						<tr>
							<th>Total Order(qty)</th>
							<th>Per Order(tk)</th>
							<th>Total(round tk)</th>
							<th>Security Code</th>
							<th>Status</th>
						</tr>
					</thead>
					<tbody id='tbl_three'>
						<tr>
							<th>$order_num</th>
							<th>$soft</th>
							<th style='background:#73CEFB;color:white'>$total</th>
							<th>$security</th>
							<th>$sataus</th>
						</tr>
					</tbody>
				</table>";
			}
			
			if($_SESSION['SOFT_CHARGE']==0){ //monthly bill
				// monthly bill
				$total="700";
				$security=getSecurity($total);
				$tbl="<table id='example' class='table table-striped table-bordered'>
					<thead>
						<tr>
							<th>Total Order(qty)</th>
							<th>Per Month(tk)</th>
							<th>Total(tk)</th>
							<th>Security Code</th>
							<th>Status</th>
						</tr>
					</thead>
					<tbody id='tbl_three'>
						<tr>
							<th>$order_num</th>
							<th>$total</th>
							<th style='background:#73CEFB;color:white'>$total</th>
							<th>$security</th>
							<th>$sataus</th>
						</tr>
					</tbody>
				</table>";
			}
			
			?>
				<div class="col-xs-12 col-sm-10">
				
				<div class="panel panel-success">
				  <div class="panel-heading" style="text-align:center">Bill(<?php echo @$bmonth; ?>)</div>
				  <div class="panel-body">
					<div>
						<h4 style="text-align: center;line-height: 0px;"><?php echo $_SESSION['COM']; ?></h4>
						<p style="text-align: center;"><?php echo $_SESSION['COM_ADDRESS']; ?></p>
						<?php echo $tbl; ?>
					</div>
				  </div>
				</div>
							
				</div>
			<?php 
			if($chk_sataus==0){
				if($_SESSION['MBILL']!=2){
			?>
			<div class="col-xs-12 col-sm-3">
					<div class="panel panel-success">
					  <div class="panel-heading" style="text-align:center">Step-1</div>
					  <div class="panel-body">
						<p style="font-size:11px;color:red;text-align:justify">1. Software এর  Monthly Bill আগে  <b>01719027713</b> এই নম্বর এ Bkash করুন.</p>
						<p style="font-size:11px;color:red;text-align:justify">2. Step-2 তে আপনি যে মোবাইল নম্বর থেকে Bkash করেছেন সেই নম্বর টি Sender Bkash Number হিসেবে বসিয়ে Send এ ক্লিক করুন.</p>
						<p style="font-size:11px;color:red;text-align:justify">2. Step-3 তে আপনার মোবাইল নম্বর এ দুইটি PIN Number SMS করা হবে তা PIN-1এবং PIN-2 তে বসিয়ে Verify এ ক্লিক করুন.</p>
					 </div>
					</div>
							
				</div>
				<div class="col-xs-12 col-sm-4">
					<div class="panel panel-info">
					  <div class="panel-heading" style="text-align:center">Step-2</div>
					  <div class="panel-body">
						<label for="comment">Total Bill(Tk)</label>
						<input type="text" readonly class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;background:#73CEFB;color:white" value="<?php echo $total; ?>" autocomplete="off" name="bill_tk" id="bill_tk" required/>
						<label for="comment">Security Code</label>
						<input type="text" readonly class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" autocomplete="off" value="<?php echo $security; ?>" name="security_code" id="security_code" required/>
						<label for="comment">Sender Bkash Number</label>
						<input type="text" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" maxlength="11" autocomplete="off" name="sender_number" id="sender_numbers" required/>
					    <button onclick="sendMonthlyBill();" style="margin-top:15px" name="btn" value="sub" id="bill_btn" class="btn btn-info">Send</button>
						<span id="bsms"></span>
					 </div>
					</div>
							
				</div>
				<div class="col-xs-12 col-sm-3">
				
				<div class="panel panel-warning">
				  <div class="panel-heading" style="text-align:center">Verification(Step-3)</div>
				  <div class="panel-body">
					<label for="comment">PIN-1</label>
					<input type="text" class="form-control" style="font-weight: bold;font-size:18px;font-style: italic;color:red" maxlength="5" autocomplete="off" name="pin1" id="pina" required/>
					<label for="comment">PIN-2</label>
					<input type="text" class="form-control" style="font-weight: bold;font-size:18px;font-style: italic;color:red" maxlength="5" autocomplete="off" name="pin2" id="pinb" required/>
					<input type="hidden" id="bill_save" value="<?php echo $total; ?>"/>
					<input type="hidden" id="security_save" value="<?php echo $security; ?>"/>
					<input type="hidden" id="month_year" value="<?php echo @$bill_array['billing_month']."_".@$bill_array['billing_year']; ?>"/>
				  <button onclick="verificationChk();" style="margin-top:15px" name="btn" value="sub" id="verify_btn" class="btn btn-warning">Verify</button>
				  <span id="vsms"></span>
				  </div>
				</div>
							
				</div>
			<?php 
				}
		}
		}else if($id==6){
			$com_id=($_SESSION['COM_ID']);
			?>
			<div class="row" style="margin-top: 6px;">
				<div class="col-xs-12 col-sm-2">
					<div class="alert alert-warning">
					  <strong><?php
					   if(check_internet_connection()==1){
						$response = file_get_contents($_SESSION['API']."api/data.php?com_id=$com_id&chk=2"); //chk=2 means check sms
						$json = json_decode($response, true);
						echo "Balance: ".$json['sms']." SMS";
						}else{
							echo '<span style="color:red">No Internet Connection</span>';
						}
					  ?></strong>
					</div>
					
				</div>
				<div class="col-xs-12 col-sm-3">
					<div class="alert alert-success">
					  <strong>Details(Last 15 Result)</strong>
					  <button onclick="getSmsDetails();" name="btn" id="sms_details" value="sub" class="form-control btn btn-success">Purchase Details(SMS)</button>
					</div>
					<table id="example" class="table table-striped table-bordered">
						<thead>
							<tr>
								<th>SL</th>
								<th>Purchase Date</th>
								<th>SMS Qty</th>
							</tr>
						</thead>
						<tbody id="sms_tbl">
							
						</tbody>
					</table>
				</div>
				<div class="col-xs-12 col-sm-4">
					<p style="font-size: 24px;">SMS ক্রয় এর জন্য  <i><b>01311240085</b></i>  এই নম্বর এ কল করুন !!!</p>
				</div>
			</div>
			<?php 
		}else if($id==7){
			
			exec($_SESSION['BACKUP']);
			
			?>
			<div class="col-xs-12 col-sm-2">
				<div class="alert alert-info">
				  <strong>Database Backup Success!</strong>
				</div>
			</div>
			<?php 
		}else if($id==8){
			$com_id=($_SESSION['COM_ID']);
			$order=$conn->query("select * from company where is_active=1 and id=$com_id");
			$taxes=$conn->query("select * from vat_tax where is_active=1 and com_id=$com_id");
			$rows=mysqli_fetch_array($order);
			?>
			<div class="col-xs-12 col-sm-3">
				<label>Order No. Set</label>
				<select class="form-control" id="order_change_option" onchange="orderChangeOption(1);">
					<option <?php if($rows['sversion']==0) echo "selected"; ?> value="0">Computer Generated Order No.</option>
					<option <?php if($rows['sversion']==1) echo "selected"; ?> value="1">Physical Books Order No.</option>
					<option <?php if($rows['sversion']==2) echo "selected"; ?> value="2">Merge Order No.</option>
				</select>
				<label>Production Copy Set</label>
				<select class="form-control" id="order_change_option2" onchange="orderChangeOption(2);">
					<option <?php if($rows['measure_type']==0) echo "selected"; ?> value="0">Standard Production Copy</option>
					<option <?php if($rows['measure_type']==2) echo "selected"; ?> value="2">Normal Production Copy</option>
					<option <?php if($rows['measure_type']==1) echo "selected"; ?> value="1">Local Production Copy</option>
				</select>
				<label>Design Set</label>
				<select class="form-control" id="order_change_option9" onchange="orderChangeOption(9);">
					<option <?php if($rows['design_set']==1) echo "selected"; ?> value="1">Show Desing</option>
					<option <?php if($rows['design_set']==0) echo "selected"; ?> value="0">Not</option>
				</select>
				<label>Order Report Set</label>
				<select class="form-control" id="order_change_option6" onchange="orderChangeOption(6);">
					<option <?php if($rows['ord_settings']==1) echo "selected"; ?> value="1">Active</option>
					<option <?php if($rows['ord_settings']==0) echo "selected"; ?> value="0">Inactive</option>
				</select>
				<label>Customer Delivery Day Set</label>
				<select class="form-control" id="order_change_option4" onchange="orderChangeOption(4);">
					<option <?php if($rows['customer_delivery']==7) echo "selected"; ?> value="7">7 Days later</option>
					<option <?php if($rows['customer_delivery']==8) echo "selected"; ?> value="8">8 Days later</option>
					<option <?php if($rows['customer_delivery']==9) echo "selected"; ?> value="9">9 Days later</option>
					<option <?php if($rows['customer_delivery']==10) echo "selected"; ?> value="10">10 Days later</option>
					<option <?php if($rows['customer_delivery']==11) echo "selected"; ?> value="11">11 Days later</option>
					<option <?php if($rows['customer_delivery']==12) echo "selected"; ?> value="12">12 Days later</option>
					<option <?php if($rows['customer_delivery']==14) echo "selected"; ?> value="14">14 Days later</option>
					<option <?php if($rows['customer_delivery']==16) echo "selected"; ?> value="16">16 Days later</option>
					<option <?php if($rows['customer_delivery']==18) echo "selected"; ?> value="18">18 Days later</option>
					<option <?php if($rows['customer_delivery']==20) echo "selected"; ?> value="20">20 Days later</option>
					<option <?php if($rows['customer_delivery']==22) echo "selected"; ?> value="22">22 Days later</option>
					<option <?php if($rows['customer_delivery']==24) echo "selected"; ?> value="24">24 Days later</option>
					<option <?php if($rows['customer_delivery']==26) echo "selected"; ?> value="26">26 Days later</option>
					<option <?php if($rows['customer_delivery']==28) echo "selected"; ?> value="28">28 Days later</option>
					<option <?php if($rows['customer_delivery']==30) echo "selected"; ?> value="30">30 Days later</option>
				</select>
				<label>Factory Delivery Day Set</label>
				<select class="form-control" id="order_change_option3" onchange="orderChangeOption(3);">
					<option <?php if($rows['factory_delivery']==1) echo "selected"; ?> value="1">1 Day Ago Delivery</option>
					<option <?php if($rows['factory_delivery']==2) echo "selected"; ?> value="2">2 Days Ago Delivery</option>
					<option <?php if($rows['factory_delivery']==3) echo "selected"; ?> value="3">3 Days Ago Delivery</option>
					<option <?php if($rows['factory_delivery']==4) echo "selected"; ?> value="4">4 Days Ago Delivery</option>
					<option <?php if($rows['factory_delivery']==5) echo "selected"; ?> value="5">5 Days Ago Delivery</option>
					<option <?php if($rows['factory_delivery']==7) echo "selected"; ?> value="7">7 Days Ago Delivery</option>
					<option <?php if($rows['factory_delivery']==10) echo "selected"; ?> value="10">10 Days Ago Delivery</option>
				</select>
				<label>Order SMS</label>
				<select class="form-control" id="order_change_option13" onchange="orderChangeOption(13);">
					<option <?php if($rows['order_sms']==0) echo "selected"; ?> value="0">Not Active</option>
					<option <?php if($rows['order_sms']==1) echo "selected"; ?> value="1">Active</option>
				</select>
				<label>Item Receive SMS</label>
				<select class="form-control" id="order_change_option14" onchange="orderChangeOption(14);">
					<option <?php if($rows['item_receive_sms']==0) echo "selected"; ?> value="0">Not Active</option>
					<option <?php if($rows['item_receive_sms']==1) echo "selected"; ?> value="1">Active</option>
				</select>
				<label>Employee Payment SMS</label>
				<select class="form-control" id="order_change_option15" onchange="orderChangeOption(15);">
					<option <?php if($rows['emp_payment_sms']==0) echo "selected"; ?> value="0">Not Active</option>
					<option <?php if($rows['emp_payment_sms']==1) echo "selected"; ?> value="1">Active</option>
				</select>
				<?php 
				if($_SESSION['IS_STOCK']==1){ // 1=means maintain stock
				?>
				<label>Is Active Selling Price?</label>
				<select class="form-control" id="order_change_option11" onchange="orderChangeOption(11);">
					<option <?php if($rows['apply_selling_price']==1) echo "selected"; ?> value="1">Yes</option>
					<option <?php if($rows['apply_selling_price']==0) echo "selected"; ?> value="0">No</option>
				</select>
				<label>Set Safety Stock</label>
				<select class="form-control" id="order_change_option12" onchange="orderChangeOption(12);">
					<option <?php if($rows['sefty_stock']==10) echo "selected"; ?> value="10">10</option>
					<option <?php if($rows['sefty_stock']==20) echo "selected"; ?> value="20">20</option>
					<option <?php if($rows['sefty_stock']==30) echo "selected"; ?> value="30">30</option>
					<option <?php if($rows['sefty_stock']==40) echo "selected"; ?> value="40">40</option>
					<option <?php if($rows['sefty_stock']==50) echo "selected"; ?> value="50">50</option>
					<option <?php if($rows['sefty_stock']==60) echo "selected"; ?> value="60">60</option>
					<option <?php if($rows['sefty_stock']==70) echo "selected"; ?> value="70">70</option>
					<option <?php if($rows['sefty_stock']==80) echo "selected"; ?> value="80">80</option>
					<option <?php if($rows['sefty_stock']==90) echo "selected"; ?> value="90">90</option>
					<option <?php if($rows['sefty_stock']==100) echo "selected"; ?> value="100">100</option>
				</select>
				<?php } ?>
				<label>Active Reference?</label>
				<select class="form-control" id="order_change_option10" onchange="orderChangeOption(10);">
					<option <?php if($rows['active_reference']==0) echo "selected"; ?> value="0">No</option>
					<option <?php if($rows['active_reference']==1) echo "selected"; ?> value="1">Yes</option>
				</select>
				<?php 
				if($rows['active_reference']==1){
				?>
				<label id="ref_amount_title">Reference Point</label>
				<input type="text" onkeyup="updateReferenceAmount();" value="<?php echo @$_SESSION['REFERENCE_AMOUNT']; ?>" maxlength="4" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" name="reference_amount" autocomplete="off" placeholder="Enter Amount(Tk)" id="reference_amount" class="form-control">
				<?php } ?>
				<span id="show_amount">
				</span>
				
				<?php 
				if($_SESSION['MEASURE_TYPE']==0){
				?>
				<label>Heading Image</label>
				<input type="file" style="width: 260px;" name="submitfile" id="submitfile" onchange="readURL(this);" />
				<img id="blah" src="" style="width: 184px;height:50px" alt="your image" />
				<button style="margin-top: 6px;" class="btn btn-success">Upload</button>
				<style>
				input[type=file]{
				padding:10px;
				background:#2d2d2d;}
				</style>
				<?php } ?>
				<!--<label>Item Settings</label>
				<select class="form-control" id="order_change_option8" onchange="orderChangeOption(8);">
					<option <?php if($_SESSION['ITEM_SETTINGS']==1) echo "selected"; ?> value="1">Active</option>
					<option <?php if($_SESSION['ITEM_SETTINGS']==0) echo "selected"; ?> value="0">Inactive</option>
				</select>
				<label>Qty Setup</label>
				<select class="form-control" id="order_change_option7" onchange="orderChangeOption(7);">
					<option value="">Select Year</option>
					<option value="2020">2020</option>
					<option value="2021">2021</option>
					<option value="2022">2022</option>
					<option value="2023">2023</option>
					<option value="2024">2024</option>
					<option value="2025">2025</option>
				</select>
				<label>Qty</label>
				<input type="text" maxlength="6" name="ord_qty" autocomplete="off" placeholder="Enter Qty" id="ord_qty" class="form-control">
				<br/>
				<span id="fegordbtn"></span>-->
				
				<span id="show_ord"></span>
				<span id="load_order_change"></span>
			</div>
			<div class="col-xs-12 col-sm-3">
				
			</div>
			<?php 
		}else if($id==9){
			$com_id=($_SESSION['COM_ID']);
			$emp_info=$conn->query("SELECT mh.user_name,mh.id,mh.mobile,mh.emp_type,mh.emp_address,mh.salary_type,mh.salary,(select taka from wages_head where emp_id=mh.id and com_id=mh.com_id) wages FROM `user` mh WHERE mh.com_id=$com_id and mh.is_active=1 and mh.emp_type in(1,2,3) order by mh.emp_type asc");
			mysqli_close($conn);
			?>
			<div class="col-xs-12 col-sm-3">
		<h5 style="text-align:center"><b>Master/Karigor/Staff Information</b></h5>
				<label for="comment">Employee Type<sup style="color:red">*</sup>:</label>
				<select id="emp_type" style="" class="form-control">
					<option value="">Select One</option>
					<option value="1">Master</option>
					<option value="2">Karigor</option>
					<option value="3">Staff</option>
				</select>
				
				<label for="comment">Name<sup style="color:red">*</sup>:</label>
				<input type="text" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="emp_name" id="emp_name" />
				
				<label for="comment">Mobile<sup style="color:red">*</sup>:</label>
				<input type="text" class="form-control" maxlength="11" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="emp_mobile" id="emp_mobile" />
				<label for="comment">Address:</label>
				<input type="text" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="emp_name" id="emp_address" />
				<label for="comment">Salary Type<sup style="color:red">*</sup>:</label>
				<select id="salary_type" onchange="changeSalaryType();" class="form-control">
					<option value="">Select One</option>
					<option value="1">Item Wise</option>
					<option value="2">Daily Basis</option>
					<option value="3">Monthly Basis</option>
				</select>
				<label for="comment"><span id="stitle">Salary</span><sup style="color:red">*</sup>:</label>
				<input type="text" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;text-align:right" name="emp_name" id="emp_salary" />
				
				<button onclick="saveMasterKarigor();" style="margin-top: 12px;" name="btn" value="sub" id="saveMasKaeBtn" class="btn btn-success form-control">Save</button>
				<span id="save_load">
				
				</span>
				<p></p>
			</div>
			
			<div class="col-xs-12 col-sm-7">
				<table id="example" style="margin-top: 5px;" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>SL</th>
							<th>Name</th>
							<th>Mobile</th>
							<th>Type</th>
							<th>Salary Type</th>
							<th style="text-align:right">Balance</th>
						</tr>
					</thead>
					<tbody id="emp_tbl">
						<?php 
						$i=1;
						if(mysqli_num_rows($emp_info)>0){
							$tot_wages=0;
							while($rows=mysqli_fetch_array($emp_info)){
								$tbl_id=$rows['id'];
								$tot_wages+=$rows['wages'];
								$sl=$i++;
								?>
								<tr style="color:<?php 
								if($rows['emp_type']==1){
									echo "blue";
								}else if($rows['emp_type']==3){
									echo "#b60bc1;";
								}
								?>">
									<td><button onclick="delEmployee('<?php echo $tbl_id; ?>','<?php echo $sl; ?>')" class="btn btn-danger form-control" id="delbtn<?php echo $sl; ?>"><?php echo $sl; ?></button></td>
									<td><?php echo $rows['user_name']; ?></td>
									<td><?php echo $rows['mobile']; ?></td>
									<td><?php if($rows['emp_type']==1){ echo "Master"; }else if($rows['emp_type']==2){ echo "Karigor"; }else{ echo "Staff";} ?></td>
									<td><?php if($rows['salary_type']==1){ echo "Item Wise"; }else if($rows['salary_type']==2){ echo "Daily Basis (".$rows['salary']."/=)"; }else{ echo "Monthly Basis (".$rows['salary']."/=)";} ?></td>
									<td style="text-align:right;font-weight:bold"><?php echo ($rows['wages']=="")? 0 : $rows['wages']; ?>/=</td>
								</tr>
								<?php 
							}
							echo "<input type='hidden' id='tbl_last_id' value='$sl'/>";
						}else{
							echo "<input type='hidden' id='tbl_last_id' value='0'/>";
						}
						?>
						<tr>
							<td style="text-align:right;font-weight:bold" colspan="5">Total Wages</td>
							<td style="text-align:right;font-weight:bold"><?php echo $tot_wages; ?>/=</td>
						</tr>
					</tbody>
				</table>
			</div>
			<?php 
		}else if($id==10){
			$com_id=($_SESSION['COM_ID']);
			$emp_info=$conn->query("SELECT c.id,c.cus_name,c.cus_mobile,c.cus_address,(select last_due from update_due where cus_id=c.id and is_active=1 order by id desc limit 0,1) due_amount FROM `customer` c WHERE c.com_id=$com_id and c.is_active=1 limit 0,500");
			$total_due=$conn->query("select sum(dd.last_dues) total_due from (SELECT `cus_id`,(select ud.`last_due` from update_due ud where ud.`cus_id`=update_due.cus_id and ud.is_active=1 order by ud.id desc limit 0,1) last_dues FROM `update_due` WHERE `is_active`=1 GROUP by `cus_id`) dd");
			$trows=mysqli_fetch_array($total_due);
			$total_due=round($trows['total_due'],2);
			mysqli_close($conn);
			$tot_emp=mysqli_num_rows($emp_info);
			?>
			<div class="col-xs-12 col-sm-3">
				<label for="comment">Customer Mobile/Name:</label>
					<input type="text" maxlength="11" placeholder="Enter Mobile Number/Name" class="form-control" onkeyup="searhMobileNumber();" style="font-weight: bold;font-size:18px;font-style: italic;" autocomplete="off" name="" id="src_cus_mobile" required/>
				
			</div>
			<div class="col-xs-12 col-sm-2" style="margin-top: 25px;">
				
				<button onclick="addNewCustomer();" name="btn" id="curtomerBtn" value="sub" class="btn btn-success">+New Customer</button>
			</div>
			<div class="col-xs-12 col-sm-5">
				<div class="col-sm-9" id="">
					<label for="comment">Status<sup style="color:red">*</sup>:</label>
					<select class="form-control" id="emp_due_statuss">
						<option value="">Select One</option>
						<option value="not_delivery">Not Delivery</option>
						<option value="delivery">Delivery</option>
						<option value="creditor">পাওনাদার (creditor)</option>
					</select>
				</div>
				<div class="col-sm-3" id="">
					<button style="margin-top: 25px;" onclick="searchEmpDueStatus();" name="btn" id="curtomerBtn" value="sub" class="btn btn-info">Search</button>
				</div>
			</div>
			<div class="col-xs-12 col-sm-10" id="customer_form">
					
			</div>
			<div class="col-xs-12 col-sm-10" id="customer_scroll" style="height: 560px;">
				<table id="example" style="margin-top: 5px;" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>SL</th>
							<th>Customer Name</th>
							<th>Mobile</th>
							<th>Address</th>
							<th style="text-align: right;">বাকি(টাকা)</th>
						</tr>
					</thead>
					<tbody id="search_mobile">
						<?php 
						$i=1;$total_tk=0;
						if($tot_emp>0){
							while($rows=mysqli_fetch_array($emp_info)){
								$tbl_id=$rows['id'];
								$sl=$i++;
								$total_tk+=$rows['due_amount'];
								?>
								<tr>
									<td>
									<?php 
									if(@$rows['due_amount']=="" || $rows['due_amount']==0){
									?>
									<button onclick="delCustomer('<?php echo $tbl_id; ?>','<?php echo $sl; ?>')" class="btn btn-danger form-control" id="delbtn<?php echo $sl; ?>"><?php echo $sl; ?></button>
									<?php }else{
										echo $sl;
									} ?>
									</td>
									<td><input type="text" class="form-control" autocomplete="off" id="cus_name<?php echo $tbl_id; ?>" onkeyup="setAddress('<?php echo $tbl_id; ?>','1');" value="<?php echo @$rows['cus_name']; ?>" /></td>
									<td><?php echo $rows['cus_mobile']; ?></td>
									<td><input type="text" class="form-control" autocomplete="off" id="cus_address<?php echo $tbl_id; ?>" onkeyup="setAddress('<?php echo $tbl_id; ?>','2');" value="<?php echo @$rows['cus_address']; ?>" /></td>
									<td style="text-align: right;font-weight:bold"><?php echo englishToBangla($rows['due_amount'])."/="; ?></td>
								</tr>
								
								<?php 
							}
						}else{
							echo "";
						}
						?>
					</tbody>
				</table>
				<?php 
					if($tot_emp>=500){
				 ?>
				 <div class="form-group" style="margin-top:15px">
				  <button onclick="seaMoreCustomer();" name="btn" id="morebtns" class="btn btn-success">More+</button><span id="load_imgs"></span>
				  </div>
				<?php } ?>
				<input type="hidden" id="last_id" value="500"/>	
			</div>
			<div class="col-xs-12 col-sm-12">
				<span id="total_dues" style="float: right;margin-right: 20px;font-weight: bold;font-size: 16px;margin-bottom: 15px;">সর্বমোট বাকি: <?php echo Converter::en2bn($total_due)."/="; ?></span>
			</div>
			<?php 
		}else if($id==11){
			
			?>
			<div class="col-xs-12 col-sm-2">
				<label for="comment" class="txt_color">Customer Name/Mobile:</label>
				<input type="text" placeholder="Customer Name/Mobile" onkeyup="chkCustomer();" class="form-control" maxlength="11" autocomplete="off" style="font-weight: bold;font-size:16px;font-style: italic;background: #ffeb3b;" name="mobile" id="cus_mobile" />
				<span id="cus_info" style="z-index: 99999999999999;
					overflow: hidden;
					position: fixed;
					width: 240px;"></span>
				
			</div>
			<input type="hidden" id="hide_cus_id"/>
			<div class="col-xs-12 col-sm-2">
				<label for="comment" class="txt_color">ধরণ:</label>
				<select class="form-control" style="font-weight: bold;font-size:16px;font-style: italic;" id="tk_type">
					<option value="">Select One</option>
					<option value="0">বাকি প্রদান(+)</option>
					<option value="1">বাকি গ্রহণ(-)</option>
					
				</select>
				
			</div>
			<div class="col-xs-12 col-sm-1">
				<label for="comment" class="txt_color">টাকা:</label>
				<input type="text" value="0" onclick="clickToSelect('adjust_tk')" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" class="form-control" maxlength="7" autocomplete="off" style="font-weight: bold;font-size:16px;font-style: italic;text-align:right" name="mobile" id="adjust_tk" />
			</div>
			<div class="col-xs-12 col-sm-2">
				<label for="comment" class="txt_color">পেমেন্ট:</label>
				<select id="payment_type" class="form-control">
					<option value="Cash">Cash</option>
					<option value="Bkash">Bkash</option>
					<option value="Rocket">Rocket</option>
					<option value="Nagad">Nagad</option>
					<option value="Upay">Upay</option>
					<option value="Sure Cash">Sure Cash</option>
					<option value="Tap">Tap</option>
					<option value="POS Machine">POS Machine</option>
					<option value="Bank">Bank</option>
				</select>
			</div>
			<div class="col-xs-12 col-sm-2">
				<label for="comment" class="txt_color">মন্তব্য:</label>
				<input type="text" placeholder="Enter Remarks"  class="form-control" autocomplete="off" style="font-weight: bold;font-size:16px;font-style: italic;" name="mobile" id="tk_remarks" />
			</div>
			<div class="col-xs-12 col-sm-1">
				<label for="comment" class="txt_color">#</label>
				<span id="adjust_sms"><button onclick="dueAdjustment();" style="" name="btn" value="sub" id="save_order" class="btn btn-success">Save</button></span>
			</div>
			<div class="col-xs-12 col-sm-10" style="margin-top: 5px;">
				<div class="row" id="tk_form">
					<div class="col-xs-12 col-sm-3">
						<label for="comment" class="txt_color">কাস্টমার:</label>
						<p id="scus_name"></p>
						<input type="hidden" id="hscus_name"/>
					</div>
					<div class="col-xs-12 col-sm-2">
						<label for="comment" class="txt_color">মোবাইল:</label>
						<p id="scus_mobile"></p>
					</div>
					<div class="col-xs-12 col-sm-5">
						<label for="comment" class="txt_color">ঠিকানা:</label>
						<p id="scus_address"></p>
					</div>
				</div>
			</div>
			
			<div class="col-xs-12 col-sm-10" id="">
				<h3>Last <select style="border: 1px solid red;" onchange="lastDaysResult();" id="last_days"><option value="">##</option><option value="1">1</option><option value="3">3</option>
				<option value="5">5</option>
				<option value="10">10</option>
				<option value="15">15</option>
				<option value="20">20</option>
				<option value="25">25</option>
				<option value="30">30</option>
				</select> days result.</h3>
				<table id="example" style="margin-top: 5px;" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>SL</th>
							<th>Date</th>
							<th style="text-align: right;">Amount</th>
							<th>Remarks</th>
							<th>Transaction By</th>
						</tr>
					</thead>
					<tbody id="result_tbl">
						
					</tbody>
				</table>
			</div>
			<?php 
		} else if($id==12){
			if($_SESSION['IS_STOCK']==0){
		?>
		<div class="col-xs-12 col-sm-3">
		<h5 style="text-align:center">Fabrics</h5>
		<input type="hidden" id="check_stock" value="<?php echo $_SESSION['IS_STOCK']; ?>"/>
		<input type="hidden" id="purchase_price" value="0"/>
		<input type="hidden" id="selling_price" value="0"/>
				<label for="comment">Item Type<sup style="color:red">*</sup>:</label>
				<select id="item_type" onchange="typwWiseItem(2);" class="form-control">
					<option value="1">Gents</option>
					<option value="2">Lady</option>
				</select>
				<label for="comment">Fabrics Item Name<sup style="color:red">*</sup>:</label>
				<input type="text" <?php if($_SESSION['IS_STOCK']==1){ ?> onkeyup="selectItemName(1);" <?php } ?> class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="item_name" id="item_name" />
				<?php if($_SESSION['IS_STOCK']==1){ ?>
				 <span id="auto_item" style="z-index: 99999999999999;
					overflow: hidden;
					position: fixed;
					width: 263px;"></span>
				<input type="hidden" id="chkAutItem" value=""/>
				
				<label for="comment">Unit:</label>
				<select id="item_unit" class="form-control">
					<option value="">Select One</option>
					<option value="পিছ">Piece(পিছ)</option>
					<option value="গজ">Yard(গজ)</option>
					<option value="মিটার">Meter(মিটার)</option>
				</select>
				<label for="comment">Item Code:</label>
				<input type="text" onblur="checkItemCode();" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="item_code" />
				<?php } ?>
				<button onclick="saveFabrics();" style="margin-top: 12px;" name="btn" value="sub" id="saveFabricsBtn" class="btn btn-success form-control">Save</button>
				<span id="save_load">
				
				</span>
				
				<p></p>
			</div>
			<div class="col-xs-12 col-sm-5" style="margin-top: 5px;">
				<input type="text" onkeyup="searchStockItem(1);" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" placeholder="Item Name/Code" id="search_item_name" />
			</div>
			<div class="col-xs-12 col-sm-2" style="margin-top: 5px;">
				<select id="search_sort_type" onchange="searchStockItem(1);" class="form-control">
					<option value="">Sorting Type</option>
					<option value="asc">SL. ASC</option>
					<option value="desc">SL. DESC</option>
					<?php if($_SESSION['IS_STOCK']==1){ ?>
					<option value="qty_asc">Stock ASC</option>
					<option value="qty_desc">Stock DESC</option>
					<?php } ?>
				</select>
			</div>
			<div class="col-xs-12 col-sm-7" style="margin-top: 5px;">
			
				<table id="example" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th style="text-align:center">SL</th>
							<th>Item Name</th>
							<?php if($_SESSION['IS_STOCK']==1){ ?>
							<th style="text-align:center;width: 16%;">Item Code</th>
							<th style="text-align:center">Stock</th>
							<th style="text-align:right">Avg Price</th>
							<?php } ?>
						</tr>
					</thead>
					<tbody id="item_tbl">
						
					</tbody>
				</table>
			</div>
		<?php 
		}else{
			?>
		<div id="stock_area">
			
			<div class="col-xs-12 col-sm-3">
				<label for="comment">Fabrics Item Name<sup style="color:red">*</sup>:</label>
				<input type="text" <?php if($_SESSION['IS_STOCK']==1){ ?> onkeyup="selectItemName(1);" <?php } ?>  onkeydown="enterEventSelection('item_name','item_unit')" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="item_name" id="item_name" />
				
				 <span id="auto_item" style="z-index: 99999999999999;
					overflow: hidden;
					position: fixed;
					width: 263px;"></span>
				<input type="hidden" id="chkAutItem" value=""/>
			</div>
			<div class="col-xs-12 col-sm-1">
				<label for="comment">Unit:</label>
				<select id="item_unit" class="form-control">
					<option value="">Select One</option>
					<option value="গজ">গজ(Yard)</option>
					<option value="মিটার">মিটার(Meter)</option>
					<option value="পিছ">পিছ(Piece)</option>
					
				</select>
			</div>
			<div class="col-xs-12 col-sm-2" style="text-align: right;">
				<!-- <h5 style="text-align:center">Fabrics</h5> -->
				<input type="hidden" id="check_stock" value="<?php echo $_SESSION['IS_STOCK']; ?>"/>
				<input type="hidden" id="item_type" value="1"/>
				<label for="comment">Purchase Price<sup style="color:red">*</sup>:</label>
				<input type="text" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;text-align:right" name="cus_price" onkeydown="enterEventSelection('purchase_price','selling_price')" id="purchase_price" />
			</div>
			<div class="col-xs-12 col-sm-2" style="text-align: right;">
				<label for="comment">Selling Price:</label>
				<input type="text" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;text-align:right" name="cus_price" onkeydown="enterEventSelection('selling_price','item_code')" id="selling_price" />
			</div>
			<div class="col-xs-12 col-sm-2">
				<label for="comment">Item Code: <span id="duplicte_code" style="color:red"></span></label>
				<input type="text" onblur="checkItemCode();" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="item_code" />
			</div>	
			<div class="col-xs-12 col-sm-10">
				<span id="save_load">
					<button onclick="saveFabrics();" style="margin-top: 25px;" name="btn" value="sub" id="saveFabricsBtn" class="btn btn-success form-control">Save</button>
				</span>
				
			</div>
		</div>
			<div class="col-xs-12 col-sm-6" style="margin-top: 5px;">
				<input type="text" onkeyup="searchStockItem(1);" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" placeholder="Item Name/Code" id="search_item_name" />
			</div>
			<div class="col-xs-12 col-sm-2" style="margin-top: 5px;">
				<select id="search_sort_type" onchange="searchStockItem(1);" class="form-control">
					<option value="">Sorting Type</option>
					<option value="asc">SL. ASC</option>
					<option value="desc">SL. DESC</option>
					<?php if($_SESSION['IS_STOCK']==1){ ?>
					<option value="qty_asc">Stock ASC</option>
					<option value="qty_desc">Stock DESC</option>
					<?php } ?>
				</select>
			</div>
			<div class="col-xs-12 col-sm-2">
				<button onclick="hideShowBtn();" style="margin-top: 5px;" name="btn" value="sub" id="hide_show_btn" class="btn btn-primary form-control">Hide</button>
				<input type="hidden" id="btn_hide_show" value="0"/>
			</div>
			<div class="col-xs-12 col-sm-12" style="margin-top: 5px;">
			
				<table id="example" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th style="text-align:center">SL</th>
							<th>Item Name</th>
							<?php if($_SESSION['IS_STOCK']==1){ ?>
							<th style="text-align:center;width: 13%;">Item Code</th>
							<th style="text-align:center">Stock</th>
							<th style="text-align:right;width: 12%;">Purchase Price</th>
							<th style="text-align:right;width: 12%;">Selling Price</th>
							<!--<th style="text-align:center;width: 10%;">Photo</th>-->
							<?php } ?>
						</tr>
					</thead>
					<tbody id="item_tbl">
						
					</tbody>
				</table>
			</div>
			<?php 
		}
		} else if($id==13){
		?>
		<div class="col-xs-12 col-sm-2">
		<h5 style="text-align:center">User Form</h5>
				<label for="comment">User Type<sup style="color:red">*</sup>:</label>
				<select id="user_type" onchange="typwWiseUser();" class="form-control">
					<option value="">Select One</option>
					<option value="0">Entry user</option>
					<option value="2">Admin</option>
				</select>
				<label for="comment">User Name<sup style="color:red">*</sup>:</label>
				<input type="text" maxlength="50" name="user" autocomplete="off" class="form-control" placeholder="User Name" id="user_name">
				
				<label for="comment">User Mobile<sup style="color:red">*</sup>:</label>
				<input type="text" maxlength="11" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" name="mobile" autocomplete="off" maxlength="11" class="form-control" placeholder="User Mobile" id="user_mobile">
				<label for="comment">Login user<sup style="color:red">*</sup>:</label>
				<input type="text" maxlength="11" name="user" autocomplete="off" class="form-control" placeholder="Login User" id="login_user">
				<label for="comment">Login Password<sup style="color:red">*</sup>:</label>
				<input type="text" maxlength="11" name="user" autocomplete="off" class="form-control" placeholder="Login Password" id="login_password">
				
				<button onclick="saveUserInfo();" style="margin-top: 12px;" name="btn" value="sub" id="saveUserBtn" class="btn btn-success form-control">Save</button>
				<span id="save_load">
				
				</span>
				
				<p></p>
			</div>
			<div class="col-xs-12 col-sm-8" style="margin-top: 5px;">
				<table id="example" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>SL</th>
							<th>User Name</th>
							<th>Mobile</th>
							<th>Login User</th>
							<th>Login Password</th>
							<th>আজকের বিক্রি(Tk)<br/>ক্যাশ গ্রহণ(Tk)</th>
						</tr>
					</thead>
					<tbody id="item_tbl">
						
					</tbody>
				</table>
			</div>
		<?php 
		} else if($id==14){
			$com_id=($_SESSION['COM_ID']);
			$emp_info=$conn->query("select t2.cus_name,t2.cus_mobile,t1.cus_id,t1.earn_point from (SELECT sum(c.point) earn_point,c.cus_id FROM point_tbl c WHERE c.com_id=$com_id and c.is_active=1 group by c.cus_id) t1,customer t2 where t1.cus_id=t2.id");
			mysqli_close($conn);
		?>
		<div class="col-xs-10 col-sm-10" style="margin-top: 5px;">
				<table id="example" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>SL</th>
							<th>Customer Name</th>
							<th>Mobile</th>
							<th style="width: 20%;">Withdraw</th>
							<th style="width: 15%;text-align:right">Earning Point</th>
						</tr>
					</thead>
					<tbody id="">
					<?php 
					if(mysqli_num_rows($emp_info)>0){
						$count=1;
					while($row=mysqli_fetch_array($emp_info)){
						@$j=$count++;
						if($row['earn_point']>0){
					?>
						<tr style="cursor:pointer" onclick="showPoint('<?php echo $row['cus_id']; ?>','<?php echo $row['cus_mobile']; ?>','<?php echo $j; ?>')" id="point_detail<?php echo $j; ?>">
							<td><?php echo $j; ?></td>
							<td><?php echo $row['cus_name']; ?></td>
							<td><?php echo $row['cus_mobile']; ?></td>
							<td>
							<input type="text" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold; font-size: 18px;font-style: italic;text-align: right;width: 68%;float: left;margin-right: 8px; border: 1px solid green;" autocomplete="off" name="tdue" id="width_draw<?php echo $j; ?>" value="<?php echo $row['earn_point']; ?>"/>
							<button onclick="widthDrawBtn('<?php echo $j; ?>',<?php echo $row['cus_id']; ?>);" name="btn" id="widthdarawBtn<?php echo $j; ?>" value="sub" class="btn btn-success">Ok</button>
							</td>
							<td style="text-align:right"><b><span id="last_point<?php echo $j; ?>"><?php echo $row['earn_point']; ?></span></b></td>
						</tr>
					<?php } } } ?>
					</tbody>
				</table>
			</div>
			<span id="sms_point"></span>
		<?php 
		}else if($id==15){
			$com_id=($_SESSION['COM_ID']);
			$product=$conn->query("select ss.id,ss.item_id,ss.dstid direct_salse_head_id,(select cus_mobile from direct_sale_head where id=ss.dstid) supplier_mobile,(select item_code from product where id=ss.item_id) item_code,(select uom from product where id=ss.item_id) item_unit,(select product_name from product where id=ss.item_id) item_name,ss.item_qty,ss.price,ss.insert_date from direct_sale ss where ss.is_active=1 and ss.com_id=$com_id and ss.in_out_status=1 order by ss.id desc limit 0,1000");
			mysqli_close($conn);
		?>
		<div class="col-xs-12 col-sm-3">
		<h5 style="text-align:center">Stock In</h5>
		<input type="hidden" id="check_stock" value="<?php echo $_SESSION['IS_STOCK']; ?>"/>
				
				<label for="comment">Fabrics Item Name<sup style="color:red">*</sup>: <span id="stk_in"></span></label>
				<input type="text" <?php if($_SESSION['is_barcode']==1){ ?> onkeydown="barcodeScan(event);" <?php }else{?>onkeyup="selectItemName(2);"<?php } ?> class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="item_name" id="item_name" />
				
				 <span id="auto_item" style="z-index: 99999999999999;
					overflow: hidden;
					position: fixed;
					width: 263px;"></span>
				<input type="hidden" id="chkAutItem" value=""/>
				<input type="hidden" id="previous_stock_qty" value="0"/>
				<input type="hidden" id="previous_total_price" value="0"/>
				<input type="hidden" id="previous_avg_price" value="0"/>
				
				<label for="comment">Unit:</label>
				<input type="text" readonly class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="item_unit" />
				<label for="comment">Item Code:</label>
				<input type="text" readonly class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="item_code" />
				<label for="comment">Purchase Qty:</label>
				<input type="text" class="form-control" onkeyup="CalculatePerPrice();" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="purchase_qty" />
				<label for="comment">Purchase Per Price:</label>
				<input type="text" class="form-control" onkeyup="CalculatePerPrice();" onkeydown="enterEvent('purchase_price','saveFabricsBtn')" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="purchase_price" />
				<label for="comment">Total Price:</label>
				<input type="text" readonly class="form-control" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="total_price" />
				<label for="comment">Supplier Mobile Number:</label>
				<input type="text" maxlength="11" class="form-control" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="supplier_mobile" />
				
				<button onclick="saveFabricsInStock();" style="margin-top: 12px;" name="btn" value="sub" id="saveFabricsBtn" class="btn btn-success form-control">Save</button>
				<span id="save_load">
				
				</span>
				
				<p></p>
			</div>
			<div class="col-xs-12 col-sm-3" style="margin-top: 5px;">
				<input type="text" onkeyup="searchStockItem(2);" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" placeholder="Item Name/Code" id="search_item_name" />
			</div>
			<div class="col-xs-12 col-sm-2" style="margin-top: 5px;">
				<input type="date" onchange="searchStockItem(2);" autocomplete="off" name="date3" id="date3" class="form-control" data-select="date">
			</div>
			<div class="col-xs-12 col-sm-2" style="margin-top: 5px;">
				<select id="search_sort_type" onchange="searchStockItem(2);" class="form-control">
					<option value="">Sorting Type</option>
					<option value="asc">SL. ASC</option>
					<option value="desc">SL. DESC</option>
					<option value="qty_asc">Qty ASC</option>
					<option value="qty_desc">Qty DESC</option>
				</select>
			</div>
			<div class="col-xs-12 col-sm-7" style="margin-top: 5px;">
			
				<table id="example" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>SL</th>
							<th>Item Name</th>
							<th style="text-align:center;width: 12%;">In Qty</th>
							<th style="text-align:right">Price</th>
							<th style="text-align:right">Total</th>
							<th style="text-align:center">Supplier Mobile</th>
						</tr>
					</thead>
					<tbody id="item_tbl">
						<?php 
						$tqty=0;$ttaka=0;$tprice_row=0;
						if(mysqli_num_rows($product)>0){
						$i=1;
							while($rows=mysqli_fetch_array($product)){
								$j=$i++;
								$tqty+=$rows['item_qty'];
								$ttaka+=round(($rows['item_qty']*$rows['price']),2);
								$tprice_row=round(($rows['item_qty']*$rows['price']),2);
								
								$tbl_id=$rows['direct_salse_head_id']; // direct sales head tbl id 
								$item_qty=$rows['item_qty'];
								$item_id=$rows['item_id'];
						?>
							<tr>
								<td><button onclick="delInStockItem('<?php echo $tbl_id; ?>','<?php echo $j; ?>','<?php echo $item_qty; ?>','<?php echo $tprice_row; ?>','<?php echo $item_id; ?>');" name='btn' id='delbtn<?php echo $j; ?>' class="btn btn-danger form-control"><?php echo $j; ?></button></td>
								<td>
									<?php echo $rows['item_name']; ?><p style='font-size:9px;color:blue'><?php echo @$rows['item_code']; ?></p>
								</td>
								<td style='text-align:center'><?php echo $rows['item_qty']; ?> <p style='font-size:8px;color:blue'><?php echo @$rows['item_unit']; ?></p></td>
								<td style='text-align:right'><?php echo $rows['price']; ?></td>
								<td style='text-align:right'><?php echo round(($rows['item_qty']*$rows['price']),2); ?></td>
								<td style='text-align:center'><?php echo @$rows['supplier_mobile']; ?> <p style='font-size:9px;color:green'><?php echo @$rows['insert_date']; ?></p></td>
							</tr>
						<?php 
							}
							echo "<input type='hidden' value='$j' id='ilast_id'/>";
			
					}else{
						echo "<input type='hidden' value='0' id='ilast_id'/>";
					}
					?>
					<tr>
						<td colspan="2" style="text-align: right;font-weight: bold;">
							Total Qty: 
						</td>
						<td style="text-align: center;font-weight: bold;">
							<?php echo $tqty; ?>
						</td>
						<td style="text-align: right;font-weight: bold;">
							Total: 
						</td>
						<td style="text-align: right;font-weight: bold;">
							<?php echo $ttaka; ?>
						</td>
					</tr>
					</tbody>
				</table>
			</div>
		<?php 
		} else if($id==16){
			$com_id=($_SESSION['COM_ID']);
			$product=$conn->query("select ss.id,ss.item_id,(select item_code from product where id=ss.item_id) item_code,(select uom from product where id=ss.item_id) item_unit,(select product_name from product where id=ss.item_id) item_name,ss.adjustment_qty,ss.remarks,ss.insert_date,(select user_name from user where id=ss.insert_by) adjust_by from stock_adjustment ss where ss.is_active=1 order by ss.id desc limit 0,100");
			mysqli_close($conn);
		?>
		<div class="col-xs-12 col-sm-3">
		<h5 style="text-align:center">Stock Adjustment</h5>
				
				<label for="comment">Fabrics Item Name<sup style="color:red">*</sup>:</label>
				<input type="text" onkeyup="selectItemName(3);" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="item_name" id="item_name" />
				
				 <span id="auto_item" style="z-index: 99999999999999;
					overflow: hidden;
					position: fixed;
					width: 263px;"></span>
				<input type="hidden" id="chkAutItem" value=""/>
				<input type="hidden" id="previous_total_price" value="0"/>
				
				<label for="comment">Unit:</label>
				<input type="text" readonly class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="item_unit" />
				<label for="comment">Item Code:</label>
				<input type="text" readonly class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="item_code" />
				<label for="comment">Present Stock Qty:</label>
				<input type="text" readonly class="form-control" autocomplete="off"  style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="previous_stock_qty" />
				<label for="comment">Adjustment Qty:</label>
				<input type="number" class="form-control" onkeyup="CalculateAdjustmentQty();" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="adjustment_qty" />
				<label for="comment">Final Qty:</label>
				<input type="text" readonly class="form-control" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="final_qty" />
				<label for="comment">Average Price:</label>
				<input type="text" onkeyup="CalculateAdjustmentQty();" class="form-control" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="previous_avg_price" />
				<label for="comment">Total Price:</label>
				<input type="text" readonly class="form-control" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="total_price" />
				
				<button onclick="saveStockAdjustment();" style="margin-top: 12px;" name="btn" value="sub" id="saveFabricsBtn" class="btn btn-success form-control">Save</button>
				<span id="save_load">
				
				</span>
				
				<p></p>
			</div>
			<div class="col-xs-12 col-sm-3" style="margin-top: 5px;">
				<input type="text" onkeyup="searchStockItem(3);" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" placeholder="Item Name/Code" id="search_item_name" />
			</div>
			<div class="col-xs-12 col-sm-2" style="margin-top: 5px;">
				<input type="date" onchange="searchStockItem(3);" autocomplete="off" name="date3" id="date3" class="form-control" data-select="date">
			</div>
			<div class="col-xs-12 col-sm-2" style="margin-top: 5px;">
				<select id="search_sort_type" onchange="searchStockItem(3);" class="form-control">
					<option value="">Sorting Type</option>
					<option value="asc">SL. ASC</option>
					<option value="desc">SL. DESC</option>
					<option value="qty_asc">Qty ASC</option>
					<option value="qty_desc">Qty DESC</option>
				</select>
			</div>
			<div class="col-xs-12 col-sm-7" style="margin-top: 5px;">
			
				<table id="example" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th style='text-align:center'>SL</th>
							<th>Item Name</th>
							<th style="text-align:center;width: 14%;">Adjus. Qty</th>
							<th style="text-align:center">Remarks</th>
							<th style="text-align:center">Insert By</th>
						</tr>
					</thead>
					<tbody id="item_tbl">
						<?php 
						$tqty=0;$ttaka=0;
						if(mysqli_num_rows($product)>0){
						$i=1;
							while($rows=mysqli_fetch_array($product)){
								$j=$i++;
								$tqty+=$rows['adjustment_qty'];
						?>
							<tr>
								<td style='text-align:center'>
									<?php echo $j; ?><!--<button onclick='delItem(<?php echo $rows['id']; ?>,<?php echo $j; ?>);' name='btn' id='delbtn<?php echo $j; ?>' class="btn btn-danger form-control"><?php echo $j; ?></button>--></td>
								<td>
									<?php echo $rows['item_name']; ?><p style='font-size:9px;color:blue'><?php echo @$rows['item_code']; ?></p>
								</td>
								<td style='text-align:center'><?php echo $rows['adjustment_qty']; ?> <p style='font-size:8px;color:blue'><?php echo @$rows['item_unit']; ?></p></td>
								<td style='text-align:center'><?php echo $rows['remarks']; ?></td>
								<td style='text-align:center'><?php echo @$rows['adjust_by']; ?> <p style='font-size:9px;color:green'><?php echo @$rows['insert_date']; ?></p></td>
							</tr>
						<?php 
							}
							echo "<input type='hidden' value='$j' id='ilast_id'/>";
			
					}else{
						echo "<input type='hidden' value='0' id='ilast_id'/>";
					}
					?>
				
					</tbody>
				</table>
			</div>
		<?php 
		} else if($id==17){
			$com_id=($_SESSION['COM_ID']);
			$product=$conn->query("select ss.id,ss.item_id,(select item_code from product where id=ss.item_id) item_code,(select uom from product where id=ss.item_id) item_unit,(select product_name from product where id=ss.item_id) item_name,ss.adjustment_qty,ss.remarks,ss.insert_date,(select user_name from user where id=ss.insert_by) adjust_by from stock_adjustment ss where ss.is_active=1 order by ss.id desc limit 0,100");
			mysqli_close($conn);
		?>
		<div class="col-xs-12 col-sm-3">
			<h5 style="text-align:center">Job Manage</h5>
				
				<label for="comment">Job Type<sup style="color:red">*</sup>:</label>
				<select id="job_type" onchange="showJobType();" class="form-control">
					<option value="">Select One</option>
					<option value="0">Job Receive</option>
					<option value="1">Payment (Tk)</option>
				</select>
				<div id="show_job_form">
				</div>
				<p></p>
		</div>
			
			<div class="col-xs-12 col-sm-7" id="right_result" style="margin-top: 5px;">
				
			</div>
		<?php 
		}
	}
	
	if(isset($_REQUEST['showJobType'])){
		$job_type=($_REQUEST['job_type']);
		if($job_type==0){ // job assign
			?>
			<label for="comment">Employee Type:</label>
			<select id="get_emp_type" onchange="getEmp();" style="" class="form-control">
					<option value="">Select One</option>
					<option value="1">Master</option>
					<option value="2">Karigor</option>
			</select>
			<label for="comment">Employee Name:</label>
			<select id="emp_name_details" onchange="getDueDetails('0');" style="" class="form-control">
					<option value="">Select One</option>
			</select>
			<label for="comment">Order No:</label>
			<input type="text" class="form-control"  style="font-weight: bold;font-size:18px;font-style: italic;text-transform:uppercase" autocomplete="off" name="edit_ord_number" onkeyup="getSrcableOrder()" id="src_ord_number" required/>
			<span id="srcable_auto_mobile" style="z-index: 99999999999999;overflow: hidden;position: fixed;width: 240px;">
			</span>
			<div id="show_order_info">
			</div>
			<label for="comment">Taka:</label>
			<input type="text" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="emp_wages" />
			<label for="comment">Remarks:</label>
			<input type="text" class="form-control" autocomplete="off"  style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="remarks" />
			
			<!--<button onclick="saveJobAssign('0');" style="margin-top: 12px;" name="btn" value="sub" id="jobAssignBtn" class="btn btn-success form-control">Save</button>-->
			<span id="save_load"></span>
			<?php 
		}
		if($job_type==1){ // payment
			?>
			<label for="comment">Employee Type:</label>
			<select id="get_emp_type" style="" onchange="getEmp();" class="form-control">
					<option value="">Select One</option>
					<option value="1">Master</option>
					<option value="2">Karigor</option>
					
			</select>
			<label for="comment">Employee Name:</label>
			<select id="emp_name_details" style="" onchange="getDueDetails('1');" class="form-control">
					<option value="">Select One</option>
					
			</select>
			<label for="comment">Taka:</label>
			<input type="text" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="emp_wages" />
			<label for="comment">Remarks:</label>
			<input type="text" class="form-control" autocomplete="off"  style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_price" id="remarks" />
			
			<button onclick="savePaymet('1');" style="margin-top: 12px;" name="btn" value="sub" id="jobAssignBtn" class="btn btn-success form-control">Save</button>
			<span id="save_load"></span>
			<?php 
		}
	}
	
	if(isset($_REQUEST['getDueDetails'])){
		date_default_timezone_set("Asia/Dhaka");
		$date=date("Y-m-d");
		$param=($_REQUEST['param']);
		$emp_id=($_REQUEST['emp_id']);
		$job_type=$_REQUEST['job_type']; //assign, payment
		
		$summery=$conn->query("SELECT `taka` FROM `wages_head` WHERE emp_id=$emp_id");
		if(mysqli_num_rows($summery)>0){
			$row=mysqli_fetch_array($summery);
			$balance=$row['taka'];
			$emp_info=$conn->query("SELECT id,emp_id,status,`order_num`,`item_name`,`item_qty`,`taka`,`remarks`,`insert_date`,date(`insert_date`) indate,ord_record_tblid FROM `wages_details` WHERE emp_id=$emp_id and is_active=1 and `status`=$job_type order by id desc limit 0,200");
		?>
		<h3 id="tot_balance">Present Balance: <?php echo @$balance; ?>/=</h3>
		<table id="example" class="table table-striped table-bordered">
			<thead>
				<tr>
					<th style='text-align:center'>SL</th>
					<th>Order No.</th>
					<th style="text-align:center;width: 14%;">Item Name</th>
					<th style="text-align:center">Item Qty</th>
					<th style="text-align:center">Remarks</th>
					<th style="text-align:right">Taka</th>
					<th style="text-align:center">Insert Date</th>
				</tr>
			</thead>
					<tbody id="item_tbl">
						<?php 
						$i=1;
						while($row=mysqli_fetch_array($emp_info)){
							$c=$i++;
							?>
						<tr>
							<td style='text-align:center'>
							<?php 
							if($job_type==0){
							?>
								<button onclick="delItemPayment('<?php echo $row['id']; ?>','<?php echo $c; ?>','<?php echo $row['taka']; ?>','<?php echo $row['emp_id']; ?>','<?php echo $row['status']; ?>','<?php echo $row['ord_record_tblid']; ?>');" name='btn' id='delbtns<?php echo $c; ?>' class="btn btn-danger form-control"><?php echo $c; ?></button>
							<?php
							}else 
							if($date==$row['indate'] && $job_type==1){
							?>
							<button onclick="delItemPayment('<?php echo $row['id']; ?>','<?php echo $c; ?>','<?php echo $row['taka']; ?>','<?php echo $row['emp_id']; ?>','<?php echo $row['status']; ?>','<?php echo $row['ord_record_tblid']; ?>');" name='btn' id='delbtns<?php echo $c; ?>' class="btn btn-danger form-control"><?php echo $c; ?></button>
							<?php }else{
								 echo $c; 
							} ?>
							</td>
							<td><?php echo $row['order_num']; ?></td>
							<td><?php echo $row['item_name']; ?></td>
							<td><?php echo $row['item_qty']; ?></td>
							<td><?php echo $row['remarks']; ?></td>
							<td style="text-align:right"><?php echo $row['taka']; ?></td>
							<td><?php echo $row['insert_date']; ?></td>
						<tr>	
							<?php 
						}
						?>
					</tbody>
					<input type="hidden" value="<?php echo @$c; ?>" id="right_tbl_id"/>
				</table>
		<?php 
		}else{
			?>
			<input type="hidden" value="0" id="right_tbl_id"/>
			<?php 
		}
		
		
		
	}
	
	if(isset($_REQUEST['srchForOrdDetails'])){
		$ord_number=trim($_REQUEST['ord_number']);
		$get_emp_type=($_REQUEST['get_emp_type']);
		$com_id=$_SESSION['COM_ID'];
		if($get_emp_type==1){
			$item_sql=$conn->query("SELECT ord.id,ord.receive_qty,ord.master_cutting_qty,ord.item_qty,ord.item_id,ord.dsms_id,(select product_name from product where id=ord.item_id) item_name,(SELECT master_price from product where id=ord.item_id) wages,(select user_name from user where id=ord.master_emp_id) karigor_name FROM `order_record` ord WHERE ord.is_active=1 and com_id=$com_id and ord.`order_number`='$ord_number'");
		}
		if($get_emp_type==2){
			$item_sql=$conn->query("SELECT ord.id,ord.receive_qty,ord.item_qty,ord.item_id,ord.dsms_id,(select product_name from product where id=ord.item_id) item_name,(SELECT artisan_price from product where id=ord.item_id) wages,(select user_name from user where id=ord.maker) karigor_name FROM `order_record` ord WHERE ord.is_active=1 and com_id=$com_id and ord.`order_number`='$ord_number'");
		}
		if(mysqli_num_rows($item_sql)>0){
			echo "<br/><ol style='margin-left: -24px;'>";
			$c=1;
			while($row=mysqli_fetch_array($item_sql)){
				$name=$row['karigor_name'];
				$receive_qty=($get_emp_type==1)? $row['master_cutting_qty'] : $row['receive_qty'];
				
				$j=$c++;
				?>
				<li>
					<span style="cursor:pointer;font-size:12px;font-weight:bold" title="<?php echo @$name; ?>"><?php echo $row['item_name'];?>(<?php echo $row['id'];?>)<input type='hidden' value='<?php echo $row['item_name'];?>' id='src_item_name<?php echo $j; ?>'/><input type='hidden' value='<?php echo $row['item_id'];?>' id='src_item_id<?php echo $j; ?>'/><input type='hidden' value='<?php echo $row['id'];?>' id='src_ord_tbl_id<?php echo $j; ?>'/></span> |<span style="font-size:12px;font-weight:bold"> Qty: <input style="width: 15%;text-align:center" <?php echo ($row['item_qty']==$receive_qty)? "readonly" : ""; ?> id="srcitem_qty<?php echo $j; ?>" onkeyup="setItemPrice('1');" type="text" value="<?php echo ($row['item_qty']==$receive_qty)? "" : ($row['item_qty']-$receive_qty); ?>"/> | Rate: <input type="hidden" id="rate<?php echo $j; ?>" value="<?php echo $row['wages'];?>"/><?php echo $row['wages'];?>/=</span>
				
				</li>
				<?php 
			}
			echo "</ol>";
			echo "<input type='hidden' id='tot_rate' value='$j'/>";
		}else{
			echo 2;
		}
		
	}
	
	if(isset($_REQUEST['getEmp'])){
		$get_emp_type=($_REQUEST['get_emp_type']);
		$com_id=$_SESSION['COM_ID'];
		$emp_info=$conn->query("SELECT ord.id,ord.user_name,ord.mobile FROM `user` ord WHERE ord.is_active=1 and salary_type=1 and emp_type=$get_emp_type");
		if(mysqli_num_rows($emp_info)>0){
			$c=1;
			echo '<option value="">Select One</option>';
			while($row=mysqli_fetch_array($emp_info)){
				?>
				<option value="<?php echo $row['id'];?>"><?php echo $row['user_name']."(".$row['mobile'].")"; ?></option>
				<?php 
			}
			
		}else{
			echo 2;
		}
		
	}
	
	if(isset($_REQUEST['saveJobAssign'])){
		date_default_timezone_set("Asia/Dhaka");
		$assign_date=date("d/m/Y");
		$com_id=($_SESSION['COM_ID']);
		$user_id=($_SESSION['USER_ID']);
		$emp_id=($_REQUEST['emp_id']);
		@$order_num=($_REQUEST['order_num']);
		$taka=($_REQUEST['taka']);
		$remarks=($_REQUEST['remarks']);
		@$item_name=($_REQUEST['item_name']);
		@$item_idss=($_REQUEST['item_id']);
		$get_emp_type=($_REQUEST['get_emp_type']);
		$item_id=explode(",",$_REQUEST['item_id']);
		$ex_item_name=explode(",",$item_name);
		$ord_tbl_id=explode(",",$_REQUEST['ord_tbl_id']);
		@$item_qty=($_REQUEST['item_qty']);
		$status=($_REQUEST['param']);
		$right_tbl_id=($_REQUEST['right_tbl_id']);
		$emp_info=$conn->query("SELECT id,taka from wages_head where emp_id=$emp_id and com_id=$com_id");
		if(mysqli_num_rows($emp_info)>0){
			$row=mysqli_fetch_array($emp_info);
			$id=$row['id'];
			$utaka=($row['taka']+$taka);
			$last_insert_head=$conn->query("update wages_head set taka='$utaka' where id=$id");
		}else{
			$last_insert_head=$conn->query("insert into wages_head(com_id,emp_id,taka) values ($com_id,$emp_id,'$taka')");
			
		}
		
		if($order_num!=""){
				$update_qty_a=explode(",",$item_qty);
				for($i=0; $i<count($item_id); $i++){
					$update_qty=$update_qty_a[$i];
					$item_ids=$item_id[$i];
					$tbl_id=$ord_tbl_id[$i];
					$item_name=$ex_item_name[$i];
					$work_tk_sql=$conn->query("SELECT * from product where id=$item_ids");
					$row_work_tk=mysqli_fetch_array($work_tk_sql);
					if($get_emp_type==2){ //karigor 
						$rec_qty=$conn->query("SELECT * from order_record where id=$tbl_id and is_active=1");
						$row=mysqli_fetch_array($rec_qty);
						$receive_qty=$row['receive_qty'];
						$work_tk=($row_work_tk['artisan_price']*$update_qty);
						$conn->query("update order_record set assign_date='$assign_date',receive_qty=($update_qty+$receive_qty),maker=$emp_id,emp_type=$get_emp_type where id=$tbl_id");
					}else{ // master=1
						$rec_qty=$conn->query("SELECT * from order_record where id=$tbl_id and is_active=1");
						$row=mysqli_fetch_array($rec_qty);
						$receive_qty=$row['master_cutting_qty'];
						$work_tk=($row_work_tk['master_price']*$update_qty);
						$conn->query("update order_record set master_assign_date='$assign_date',master_cutting_qty=($update_qty+$receive_qty),master_emp_id=$emp_id where id=$tbl_id");
					}
					
					$last_insert=$conn->query("insert into wages_details(com_id,
								emp_id,
								order_num,
								taka,
								remarks,
								item_name,
								item_qty,
								status,
								item_ids,
								emp_type,
								ord_record_tblid,
								insert_by
								) values($com_id,
								$emp_id,
								'$order_num',
								'$work_tk',
								'$remarks',
								'$item_name',
								'$update_qty',
								'$status',
								'$item_ids',
								'$get_emp_type',
								'$tbl_id',
								$user_id)");
				}
			
		}else{
			$last_insert=$conn->query("insert into wages_details(com_id,
						emp_id,
						order_num,
						taka,
						remarks,
						item_name,
						item_qty,
						status,
						item_ids,
						emp_type,
						insert_by
						) values($com_id,
						$emp_id,
						'$order_num',
						'$taka',
						'$remarks',
						'$item_name',
						'$item_qty',
						'$status',
						'$item_idss',
						'$get_emp_type',
						$user_id)");
		}
		
		
			
			if($order_num!=""){
				//$ord_tbl_select=$conn->query("SELECT CASE WHEN sum(item_qty)=sum(receive_qty) THEN 1 ELSE 0 END receive_test FROM `order_record` WHERE `com_id`=$com_id and is_active=1 and order_number='$order_num'");
				$ord_tbl_select=$conn->query("select itbl.iitem_qty,rtbl.rreceive_qty from (SELECT sum(item_qty) iitem_qty FROM `order_record` WHERE `com_id`=$com_id and is_active=1 and order_number='$order_num') itbl, (SELECT sum(receive_qty) rreceive_qty FROM `order_record` WHERE `com_id`=$com_id and is_active=1 and order_number='$order_num' and `emp_type`=2) rtbl");
				$ord_tbl_selecta=mysqli_fetch_array($ord_tbl_select);
				//if($ord_tbl_selecta['receive_test']==1){
				if($ord_tbl_selecta['iitem_qty']==$ord_tbl_selecta['rreceive_qty']){
					$date=date("Y-m-d");
					$chk_com=$conn->query("update dsms set factory_status=1,factory_receive_date='$date' where tagnum='$order_num' and com_id=$com_id");
						if($from_factory_recive_live_sms==1){ // 1=means active order live smsm 
							if($get_emp_type==2){ //karigor 
								if(check_internet_connection()==1){
									$cus_mobiles=$conn->query("SELECT cus_mobile FROM `dsms` WHERE `com_id`=$com_id and is_active=1 and tagnum='$order_num'");
									$cus_mobilea=mysqli_fetch_array($cus_mobiles);
									$mobile=$cus_mobilea['cus_mobile'];
									$response = file_get_contents($_SESSION['API']."api/data.php?com_id=$com_id&cus_mobile=$mobile&order_no=$order_num&chk=11"); //chk=2 means check sms
									$json = json_decode($response, true);
								}
							}
						}
					
				}
			}
		
		if($last_insert){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['savePaymet'])){
		$due_tk="";
		$com_id=($_SESSION['COM_ID']);
		$user_id=($_SESSION['USER_ID']);
		$emp_id=($_REQUEST['emp_id']);
		$taka=($_REQUEST['taka']);
		$remarks=($_REQUEST['remarks']);
		$status=($_REQUEST['param']);
		$right_tbl_id=($_REQUEST['right_tbl_id']);
		$emp_info=$conn->query("SELECT id,taka from wages_head where emp_id=$emp_id and com_id=$com_id");
		$emp_info_mobile=$conn->query("SELECT mobile from user where id=$emp_id");
		$row_mobile=mysqli_fetch_array($emp_info_mobile);
		$cus_mobile=$row_mobile['mobile'];
		if(mysqli_num_rows($emp_info)>0){
			$row=mysqli_fetch_array($emp_info);
			$id=$row['id'];
			$utaka=($row['taka']-$taka);
			$due_tk=$utaka;
			$last_insert_head=$conn->query("update wages_head set taka='$utaka' where id=$id");
		}else{
			if($status==1){ // at first advance payment 
				$last_insert_head=$conn->query("insert into wages_head(com_id,emp_id,taka) values ($com_id,$emp_id,'-$taka')");
				$due_tk=-$taka;
			}else{
				$last_insert_head=$conn->query("insert into wages_head(com_id,emp_id,taka) values ($com_id,$emp_id,'$taka')");
				$due_tk=$taka;
			}
		}
		$last_insert=$conn->query("insert into wages_details(com_id,
			emp_id,
			taka,
			remarks,
			status,
			insert_by
			) values($com_id,
			$emp_id,
			'$taka',
			'$remarks',
			'$status',
			$user_id)");
			
			 if($wages_sms==1){ // 1=means active order live smsm 
				if(check_internet_connection()==1){
					
					$response = file_get_contents($_SESSION['API']."api/data.php?com_id=$com_id&cus_mobile=$cus_mobile&taka=$taka&remarks=1&balance=$due_tk&chk=12"); //chk=2 means check sms
					$json = json_decode($response, true);
				}
			} 
		
		if($last_insert){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['widthDrawBtn'])){
		$com_id=($_SESSION['COM_ID']);
		$cus_id=($_REQUEST['cus_id']);
		$width_draw=($_REQUEST['width_draw']);
		$paidpoint=$conn->query("insert into point_tbl(cus_id,point,com_id) values($cus_id,'-$width_draw',$com_id)");
		if($paidpoint){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['show_point_details'])){
		$com_id=($_SESSION['COM_ID']);
		$cus_id=($_REQUEST['cus_id']);
		$mobile=($_REQUEST['mobile']);
			$emp_info=$conn->query("SELECT c.point earn_point,c.cus_id,c.insert_date FROM point_tbl c WHERE c.com_id=$com_id and c.cus_id=$cus_id and c.is_active=1");
			mysqli_close($conn);
		?>
		<div class="col-xs-10 col-sm-10" style="margin-top: 5px;">
			<h3>Mobile: <?php echo $mobile; ?></h3>
				<table id="example" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>SL</th>
							<th>Earning Date</th>
							<th style="width: 15%;text-align:right">Earning Point</th>
						</tr>
					</thead>
					<tbody id="">
					<?php 
					if(mysqli_num_rows($emp_info)>0){
						$count=1;$total=0;
					while($row=mysqli_fetch_array($emp_info)){
						@$j=$count++;
						$total+=$row['earn_point'];
					?>
						<tr>
							<td><?php echo $j; ?></td>
							<td><?php echo $row['insert_date']; ?></td>
							<td style="text-align:right"><b><?php echo $row['earn_point']; ?></b></td>
						</tr>
						
					<?php } } ?>
					<tr>
						<td colspan="2" style="text-align:right">Total Point</td>
						<td style="text-align:right"><b><?php echo $total; ?></b></td>
					</tr>
					</tbody>
				</table>
			</div>
		<?php 
		
	}
	
	if(isset($_REQUEST['customerForm'])){
		?>
		<div class="col-xs-12 col-sm-6">
			<div class="row">
				<div class="col-xs-12 col-sm-12">
					<label for="comment">Customer Name:</label>
					<input type="text" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="smobile" id="customer_name" />
				</div>
				<div class="col-xs-12 col-sm-12">
					<label for="comment">Customer Mobile Number:<sup style="color:red">*</sup></label>
					<input type="text" maxlength="11" class="form-control" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" name="smobile" id="customer_mobile" />
				</div>
				<div class="col-xs-12 col-sm-12">
					<label for="comment">Customer Address:</label>
					<input type="text" class="form-control" autocomplete="off" style="font-weight: bold;font-size:18px;font-style: italic;" name="smobile" id="customer_address" />
				</div>
				<div class="col-xs-12 col-sm-12" style="margin-top: 15px;">
					<button onclick="saveCustomer();" name="btn" id="saveBtns" value="sub" class="btn btn-info">Save</button>
					<button onclick="canceForm();" name="btn" id="cancelBtns" value="sub" class="btn btn-danger">Cancel</button>
					<span id="save_sms"></span>
				</div>
			</div>
		</div>
		<?php 
	}
	

	
	if(isset($_REQUEST['dueAdjustment'])){
		$cus_id=$_REQUEST['cus_id'];
		$cus_mobile=$_REQUEST['cus_mobile'];
		$tk_type=$_REQUEST['tk_type'];
		$adjust_tk=$_REQUEST['adjust_tk'];
		$tk_remarks=$_REQUEST['tk_remarks'];
		$payment_type=$_REQUEST['payment_type'];
		$hscus_name=$_REQUEST['hscus_name'];
		$previous_due=$_REQUEST['cus_last_due'];
		$user_id=$_SESSION['USER_ID'];
		$com_id=($_SESSION['COM_ID']);
		
		
		
		if($tk_type==0){
			//if($tk_remarks==""){
				$tk_remarks.="[ বাকি প্রদান অথবা Adjustment(+) ]-$payment_type";
			//}
			//echo dueTblUpdate($cus_id,$adjust_tk,0,$tk_remarks,'0');
			$conn->query("insert into transaction(cus_id,com_id,amount,status,remarks,insert_by,transaction_type,method_name) values($cus_id,$com_id,'$adjust_tk',$tk_type,'$tk_remarks',$user_id,'0','$payment_type')");
			echo $conn->query("insert into update_due(cus_id,com_id,last_due) values($cus_id,$com_id,(select ud.last_due+$adjust_tk from update_due ud where ud.com_id=$com_id and ud.cus_id=$cus_id and ud.is_active=1 order by ud.id desc limit 0,1))");
		}else{
			if(payToSms()==1){ //for offline
				
				if(check_internet_connection()==1){
					$mobiles=$cus_mobile;
					$response = file_get_contents($_SESSION['API']."api/data.php?com_id=$com_id&previous_due=$previous_due&paytxt=$adjust_tk&mobiles=$mobiles&chk=13"); //chk=5 means dv date update sms
					$json = json_decode($response, true);
					
				}
			}
			
				$tk_remarks.="[ $hscus_name এর বাকি গ্রহণ  অথবা Adjustment(=) ]-$payment_type";
			
			echo dueTblUpdate($cus_id,$adjust_tk,1,$tk_remarks,1); // 1= due receive from cus from due adjustment panel 
		}	
	}
	
	if(isset($_REQUEST['getLastResult'])){
		$cus_id=$_REQUEST['cus_id'];
		@$days=$_REQUEST['days'];
		if($days==""){
			$days=24;
		}
		$com_id=($_SESSION['COM_ID']);
		$last_closing=$conn->query("SELECT tt.`last_due`,date(tt.insert_date) closing_date FROM `update_due` tt WHERE date(tt.`insert_date`)=(select date(`insert_date`) FROM `transaction` WHERE `is_active`=1 and `cus_id`=$cus_id and `com_id`=$com_id order by id desc limit $days,1) and tt.cus_id=$cus_id and tt.com_id=$com_id order by tt.id desc limit 0,1");
		$last_details=$conn->query("SELECT id,amount,date(insert_date) dates,remarks,status,(select user_name from user where id=transaction.insert_by) insert_by FROM `transaction` WHERE `is_active`=1 and `cus_id`=$cus_id and `com_id`=$com_id and date(`insert_date`)>(SELECT date(tt.`insert_date`) FROM `transaction` tt WHERE tt.`is_active`=1 and tt.`cus_id`=$cus_id and tt.`com_id`=$com_id order by tt.id desc limit $days,1)");
		
		$i=1;
		$close_due=0;
		if(mysqli_num_rows($last_closing)>0){
		$close=mysqli_fetch_array($last_closing);
		?>
		<tr style="background: #f5d433;">
			<td style="text-align:center">***</td>
			<td><?php echo Converter::en2bn($close['closing_date']); ?></td>
			<td style="text-align: right;font-weight:bold"><?php echo Converter::en2bn($close_due=$close['last_due']); ?></td>
			<td style="font-weight:bold">Total Due of last closing</td>
			<td></td>
		</tr>
		<?php 
		}else{
			$last_details=$conn->query("SELECT id,amount,date(insert_date) dates,remarks,status,(select user_name from user where id=transaction.insert_by) insert_by FROM `transaction` WHERE `is_active` in(0,1) and `cus_id`=$cus_id and `com_id`=$com_id");	
		}
		mysqli_close($conn);
		$sl=1;$status="";
		date_default_timezone_set("Asia/Dhaka");
		$date=date("Y-m-d");
		if(mysqli_num_rows($last_details)>0){
			while($rows=mysqli_fetch_array($last_details)){
				$sl=$i++;
				if($rows['status']==0){
					$status="+";
					$close_due+=$rows['amount'];
				}else{
					$status="-";
					$close_due-=$rows['amount'];
				}
				?>
				<tr id="delete_row<?php echo $sl; ?>">
					<td style="text-align:center">
					<?php 
					if($date==$rows['dates']){
					?>
					<button onclick="delCustomerDue('<?php echo $rows['amount']; ?>','<?php echo $rows['id']; ?>','<?php echo $sl; ?>','<?php echo $rows['status']; ?>')" class="btn btn-danger form-control" id="delbtn<?php echo $sl; ?>">
					<?php echo $sl; ?>
					</button>
					<?php }else{
						echo $sl;
					} ?>
					</td>
					<td><?php echo Converter::en2bn($rows['dates']); ?></td>
					<td style="text-align: right;font-weight:bold"><?php echo Converter::en2bn($status.$rows['amount']); ?></td>
					<td><?php echo $rows['remarks']; ?></td>
					<td><?php echo $rows['insert_by']; ?></td>
				</tr>
				<?php 
			}
			?>
			<tr>
				<input type="hidden" value="<?php echo (@$close_due=="")? 0 : @$close_due; ?>" id="cus_last_due"/>
				<td colspan="2" style="text-align:right;font-weight: bold;">সর্বমোট বাকি :</td>
				<td style="text-align: right;font-weight: bold;">=<?php echo Converter::en2bn($close_due); ?></td>
			</tr>
			<?php 
		}else{
			echo "";
		}
					
	}
	
	if(isset($_REQUEST['searhMobileNumber'])){
		$src_cus_mobile=$_REQUEST['src_cus_mobile'];
		$com_id=($_SESSION['COM_ID']);
		if($src_cus_mobile!=""){
			$emp_info=$conn->query("SELECT c.id,c.cus_name,c.cus_mobile,c.cus_address,(select last_due from update_due where cus_id=c.id and is_active=1 order by id desc limit 0,1) due_amount FROM `customer` c WHERE c.com_id=$com_id and c.is_active=1 and (c.cus_mobile like '%$src_cus_mobile%' or c.cus_name like '%$src_cus_mobile%')");
			mysqli_close($conn);
			$i=1;
			if(mysqli_num_rows($emp_info)>0){
				while($rows=mysqli_fetch_array($emp_info)){
					$tbl_id=$rows['id'];
					$sl=$i++;
					?>
					<tr>
						<td><?php echo $sl; ?></td>
						<td><input type="text" class="form-control" autocomplete="off" id="cus_name<?php echo $tbl_id; ?>" onkeyup="setAddress('<?php echo $tbl_id; ?>','1');" value="<?php echo @$rows['cus_name']; ?>" /></td>
						<td><?php echo $rows['cus_mobile']; ?></td>
						<td><input type="text" class="form-control" autocomplete="off" id="cus_address<?php echo $tbl_id; ?>" onkeyup="setAddress('<?php echo $tbl_id; ?>','2');" value="<?php echo @$rows['cus_address']; ?>" /></td>
						<td style="text-align: right;font-weight:bold"><?php echo englishToBangla($rows['due_amount']); ?>/=</td>
					</tr>
					<?php 
				}
			}else{
				echo "";
			}
		}else{
			$emp_info=$conn->query("SELECT c.id,c.cus_name,c.cus_mobile,c.cus_address,(select last_due from update_due where cus_id=c.id and is_active=1 order by id desc limit 0,1) due_amount FROM `customer` c WHERE c.com_id=$com_id and c.is_active=1 limit 0,100");
			mysqli_close($conn);
			$i=1;
			if(mysqli_num_rows($emp_info)>0){
				while($rows=mysqli_fetch_array($emp_info)){
					$tbl_id=$rows['id'];
					$sl=$i++;
					?>
					<tr>
						<td><?php echo $sl; ?></td>
						<td><input type="text" class="form-control" autocomplete="off" id="cus_name<?php echo $tbl_id; ?>" onkeyup="setAddress('<?php echo $tbl_id; ?>','1');" value="<?php echo @$rows['cus_name']; ?>" /></td>
						<td><?php echo $rows['cus_mobile']; ?></td>
						<td><input type="text" class="form-control" autocomplete="off" id="cus_address<?php echo $tbl_id; ?>" onkeyup="setAddress('<?php echo $tbl_id; ?>','2');" value="<?php echo @$rows['cus_address']; ?>" /></td>
						<td style="text-align: right;font-weight:bold"><?php echo englishToBangla($rows['due_amount']); ?>/=</td>
					</tr>
					<?php 
				}
			}else{
				echo "";
			}
			
		}
		
	}
	
	if(isset($_REQUEST['searchStockItem'])){
			$search_item_name=$_REQUEST['search_item_name'];
			$search_sort_type=$_REQUEST['search_sort_type'];
			$search_page_type=$_REQUEST['search_page_type'];
			
			$item_type=$_REQUEST['item_type'];
			$com_id=($_SESSION['COM_ID']);
		if($search_page_type==1){ // stock page area 
			$sort=" order by pp.id asc limit 0,2500";
			if($search_sort_type=="asc" || $search_sort_type=="desc"){
				$sort=" order by pp.id $search_sort_type limit 0,2500";
			}else if($search_sort_type=="qty_asc" || $search_sort_type=="qty_desc"){
				$stype=explode("_",$search_sort_type);
				$search_sort_type=$stype[1];
				$sort=" order by cast(pp.stock_qty as decimal(20,2)) $search_sort_type limit 0,2500";
			}
			if($search_item_name!=""){
				$product=$conn->query("select * from product pp where pp.is_active=2 and pp.com_id=$com_id and pp.ptype=$item_type and (pp.product_name like '%$search_item_name%' or pp.item_code like '%$search_item_name%') $sort");
				
				if(mysqli_num_rows($product)>0){
							$i=1;
								while($rows=mysqli_fetch_array($product)){
									$j=$i++;
							?>
								<tr>
									<td style="text-align:center">
										<?php 
										if($rows['stock_qty']>0){
											echo $j;
										}else{
											
											if($_SESSION['LOG_USER']=='admin'){
											?>
											<button onclick='delItem(<?php echo $rows['id']; ?>,<?php echo $j; ?>);' name='btn' id='delbtn<?php echo $j; ?>' class="btn btn-danger form-control"><?php echo $j; ?></button>
											<?php }else{
												echo $j;
											} 
										}
										?>
									</td>
									<td>
										<?php 
										if($_SESSION['LOG_USER']=='admin'){
										?>
										<input type="text" class="form-control" onkeyup="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','5');" value="<?php echo $rows['product_name']; ?>" id="product_name<?php echo $j; ?>"/>
										<?php }else{
											echo $rows['product_name'];
										} ?>
									</td>
									<?php 
									if($_SESSION['IS_STOCK']==1){ // 1=means maintain stock
									?>
									<td style="text-align:center">
									 	<?php 
										if($_SESSION['LOG_USER']=='admin'){
										?>
										<input type="text" style="text-align:center" class="form-control" onblur="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','6')" value="<?php echo $rows['item_code']; ?>" id="product_code<?php echo $j; ?>"/>
										<?php }else{
											echo $rows['item_code'];
										} ?>
									</td>
									<td style="text-align:center;font-weight:bold">
									<?php echo ($rows['stock_qty']<$_SESSION['SAFETY_STOCK'])? "<span style='color:red'>".$rows['stock_qty']."</sapn>" : $rows['stock_qty']; ?><p style="font-size:8px;color:blue"><?php echo $rows['uom']; ?></p>
									</td>
									<td style="text-align:right">
										<?php 
										if($_SESSION['LOG_USER']=='admin'){
										?>
										<input type="text" style="text-align:right;" class="form-control" onclick="clickToSelect('purchase_price<?php echo $j; ?>')" onkeyup="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','8')" value="<?php echo $rows['purchase_price']; ?>" id="purchase_price<?php echo $j; ?>"/>
										<?php }else{
										echo $rows['purchase_price']; 
										} ?>
									</td>
									<td style="text-align:right;font-weight:bold;">
									 	<?php 
										if($_SESSION['LOG_USER']=='admin'){
										?>
										<input type="text" style="text-align:right;<?php echo ($rows['avg_price']>=$rows['selling_price'])? 'color:red': ''; ?>" class="form-control" onclick="clickToSelect('selling_price<?php echo $j; ?>')" onkeyup="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','7')" value="<?php echo $rows['selling_price']; ?>" id="selling_price<?php echo $j; ?>"/>
										<?php }else{
											echo $rows['selling_price'];
										} ?>
									</td>
									<!--<td>
										<img style="width: 80px;height: 50px;" src="item_img/pant.jpg"/>
									</td>-->
									<?php } ?>
								</tr>
							<?php 
								}
								echo "<input type='hidden' value='$j' id='ilast_id'/>";
				
				}else{
					echo "<input type='hidden' value='0' id='ilast_id'/>";
				}
			}else{
				$product=$conn->query("select * from product pp where pp.is_active=2 and pp.com_id=$com_id and pp.ptype=$item_type $sort");
				
				if(mysqli_num_rows($product)>0){
							$i=1;
								while($rows=mysqli_fetch_array($product)){
									$j=$i++;
							?>
								<tr>
									<td style="text-align:center">
										<?php 
										if($rows['stock_qty']>0){
											echo $j;
										}else{
											if($_SESSION['LOG_USER']=='admin'){
											?>
											<button onclick='delItem(<?php echo $rows['id']; ?>,<?php echo $j; ?>);' name='btn' id='delbtn<?php echo $j; ?>' class="btn btn-danger form-control"><?php echo $j; ?></button>
											<?php }else{
												echo $j;
											} 
										}
										?>
									</td>
									<td>
										<?php 
										if($_SESSION['LOG_USER']=='admin'){
										?>
										<input type="text" class="form-control" onkeyup="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','5');" value="<?php echo $rows['product_name']; ?>" id="product_name<?php echo $j; ?>"/>
										<?php }else{
											echo $rows['product_name'];
										} ?>
									</td>
									<?php 
									if($_SESSION['IS_STOCK']==1){ // 1=means maintain stock
									?>
									<td style="text-align:center">
									 	<?php 
										if($_SESSION['LOG_USER']=='admin'){
										?>
										<input type="text" style="text-align:center" class="form-control" onblur="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','6')" value="<?php echo $rows['item_code']; ?>" id="product_code<?php echo $j; ?>"/>
										<?php }else{
											echo $rows['item_code'];
										} ?>
									</td>
									<td style="text-align:center;font-weight:bold">
									<?php echo ($rows['stock_qty']<$_SESSION['SAFETY_STOCK'])? "<span style='color:red'>".$rows['stock_qty']."</sapn>" : $rows['stock_qty']; ?><p style="font-size:8px;color:blue"><?php echo $rows['uom']; ?></p>
									</td>
									<td style="text-align:right">
									<?php 
										if($_SESSION['LOG_USER']=='admin'){
										?>
										<input type="text" style="text-align:right;font-weight:bold;" class="form-control" onclick="clickToSelect('purchase_price<?php echo $j; ?>')" onkeyup="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','8')" value="<?php echo $rows['purchase_price']; ?>" id="selling_price<?php echo $j; ?>"/>
										<?php }else{
											echo $rows['purchase_price'];
										} ?>
									</td>
									<td style="text-align:right;font-weight:bold;">
									 	<?php 
										if($_SESSION['LOG_USER']=='admin'){
										?>
										<input type="text" style="text-align:right;font-weight:bold;<?php echo ($rows['avg_price']>=$rows['selling_price'])? 'color:red': ''; ?>" class="form-control" onclick="clickToSelect('selling_price<?php echo $j; ?>')" onkeyup="setCusPrice('<?php echo $j; ?>','<?php echo $rows['id']; ?>','7')" value="<?php echo $rows['selling_price']; ?>" id="selling_price<?php echo $j; ?>"/>
										<?php }else{
											echo $rows['selling_price'];
										} ?>
									</td>
									<!--<td>
										<img style="width: 80px;height: 50px;" src="item_img/pant.jpg"/>
									</td>-->
									<?php } ?>
								</tr>
							<?php 
								}
								echo "<input type='hidden' value='$j' id='ilast_id'/>";
				
				}else{
					echo "<input type='hidden' value='0' id='ilast_id'/>";
				}
			}
			
		}else if($search_page_type==2){ //in stock area
			$tqty=0;$ttaka=0;
			$condition="";
			$sort=" order by ds.id desc limit 0,1000";
			if($search_sort_type=="asc" || $search_sort_type=="desc"){
				$sort=" order by ds.id $search_sort_type limit 0,1000";
			}else if($search_sort_type=="qty_asc" || $search_sort_type=="qty_desc"){
				$stype=explode("_",$search_sort_type);
				$search_sort_type=$stype[1];
				$sort=" order by cast(ds.item_qty as decimal(20,2)) $search_sort_type limit 0,1000";
			}
			@$date3=$_REQUEST['date3'];
			if($date3!=""){
				$condition=" and date(ds.insert_date)='$date3'";
			}
			if($search_item_name!=""){
				$product=$conn->query("select pp.id,
				pp.product_name item_name,
				pp.item_code,
				pp.uom item_unit,
				ds.dstid direct_salse_head_id,
				ds.item_id,
				ds.item_qty,
				ds.price,
				(select cus_mobile from direct_sale_head where id=ds.dstid) supplier_mobile,
				ds.insert_date
				from product pp,direct_sale ds where ds.item_id=pp.id and ds.in_out_status=1 and ds.com_id=$com_id and pp.is_active=2 and (pp.product_name like '%$search_item_name%' or pp.item_code like '%$search_item_name%') $condition $sort");
				
				if(mysqli_num_rows($product)>0){
							$i=1;
								while($rows=mysqli_fetch_array($product)){
									$j=$i++;
									$tqty+=$rows['item_qty'];
									$ttaka+=round(($rows['item_qty']*$rows['price']),2);
									$tprice_row=round(($rows['item_qty']*$rows['price']),2);
									
								$tprice_row=round(($rows['item_qty']*$rows['price']),2);
								$tbl_id=$rows['direct_salse_head_id']; // direct sales head tbl id 
								$item_qty=$rows['item_qty'];
								$item_id=$rows['item_id'];
							?>
								<tr>
									<td><button onclick="delInStockItem('<?php echo $tbl_id; ?>','<?php echo $j; ?>','<?php echo $item_qty; ?>','<?php echo $tprice_row; ?>','<?php echo $item_id; ?>');" name='btn' id='delbtn<?php echo $j; ?>' class="btn btn-danger form-control"><?php echo $j; ?></button></td>
									<td>
										<?php echo $rows['item_name']; ?><p style='font-size:9px;color:blue'><?php echo @$rows['item_code']; ?></p>
									</td>
									<td style='text-align:center'><?php echo $rows['item_qty']; ?> <p style='font-size:8px;color:blue'><?php echo @$rows['item_unit']; ?></p></td>
									<td style='text-align:right'><?php echo $rows['price']; ?></td>
									<td style='text-align:right'><?php echo round(($rows['item_qty']*$rows['price']),2); ?></td>
									<td style='text-align:center'><?php echo @$rows['supplier_mobile']; ?> <p style='font-size:9px;color:green'><?php echo @$rows['insert_date']; ?></p></td>
								</tr>
							<?php 
								}
								?>
								<tr>
									<td colspan="2" style="text-align: right;font-weight: bold;">
										Total Qty: 
									</td>
									<td style="text-align: center;font-weight: bold;">
										<?php echo $tqty; ?>
									</td>
									<td style="text-align: right;font-weight: bold;">
										Total: 
									</td>
									<td style="text-align: right;font-weight: bold;">
										<?php echo $ttaka; ?>
									</td>
								</tr>
								<?php 
								echo "<input type='hidden' value='$j' id='ilast_id'/>";
				
				}else{
					echo "<input type='hidden' value='0' id='ilast_id'/>";
				}
			}else{
				$product=$conn->query("select pp.id,pp.product_name item_name,pp.item_code,pp.uom item_unit,ds.item_qty,ds.price,(select cus_mobile from direct_sale_head where id=ds.dstid) supplier_mobile,ds.insert_date from product pp,direct_sale ds where ds.item_id=pp.id and ds.in_out_status=1 and ds.com_id=$com_id and pp.is_active=2 and (pp.product_name like '%$search_item_name%' or pp.item_code like '%$search_item_name%') $condition $sort");
				
				if(mysqli_num_rows($product)>0){
							$i=1;
								while($rows=mysqli_fetch_array($product)){
									$j=$i++;
									$tqty+=$rows['item_qty'];
									$ttaka+=round(($rows['item_qty']*$rows['price']),2);
							?>
								<tr>
									<td><button onclick='delItem(<?php echo $rows['id']; ?>,<?php echo $j; ?>);' name='btn' id='delbtn<?php echo $j; ?>' class="btn btn-danger form-control"><?php echo $j; ?></button></td>
									<td>
										<?php echo $rows['item_name']; ?><p style='font-size:9px;color:blue'><?php echo @$rows['item_code']; ?></p>
									</td>
									<td style='text-align:center'><?php echo $rows['item_qty']; ?> <p style='font-size:8px;color:blue'><?php echo @$rows['item_unit']; ?></p></td>
									<td style='text-align:right'><?php echo $rows['price']; ?></td>
									<td style='text-align:right'><?php echo round(($rows['item_qty']*$rows['price']),2); ?></td>
									<td style='text-align:center'><?php echo @$rows['supplier_mobile']; ?> <p style='font-size:9px;color:green'><?php echo @$rows['insert_date']; ?></p></td>
								</tr>
							<?php 
								}
								?>
								<tr>
									<td colspan="2" style="text-align: right;font-weight: bold;">
										Total Qty: 
									</td>
									<td style="text-align: center;font-weight: bold;">
										<?php echo $tqty; ?>
									</td>
									<td style="text-align: right;font-weight: bold;">
										Total: 
									</td>
									<td style="text-align: right;font-weight: bold;">
										<?php echo $ttaka; ?>
									</td>
								</tr>
								<?php 
								echo "<input type='hidden' value='$j' id='ilast_id'/>";
				
				}else{
					echo "<input type='hidden' value='0' id='ilast_id'/>";
				}
			}
		}else if($search_page_type==3){ //in stock Adjustment area 
			$tqty=0;$ttaka=0;
			$condition="";
			$sort=" order by ds.id desc limit 0,100";
			if($search_sort_type=="asc" || $search_sort_type=="desc"){
				$sort=" order by ds.id $search_sort_type limit 0,100";
			}else if($search_sort_type=="qty_asc" || $search_sort_type=="qty_desc"){
				$stype=explode("_",$search_sort_type);
				$search_sort_type=$stype[1];
				$sort=" order by cast(ds.adjustment_qty as decimal(20,2)) $search_sort_type limit 0,100";
			}
			@$date3=$_REQUEST['date3'];
			if($date3!=""){
				$condition=" and date(ds.insert_date)='$date3'";
			}
			if($search_item_name!=""){
				
				$product=$conn->query("select pp.id,pp.product_name item_name,pp.item_code,pp.uom item_unit,ds.remarks,ds.adjustment_qty,ds.insert_date,(select user_name from user where id=ds.insert_by) adjust_by from product pp,stock_adjustment ds where ds.item_id=pp.id and ds.is_active=1 and pp.is_active=2 and (pp.product_name like '%$search_item_name%' or pp.item_code like '%$search_item_name%') $condition $sort");
				
				if(mysqli_num_rows($product)>0){
							$i=1;
								while($rows=mysqli_fetch_array($product)){
									$j=$i++;
							?>
							<tr>
								<td style='text-align:center'>
									<?php echo $j; ?><!--<button onclick='delItem(<?php echo $rows['id']; ?>,<?php echo $j; ?>);' name='btn' id='delbtn<?php echo $j; ?>' class="btn btn-danger form-control"><?php echo $j; ?></button>--></td>
								<td>
									<?php echo $rows['item_name']; ?><p style='font-size:9px;color:blue'><?php echo @$rows['item_code']; ?></p>
								</td>
								<td style='text-align:center'><?php echo $rows['adjustment_qty']; ?> <p style='font-size:8px;color:blue'><?php echo @$rows['item_unit']; ?></p></td>
								<td style='text-align:center'><?php echo $rows['remarks']; ?></td>
								<td style='text-align:center'><?php echo @$rows['adjust_by']; ?> <p style='font-size:9px;color:green'><?php echo @$rows['insert_date']; ?></p></td>
							</tr>
							<?php 
								}
								
								echo "<input type='hidden' value='$j' id='ilast_id'/>";
				
				}else{
					echo "<input type='hidden' value='0' id='ilast_id'/>";
				}
			}else{
				$product=$conn->query("select pp.id,pp.product_name item_name,pp.item_code,pp.uom item_unit,ds.remarks,ds.adjustment_qty,ds.insert_date,(select user_name from user where id=ds.insert_by) adjust_by from product pp,stock_adjustment ds where ds.item_id=pp.id and ds.is_active=1 and pp.is_active=2 and (pp.product_name like '%$search_item_name%' or pp.item_code like '%$search_item_name%') $condition $sort");
				
				if(mysqli_num_rows($product)>0){
							$i=1;
								while($rows=mysqli_fetch_array($product)){
									$j=$i++;
							?>
							<tr>
								<td style='text-align:center'>
									<?php echo $j; ?><!--<button onclick='delItem(<?php echo $rows['id']; ?>,<?php echo $j; ?>);' name='btn' id='delbtn<?php echo $j; ?>' class="btn btn-danger form-control"><?php echo $j; ?></button>--></td>
								<td>
									<?php echo $rows['item_name']; ?><p style='font-size:9px;color:blue'><?php echo @$rows['item_code']; ?></p>
								</td>
								<td style='text-align:center'><?php echo $rows['adjustment_qty']; ?> <p style='font-size:8px;color:blue'><?php echo @$rows['item_unit']; ?></p></td>
								<td style='text-align:center'><?php echo $rows['remarks']; ?></td>
								<td style='text-align:center'><?php echo @$rows['adjust_by']; ?> <p style='font-size:9px;color:green'><?php echo @$rows['insert_date']; ?></p></td>
							</tr>
							<?php 
								}
								
								echo "<input type='hidden' value='$j' id='ilast_id'/>";
				
				}else{
					echo "<input type='hidden' value='0' id='ilast_id'/>";
				}
			}
		}
		
		
	}
	
	if(isset($_REQUEST['autoCompleteMobile'])){
		$src_cus_mobile=$_REQUEST['mobile'];
		$com_id=($_SESSION['COM_ID']);
		$emp_info=$conn->query("SELECT c.id,c.cus_mobile,c.cus_name,(select sum(point) from point_tbl where is_active=1 and cus_id=c.id) getpoint FROM `customer` c WHERE c.com_id=$com_id and c.is_active=1 and c.cus_mobile like '%$src_cus_mobile%' limit 0,12");
			mysqli_close($conn);
			$i=1;
			if(mysqli_num_rows($emp_info)>0){
				
				while($rows=mysqli_fetch_array($emp_info)){
					$tbl_id=$rows['id'];
					$sl=$i++;
					?>
					<a style="text-decoration:none" href="javascript:void(0)"><p onclick="setMobileNumber('<?php echo $rows['cus_mobile']; ?>','<?php echo $rows['cus_name']; ?>','<?php echo $tbl_id; ?>','<?php echo $rows['getpoint']; ?>');" style="    color: #347909fc;
    border: 1px solid #8e898942;
    background: white;
    padding-left: 10px;
    cursor: pointer;
    margin-bottom: 0px !important;
    font-style: italic;
    font-weight: bold;
    border-radius: 5px;
    padding: 5px 3px 6px 10px;
    line-height: 16px;"><?php echo $rows['cus_mobile']; ?><br/><?php echo $rows['cus_name']; ?></p></a>
					<?php 
				}
				
			}else{
				echo "";
			}
	}
	
	if(isset($_REQUEST['autoCompleteMobileSearchable'])){ // editable searching 
		$src_cus_mobile=$_REQUEST['mobile'];
		$com_id=($_SESSION['COM_ID']);
		if($_REQUEST['chk_searchable_number']==1){ // order number 
			$src_cus_mobile=strtoupper($src_cus_mobile);
			$emp_info=$conn->query("SELECT c.id,dss.phy_ord_num as cus_mobile,c.cus_name FROM `customer` c,dsms dss WHERE c.cus_mobile=dss.cus_mobile and c.com_id=$com_id and c.is_active=1 and dss.phy_ord_num like '%$src_cus_mobile%' limit 0,12");
		}
		if($_REQUEST['chk_searchable_number']==2){ // mobile number 
			$emp_info=$conn->query("SELECT distinct(c.cus_mobile) cus_mobile,c.id,c.cus_name FROM `customer` c WHERE c.com_id=$com_id and c.is_active=1 and c.cus_mobile like '%$src_cus_mobile%' limit 0,12");
		}
		
			mysqli_close($conn);
			$i=1;
			if(mysqli_num_rows($emp_info)>0){
				
				while($rows=mysqli_fetch_array($emp_info)){
					$tbl_id=$rows['id'];
					$sl=$i++;
					?>
					<a style="text-decoration:none" href="javascript:void(0)"><p onclick="srchByMobileNum('<?php echo $rows['cus_mobile']; ?>');" style="color: #347909fc;
						border: 1px solid #8e898942;
						background: white;
						padding-left: 10px;
						cursor: pointer;
						margin-bottom: 0px !important;
						font-style: italic;
						font-weight: bold;
						border-radius: 5px;
						padding: 5px 3px 6px 10px;
						line-height: 16px;"><?php echo $rows['cus_mobile']; ?><br/><?php echo $rows['cus_name']; ?></p></a>
					<?php 
				}
				
			}else{
				echo "";
			}
	}
	
	if(isset($_REQUEST['autoCompleteMobileSearchableForJob'])){ // editable searching 
		$src_cus_mobile=$_REQUEST['mobile'];
		$com_id=($_SESSION['COM_ID']);
		if($_REQUEST['chk_searchable_number']==1){ // order number 
			$src_cus_mobile=strtoupper($src_cus_mobile);
			$emp_info=$conn->query("SELECT c.id,dss.phy_ord_num as cus_mobile,c.cus_name FROM `customer` c,dsms dss WHERE c.cus_mobile=dss.cus_mobile and c.com_id=$com_id and c.is_active=1 and dss.phy_ord_num like '%$src_cus_mobile%' limit 0,12");
		}
		if($_REQUEST['chk_searchable_number']==2){ // mobile number 
			$emp_info=$conn->query("SELECT distinct(c.cus_mobile) cus_mobile,c.id,c.cus_name FROM `customer` c WHERE c.com_id=$com_id and c.is_active=1 and c.cus_mobile like '%$src_cus_mobile%' limit 0,12");
		}
		
			mysqli_close($conn);
			$i=1;
			if(mysqli_num_rows($emp_info)>0){
				
				while($rows=mysqli_fetch_array($emp_info)){
					$tbl_id=$rows['id'];
					$sl=$i++;
					?>
					<a style="text-decoration:none" href="javascript:void(0)"><p onclick="srchForOrdDetails('<?php echo $rows['cus_mobile']; ?>');" style="color: #347909fc;
						border: 1px solid #8e898942;
						background: white;
						padding-left: 10px;
						cursor: pointer;
						margin-bottom: 0px !important;
						font-style: italic;
						font-weight: bold;
						border-radius: 5px;
						padding: 5px 3px 6px 10px;
						line-height: 16px;"><?php echo $rows['cus_mobile']; ?><br/><?php echo $rows['cus_name']; ?></p></a>
					<?php 
				}
				
			}else{
				echo "";
			}
	}
	
	if(isset($_REQUEST['seaMoreCustomer'])){
		$last_id=trim($_REQUEST['last_id']);
		$com_id=$_SESSION['COM_ID'];
		$i=$last_id+1;
		$emp_info=$conn->query("SELECT c.id,c.cus_name,c.cus_mobile,c.cus_address,(select last_due from update_due where cus_id=c.id and is_active=1 order by id desc limit 0,1) due_amount FROM `customer` c WHERE c.com_id=$com_id and c.is_active=1 limit  $last_id,100");
			mysqli_close($conn);
			$tot_emp=mysqli_num_rows($emp_info);
			
			$total_tk=0;
			if($tot_emp>0){
				while($rows=mysqli_fetch_array($emp_info)){
					$tbl_id=$rows['id'];
					$sl=$i++;
					$total_tk+=$rows['due_amount'];
					?>
					<tr>
						<td>
						<?php 
						if(@$rows['due_amount']=="" || $rows['due_amount']==0){
						?>
						<button onclick="delCustomer('<?php echo $tbl_id; ?>','<?php echo $sl; ?>')" class="btn btn-danger form-control" id="delbtn<?php echo $sl; ?>"><?php echo $sl; ?></button>
						<?php }else{
							echo $sl;
						} ?>
						</td>
						<td><input type="text" class="form-control" autocomplete="off" id="cus_name<?php echo $tbl_id; ?>" onkeyup="setAddress('<?php echo $tbl_id; ?>','1');" value="<?php echo @$rows['cus_name']; ?>" /></td>
						<td><?php echo $rows['cus_mobile']; ?></td>
						<td><input type="text" class="form-control" autocomplete="off" id="cus_address<?php echo $tbl_id; ?>" onkeyup="setAddress('<?php echo $tbl_id; ?>','2');" value="<?php echo @$rows['cus_address']; ?>" /></td>
						<td style="text-align: right;font-weight:bold"><?php echo englishToBangla($rows['due_amount'])."/="; ?></td>
					</tr>
					
					<?php 
				}
			}else{
				echo 2;
			}
					
	}
	
	if(isset($_REQUEST['saveRentInfo'])){
		$rent_item=trim($_REQUEST['rent_item']);
		$item_details=trim($_REQUEST['item_details']);
		$emp_info=$conn->query("insert into product(product_name,description,is_active) values('$rent_item','$item_details','4')");
		if($emp_info){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['showRentItem'])){
		$emp_info=$conn->query("SELECT * FROM `product` c WHERE c.is_active=4 order by id desc limit 0,100");
			mysqli_close($conn);
			$tot_emp=mysqli_num_rows($emp_info);
			
			if($tot_emp>0){
				$sl=1;
				while($rows=mysqli_fetch_array($emp_info)){
					
					?>
					<tr>
						<td style="text-align:center"><?php echo $sl++;?></td>
						<td><?php echo @$rows['product_name']; ?></td>
						<td><?php echo @$rows['description']; ?></td>
					</tr>
					<?php 
				}
			}else{
				echo 2;
			}
		
	}
	
	if(isset($_REQUEST['addRentItem'])){
		?>
		<div class="row">
				<div class="col-xs-12 col-sm-5">
					<label for="comment" class="txt_color">Item Name:</label>
					<input type="text" class="form-control" autocomplete="off" maxlength="100" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_name" id="rent_items" />
				</div>
				<div class="col-xs-12 col-sm-7">
					<label for="comment" class="txt_color">Description:</label>
					<input type="text" class="form-control" autocomplete="off" maxlength="200" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_name" id="item_details" />
				</div>
				<div class="col-xs-12 col-sm-5">
					<button onclick="saveRentInfo();" style="margin-top: 12px;margin-right:5px" name="btn" value="sub" class="btn btn-success">Save</button>
					<span id="rent_sms" style="color:green;font-weight:bold"></span>
				</div>
		</div>
		<div class="row">
				<div class="col-xs-12 col-sm-12">
					<table id="myTable3" class="table table-striped table-bordered table-hover">
						<thead>
							<thead>
							<tr style="background: aquamarine;">
								<th style="width: 6%;text-align:center">Sl</th>
								<th style="width: 40%;text-align:center">Item Name</th>
								<th style="width: 54%;">Description</th>
							</tr>
						</thead>
						<tbody id="rent_tbl">
						</tbody>
						
					</table>
				</div>
		</div>
	<?php 
	}
	
	if(isset($_REQUEST['onlyBoxUpdateBtn'])){
		$box_number=trim($_REQUEST['box_number']);
		$order_number=trim($_REQUEST['order_number']);
		$com_id=($_SESSION['COM_ID']);
		$update_box_num=$conn->query("update dsms set box_number='$box_number' WHERE phy_ord_num='$order_number'");
			mysqli_close($conn);
			$i=1;
			if($update_box_num){
				echo 2;
			}else{
				echo "";
			}
	}
	
	if(isset($_REQUEST['autoCompleteMobile2'])){
		$src_cus_mobile=$_REQUEST['mobile'];
		$com_id=($_SESSION['COM_ID']);
		$emp_info=$conn->query("SELECT * FROM `customer` WHERE com_id=$com_id and is_active=1 and (cus_mobile like '%$src_cus_mobile%' or cus_name like '%$src_cus_mobile%') limit 0,12");
			mysqli_close($conn);
			$i=1;
			if(mysqli_num_rows($emp_info)>0){
				
				while($rows=mysqli_fetch_array($emp_info)){
					$tbl_id=$rows['id'];
					$sl=$i++;
					?>
					<a style="text-decoration:none" href="javascript:void(0)"><p onclick="setMobileNumber('<?php echo $rows['cus_mobile']; ?>','<?php echo $rows['cus_name']; ?>','<?php echo $tbl_id; ?>');" style="    color: #347909fc;
    border: 1px solid #8e898942;
    background: white;
    padding-left: 10px;
    cursor: pointer;
    margin-bottom: 0px !important;
    font-style: italic;
    font-weight: bold;
    border-radius: 5px;
    padding: 5px 3px 6px 10px;
    line-height: 16px;"><?php echo $rows['cus_mobile']; ?><br/><?php echo $rows['cus_name']; ?></p></a>
					<?php 
				}
				
			}else{
				echo "";
			}
	}
	
	if(isset($_REQUEST['previousDuePayable'])){
		$remarks="পূর্বের বাকি পরিশোধ";
		echo dueTblUpdate(getCustomerId($_REQUEST['mobile']),$_REQUEST['previous_due_payable'],1,$remarks,'3'); // 3= from order form due receive 
	}
	
	if(isset($_REQUEST['searchYearlyOrder'])){
		$com_id=($_SESSION['COM_ID']);
		$year=$_REQUEST['year'];
		$order_details=$conn->query("SELECT * FROM `feg_order` WHERE com_id=$com_id and year='$year' order by id desc limit 0,1");
		$rows=mysqli_fetch_array($order_details);
		echo $rows['order_qty'];
	}
	
	if(isset($_REQUEST['showDetailYearlyOrder'])){
		
		$com_id=($_SESSION['COM_ID']);
		$horder=$_REQUEST['horder'];
		$year=$_REQUEST['year'];
		$order_details=$conn->query("SELECT * FROM `dsms` WHERE is_active=1 and com_id=$com_id and year(insert_date)='$year' order by id desc limit 0,$horder");
		?>
		<p>Order Details</p>
		<table id="example" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>SL</th>
						<th>Order Number</th>
					</tr>
				</thead>
		<tbody id="">
		<?php 
			$i=0;
			while($row=mysqli_fetch_array($order_details)){
				?>
					<tr>
						<td>
							<?php echo ++$i; ?>
						</td>
						<th><?php echo $row['phy_ord_num']; ?></th>
					</tr>
				<?php 
			}
		
		?>
					
		</tbody>
		</table>
		<?php 
	}
	
	
	if(isset($_REQUEST['getSelectHead'])){
		$com_id=($_SESSION['COM_ID']);
		$item_type=$_REQUEST['item_type'];
		$ex=explode("#sep#",$_REQUEST['item_id']);
		$group_id=$ex[1];
		$order_details=$conn->query("SELECT * FROM `measurement_head` WHERE group_id=$group_id and ptype=$item_type and mtype=2 and is_active=1");
		if(mysqli_num_rows($order_details)>0){
			echo '<option value="">Select One</option>';
			while($rows=mysqli_fetch_array($order_details)){
				?>
				<option value='<?php echo $rows['title']; ?>'><?php echo $rows['title']; ?></option>
				<?php 
			}
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['setEmployee'])){
		$com_id=($_SESSION['COM_ID']);
		$userid=$_REQUEST['userid'];
		$user_type=$_REQUEST['user_type'];
		$sl=$_REQUEST['sl'];
		$order_num_id=$_REQUEST['order_num_id'];
		$order_details=$conn->query("SELECT * FROM `user` WHERE com_id=$com_id and emp_type=$user_type and is_active=1");
		if(mysqli_num_rows($order_details)>0){
			if($user_type==2){ //for karigor
			?>
			<select id="get_select_karigor<?php echo $sl; ?>" onchange="changeUser(<?php echo $sl; ?>,'<?php echo $order_num_id; ?>',<?php echo $userid; ?>);" style="" class="form-control">
			<option value="">Select One</option>
			<?php 
			while($rows=mysqli_fetch_array($order_details)){
				if($rows['id']==$userid){
					$slect="selected";
				}else{
					$slect="";
				}
				?>
				<option <?php echo $slect; ?> value='<?php echo $rows['id']."#sep#".$rows['user_name']; ?>'><?php echo $rows['user_name']; ?></option>
				<?php 
			}
			?>
			</select>
			<?php 
			}
		
		
		if($user_type==1){ //for master
			?>
			<select id="get_select_master<?php echo $sl; ?>" onchange="changeUser2(<?php echo $sl; ?>,'<?php echo $order_num_id; ?>',<?php echo $userid; ?>);" style="" class="form-control">
			<option value="">Select One</option>
			<?php 
			while($rows=mysqli_fetch_array($order_details)){
				if($rows['id']==$userid){
					$slect="selected";
				}else{
					$slect="";
				}
				?>
				<option <?php echo $slect; ?> value='<?php echo $rows['id']."#sep#".$rows['user_name']; ?>'><?php echo $rows['user_name']; ?></option>
				<?php 
			}
			?>
			</select>
			<?php 
			}
		
		}
	}
	
	if(isset($_REQUEST['searchExpense'])){
		date_default_timezone_set("Asia/Dhaka");
		@$srcdate=$_REQUEST['srcdate'];
		$com_id=($_SESSION['COM_ID']);
		$date=date("Y-m-d");
		if($srcdate!=""){
			$ex=explode("/",$srcdate);
			if(count($ex)==3){
			$srcdate=$ex[2]."-".$ex[1]."-".$ex[0];
			}else{
				$srcdate="";
			}
			$expense_detail=$conn->query("SELECT  ex.id,ex.expense_type,date(ex.insert_date) indate,ex.expense,ex.remarks,(select expense from expense_type where id=ex.expense_type) ex_title  FROM `expenses` ex WHERE ex.com_id=$com_id and date(ex.insert_date)='$srcdate' and ex.is_active=1 order by ex.id desc");
		}else{
			$expense_detail=$conn->query("SELECT  ex.id,ex.expense_type,ex.expense,ex.remarks,(select expense from expense_type where id=ex.expense_type) ex_title  from expenses ex where ex.com_id=$com_id and date(ex.insert_date)='$date' and ex.is_active=1 order by ex.id desc");
		}
		if(mysqli_num_rows($expense_detail)>0){
		?>
		<?php 
			$sl=0;$i=1;
			if(mysqli_num_rows($expense_detail)>0){
				while($row=mysqli_fetch_array($expense_detail)){
					$sl=$i++;
					$tbl_id=$row['id'];
					?>
					<tr id="delrow<?php echo $tbl_id; ?>">
					<td style="text-align:center">
					<?php 
						if($date==$row['indate']){
					?>
					<button onclick="delExpense('<?php echo $tbl_id; ?>','<?php echo $sl; ?>')" class="btn btn-danger form-control" id="delExbtn<?php echo $sl; ?>"><?php echo $sl; ?></button>
					<?php }else{
						echo $sl;
					} ?>
					</td>
					<td><?php echo $row['ex_title']; ?></td>
					<td><?php echo $row['remarks']; ?></td>
					<td style="text-align:right"><?php echo $row['expense'] ?></td>
					</tr>
					<?php 
				}
			}
		?>
					
		<?php 
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['salesReturnOption'])){
		date_default_timezone_set("Asia/Dhaka");
		@$srcdate=$_REQUEST['srcdate'];
		$com_id=($_SESSION['COM_ID']);
		$date=date("Y-m-d");
		if($srcdate!=""){
			$ex=explode("/",$srcdate);
			if(count($ex)==3){
			$srcdate=$ex[2]."-".$ex[1]."-".$ex[0];
			}else{
				$srcdate="";
			}
			$sales_details=$conn->query("SELECT id,cus_mobile,insert_date,f_total,others_tk,discount_tk,(select order_number from direct_sale where dstid=direct_sale_head.id and is_active=1 limit 0,1) ord_num FROM `direct_sale_head` WHERE com_id=$com_id and date(insert_date)='$srcdate' and is_active!=0 and in_out_status=0 order by id desc");
		}else{
			$sales_details=$conn->query("SELECT id,cus_mobile,insert_date,f_total,others_tk,discount_tk,(select order_number from direct_sale where dstid=direct_sale_head.id and is_active=1 limit 0,1) ord_num FROM `direct_sale_head` WHERE com_id=$com_id and date(insert_date)='$date' and is_active!=0 and in_out_status=0 order by id desc");
		}
		if(mysqli_num_rows($sales_details)>0){
		?>
			<table id="example" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>SL</th>
						<th>Order No</th>
						<th>Mobile</th>
						<th>Sales Date</th>
						<th style="text-align:right">Net Total</th>
						<th style="text-align:right">Others(Tk)</th>
						<th style="text-align:right">discount(Tk)</th>
						<th style="text-align:right">Total(Tk)</th>
					</tr>
				</thead>
				<tbody id="tbl_two2">
					<?php 
						$i=1;$ttk=0;$others=0;$total=0;$gtotal=0;
						while($row=mysqli_fetch_array($sales_details)){
							$ttk=$row['f_total'];
							$others=$row['others_tk'];
							$discount=$row['discount_tk'];
							$total=($ttk+$others)-$discount;
							$gtotal+=$total;
							?>
								<tr>
									<td>
										<button onclick="showDetailSales('<?php echo $row['id']; ?>');" name="btn" value="sub" class="btn btn-success form-control"><?php echo $row['id'];//$i++; ?></button>
									</td>
									<th><?php echo $row['ord_num']; ?></th>
									<th><?php echo $row['cus_mobile']; ?></th>
									<th><?php echo $row['insert_date']; ?></th>
									<th style="text-align:right"><?php echo $ttk; ?></th>
									<th style="text-align:right"><?php echo $others; ?></th>
									<th style="text-align:right"><?php echo $discount; ?></th>
									<th style="text-align:right"><?php echo $total; ?></th>
								</tr>
							<?php 
						}
					
					?>
					<tr>
						<th colspan="7" style="text-align:right">Total: </th>
						<th style="text-align:right"><?php echo $gtotal; ?></th>
					</tr>
					
				</tbody>
			</table>
		<?php 
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['showDetailSales'])){
		@$dstblid=$_REQUEST['dstblid'];
		$com_id=($_SESSION['COM_ID']);
		$sales_details=$conn->query("SELECT ds.id,ds.dstid,(select id from customer where cus_mobile=(select direct_sale_head.cus_mobile from direct_sale_head where direct_sale_head.id=ds.dstid) limit 0,1) customer_id,(select cus_mobile from direct_sale_head where direct_sale_head.id=ds.dstid) cus_mobile,(select uom from product where id=ds.item_id) item_unit,(select product_name from product where id=ds.item_id) item_name,ds.item_qty,ds.price,ds.order_number,ds.item_id FROM `direct_sale` ds WHERE ds.com_id=$com_id and ds.is_active!=0 and ds.dstid=$dstblid order by ds.id asc");
		if(mysqli_num_rows($sales_details)>0){
		?>
			<table id="example" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th style="text-align:center;width: 13%;">SL</th>
						<th>Item</th>
						<th style="text-align:center;width:15%">Qty</th>
						<th style="text-align:right">Price</th>
					</tr>
				</thead>
				<tbody id="tbl_two2">
					<?php 
						$i=1;$ttk=0;
						while($row=mysqli_fetch_array($sales_details)){
							?>
								<tr>
									<td style="text-align:center">
										<button onclick="delDetailSales('<?php echo $row['id']; ?>','<?php echo ($row['price']*$row['item_qty']); ?>','<?php echo $dstblid; ?>','<?php echo $row['order_number']; ?>','<?php echo $row['item_id']; ?>','<?php echo $row['item_qty']; ?>','<?php echo $row['cus_mobile']; ?>');" id="delid<?php echo $row['id']; ?>" name="btn" value="sub" class="btn btn-danger form-control"><?php echo $i++; ?></button>
									</td>
									<th><?php echo $row['item_name']; ?></th>
									<th style="text-align:center"><button style="width: 22%;" id="update_btn<?php echo $row['id']; ?>" onclick="updateFabQty('<?php echo $row['item_id']; ?>','<?php echo $row['item_qty']; ?>','<?php echo $row['price']; ?>','<?php echo $row['id']; ?>','<?php echo $row['dstid']; ?>','<?php echo $row['customer_id']; ?>','<?php echo $row['order_number']; ?>')">ok</button><input type="text" style="text-align: center;width: 40%;" id="edit_fab_qty<?php echo $row['id']; ?>" onkeyup="liveCheckStockQty('<?php echo $row['id']; ?>','<?php echo $row['item_id']; ?>','<?php echo $row['item_qty']; ?>');" value="<?php echo $row['item_qty']; ?>"/> <?php echo $row['item_unit']; ?></th>
									<th style="text-align:right"><?php echo ($row['price']*$row['item_qty']); ?></th>
								</tr>
							<?php 
						}
					
					?>
					
				</tbody>
			</table>
		<?php 
		}else{
			echo 2;
		}
	}
}


?>


 
 