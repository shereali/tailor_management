
<?php 
	if(isset($_SESSION['COM_ID'])){
		$com_id=$_SESSION['COM_ID'];
		$pending_order=$conn->query("SELECT ord.*,date(ord.insert_date) insert_date,(select sum(amount) from accounting where dsms_id=ord.id and is_active=1 and pay_status in(1,0)) tpay FROM `dsms` ord WHERE ord.is_active=1 and com_id=$com_id order by id desc limit 0,200");
		//$sewing_pending=$conn->query("SELECT ord.*,(ord.master_cutting_qty-ord.receive_qty) item_qtys,(select product_name from product where id=ord.item_id limit 0,1) item_name,(select cus_name from dsms where id=ord.dsms_id limit 0,1) cus_name FROM `order_record` ord WHERE ord.is_active=1 and ord.receive_qty!=ord.`master_cutting_qty` and com_id=$com_id");
		
		mysqli_close($conn);		
?>

<ul class="nav nav-tabs" style="display: none;">
	
    <li class="active"><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" href="#home">Customer</a></li>
	
   <!-- <li><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" onclick="sclick();" id="attach_tbl" href="#menu1">Order Details</a></li>
	
    <li><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" id="order_print_area" href="#menu2">Print</a></li>-->
    
</ul>

<div class="tab-content" id="tabs">
    <div id="home" class="tab-pane fade in active">
	<br/>
     
	<div class="panel-group">
		 <div id="show_history">
	  
		   <div class='panel panel-info' style="color: black; box-shadow: inset 0 0 1em gray; padding: 15px;margin-left: 0px;margin-right: 0px;">
			  <div class="panel-heading">
			  <div style="overflow:hidden">
				<input type="text" onkeyup="getCustomerList('search_ord_num');" placeholder="অর্ডার নম্বর" class="form-control" style="font-weight: bold;font-size:18px;font-style: italic;color: #5e5ea2;width: 12%;float:left;margin-right: 5px;" autocomplete="off" name="total_due" id="search_ord_num"/>
				<input type="text" onkeyup="getCustomerList('cus_name_mobile');" placeholder="কাস্টমার নাম/মোবাইল" class="form-control" style="font-weight: bold;font-size:18px;font-style: italic;color: #5e5ea2;width: 18%;float:left;margin-right: 5px;" autocomplete="off" name="total_due" id="cus_name_mobile"/>
				<input type="text" onchange="getCustomerList('kstart_date');" style="width: 18%;float: left; margin-right: 5px;font-weight: bold;font-size:18px;" autocomplete="off" placeholder="Start Date" id="kstart_date" class="form-control" />	
				<input type="text" onchange="getCustomerList('kend_date');" style="width: 18%;float: left; margin-right: 5px;font-weight: bold;font-size:18px;" autocomplete="off" placeholder="End Date" id="kend_date" class="form-control" />	
										
				<select class="form-control" id="searching_status" onchange="getCustomerList('searching_status');" style="width: 18%;color:red;float:left">
					<option value="">Select One</option>
					<option value="1">Order Date</option>
					<option value="2">Delivery Date</option>
					<option value="3">Is Received</option>
					<option value="4">Is Not Received</option>
					<option value="5">Is Delivered</option>
					<option value="6">Is Not Delivered</option>
					<option value="7">Is Paid</option>
					<option value="8">Is UnPaid</option>
					<option value="9">Is Partial Paid</option>
				</select>
				<span style="float: right;font-size: 22px;">কাস্টমার প্যানেল</span>
				</div>
			  </div>
			 
			  <div class="panel-body">
					<div class="row">
						<div class="col-xs-12 col-sm-12">
							<label>Customer List</label>
							<div id="details_area" style="border: 2px solid gray;">
							</div>
							<table id="myTable" class="table table-striped table-bordered table-hover">
								<thead>
									<thead>
									<tr style="background: antiquewhite;">
										<th style="width: 6%;text-align:center">Sl</th>
										<th style="width: 8%;text-align:center">Order No.</th>
										<th style="width: 13%;">Customer</th>
										<th style="width: 12%;text-align:center">Mobile</th>
										<th style="width: 8%;text-align:center">Order Date</th>
										<th style="width: 8%;text-align:center;color:blue">Delivery</th>
										<th style="width: 6%;text-align:right">Total</th>
										<th style="width: 6%;text-align:right">Discount</th>
										<th style="width: 6%;text-align:right">Payment</th>
										<th style="width: 6%;text-align:right">Due</th>
										<th style="width: 8%;text-align:center">Status</th>
										<th style="width: 11%;text-align:center">Action</th>
										
									</tr>
								</thead>
								<tbody id="pending_list">
									<?php 
										$sl2=1;$order_tk2=0;$c=0;$color="";
										if(mysqli_num_rows($pending_order)>0){
											while($row=mysqli_fetch_array($pending_order)){
												$c=$sl2++;
												@$factory_receive_date=$row['factory_receive_date'];
												if($row['tpay']=="" || $row['tpay']==0){
													$color="red";
												}
												if($row['tpay']==$row['amount']){
													$color="#177617;";
												}
												if($row['tpay']>0 && $row['tpay']<$row['amount']){
													$color="#8a6d3b;";
												}
												?>
												<tr id="cleft_row<?php echo $row['id']; ?>" style="color:<?php echo $color; ?>">
												<td style="text-align:center"><?php echo $c; ?></td>
												<td style="text-align:center;font-weight:bold">
													<span style='color:#180cac;cursor: pointer;' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$row['phy_ord_num']; ?>')"><b><?php echo $row['phy_ord_num']; ?></b></span>
												</td>
												<td>
													<?php echo $row['cus_name']; ?>
												</td>
												<td style="text-align:center">
													<?php echo $row['cus_mobile']; ?>
												</td>
												
												<td style="text-align:center">
													<?php echo date_format(date_create($row['insert_date']),"d/m/Y"); ?>
												</td>
												<!--<td style="text-align:center;color:#a01546;">
													<?php echo (@$row['factory_receive_date']!="")? date_format(date_create($row['factory_receive_date']),"d/m/Y") : ''; ?>
												</td>-->
												<td style="text-align:center;color:blue">
													<?php echo date_format(date_create($row['dv_date']),"d/m/Y"); ?>
												</td>
												<td style="text-align:right;font-weight:bold">
													<?php echo ($row['amount']+$row['discount']); ?>
												</td>
												<td style="text-align:right;font-weight:bold">
													<?php echo ($row['discount']); ?>
												</td>
												<td style="text-align:right;font-weight:bold">
													<?php echo $row['tpay']; ?>
												</td>
												<td style="text-align:right;font-weight:bold">
													<?php echo ($row['amount']-$row['tpay']); ?>
												</td>
												
												<td style="text-align:center;cursor:pointer">
													<?php 
													if(isset($row['phy_dv_date'])){
														@$phy_dv_date=date_format(date_create($row['phy_dv_date']),"d/m/Y");
														echo "<span style='font-weight: bold;' title='Physical Delivery Date: $phy_dv_date'>Delivered</span>";
													}else if(isset($factory_receive_date)){
														@$factory_receive_date=date_format(date_create($factory_receive_date),"d/m/Y");
														echo "<span style='font-weight: bold;' title='Physical Delivery Date: $factory_receive_date'>Received</span>";
													}else{
														echo "<span style=''><i>Pending</i></span>";
													}
													
													?>
												</td>
												<td style="text-align:center;cursor: pointer;">
													<span onclick="viewEditArea('<?php echo @$row['phy_ord_num']; ?>');"><i>Edit</i></span> | 
													<span onclick="getOrderDetails('<?php echo @$row['phy_ord_num']; ?>');">View</span> | 
													<span style="color: blue;" onclick="moneyReceitPrint('<?php echo @$row['phy_ord_num']; ?>');">Print</span>
												</td>
												</tr>
												<?php 
											}
										}
									?>
									<input type="hidden" value="<?php echo $c; ?>" id="pending_total"/>
								</tbody>
								
							</table>
						</div>
						
					</div>
					
			  </div>
			 
		   </div>
		
	   </div>	
	</div>
</div>

	 <div id="menu1" class="tab-pane">
       <br/>
	
   </div>
 
	<div id="menu2" class="tab-pane">
     <br/>
		
    </div>
	
</div>

 <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg" id="modal_width">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" id="heading_id"></h4>
        </div>
        <div class="modal-body">
          <span id="smeasurement"></span>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  
  <script>
  
  $(function() {
		$( "#date1,#attenstart_date,#attenend_date,#attendance_date,#mstart_date,#kstart_date,#kend_date,#rstart_date,#rend_date,#pstart_date,#pend_date,#order_delivery_date" ).datepicker({
			dateFormat: 'dd/mm/yy' 
		});
		$("#mend_date" ).datepicker({
			dateFormat: 'dd/mm/yy' 
		});
		
		
	});
	
$(document).ready(function(){
		$(".select2").select2();
		$("#head_measurement,#edit_measurement").hide();
});

function closeArea(){
	$("#details_area").html(null);
}

function copyOrderNumber(id) {
	var tag_num = document.getElementById("copying"+id);
	tag_num.select();
	tag_num.setSelectionRange(0, 99999)
	document.execCommand("copy");
}

 function onlyBoxUpdateBtn(id,order_number){
	var box_number=$("#box_number"+id).val();
	if(confirm('Do you want save it?')){
		$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				box_number:box_number,
				order_number:order_number,
				onlyBoxUpdateBtn:1
			},
			 success: function (response) {
				 if(response==2){
					$("#box_update_sms"+id).html("Save Success!").css('color','green'); 
				 }else{
					$("#box_update_sms"+id).html("Not Success!").css('color','red'); 
				 }
			}
		});
	}
 }
 
 	function recCuttingBtn(sl){
		var hidebtn=$("#chidebtn"+sl).val();
		var dressQtys=$("#cdressQtys"+sl).val();
		
		var sp=hidebtn.split("#sep#");
		var totid=$("#totid"+sp[2]).val();
		var t="";
		if(dressQtys<=0 || dressQtys==""){
			t=1;
			$("#cdressQtys"+sl).css("border-color","red");
			$("#cdressQtys"+sl).val("");
		}else{
			$("#cdressQtys"+sl).css("border-color","#CCCCCC");
			document.getElementById("dressCuttingBtn"+sl).disabled = true;
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						hidebtn:hidebtn,
						dressQtys:dressQtys,
						cuttingDressBtn:1
					},
					 beforeSend: function () {
						$("#order_deny_sms"+sp[2]).show();
						$("#order_deny_sms"+sp[2]).html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						document.getElementById("dressCuttingBtn"+sl).disabled = false;
						$("#order_deny_sms"+sp[2]).hide();
						if(response==10000000){
							$("#cdressQtys"+sl).css("border-color","red");
							$("#cdressQtys"+sl).val("");
						}else{
							var split=response.split("#sep#");
							if(split[0]==1){ // dress receive complete
								for(var ij=1;ij<=totid;ij++){
								$("#cdressQtys"+ij+sp[2]).hide();
								$("#dressCuttingBtn"+ij+sp[2]).hide();
								$("#cqty"+sl).html("("+split[1]+")");
								}
								//productionReceiveBtn(sp[2],0);
							}
							if(split[0]==0){
								$("#cqty"+sl).html("("+split[1]+")");
								$("#cdressQtys"+sl).val("");
							}
						}
					 }
			});
		}
		
	}
	
function recDressBtn(sl){
		var hidebtn=$("#hidebtn"+sl).val();
		var dressQtys=$("#dressQtys"+sl).val();
		
		var sp=hidebtn.split("#sep#");
		var totid=$("#totid"+sp[2]).val();
		var t="";
		if(dressQtys<=0 || dressQtys==""){
			t=1;
			$("#dressQtys"+sl).css("border-color","red");
			$("#dressQtys"+sl).val("");
		}else{
			$("#dressQtys"+sl).css("border-color","#CCCCCC");
			document.getElementById("dressReceiveBtn"+sl).disabled = true;
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						hidebtn:hidebtn,dressQtys:dressQtys,recDressBtn:1
					},
					 beforeSend: function () {
						$("#order_deny_sms"+sp[2]).show();
						$("#order_deny_sms"+sp[2]).html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						document.getElementById("dressReceiveBtn"+sl).disabled = false;
						$("#order_deny_sms"+sp[2]).hide();
						if(response==10000000){
							$("#dressQtys"+sl).css("border-color","red");
							$("#dressQtys"+sl).val("");
						}else{
							var split=response.split("#sep#");
							if(split[0]==1){ // dress receive complete
								for(var ij=1;ij<=totid;ij++){
								$("#dressQtys"+ij+sp[2]).hide();
								$("#dressReceiveBtn"+ij+sp[2]).hide();
								$("#dqty"+sl).html("("+split[1]+")");
								}
								productionReceiveBtn(sp[2],0);
							}
							if(split[0]==0){
								$("#dqty"+sl).html("("+split[1]+")");
								$("#dressQtys"+sl).val("");
							}
						}
					 }
			});
		}
		
	}
	
	function pdeliveryBtn(sl){
		var hidebtn=$("#pdelivery"+sl).val();
		var dressQtys=$("#pdeliveryQtys"+sl).val();
		
		var sp=hidebtn.split("#sep#");
		var totid=$("#totid"+sp[2]).val();
		var t="";
		if(dressQtys<=0 || dressQtys==""){
			t=1;
			$("#pdeliveryQtys"+sl).css("border-color","red");
			$("#pdeliveryQtys"+sl).val("");
		}else{
			$("#pdeliveryQtys"+sl).css("border-color","#CCCCCC");
			document.getElementById("pdeliveryBtn"+sl).disabled = true;
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						hidebtn:hidebtn,dressQtys:dressQtys,pdeliveryBtn:1
					},
					 beforeSend: function () {
						$("#order_deny_sms"+sp[2]).show();
						$("#order_deny_sms"+sp[2]).html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						document.getElementById("pdeliveryBtn"+sl).disabled = false;
						$("#order_deny_sms"+sp[2]).hide();
						if(response==10000000){
							$("#pdeliveryQtys"+sl).css("border-color","red");
							$("#pdeliveryQtys"+sl).val("");
						}else{
							var split=response.split("#sep#");
							if(split[0]==1){ // dress receive complete
								for(var ij=1;ij<=totid;ij++){
								$("#pdeliveryQtys"+ij+sp[2]).hide();
								$("#pdeliveryBtn"+ij+sp[2]).hide();
								$("#ddqty"+sl).html("("+split[1]+")");
								}
								productionReceiveBtn(sp[2],1);
							}
							if(split[0]==0){
								$("#ddqty"+sl).html("("+split[1]+")");
								$("#pdeliveryQtys"+sl).val("");
							}
						}
					 }
			});
		}
		
	}
	
function productionReceiveBtn(div_id,sms_status){
		var hide_sms_id=$("#hide_sms_id"+div_id).val();
		var mobile=$("#mobile3"+div_id).val();
		var ord_no=$("#copying"+div_id).val();
		//document.getElementById("order_receive"+div_id).disabled = true;
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						div_id:div_id,
						hide_sms_id:hide_sms_id,
						mobile:mobile,
						ord_no:ord_no,
						sms_status:sms_status,
						productionReceiveBtn:1
					},
					 beforeSend: function () {
						$("#order_deny_sms"+div_id).show();
						$("#order_deny_sms"+div_id).html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						
						if(response==1){
							$("#order_deny_sms"+div_id).html("Receive Success!").css("color","green");
						}else{
							$("#order_deny_sms"+div_id).html("Not Success!").css("color","red");
						}
					 }
			});
	}
	
	function onlyDateUpdateBtn(sl){
		if(confirm("আপনি কি কাস্টমার এর মোবাইল নম্বর এ SMS পাঠাতে চান?")){
		var date1=$("#date3"+sl).val();
		var date_org=$("#date_org3"+sl).val();
		var hide_sms_id=$("#hide_sms_ids"+sl).val();
		var mobile=$("#mobile3"+sl).val();
		
		if(date1==""){
			$("#date1"+sl).css("border-color","red");
			exit();
		}else{
			$("#date1"+sl).css("border-color","#CCCCCC");
			document.getElementById("only_dateupdate"+sl).disabled = true;	
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						mobile:mobile,
						date_org:date_org,
						hide_sms_id: hide_sms_id,
						date1:date1,
						after_receive_only_date_update:1
					},
					 beforeSend: function () {
						$("#only_date_update_sms"+sl).show();
						$("#only_date_update_sms"+sl).html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						//$("#only_date_update_sms"+sl).hide();
						if(response==10000000){
							$("#only_date_update_sms"+sl).html("Insufficient (SMS) Balance").css("color","red");;
							document.getElementById("only_dateupdate"+sl).disabled = true;
						}
						else if(response==1){
							$("#only_date_update_sms"+sl).html("SMS has not sent!").css("color","red");;
							document.getElementById("only_dateupdate"+sl).disabled = true;
						
						}else if(response==20000000){
							$("#only_date_update_sms"+sl).html("Warning! Server Busy.").css("color","red");;
							document.getElementById("only_dateupdate"+sl).disabled = true;
						}else if(response==40000000){
							$("#only_date_update_sms"+sl).html("No Internet Connection").css("color","red");;
							document.getElementById("only_dateupdate"+sl).disabled = true;
						}else if(response==50000000){
							$("#only_date_update_sms"+sl).html("সবগুলি আইটেম এখনো রিসিভ হয় নাই.").css("color","red");;
							document.getElementById("only_dateupdate"+sl).disabled = true;
						}else{
							$("#dv_date"+sl).html(date1);
							$("#only_date_update_sms"+sl).html("SMS has been sent!").css("color","green");;
							document.getElementById("only_dateupdate"+sl).disabled = false;	
						}
					}
			});
		}
		}else{
			
		}
	}
	
function showLiveDiscount(sl_no){
		var due_tk=($("#hide_due"+sl_no).val()=="")? 0 : $("#hide_due"+sl_no).val();
		var present_tk=($("#paytxt"+sl_no).val()=="")? 0 : $("#paytxt"+sl_no).val();
		
		$("#discount_tks"+sl_no).html(parseFloat(due_tk)-parseFloat(present_tk)+" Tk.");
		$("#exdiscount"+sl_no).val(null);
	}
	
function setDiscountTk(sl_no){
		var due_tk=($("#hide_due"+sl_no).val()=="")? 0 : $("#hide_due"+sl_no).val();
		var present_tk=($("#paytxt"+sl_no).val()=="")? 0 : $("#paytxt"+sl_no).val();
		$("#exdiscount"+sl_no).val(parseFloat(due_tk)-parseFloat(present_tk));
	}

	function payTk(div_id){
		var customer_id=$("#customer_id").val();
		var ord_number=$("#copying"+div_id).val();
		var previous_due=$("#previous_due").val();
		var hide_due=$("#hide_due"+div_id).val();
		var paytxt=$("#paytxt"+div_id).val();
		var payment_type=$("#payment_type"+div_id).val();
		var mobile=$("#mobile3"+div_id).val();
		var dsms_ids=$("#dsms_ids"+div_id).val();
		var total_tk=$("#total_tk"+div_id).val();
		var discount=$("#discount"+div_id).val();
		var discount_tot=$("#discount_tot"+div_id).val();
		var exdiscount=$("#exdiscount"+div_id).val();
		var order_number=$("#copying"+div_id).val();
		var fab_total_tk=$("#fab_total_tk"+div_id).val();
		
		if(parseFloat(exdiscount)>=parseFloat(hide_due)){
			$("#stksms"+div_id).html("Invalid! Enter correct discount.").css("color","red");
			return;
		}
		
		if(parseFloat(paytxt)>parseFloat(hide_due)){
			$("#stksms"+div_id).html("Invalid! Enter correct payment.").css("color","red");
			return;
		}
		
		if($("#exdiscount"+div_id).val()=="" && $("#paytxt"+div_id).val()==""){
			$("#stksms"+div_id).html("Invalid! Enter discount or payment.").css("color","red");
			return;
		}
		
		
			if(exdiscount!=""){
				if((parseFloat(paytxt)+parseFloat(exdiscount))>parseFloat(hide_due)){
					$("#stksms"+div_id).html("Invalid! Enter correct amount.").css("color","red");
					return;
				}
			}
			
		document.getElementById("paybtns"+div_id).disabled = true;
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						discount_tot:discount_tot,
						discount:discount,
						div_id:div_id,
						total_tk:total_tk,
						order_number:order_number,
						exdiscount:exdiscount,
						ord_number:ord_number,
						dsms_ids:dsms_ids,
						customer_id:customer_id,
						payment_type:payment_type,
						previous_due:previous_due,
						hide_due:hide_due,
						fab_total_tk:fab_total_tk,
						mobile:mobile,
						paytxt:paytxt,
						payTk:1
					},
					 beforeSend: function () {
						$("#stksms"+div_id).show();
						$("#stksms"+div_id).html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						if(response!=2){
							$("#payment_tbl"+div_id).html(response);
							getUpdateDue();
						}else{
							$("#stksms"+div_id).html("Not Success!").css("color","red");
						}
					 }
			});
	}
	
	function delPay(accounting_tbl_id,div_id){
		var customer_id=$("#customer_id").val();
		var dsms_ids=$("#dsms_ids"+div_id).val();
		var total_tk=$("#total_tk"+div_id).val(); // total tk
		var discount=$("#discount"+div_id).val(); // discount tk
		var discount_tot=$("#discount_tot"+div_id).val(); // after discount tk
		var ord_no=$("#copying"+div_id).val();
		
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						discount:discount,
						discount_tot:discount_tot,
						div_id:div_id,
						total_tk:total_tk,
						dsms_ids:dsms_ids,
						accounting_tbl_id:accounting_tbl_id,
						customer_id:customer_id,
						ord_no:ord_no,
						delPay:1
					},
					 beforeSend: function () {
						$("#stksms"+div_id).show();
						$("#stksms"+div_id).html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						if(response!=2){
							$("#payment_tbl"+div_id).html(response);
							getUpdateDue();
						}else{
							$("#stksms"+div_id).html("Not Success!").css("color","red");
						}
					 }
			});
	}

function clickToSelect(txtboxid) {
		const txtbox = document.getElementById(txtboxid);
		txtbox.focus();
		txtbox.select();
 
	}

function orderDeliveryBtn(div_id){
		if(confirm("আপনি কি অর্ডার টি ডেলিভারি দিতে চান?")){
			var hide_sms_id=$("#hide_sms_id"+div_id).val();
			var customer_id=$("#customer_id").val();
			var hide_due=$("#hide_due"+div_id).val();
			var payment_type=$("#payment_type"+div_id).val();
			var total_tk=$("#total_tk"+div_id).val();
			var discount=$("#discount"+div_id).val();
			var discount_tot=$("#discount_tot"+div_id).val();
			var order_number=$("#copying"+div_id).val();
			var fab_total_tk=$("#fab_total_tk"+div_id).val();
			var ord_number=$("#copying"+div_id).val();
			var paytxt="", exdiscount="";
			if(hide_due!=0){
				if($("#paytxt"+div_id).val()==""){
				$("#order_delivery_sms"+div_id).html("Enter Due!").css("color","red");
				exit;
				}else{
					paytxt=$("#paytxt"+div_id).val();
					exdiscount=$("#exdiscount"+div_id).val();
				}
			}
		
			if(parseFloat(hide_due)<0){
				$("#order_delivery_sms"+div_id).html("Invalid! Delete any amount.").css("color","red");
				return;
			}
			
			if(exdiscount!=""){
				if((parseFloat(paytxt)+parseFloat(exdiscount))>parseFloat(hide_due)){
					$("#order_delivery_sms"+div_id).html("Invalid! Enter correct amount.").css("color","red");
					return;
				}
			}
		
			if(parseFloat(paytxt)>parseFloat(hide_due)){
				$("#order_delivery_sms"+div_id).html("Invalid! Enter correct amount.").css("color","red");
				return;
			}
			
			if(parseFloat(exdiscount)>=parseFloat(hide_due)){
				$("#stksms"+div_id).html("Invalid! Enter correct discount.").css("color","red");
				return;
			}
			
			if(parseFloat(paytxt)>parseFloat(hide_due)){
				$("#stksms"+div_id).html("Invalid! Enter correct payment.").css("color","red");
				return;
			}
		
			document.getElementById("order_delivery"+div_id).disabled = true;
			$.ajax({
						type: 'post',
						url: 'sql.php',
						data: {
							discount_tot:discount_tot,
							discount:discount,
							div_id:div_id,
							total_tk:total_tk,
							paytxt:paytxt,
							exdiscount:exdiscount,
							payment_type:payment_type,
							hide_due:hide_due,
							hide_sms_id:hide_sms_id,
							customer_id:customer_id,
							order_number:order_number,
							fab_total_tk:fab_total_tk,
							orderDeliveryBtn:1
						},
						 beforeSend: function () {
							$("#order_delivery_sms"+div_id).show();
							$("#order_delivery_sms"+div_id).html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							//document.getElementById("order_delivery").disabled = false;
							if(response!=2){
								$("#order_delivery_sms"+div_id).html("Success!").css("color","green");
								var sp=response.split("#sep#");
								$("#phy_dv_date"+div_id).html(sp[0]);
								$("#payment_tbl"+div_id).html(sp[1]);
								getUpdateDue();
								/* setTimeout(function() {
								  srchByMobileNum($("#mobile").val());
								},500); */
							}else{
								$("#order_delivery_sms"+div_id).html("Not Success!").css("color","red");
							}
						 }
				});
		}
	}
	
	function getUpdateDue(){
		var customer_id=$("#customer_id").val();
		$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				cus_id:customer_id,get_update_due:1
			},
			 success: function (response) {
				var update_due=parseFloat(response).toFixed(2);
				$("#previous_due_tab").show(); // set individual customers previous due
				$("#previous_due").val(update_due.trim()); // set individual customers previous due
			}
		});
	}
	
	
 function showMeasurement(sl,ord_num){
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					ord_num:ord_num,smeasurement:1
				},
				 beforeSend: function () {
					$("#smeasurement").html('<img src="img/loading.gif"/>');
				},
				 success: function (response) {
					console.log(response);
					$("#heading_id").html("Measurement");
					$("#smeasurement").html(response);
				}
		});
	}
	
 function showMeasurementImage(ord_tbl_id,sl_no){
		$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					ord_tbl_id:ord_tbl_id,
					hidden_img_link:$("#hidden_img_link"+sl_no).val(),
					showMeasurementImage:1
				},
				 beforeSend: function () {
					$("#smeasurement").html('<img src="img/loading.gif"/>');
				},
				 success: function (response) {
					console.log(response);
					$("#heading_id").html("Measurement Photo");
					$("#smeasurement").html(response);
				}
		});
	}

function getCustomerList(searh_status){
	var search_ord_num=$("#search_ord_num").val();
	var cus_name_mobile=$("#cus_name_mobile").val();
	var kstart_date=$("#kstart_date").val();
	var kend_date=$("#kend_date").val();
	var searching_status=$("#searching_status").val();
	
	$.ajax({
		type: 'post',
		url: 'sql.php',
		data: {
			search_ord_num: search_ord_num,
			cus_name_mobile: cus_name_mobile,
			kstart_date: kstart_date,
			kend_date: kend_date,
			searching_status: searching_status,
			getCustomerList:1
		},
		 beforeSend: function () {
			$("#pending_list").html('Wait..');
		},
		 success: function (response) {
			console.log(response);
			$("#pending_list").html(response);
		 }
});
}



function getOrderDetails(mobile){
	$.ajax({
		type: 'post',
		url: 'sql.php',
		data: {
			getOrderDetails:1
		},
		 beforeSend: function () {
			$("#details_area").html('<img src="img/loading.gif"/>');
		},
		 success: function (response) {
			console.log(response);
			$("#details_area").html(response);
			searchOrder(mobile);
		 }
});
		
}
	
	function searchOrder(mobile){
		var mobile=mobile;
		$("#last_id_hide").val(3);
		var m="";
		if(mobile==""){
			$("#mobile").css("border-color","red");
			m=1;
		}else{
			$("#mobile").css("border-color","#CCCCCC");
		}
		
		
		if(m==1){
			exit();
		}else{
		//document.getElementById("srcbymob").disabled = true;	
		
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						mobile:mobile,search_btn:1
					},
					 beforeSend: function () {
						$("#src_result").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						//console.log(response);
						//document.getElementById("srcbymob").disabled = false;
						$("#attach_tbl").click();
						if(response==1){
							$("#src_result").html("No result found!").css("color","red");
							
						}else{
							$("#src_result").html(response);
							document.body.scrollTop = 0;
							document.documentElement.scrollTop = 0;
							getUpdateDue();
						}
					 }
			});
		}
	}
	
	function moneyReceitPrint(ord_num){
		$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				moneyReceitPrint:1
			},
			 beforeSend: function () {
				$("#details_area").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
				//console.log(response);
				//document.getElementById("srcbymob").disabled = false;
				$("#attach_tbl").click();
				if(response==1){
					$("#details_area").html("No result found!").css("color","red");
					
				}else{
					$("#details_area").html(response);
					dateWisePrint(ord_num);
				}
			 }
	});
		
	}
	
	function dateWisePrint(order_number){
		//$("#order_print_area").click();
		var date1="";
		var date2="",extra_item="",karigor_list="",order_type="",expense_type="";
		var mobile="";
		var order_number=order_number;
		var serial_no="";
		var print_type=2;
		extra_item="";
		var month="",year="";
		if(print_type==14 || print_type==23){
			karigor_list=$("#karigor_list").val();
			date1="2023/01/01";
		}
		if(print_type==24){
			order_type=$("#decision_list").val();
			order_number=1;
		}
		if(print_type==15){
			order_type=$("#order_type").val();
			date1="2023/01/01";
		}
		if(print_type==16){
			expense_type=$("#expense_type").val();
			date1=$("#date1").val();
		}
		if(print_type==18){
			extra_item=$("#item_statuss").val();
			date1=$("#date1").val();
		}
		if(print_type==19){
			karigor_list=$("#emp_lists").val();
			extra_item=$("#emp_statuss").val();
			date1=$("#date1").val();
		}
		if(print_type==4 || print_type==5 || print_type==6 || print_type==7){
			order_number="123";
			month=$("#month").val();
			year=$("#year").val();
		}
		if(print_type==9){
			date1="2023/01/01";
			mobile="1";
			order_number="1";
			serial_no="1";
		}
		if(print_type==3){
			if(date1==""){
				$("#date1").css("border-color","red");
				$("#date1").focus();
				exit;
			}else{
				$("#date1").css("border-color","#CCCCCC");
				$("#send_email").show("slow");
			}
		}
		if(print_type==11 || print_type==12 || print_type==16 || print_type==8 || print_type==17 || print_type==18 || print_type==19){
			if(date1==""){
				$("#date1").css("border-color","red");
				$("#date1").focus();
				exit;
			}else{
				$("#date1").css("border-color","#CCCCCC");
				$("#send_email").show("slow");
			}
			date2=$("#date2").val();
			if(date2==""){
				$("#date2").css("border-color","red");
				$("#date2").focus();
				exit;
			}else{
				$("#date2").css("border-color","#CCCCCC");
				//$("#send_email").show("slow");
			}
		}
		if(date1=="" && mobile=="" && order_number=="" && serial_no==""){
			$("#summery_report2").html("Enter Date/Mobile/Order No.").css("color","red");
		}else{
			$.ajax({
						type: 'post',
						url: 'ajax.php',
						data: {
							month:month,
							year:year,
							print_type:print_type,
							date1:date1,
							date2:date2,
							mobile:mobile,
							order_number:order_number,
							serial_no:serial_no,
							extra_item:extra_item,
							karigor_list:karigor_list,
							order_type:order_type,
							expense_type:expense_type,
							dateWisePrint:1
						},
						 beforeSend: function () {
							$("#summery_report2").html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							if(response==2){
								$("#summery_report2").html("No Result Found!").css("color","red");
							}else{
								$("#summery_report2").html(response).css("color","black");
								document.body.scrollTop = 0;
								document.documentElement.scrollTop = 0;
							}
						}
			});
		}
		
	}
	
	function viewAllEditArea(ord_num){
		$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				ord_num:ord_num,
				viewAllEditArea:1
			},
			 beforeSend: function () {
				$("#details_area").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
				console.log(response);
				$("#details_area").html(response);
				document.body.scrollTop = 0;
				document.documentElement.scrollTop = 0;
				$(".select2").select2();
			 }
	});
		
	}
	
	function viewEditArea(ord_num){
		$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				ord_num:ord_num,
				viewEditArea:1
			},
			 beforeSend: function () {
				$("#details_area").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
				//console.log(response);
				//document.getElementById("srcbymob").disabled = false;
				$("#attach_tbl").click();
				if(response==1){
					$("#details_area").html("No result found!").css("color","red");
					
				}else{
					$("#details_area").html(response);
					$("#head_measurement,#edit_measurement").hide();
					srchByOrdNum(ord_num);
				}
			 }
	});
		
	}
	
	function photoUpload(record_tbl_id,sl_no){
		
		
		if(confirm("Do you want to file upload?")){
			var file_name = document.getElementById("file"+sl_no).files;
			console.log(file_name);
			if (file_name.length > 0) {
				var files = file_name;
				var formData = new FormData();
				formData.append("file", files[0]);
				formData.append("record_tbl_id", record_tbl_id);
				formData.append("save_file", 1);
				//console.log(formData); return;
				$.ajax({//url will be related class name
					type: 'post',
					url: 'sql.php',
					processData: false,
					contentType: false,
					cache: false,
					data: formData,
					enctype: 'multipart/form-data',
					
					success: function (response) {
						console.log(response);
						if(response!='2'){
							$("#hidden_img_link"+sl_no).val(response.trim());
							$("#file"+sl_no).val(null);
							$("#upload_sms"+sl_no).html("Upload success!");
							document.getElementById("upload_btn"+sl_no).disabled = true;
						}
					}
				});
			}
		}
	}
	
	function srchByOrdNum(ord_number){
		var edit_ord_number=ord_number; //$("#edit_ord_number").val();
		
		if(edit_ord_number!=""){
			$("#edit_ord_number").css("border-color","#CCCCCC");
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						edit_ord_number:edit_ord_number,
						get_edit_item:1
					},
					 beforeSend: function () {
						$("#item_area").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response!=2){
							$("#item_area").html(response).css("color","black");
							document.body.scrollTop = 0;
							document.documentElement.scrollTop = 0;
						}else{
							$("#item_area").html("Not Found!").css("color","red");
						}
						var hidden_ord_number=$("#hidden_ord_number").val();
						if(hidden_ord_number!=""){
							$("#active_btn"+hidden_ord_number).css("color","#337ab7");
						}
						$("#hidden_ord_number").val(edit_ord_number);
						$("#active_btn"+edit_ord_number).css("color","red");
					}
			});
		}else{
			$("#edit_ord_number").css("border-color","red");
		}
	}
	
	function itemAmountChangeEdit(item_id){
		var item_qty=parseFloat($("#item_qtye"+item_id).val());
		if($("#item_qtye"+item_id).val()==""){
			item_qty=0;
		}
		
		var item_rate=parseFloat($("#item_ratee"+item_id).val());
		if($("#item_ratee"+item_id).val()==""){
			item_rate=0;
		}
		//var item_others=parseFloat($("#item_otherse"+item_id).val());
		$("#item_amounte"+item_id).val(item_rate*item_qty);
		getTotal();
	}
	
function showEditDetails(master_id,karigor_id,ord_tbl_id,group_id,ptye,item_id,item_name,sl,orderinfo,design_cost,amount_cost,item_qty){
		var eitem_chk=$("#eitem_chk").val();
		$("#eitem"+sl).css("color",'red');
		$("#eitem"+eitem_chk).css("color",'#337AB7');
		$("#eitem_chk").val(sl);
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					master_id:master_id,
					karigor_id:karigor_id,
					ord_tbl_id:ord_tbl_id,
					group_id:group_id,
					ptye:ptye,
					item_id:item_id,
					item_name:item_name,
					orderinfo:orderinfo,
					design_cost:design_cost,
					amount_cost:amount_cost,
					item_qty:item_qty,
					sl_no:sl,
					get_item_detail_edit:1
				},
				 beforeSend: function () {
					$("#edit_measurement").show();
					$("#edit_measurement").html('<img src="img/loading.gif"/>');
					$("#updatebtn,#newordbtn").show();
					$("#new_measurement_parameter").val(ord_tbl_id+"#sep#"+group_id+"#sep#"+ptye+"#sep#"+item_id+"#sep#"+item_name+"#sep#"+sl+"#sep#"+orderinfo+"#sep#"+design_cost+"#sep#"+amount_cost+"#sep#"+item_qty+"#sep#"+master_id+"#sep#"+karigor_id);
				},
				 success: function (response) {
					$("#head_measurement").hide();
					$("#edit_measurement").show("slow");
					$("#edit_measurement").html(response).css("color","black");
				
				}
		});
	}
	
function showFabricsDetails(order_num){
		$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					order_num:order_num,
					showFabricsDetails:1
				},
				 beforeSend: function () {
					$("#edit_measurement").show("slow");
					$("#edit_measurement").html('<img src="img/loading.gif"/>');
				},
				 success: function (response) {
					$("#edit_measurement").html(response).css("color","black");
				
				}
		});
	}
	
	window.esizea = [];
	window.esizeida = [];
	window.eproperticetitlea = [];
	window.eproperticea = [];
	window.eexproperticea = [];
	function updateMeasurement(){
		if(confirm("আপনি কি আপডেট করতে চান?")){
		var ord_tbl_id="";
		var i="",m="",ep="",epc=0,iid="",jj="",extra_remarks="";
		ord_tbl_id=$("#ord_tbl_id").val();
		var calculate_item_id=$("#calculate_item_id").val();
		var item_sl_no=$("#item_sl_no").val();
		var item_namee=$("#item_namee"+calculate_item_id).val();
		var edit_ord_number=$("#edit_ord_number").val();
		
		
		var previous_amount_cost=$("#previous_amount_cost").val(); 
		var previous_design_cost=$("#previous_design_cost").val(); 
		var previous_group_name=$("#previous_group_name").val(); 
		var previous_orderinfo=$("#previous_orderinfo").val(); 
		
		
		var item_amounte=$("#item_amounte"+calculate_item_id).val(); 
		var item_qtye=$("#item_qtye"+calculate_item_id).val(); 
		var item_ratee=$("#item_ratee"+calculate_item_id).val(); 
		var item_otherse=$("#item_otherse"+calculate_item_id).val(); 
		var group_namee=$("#group_namee"+calculate_item_id).val(); 
		var master_ide=$("#master_ide"+calculate_item_id).val(); 
		var karigor_ide=$("#karigor_ide"+calculate_item_id).val(); 
		
		var sizetot=$("#sizetote").val(); //sizetxt
		var propertice_title_tot=$("#propertice_title_tote").val(); //propertice
		var expropertice_tot=$("#expropertice_tote").val(); //expropertice expropertice_tot
		var txtareaid=$("#txtareaide").val(); //
		if(txtareaid>0){
			extra_remarks=$("#extra_remarkse").val();
		}
		
		for(i=0; i<sizetot; i++){
			
			if($("#sizee"+i).val()!=""){
				$("#sizee"+i).css("border-color","#CCCCCC");
				esizea.push($("#sizee"+i).val());
				esizeida.push($("#sizetxte"+i).val());
			}
		}
		for(i=0; i<propertice_title_tot; i++){
				eproperticetitlea.push($("#propertice_titlee"+i).val());
				if($("#properticee"+i).val()!=""){
					eproperticea.push($("#properticee"+i).val());
				}else{
				eproperticea.push(0);
				}
		}
		
		if(expropertice_tot!=0){
			for(i=0; i<expropertice_tot; i++){
					if ($('#exproperticee'+i).is(":checked")){
						eexproperticea.push($("#exproperticee"+i).val());
					}else{
						epc++;
					}
			}
			
			var all_exproperticea = eexproperticea.join('#sep#');
		}else{
			var all_exproperticea =0;
		}
		
		console.log(expropertice_tot+"= "+epc);
		console.log("size id: "+esizeida);
		console.log("size p: "+esizea);
		console.log("ex p: "+eexproperticea);
		console.log("p t: "+eproperticetitlea);
		console.log("p : "+eproperticea);
		
		var all_sizeida = esizeida.join('#sep#');
		var all_sizea = esizea.join('#sep#');
		var all_properticetitlea = eproperticetitlea.join('#sep#');
		var all_properticea = eproperticea.join('#sep#');
		if(ord_tbl_id!=""){
			$("#edit_ord_number").css("border-color","#CCCCCC");
			document.getElementById("updatebtn").disabled = true;
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						ord_tbl_id:ord_tbl_id,
						all_sizeida:all_sizeida,
						all_sizea:all_sizea,
						all_properticetitlea:all_properticetitlea,
						all_properticea:all_properticea,
						all_exproperticea:all_exproperticea,
						txtareaid:txtareaid,
						extra_remarks:extra_remarks,
						previous_amount_cost:previous_amount_cost,
						previous_design_cost:previous_design_cost,
						previous_group_name:previous_group_name,
						previous_orderinfo:previous_orderinfo,
						item_amounte:item_amounte,
						item_qtye:item_qtye,
						item_ratee:item_ratee,
						item_otherse:item_otherse,
						group_namee:group_namee,
						master_ide:master_ide,
						karigor_ide:karigor_ide,
						edit_ord_number:edit_ord_number,
						edit_order:1
					},
					 beforeSend: function () {
						$("#uload").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response==1){
							$("#uload").html(null);
							$("#edit_measurement").html("Update Success!").css("color","green");
							
						}else{
							$("#uload").html("Not Success!").css("color","red");
						}
						//srchByOrdNum($("#hidden_ord_number").val());
						document.getElementById("updatebtn").disabled = false;
						esizeida = [];
						esizea = [];
						eexproperticea = [];
						eproperticetitlea = [];
						eproperticea = [];
					}
			});
		}else{
			$("#edit_ord_number").css("border-color","red");
		}
		}
	}
	
	function delDetailSales(deltblid,price,headid,ord_num,item_id,item_qty,cus_mobile){
		 if(confirm("আপনি কি Item টি ডিলিট করতে চান?")){
			 if(ord_num=="" || ord_num=='0'){
				document.getElementById("delid"+deltblid).disabled = true;	
				$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						headid:headid,
						price:price,
						ord_num:ord_num,
						deltblid:deltblid,
						item_id:item_id,
						item_qty:item_qty,
						cus_mobile:cus_mobile,
						delDetailSales:1
					},
					 beforeSend: function () {
						$("#del_sms").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						 console.log(response);
						if(response==1){
							showDetailSales(headid);
							var netpay=document.getElementById('netpay'+headid).innerHTML;
							var tbl_discount_tk=document.getElementById('tbl_discount_tk'+headid).innerHTML;
							var net_tk=parseFloat(netpay)-parseFloat(price);
							$("#netpay"+headid).html(net_tk);
							var udiscount=((net_tk-parseFloat(tbl_discount_tk))<=0)? '0' : (net_tk-parseFloat(tbl_discount_tk));
							$("#tbl_total_tk"+headid).html(udiscount);
							if(parseFloat(udiscount)==0){
								$("#tbl_discount_tk"+headid).html(udiscount);
							}
						}else{
							$("#del_sms").html("Not Success!").css("color","red");
						}
						
					}
				});
			 }else{
				 //alert("Sales return is not possible. Please exchange it!!");
				document.getElementById("delid"+deltblid).disabled = true;	
				$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						headid:headid,
						price:price,
						ord_num:ord_num,
						deltblid:deltblid,
						item_id:item_id,
						item_qty:item_qty,
						cus_mobile:cus_mobile,
						delDetailSales:1
					},
					 beforeSend: function () {
						$("#del_sms").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						 console.log(response);
						if(response==1){
							viewAllEditArea(ord_num);
						}else{
							$("#del_sms").html("Not Success!").css("color","red");
						}
						
					}
				});
			 }
		  }
	}
	
function getNewItem(head_id,order_num,cus_id,cus_mobile){
		var ds_item_id=$("#ds_item_id").val();
		var fab_hidden_id=$("#fab_hidden_id").val();
		$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				cus_id:cus_id,
				cus_mobile:cus_mobile,
				head_id:head_id,
				order_num:order_num,
				ds_item_id:ds_item_id,
				fab_hidden_id:fab_hidden_id,
				getNewItemOrder:1
			},
			
			 success: function (response) {
				console.log(response);
					$("#item_details").prepend(response);
					$("#fab_hidden_id").val(parseInt(fab_hidden_id)+1);
			}
		});
	}

function liveCheckStockQty(sl_no,tbl_id,item_id,item_qty,head_id,item_per_price,cus_id){
		
		getTotal();
		$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				tbl_id:tbl_id,
				item_id:item_id,
				item_qty:item_qty,
				edit_fab_qty:$("#edit_fab_qty"+sl_no).val(),
				liveCheckStockQty:1
			},
			 success: function (response) {
				if(response==3){
					alert('Item stock not available.');
					$("#edit_fab_qty"+sl_no).val(item_qty);
					$("#edit_fab_qty"+sl_no).css("border-color","red");
				}else{
					$("#edit_fab_qty"+sl_no).css("border-color","blue");
				}
				//updateFabQtyLive(sl_no,item_id,item_qty,item_per_price,tbl_id,head_id,cus_id,0);
			}
		});
	}

function pricef(sl_no,item_id){
		getTotal();
	}
	
function getTotal(){
		var id_name = "";
		var fab_hidden_id=$("#fab_hidden_id").val();
		var tot=0,taitot=0;
		for(var i=1;i<=fab_hidden_id;i++){
			id_name = document.getElementById("edit_fab_qty" + i);
			if (id_name != null) {
				tot+=((($("#edit_fab_qty"+i).val()=="")? 0 : parseFloat($("#edit_fab_qty"+i).val()))*(($("#live_item_pricec"+i).val()=="")? 0 : parseFloat($("#live_item_pricec"+i).val()))); //.toFixed(3)
				$("#sub_total"+i).html(((($("#edit_fab_qty"+i).val()=="")? 0 : parseFloat($("#edit_fab_qty"+i).val()))*(($("#live_item_pricec"+i).val()=="")? 0 : parseFloat($("#live_item_pricec"+i).val()))).toFixed(2));
			}
	   }
	   
	    var id_name_making = "";
		var making_hidden_id=$("#making_hidden_id").val();
		var tot_making=0,taitot=0;
		for(var j=1;j<=making_hidden_id;j++){
			id_name_making = document.getElementById("item_amounte" + j);
			if (id_name_making != null) {
				tot_making+=(($("#item_amounte"+j).val()=="")? 0 : parseFloat($("#item_amounte"+j).val())); //.toFixed(3)
			}
	   }
	   
		$("#total_h").val((tot+tot_making).toFixed(2));
		
		var chain_tk=($("#chain_tk").val()=="")? 0 : parseFloat($("#chain_tk").val());
		var bottam_tk=($("#bottam_tk").val()=="")? 0 : parseFloat($("#bottam_tk").val());
		var design_tk=($("#others_tk").val()=="")? 0 : parseFloat($("#others_tk").val());
		
		var discount_tk=($("#discount_tk").val()=="")? 0 : parseFloat($("#discount_tk").val());
		
		$("#grant_total").val(((tot+tot_making+chain_tk+bottam_tk+design_tk)-parseFloat(discount_tk)).toFixed(2));
		
		var advance_tk=($("#advance_tk").val()=="")? 0 : parseFloat($("#advance_tk").val());
		var grant_total=($("#grant_total").val()=="")? 0 : parseFloat($("#grant_total").val());
		
		$("#due_tk").val((parseFloat(grant_total)-parseFloat(advance_tk)).toFixed(2));
		
}
	
	
function editCustomerInformation(tbl_id,cus_id,field_name,tbl_name,extra_tbl){
		var edit_cus_name=$("#"+field_name).val();
		
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						tbl_id:tbl_id,
						field_name:field_name,
						edit_cus_name:edit_cus_name,
						customer_id:cus_id,
						tbl_name:tbl_name,
						extra_tbl:extra_tbl,
						editAllformation:1
					},
					
					 success: function (response) {
						console.log(response);
						if(response==1){
							$("#"+field_name).css("border-color","blue");
						}
					 }
			});
		
		
	}

function deleteMeasurement(ord_record_tbl,ord_num,item_id,item_qty,sl_num,amount){
	if(confirm('Do you want to delete it?')){
		$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					tbl_id:ord_record_tbl,
					ord_num:ord_num,
					item_id:item_id,
					item_qty:item_qty,
					amount:amount,
					sl_num:sl_num,
					deleteMeasurement:1
				},
				
				 success: function (response) {
					console.log(response);
					if(response==1){
						viewAllEditArea(ord_num);
					}
				 }
		});
	}
}

function itemIdWiseDetails(item_info){
	var making_hidden_id=$("#making_hidden_id").val();
	$.ajax({
		type: 'post',
		url: 'sql.php',
		data: {
			item_info:item_info,
			making_hidden_id:making_hidden_id,
			itemIdWiseDetails:1
		},
		
		 success: function (response) {
			console.log(response);
				$("#head_measurement_details").prepend(response);
				$("#making_hidden_id").val(parseInt(making_hidden_id)+1);
		}
	});
}

	function updateAllInfo(ord_num,dsms_id,head_id,cus_id){
		window.hfs_tblid = [];
		window.hitem_id = [];
		window.hitem_qty = [];
		window.hprice = [];
		window.litem_qty = [];
		window.lprice = [];
		window.loriginal_price = [];
		
		window.order_record_id = [];
		window.making_item_qty = [];
		window.making_item_amount = [];
		
		var hfs_tblida = "";
		var hitem_ida = "";
		var hitem_qtya = "";
		var hpricea = "";
	
		var litem_qtya = "";
		var loriginal_pricea = "";
		var lpricea = "";
		
	if(confirm('Do you want to update?')){
		var fab_hidden_id=$("#fab_hidden_id").val();
		var making_hidden_id=$("#making_hidden_id").val();
		var chk="",id_name = "",id_name_making="";
	if(parseInt(fab_hidden_id)>0){
		var febdis=($("#discount_percentage").val()=="")? 0 : parseFloat($("#discount_percentage").val());
		for(var i=1;i<=fab_hidden_id;i++){
			id_name = document.getElementById("edit_fab_qty"+i);
			if (id_name != null) {
				if($("#edit_fab_qty"+i).val()=="" || $("#edit_fab_qty"+i).val()==0){
					alert("Warning! Item quantity is missing.");
					$("#edit_fab_qty"+i).click();
					$("#edit_fab_qty"+i).focus();
					chk="notok";
					return;
				}
				if($("#live_item_pricec"+i).val()=="" || $("#live_item_pricec"+i).val()==0){
					alert("Warning! Item price is missing.");
					$("#live_item_pricec"+i).click();
					$("#live_item_pricec"+i).focus();
					chk="notok";
					return;
				}
				
			}
	   }
	   if(chk==""){
			for(var i=1;i<=fab_hidden_id;i++){
				id_name = document.getElementById("edit_fab_qty" + i);
				if (id_name != null) {
					hfs_tblid.push($("#hidden_fs_tbl_id"+i).val());
					hitem_id.push($("#hidden_edit_item_id"+i).val());
					hitem_qty.push($("#hidden_edit_fab_qty"+i).val());
					hprice.push($("#hidden_purchase_price"+i).val());
					
					litem_qty.push($("#edit_fab_qty"+i).val());
					loriginal_price.push($("#live_item_pricec"+i).val());
					lprice.push($("#live_item_pricec"+i).val());
					
				}
		   }
		   
			var hfs_tblida = hfs_tblid.join('#sep#');
			var hitem_ida = hitem_id.join('#sep#');
			var hitem_qtya = hitem_qty.join('#sep#');
			var hpricea = hprice.join('#sep#');
		
			var litem_qtya = litem_qty.join('#sep#');
			var loriginal_pricea = loriginal_price.join('#sep#');
			var lpricea = lprice.join('#sep#');
	 }
	}
	if(parseInt(making_hidden_id)>0){
		for(var j=1;j<=making_hidden_id;j++){
			id_name_making = document.getElementById("order_record_id" + j);
			if (id_name_making != null) {
				order_record_id.push($("#order_record_id"+j).val());
				making_item_qty.push($("#item_qtye"+j).val());
				making_item_amount.push($("#item_amounte"+j).val());
			}
		}
	}else{
		alert('Warning! Please add at least one tailor item.');
		return;
	}
	var order_record_ida = order_record_id.join('#sep#');
	var making_item_qtya = making_item_qty.join('#sep#');
	var making_item_amounta = making_item_amount.join('#sep#');
	 
		$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				head_id:head_id,
				ord_num:ord_num,
				dsms_id:dsms_id,
				cus_id:cus_id,
				fab_hidden_id:fab_hidden_id,
				hfs_tblida:hfs_tblida,
				hitem_ida:hitem_ida,
				hitem_qtya:hitem_qtya,
				hpricea:hpricea,
				litem_qtya:litem_qtya,
				lpricea:lpricea,
				loriginal_price:loriginal_pricea,
				order_record_ida:order_record_ida,
				making_item_qtya:making_item_qtya,
				making_item_amounta:making_item_amounta,
				total_h:($("#total_h").val()=="")? 0 : parseFloat($("#total_h").val()),
				chain_tk:($("#chain_tk").val()=="")? 0 : parseFloat($("#chain_tk").val()),
				bottam_tk:($("#bottam_tk").val()=="")? 0 : parseFloat($("#bottam_tk").val()),
				design_tk:($("#others_tk").val()=="")? 0 : parseFloat($("#others_tk").val()),
				discount_tk:($("#discount_tk").val()=="")? 0 : parseFloat($("#discount_tk").val()),
				advance_tk:($("#advance_tk").val()=="")? 0 : parseFloat($("#advance_tk").val()),
				payment_type:($("#payment_type").val()=="")? 0 : parseFloat($("#payment_type").val()),
				updateAllMakingInfo:1
			},
			beforeSend: function () {
				$("#usuccess").html('<img src="img/loading.gif"/>');
				document.getElementById("update_order").disabled = true;	
			},
			 success: function (response) {
				 console.log(response);
				if(response==1){
					$("#usuccess").html("Update Success!");
				}else{
					$("#usuccess").html("Update Not Success!").css('color','red');
				}
				document.getElementById("update_order").disabled = false;
			}
		});
	}
	
	}
	
	function deleteFabricsOrder(ord_num,dsms_id,fab_head_id,cus_id,cus_mobile){
		var chk="",id_name = "";
		var fab_hidden_id=$("#fab_hidden_id").val();
		if(confirm('Do you want to cancel this order?')){
			$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					ord_num:ord_num,
					dsms_id:dsms_id,
					cus_id:cus_id,
					fab_head_id:fab_head_id,
					cus_mobile:cus_mobile,
					deleteMakingOrder:1
				},
				success: function (response) {
					console.log(response);
					if(response==3){
						$("#usuccess").html('Warning! কারিগর অথবা মাস্টার এর কাছে আইটেম দেওয়া আছে.').css('color','red');
					}else{
						if(parseInt(fab_hidden_id)<=0){
							$("#usuccess").html("Delete Success.");
								closeArea();
								var elem = document.querySelector('#cleft_row' + dsms_id);
								elem.remove();
								
						}else{
							for(var i=1;i<=fab_hidden_id;i++){
								id_name = document.getElementById("edit_fab_qty" + i);
								if (id_name != null) {
									delDetailsAndStock(fab_hidden_id,i,$("#hidden_fs_tbl_id"+i).val(),$("#hidden_purchase_price"+i).val(),fab_head_id,dsms_id,0,$("#hidden_edit_item_id"+i).val(),$("#hidden_edit_fab_qty"+i).val(),'',cus_id);
								}
								//closeArea();
							}
						}
					}
				}
			});
		}
	}
	
	function delDetailsAndStock(last_id,incrementid,deltblid,price,headid,dsms_id,ord_num,item_id,item_qty,cus_mobile,cus_id){
			$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					headid:headid,
					price:price,
					ord_num:ord_num,
					deltblid:deltblid,
					item_id:item_id,
					item_qty:item_qty,
					cus_mobile:cus_mobile,
					cus_id:cus_id,
					delDetailsAndStock:1
				},
				success: function (response) {
					 console.log(response);
					if(response==1){
						$("#usuccess").html("Delete Success.");
						if(last_id==incrementid){
							closeArea();
							 var elem = document.querySelector('#cleft_row' + dsms_id);
							elem.remove();
						}
						
					}
				}
			});
		
	}
	
	function printOrder(){
		var order_number="";
		
		printDiv("summery_report2",order_number);
	}
	
	function printDiv(divName,order_number) {
		var printContents = document.getElementById(divName).innerHTML;
		var originalContents = document.body.innerHTML;
		document.body.innerHTML = printContents;
		window.print();
		document.body.innerHTML = originalContents;
		
	}
	
	
</script>

<style>
.chkbox{
	 -ms-transform: scale(2); /* IE */
  -moz-transform: scale(2); /* FF */
  -webkit-transform: scale(2); /* Safari and Chrome */
  -o-transform: scale(2); /* Opera */
  transform: scale(2);
  padding: 10px;
}

.checkboxtext
{
  /* Checkbox text */
  font-size: 120%;
  display: inline;
  padding-left: 6px;
  padding-right: 40px;
}
#tblhight{
			overflow-y: scroll;
		overflow-x: hidden;
</style>

<?php
	}else{
		header("location:index.php?id=1");
	}
?>
