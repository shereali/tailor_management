
<?php 

	$com_id=$_SESSION['COM_ID'];
	
	$rem_sms=$conn->query("select (select rem_sms from rem_sms where com_id=c.id) remaining,c.status from company c where c.is_active=1 and c.id=$com_id");
	$product=$conn->query("select * from product where is_active=1 and com_id=$com_id and ptype=1 order by id asc");
	mysqli_close($conn);
	if(mysqli_num_rows($rem_sms)>0){
	$srow=mysqli_fetch_array($rem_sms);
?>

<ul class="nav nav-tabs">
	<li class="active"><a data-toggle="tab" href="#home">Direct Sales</a></li>
    <li><a data-toggle="tab" onclick="getOrderDetails();" href="#menu1">View</a></li>
    
</ul>

<div class="tab-content">
    <div id="home" class="tab-pane fade in active">
	<br/>
	<div id="item_head">
	<select id="item_type" onchange="changeType();" style="width:30%;float:left" class="form-control">
			<option value="1">Gents</option>
			<option value="2">Lady</option>
		
	</select>
	<select id="item_id" onchange="itemIdWiseDetails();" style="width:50%;float:left" class="form-control">
			<option value="">Select Any Item</option>
		<?php 
		while($rows=mysqli_fetch_array($product)){
		?>
			<option value="<?php echo $rows['id']."#sep#".$rows['group_id']."#sep#".$rows['product_name']; ?>"><?php echo $rows['product_name']; ?></option>
		<?php 
			}
		?>
	</select>&nbsp;<button onclick="saveMeasurement();" name="btn" value="sub" id="save_measurement" class="btn btn-success">Save</button><span id="dtls_load"></span>
	
	</div>
	<div id="measurement_details" style="color: black;box-shadow: inset 0 0 1em gray;padding: 15px;margin-top: 10px;">
	
	</div>
		
	</div>
	 <div id="menu1" class="tab-pane fade">
      <br/>
    <div class="panel-group">
   <div class="panel panel-info">
      <div class="panel-heading"><?php if($_SESSION['USER_TYPE']==1){
		  ?>
		  <a href="home.php?loc=registration">Create User</a> | <a href="home.php?loc=view">View User</a> | <a href="home.php?loc=purchase">Purchase</a> 
		  <?php 
	  } if($srow['status']==1){ ?> | <a href="home.php?loc=user">Create User</a> |<?php } if($_SESSION['SOFT_TYPE']==1){ ?>  <span style="color:blue">Balance:<span id="rem_sms"> <?php echo @$srow['remaining']; ?></span> SMS</span> <?php } ?></div>
      <div class="panel-body">
	
		<div class="row">
			<div class="col-xs-12 col-sm-4">
				<label for="comment">Delivery Date<sup style="color:red">*</sup>:</label>
				<input type="text" autocomplete="off" name="date1" id="date1" class="form-control" data-select="date">
			</div>
			<div class="col-xs-12 col-sm-4">
				<label for="comment">Mobile Number<sup style="color:red">*</sup>:</label>
				<input type="text" class="form-control" maxlength="11" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" name="mobile" id="mobile" />
			</div>
			<div class="col-xs-12 col-sm-4">
				<label for="comment">Customer Name:</label>
				<input type="text" class="form-control" autocomplete="off" maxlength="30" style="font-weight: bold;font-size:18px;font-style: italic;" name="cus_name" id="cus_name" />
			</div>
			
		</div>
		<div class="row">
			<div class="col-xs-12 col-sm-3">
				<label for="comment">Total Tk<sup style="color:red">*</sup>:</label>
				<input type="text" onkeyup="getAdvance();" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" autocomplete="off" name="total_tk" id="total_tk" required/>
			</div>
			<div class="col-xs-12 col-sm-2">
				<label for="comment">Discount(%) </label>
				<input type="text" onkeyup="getAdvance();" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" autocomplete="off" name="discount" id="discount" value="0" required/>
			</div>
			<div class="col-xs-12 col-sm-2">
				<label for="comment">Payment Type </label>
				<select id="payment_type" class="form-control">
					<option value="1">Cash</option>
					<option value="2">ATM(POS Machine)</option>
					<option value="3">BKash</option>
					<option value="4">Rocket</option>
					<option value="5">Nagad</option>
				</select>
			</div>
			<div class="col-xs-12 col-sm-2">
				<label for="comment">Advance </label>
				<input type="text" onkeyup="getAdvance();" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" autocomplete="off" name="advance_tk" id="advance_tk" required/>
			</div>
			<div class="col-xs-12 col-sm-3">
				<label for="comment">Due </label>
				<input type="text" readonly class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" autocomplete="off" name="due_tk" id="due_tk" required/>
			</div>
		</div>
			<input type="hidden" class="form-control" name="txt_sms" id="txt_sms" />
			<div class="col-xs-12 col-sm-3" style="margin-top:7px;margin-bottom: 15px;float: left;margin: 12px;">
				<input type="checkbox" class="chkbox" checked name="normal" id="normal" value="0"/> <span class="checkboxtext" id="nor">Normal</span>
				<input type="checkbox" class="chkbox" name="emergency" id="emergency" value="1"/> <span class="checkboxtext" id="emg">Urgent</span>
			</div>
				<button onclick="sendSms();" style="margin: 12px;" name="btn" value="sub" id="orderbtn" class="btn btn-success">Save</button>
				
				<button onclick="printOrder();" style="margin: 12px;" name="btn" value="sub" id="orderbtn1" class="btn btn-info">Print</button>
			
			<div class="col-xs-12 col-sm-3" id="print_option">
				<select class="form-control" name="print_type" style="font-weight: bold;font-size:18px;font-style: italic;margin-top: 12px;" id="print_type">
					<option value="1">Customer Copy</option>
					<option value="2">Production Copy</option>
				</select>
			</div>
			<span id="sms"></span>
			<div id="getOrderDetails">
			</div>
	
			
	  </div>
    </div>

  </div>
	 
    </div>
	 <div id="menu2" class="tab-pane fade">
      <br/>
    <span id="summery_report"></span>
	 
    </div>
	
</div>


  
  
  <script>
	window.itema = [];
	window.itemqtya = [];
	function sendSms(){
		var txt_sms=$("#txt_sms").val();
		var date1=$("#date1").val();
		var mobile=$("#mobile").val();
		var total_tk=$("#total_tk").val();
		var advance_tk=$("#advance_tk").val();
		var discount=$("#discount").val();
		var payment_type=$("#payment_type").val();
		var cus_name=$("#cus_name").val();
		var lastid=$("#last_ids").val();
		var tot_cus_price=$("#tot_cus_price").val();
		var order_type="";
		if ($("#normal").is(":checked")) {
			order_type=$("#normal").val();
		}
		if ($("#emergency").is(":checked")) {
			order_type=$("#emergency").val();
		}
		
		if(lastid>0){
		for(var i=0;i<lastid;i++){
				itema.push($("#item"+i).val());
				itemqtya.push($("#item_qty"+i).val());
		}
		
		var all_itema = itema.join('#sep#');
		var all_itemqtya = itemqtya.join('#sep#');
		}else{
			all_itema="";
			all_itemqtya="";
		}
		
		 
		var t="",m="",e="",ttk="",ord_no="",adv="",tcp="";
		
		if(tot_cus_price==0){
			$("#sms").show();			
			$("#sms").html("No Order Found!").css("color","red");
			tcp=1;
		}else{
			$("#sms").html(null);
		}
		if(date1==""){
			$("#date1").css("border-color","red");
			t=1;
		}else{
			$("#date1").css("border-color","#CCCCCC");
		}
		if(mobile=="" || mobile.length<11 || mobile.length>11){
			$("#mobile").css("border-color","red");
			m=1;
		}else{
			$("#mobile").css("border-color","#CCCCCC");
		}
		if(total_tk==""){
			$("#total_tk").css("border-color","red");
			ttk=1;
		}else{
			$("#total_tk").css("border-color","#CCCCCC");
		}
		if(discount==""){
			$("#discount").css("border-color","red");
			ord_no=1;
		}else{
			$("#discount").css("border-color","#CCCCCC");
		}
		
		
		var chkmobile =mobile.split(",");
		if(chkmobile.length>1 && chkmobile.length==0){
			$("#mobile").css("border-color","red");
			e=1;
		}
		
	if(m==1 || t==1 || e==1 || ttk==1 || ord_no==1 || tcp==1){
			exit();
		}else{
			document.getElementById("orderbtn").disabled = true;
			
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						payment_type:payment_type,all_itemqtya:all_itemqtya,all_itema:all_itema,advance_tk:advance_tk,discount:discount,total_tk:total_tk,txt_sms: txt_sms,mobile:mobile,date1:date1,tag:1,order_type:order_type,cus_name:cus_name,btn:1
					},
					 beforeSend: function () {
						$("#sms").show();
						$("#sms").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						document.getElementById("orderbtn").disabled = false;
						if(response==20000000){
							$("#sms").html("Invalid Text SMS!").css("color","red");
						}else if(response==10000000){
							$("#sms").html("SMS Not Available!").css("color","red");
						}else if(response==30000000){
							window.location.href = "signout.php";
						}else if(response==40000000){
							$("#sms").html("SMS Not Available!").css("color","red");
						}else{
							var sp=response.split("#sep#");
							console.log(sp[3]);
							//$("#rem_sms_hidden").val(sp[0]);
							$("#sms").html("Order Success!").css("color","green");
							$("#print_option").show();
							$("#rem_sms").html(sp[0]);
							//$("#tag").html("Tag No: "+sp[1]);
							$("#mobile").val(null);
							$("#date1").val(null);
							//$("#order_no").val(null);
							$("#total_tk").val(null);
							$("#advance_tk").val(null);
							$("#due_tk").val(null);
							$("#discount").val(0);
							$("#cus_name").val(null);
							for(var i=0;i<lastid;i++){
								$("#ord_date"+i).html(sp[1]);
								$("#ord_date2"+i).html(sp[1]);
								$("#del_date"+i).html(sp[2]);
								$("#del_date2"+i).html(sp[2]);
								$("#delOrder"+i).hide();
							}
							$("#getOrderDetails").prepend(sp[3]);
							$('#normal').prop('checked', true);
							$('#emergency').prop('checked', false);
							$("#nor").css('color','black');
							$("#emg").css('color','#E0E0E0');
							window.itema = [];
							window.itemqtya = [];
						}
					 }
			});
		}
		
	}
	
	function changeType(){
		var item_type=$("#item_type").val();
		$.ajax({
						type: 'post',
						url: 'ajax.php',
						data: {
							item_type:item_type,select_item_type:1
						},
						 beforeSend: function () {
							$("#sms").show();
							$("#sms").html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							$("#sms").hide();
							$("#item_id").html(response);
						
						}
			});
	}
	
	function getAdvance(){
		var total_tk=$("#total_tk").val();
		var discount=$("#discount").val();
		if(total_tk!="" || parseFloat(total_tk)>=0){
		if(parseFloat(discount)>=0 || discount!=""){
		var due=(parseFloat(total_tk)-((parseFloat(total_tk)*parseFloat(discount))/100));
		$("#due_tk").val(due);
		$("#discount").css("border-color","#CCCCCC");
		}else{
			$("#discount").css("border-color","red");
		}
		$("#total_tk").css("border-color","#CCCCCC");
		}else{
			$("#total_tk").css("border-color","red");
		}
		var advance_tk=$("#advance_tk").val();
		if(parseFloat(advance_tk)>=0){
			$("#due_tk").val(due-parseFloat(advance_tk));
		}else{
			$("#due_tk").val(due);
		}
	}
	
	function getOrderDetails(){
			$.ajax({
						type: 'post',
						url: 'ajax.php',
						data: {
							get_order_details:1
						},
						 beforeSend: function () {
							$("#sms").show();
							$("#sms").html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							$("#sms").hide();
							$("#getOrderDetails").html(response);
							setCusTotalPrice();
						}
			});
		
	}
	
	function setCusTotalPrice(){
		$("#total_tk").val($("#tot_cus_price").val());
	}
	
	function delOrderFnc(ord_num,sl){
	document.getElementById("delOrder"+sl).disabled = true;
		$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					ord_num:ord_num,delOrderFnc:1
				},
					 beforeSend: function () {
						$("#sms").show();
						$("#sms").html('<img src="img/loading.gif"/>');
					},
						success: function (response) {
						console.log(response);
						if(response==1){
						$("#sms").hide();
						getOrderDetails();
						}else{
							$("#sms").html("Not Success!").css("color","red");;
						}
					}
			});
	}
	
	
	
	function itemIdWiseDetails(){
		var item_id=$("#item_id").val();
		var item_type=$("#item_type").val();
		if(item_id!=""){
			$.ajax({
						type: 'post',
						url: 'ajax.php',
						data: {
							item_type:item_type,item_id:item_id,get_item_detail:1
						},
						 beforeSend: function () {
							$("#dtls_load").show();
							$("#dtls_load").html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							if(response!=2){
							$("#dtls_load").hide();
							$("#measurement_details").html(response).css("color","black");
							}else{
								$("#dtls_load").hide();
								$("#measurement_details").html("No Result Found!").css("color","red");
							}
						}
			});
		}else{
			$("#measurement_details").html(null);
		}
	}
	
	window.sizea = [];
	window.sizeida = [];
	window.properticetitlea = [];
	window.properticea = [];
	window.exproperticea = [];
	function saveMeasurement(){
		var item_id=$("#item_id").val();
		var item_type=$("#item_type").val();
		var phy_ord_num=$("#phy_ord_num").val();
		var tbl_ord_num=$("#tbl_ord_num").val();
		var item_qty=$("#item_qty").val();
		var master_id=$("#master_id").val();
		var karigor_id=$("#karigor_id").val();
		var sizetot=$("#sizetot").val(); //sizetxt
		var propertice_title_tot=$("#propertice_title_tot").val(); //propertice
		var expropertice_tot=$("#expropertice_tot").val(); //expropertice expropertice_tot
		var i="",m="",ep="",epc=0,iid="",jj="";
		
		if(phy_ord_num==""){
			$("#phy_ord_num").css("border-color","red");
			jj=1;
		}else{
			$("#phy_ord_num"+i).css("border-color","#CCCCCC");
		}
		
		if(item_qty==""){
			$("#item_qty").css("border-color","red");
			iid=1;
		}else{
			$("#item_qty"+i).css("border-color","#CCCCCC");
		}
		for(i=0; i<sizetot; i++){
			//if($("#size"+i).val()==""){
				//$("#size"+i).css("border-color","red");
				//$("#dtls_load").html("Select Size!").css("border-color","red");
				//m=1;
			if($("#size"+i).val()!=""){
				$("#size"+i).css("border-color","#CCCCCC");;
				sizea.push($("#size"+i).val());
				sizeida.push($("#sizetxt"+i).val());
			}
		}
		for(i=0; i<propertice_title_tot; i++){
				properticetitlea.push($("#propertice_title"+i).val());
				if($("#propertice"+i).val()!=""){
					properticea.push($("#propertice"+i).val());
				}else{
				properticea.push(0);
				}
		}
		if(expropertice_tot!=0){
			for(i=0; i<expropertice_tot; i++){
					if ($('#expropertice'+i).is(":checked")){
						exproperticea.push($("#expropertice"+i).val());
					}else{
						epc++;
					}
			}
			if(expropertice_tot==epc){
				$("#dtls_load").show();
				$("#dtls_load").html("Select Any Propertice!").css("color","red");
				ep=1;
				}
				var all_exproperticea = exproperticea.join('#sep#');
		}else{
			var all_exproperticea =0;
		}
		
		console.log(expropertice_tot+"= "+epc);
		console.log("size id: "+sizeida);
		console.log("size p: "+sizea);
		console.log("ex p: "+exproperticea);
		console.log("p t: "+properticetitlea);
		console.log("p : "+properticea);
		
		var all_sizeida = sizeida.join('#sep#');
		var all_sizea = sizea.join('#sep#');
		var all_properticetitlea = properticetitlea.join('#sep#');
		var all_properticea = properticea.join('#sep#');
		
		
		if(ep==1 || iid==1 || jj==1){ //m==1 || 
			sizeida = [];
			sizea = [];
			exproperticea = [];
			properticetitlea = [];
			properticea = [];
			exit();
		}else{
			document.getElementById("save_measurement").disabled = true;
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						item_id:item_id,
						all_sizeida:all_sizeida,
						all_sizea:all_sizea,
						all_properticetitlea:all_properticetitlea,
						all_properticea:all_properticea,
						all_exproperticea:all_exproperticea,
						phy_ord_num:phy_ord_num,
						tbl_ord_num:tbl_ord_num,
						item_qty:item_qty,
						master_id:master_id,
						karigor_id:karigor_id,
						item_type:item_type,
						add_order:1
					},
					 beforeSend: function () {
						$("#dtls_load").show();
						$("#dtls_load").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response==1){
							$("#dtls_load").html("Save Success!").css("color","green");
							$("#measurement_details").html(null);
						}else{
							$("#dtls_load").html("No result found!").css("color","red");
							}
						document.getElementById("save_measurement").disabled = false;
						sizeida = [];
						sizea = [];
						exproperticea = [];
						properticetitlea = [];
						properticea = [];
					}
			});
		}
	}
	
	
	function getDeliverySummary(){
		$(".btn-cancel").click();
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						getDeliverySummary:1
					},
					 beforeSend: function () {
						$("#summery_report").show();
						$("#summery_report").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response==1){
							$("#summery_report").html("No result found!").css("color","red");
						}else{
							$("#summery_report").html(response);
							$("#stdv").html("Pending Delivery: "+$("#tdev").val()+" (In 30 days)");
						}
					}
		});
	}
	
	$(document).ready(function(){
		$("#print_option").hide();
		$('#normal').prop('checked', true);
		$("#emg").css('color','#E0E0E0');
		$('#normal').click(function () {
			if ($(this).is(":checked")) {
				$('#emergency').prop('checked', false);
				$("#nor").css('color','black');
				$("#emg").css('color','#E0E0E0');
			}else{
				$('#emergency').prop('checked', true);
				$("#emg").css('color','black');
				$("#nor").css('color','#E0E0E0');
			}
		});
		$('#emergency').click(function () {
			if ($(this).is(":checked")) {
				$('#normal').prop('checked', false);
				$("#emg").css('color','black');
				$("#nor").css('color','#E0E0E0');
			}else{
				$('#normal').prop('checked', true);
				$("#emg").css('color','black');
				$("#nor").css('color','#E0E0E0');
			}
		});
	
	});
	
	function printOrder(){
		var print_type=$("#print_type").val();
		if(print_type==1){
			printDiv("print_area");
		}else{
		printDiv("print_main_body");
		}
	}
	
	function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

    window.print();
	
	  
	document.body.innerHTML = originalContents;
	
	 
}
	
</script>

<style>
.chkbox{
	 -ms-transform: scale(2); /* IE */
  -moz-transform: scale(2); /* FF */
  -webkit-transform: scale(2); /* Safari and Chrome */
  -o-transform: scale(2); /* Opera */
  transform: scale(2);
  padding: 10px;
}

.checkboxtext
{
  /* Checkbox text */
  font-size: 120%;
  display: inline;
  padding-left: 6px;
  padding-right: 40px;
}
#tblhight{
			overflow-y: scroll;
		overflow-x: hidden;
</style>

<?php
	}else{
		header("location:index.php");
	}
?>
