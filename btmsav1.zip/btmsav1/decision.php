
<?php 
	if(isset($_SESSION['COM_ID'])){
		$com_id=$_SESSION['COM_ID'];
		$psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,ds.cus_mobile umobile,ds.phy_ord_num,ds.amount,ds.cus_name,ds.factory_status,ds.fddate from dsms ds where ds.is_active=1 and ds.phy_dv_date IS NULL and ds.occasion=0 and ds.order_type=1 and ds.factory_status not in(1,2) and ds.com_id='$com_id' order by ds.id asc limit 0,10");
		
?>

<ul class="nav nav-tabs">
		<?php 
		if($_SESSION['URGENT']==1){
		?>
    <li class="active"><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" href="#home">Urgent</a></li>
	<?php 
		}
		if($_SESSION['TODAYS']==1){
		?>
    <li><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" onclick="toDayDelivery();" href="#menu1">Todays</a></li>
	<?php 
		}
		if($_SESSION['TOMORROW']==1){
		?>
    <li><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" onclick="tomorrowDelivery();" href="#menu2">Tomorrow</a></li>
	<?php 
		}
		if($_SESSION['N3D']==1){
		?>
   <li><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" onclick="next3DayDelivery();" href="#menu3">N2D</a></li>
   <?php 
		}
		if($_SESSION['N3D']==1){
		?>
		<li><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" onclick="pendingDelivery();" href="#menu4">Expired Delivery</a></li>
   <?php 
		}
	?>
	
</ul>

<div class="tab-content">
    <div id="home" class="tab-pane fade in active">
	<br/>
     
	 <?php 
	 if(mysqli_num_rows($psmsquery)>0){
		?>
		<div class="panel-group">
	 <div id="show_history">
   <?php 
			$i=1;
			$date=date("Y-m-d");
			
				while($row=mysqli_fetch_array($psmsquery)){
					$j=$i++;
					$sms_id=$row['id'];
					$sms_status=$row['sms_status'];
					$dv_date=explode("-",$row['dv_date']);
					$dv_date=$dv_date[2]."/".$dv_date[1]."/".$dv_date[0];
					$dv_date=$row['fddate'];
					@$txt_sms=$row['txt_sms'];
					@$tagnum=$row['tagnum'];
					@$order_type=$row['order_type'];
					@$phy_ord_num=$row['phy_ord_num'];
					@$amount=$row['amount'];
					
					@$umobile=$row['umobile']; 
					
				$chk_com_p=$conn->query("SELECT (select product_name from product where id=sd.item_id) pname,sd.item_qty pqty,sd.order_number,sd.id ord_id,sd.receive_qty FROM `order_record` sd WHERE sd.com_id=$com_id and sd.is_active=1 and sd.dsms_id=$sms_id");
			
			?>
	
   <div class='panel panel-info'>
      <div class="panel-heading"><?php  echo $j.". (".date('d/m/Y',strtotime($row['indate'])).")"; if($sms_status==0) echo " pending "; else echo " sent "; ?></div>
	 
      <div class="panel-body">
			<div class="row">
			<div class="col-xs-12 col-sm-6">
				<p for="comment">Serial: 
				<span style='cursor: pointer;color:red;font-weight:bold' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$row['phy_ord_num']; ?>')">
					<?php echo $row['phy_ord_num']; ?>
				</span>
				</p>
				<p for="comment">Customer Name: <b><?php echo $row['cus_name']; ?></b></p>
				<p for="comment">Mobile Number: <b><?php echo $umobile; ?></b></p>
				<p for="comment" style="color:blue">Production Receive: <b><?php echo ($row['factory_status']==1 || $row['factory_status']==2)? "Yes" : "No"; ?></b></p>
				<p for="comment">Factory Delivery Date: <b><?php echo $dv_date; ?></b></p>
					<input type="hidden" style="font-weight: bold;font-size:18px;font-style: italic;" name="date1" id="date1<?php echo $j; ?>" value="<?php echo $dv_date; ?>" class="form-control" data-select="date">
					<input type="hidden"  name="cus_name" id="cus_name<?php echo $j; ?>" value="<?php echo $row['cus_name']; ?>" />
					<input type="hidden" name="mobile"  id="mobile<?php echo $j; ?>" value="<?php echo $umobile; ?>" />
					<input type="hidden"  name="org_dv_date" id="org_dv_date<?php echo $j; ?>" value="<?php echo $dv_date; ?>" />
					<input type="hidden"  name="sms_id" id="sms_id<?php echo $j; ?>" value="<?php echo $sms_id; ?>" />
				
				
			</div>
			<div class="col-xs-12 col-sm-6">
				<span for="">Dress Details:</span>
				<table id="example" class="table table-striped table-bordered">
				
					<thead>
						<tr>
							<th>SL</th>
							<th>Dress/Order Number</th>
							<th>Qty</th>
						</tr>
					</thead>
					<tbody>
					<?php 
					$jj=1;
					while($rrows=mysqli_fetch_array($chk_com_p)){
						$pname=$rrows['pname'];
						$pqty=$rrows['pqty'];
						$order_number=$rrows['order_number'];
						$receive_qty=$rrows['receive_qty'];
						if($receive_qty<$pqty){
							$rd="<span id='dqty$jj$j'>($receive_qty)</span>";
						}else{
							$rd="<span style='color:blue' id='dqty$jj$j'>($receive_qty)</span>";
						}
						?>
						<tr>
							<td>
								<b><?php echo $jj++; ?></b>
							</td>
							<td><b>
								<?php echo $pname." ".$rd; ?>
							</b>
							</td>
							<td><b>
								<?php echo $pqty; ?>
							</b>
							</td>
						
						</tr>
						<?php  
					}
					
					?>
					</tbody>
				</table>
				<!--<button onclick="sendUrgent('<?php echo $j; ?>');" name="btn" value="sub" id="urg_btn<?php echo $j; ?>" class="btn btn-success">Update</button>-->
				<span id="urgsms<?php echo $j; ?>"></span>
			</div>
		</div>
			
	  </div>
	 
		</div>
		
	 <?php } ?>
	
	
</div>	
 <?php 
	if(mysqli_num_rows($psmsquery)>9){
	 ?>
	 <div class="form-group" style="margin-top:15px">
	  <button onclick="seaMoreUrgent();" name="btn" id="moreUrgentbtn" class="btn btn-danger">More+</button><span id="load_img_urgent"></span>
	  </div>
		<?php } ?>
<input type="hidden" id="urgent_last_id" value="10"/>
 </div>
	
		<?php
		
		}else{
			echo "<span style='color:red'>No Result Found!</span>";
		}
		mysqli_close($conn);
	 ?>
	
	</div>
	 <div id="menu1" class="tab-pane fade">
       <br/>
     <span id="nddd"></span>
	 <input type="hidden" id="today_last_id" value="10"/>
    </div>
	<div id="menu2" class="tab-pane fade">
     <br/>
		 <span id="tomorrow"></span>
		 <input type="hidden" id="tomorrow_last_id" value="10"/>
    </div>
	<div id="menu3" class="tab-pane fade">
		 <br/>
		 <span id="ndd"></span>
		 <input type="hidden" id="n3d_last_id" value="10"/>
    </div>
	<div id="menu4" class="tab-pane fade">
     <br/>
		 <span id="expired_delivery"></span>
		 <input type="hidden" id="expired_delivery_last_id" value="10"/>
    </div>
</div>

 <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" id="heading_id"></h4>
        </div>
        <div class="modal-body">
          <span id="smeasurement"></span>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
  
  <script>
  
  	function urgent(){
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						urgentbtn:1
					},
					 beforeSend: function () {
						$("#urgss").show();
						$("#urgss").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response==1){
							$("#urgss").html("No result found!").css("color","red");
						}else{
							$("#urgss").html(response);
						}
					 }
			});
	}
	
	
	function sendUrgent(id){
		var mobile=$("#mobile"+id).val();
		var date1=$("#date1"+id).val();
		var sms_id=$("#sms_id"+id).val();
		var org_dv_date=$("#org_dv_date"+id).val();
		var cus_name=$("#cus_name"+id).val();
		var t="",m="",d="";
		
		if(mobile=="" || mobile.length<11 || mobile.length>11){
			$("#mobile"+id).css("border-color","red");
			m=1;
		}else{
			$("#mobile"+id).css("border-color","#CCCCCC");
		}
		
		if(date1==""){
			$("#date1"+id).css("border-color","red");
			d=1;
		}else{
			$("#date1"+id).css("border-color","#CCCCCC");
		}
		
		var chkmobile =mobile.split(",");
		if(chkmobile.length>1){
			$("#mobile").css("border-color","red");
			m=1;
		}else{
			$("#mobile").css("border-color","#CCCCCC");
		}
		
		if(m==1 || d==1){
			exit();
		}else{
			document.getElementById("urg_btn"+id).disabled = true;
			if(confirm("আপনি কি কাস্টমার এর মোবাইল নম্বর এ SMS পাঠাতে চান?")){		
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						mobile:mobile,date1:date1,hide_sms_id:sms_id,date_org:org_dv_date,only_date_update:1
					},
					 beforeSend: function () {
						$("#urgsms"+id).show();
						$("#urgsms"+id).html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
					/*	if(response==20000000){
							$("#urgsms"+id).html("Invalid Text SMS!").css("color","red");
						}else if(response==10000000){
							$("#urgsms"+id).html("SMS Not Available!").css("color","red");
						}else if(response==40000000){
							$("#urgsms"+id).html("Invalid Mobile No.!").css("color","red");
						}else if(response==30000000){
							window.location.href = "signout.php";
						}else{
						$("#urgsms"+id).html("Update Success!").css("color","green");
						
						}*/
						
						if(response==10000000){
							$("#urgsms"+id).html("Insufficient (SMS) Balance").css("color","red");;
							document.getElementById("urg_btn"+id).disabled = true;
						}
						else if(response==1){
							$("#urgsms"+id).html("Update Not Success").css("color","red");;
							document.getElementById("urg_btn"+id).disabled = true;
						
						}else if(response==20000000){
							$("#urgsms"+id).html("Warning! Server Busy.").css("color","red");;
							document.getElementById("urg_btn"+id).disabled = true;
						}else if(response==40000000){
							$("#urgsms"+id).html("No Internet Connection").css("color","red");;
							document.getElementById("urg_btn"+id).disabled = true;
						}else{
							$("#urgsms"+id).html("Update Success").css("color","green");;
							document.getElementById("urg_btn"+id).disabled = false;	
						}
						
					 }
			});
			}
		}
		
	}
	
	
	function next3DayDelivery(){
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						nddbtn:1
					},
					 beforeSend: function () {
						$("#ndd").show();
						$("#ndd").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response==1){
							$("#ndd").html("No result found!").css("color","red");
						}else{
							$("#ndd").html(response);
						}
					 }
			});
	}
	
	function pendingDelivery(){
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						pendingDelivery:1
					},
					 beforeSend: function () {
						$("#expired_delivery").show();
						$("#expired_delivery").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response==1){
							$("#expired_delivery").html("No result found!").css("color","red");
						}else{
							$("#expired_delivery").html(response);
						}
					 }
			});
	}
	
	function showMeasurement(sl,ord_num){
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					ord_num:ord_num,smeasurement:1
				},
				 beforeSend: function () {
					$("#smeasurement").html('<img src="img/loading.gif"/>');
				},
				 success: function (response) {
					console.log(response);
					$("#heading_id").html("Measurement");
					$("#smeasurement").html(response);
				}
		});
	}
	
	function tomorrowDelivery(){
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						tomorrowDelivery:1
					},
					 beforeSend: function () {
						$("#tomorrow").show();
						$("#tomorrow").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response==1){
							$("#tomorrow").html("No result found!").css("color","red");
						}else{
							$("#tomorrow").html(response);
						}
					 }
			});
	}

	
	function toDayDelivery(){
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						todays_delivery:1
					},
					 beforeSend: function () {
						$("#nddd").show();
						$("#nddd").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response==1){
							$("#nddd").html("No result found!").css("color","red");
						}else{
							$("#nddd").html(response);
						}
					}
		});
}

function orderDeliveryBtn(div_id){
		var hide_sms_id=$("#hide_sms_id"+div_id).val();
		var hide_due=$("#hide_due"+div_id).val();
		var total_tk=$("#total_tk"+div_id).val();
		var discount=$("#discount"+div_id).val();
		var discount_tot=$("#discount_tot"+div_id).val();
		var paytxt="";
		if(hide_due!=0){
			if($("#paytxt"+div_id).val()==""){
			$("#order_delivery_sms"+div_id).html("Enter Due!").css("color","red");
			exit();
			}else{
				paytxt=$("#paytxt"+div_id).val();
			}
		}
		
		if(parseFloat(hide_due)<0){
			$("#order_delivery_sms"+div_id).html("Invalid! Delete any pay.").css("color","red");
			exit();
		}
		
		if(parseFloat(paytxt)>parseFloat(hide_due)){
			$("#order_delivery_sms"+div_id).html("Invalid! Enter correct pay.").css("color","red");
			exit();
		}
		
		document.getElementById("order_delivery"+div_id).disabled = true;
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						discount_tot:discount_tot,discount:discount,div_id:div_id,total_tk:total_tk,paytxt:paytxt,hide_sms_id:hide_sms_id,orderDeliveryBtn:1
					},
					 beforeSend: function () {
						$("#order_delivery_sms"+div_id).show();
						$("#order_delivery_sms"+div_id).html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						//document.getElementById("order_delivery").disabled = false;
						if(response!=2){
							$("#order_delivery_sms"+div_id).html("Success!").css("color","green");
							var sp=response.split("#sep#");
							$("#phy_dv_date"+div_id).html(sp[0]);
							$("#payment_tbl"+div_id).html(sp[1]);
						}else{
							$("#order_delivery_sms"+div_id).html("Not Success!").css("color","red");
						}
					 }
			});
		
	}
	
		function payTk(div_id){
		var paytxt=$("#paytxt"+div_id).val();
		var dsms_ids=$("#dsms_ids"+div_id).val();
		var total_tk=$("#total_tk"+div_id).val();
		var discount=$("#discount"+div_id).val();
		var discount_tot=$("#discount_tot"+div_id).val();
		document.getElementById("paybtns"+div_id).disabled = true;
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						discount_tot:discount_tot,discount:discount,div_id:div_id,total_tk:total_tk,dsms_ids:dsms_ids,paytxt:paytxt,payTk:1
					},
					 beforeSend: function () {
						$("#stksms"+div_id).show();
						$("#stksms"+div_id).html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						if(response!=2){
							$("#payment_tbl"+div_id).html(response);
						}else{
							$("#stksms"+div_id).html("Not Success!").css("color","red");
						}
					 }
			});
	}
	
	function delPay(accounting_tbl_id,div_id){
		var dsms_ids=$("#dsms_ids"+div_id).val();
		var total_tk=$("#total_tk"+div_id).val();
		var discount=$("#discount"+div_id).val();
		var discount_tot=$("#discount_tot"+div_id).val();
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						discount_tot:discount_tot,discount:discount,div_id:div_id,total_tk:total_tk,dsms_ids:dsms_ids,accounting_tbl_id:accounting_tbl_id,delPay:1
					},
					 beforeSend: function () {
						$("#stksms"+div_id).show();
						$("#stksms"+div_id).html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						if(response!=2){
							$("#payment_tbl"+div_id).html(response);
						}else{
							$("#stksms"+div_id).html("Not Success!").css("color","red");
						}
					 }
			});
	}

	
	$(document).ready(function(){
		$('#urgss').hide();
	
	});
	
	
	function seaMoreUrgent(){
	seaMoreInfo($("#urgent_last_id").val());

	document.getElementById("moreUrgentbtn").disabled = true;	
	}

function seaMoreInfo(last_id){
			$.ajax({
					type: 'post',
					url: 'ajax.php',
					data: {
						last_id: last_id,page: 'more_urgent',page_btn:1
					},
					 beforeSend: function () {
						$("#load_img_urgent").show();
						$("#load_img_urgent").html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						$("#load_img_urgent").hide();
						if(response!=2){
						$("#show_history").append(response);
						$("#urgent_last_id").val((parseInt(last_id)+10));
						document.getElementById("moreUrgentbtn").disabled = false;	
						}else{
							$("#urgent_last_id").val(0);
							document.getElementById("moreUrgentbtn").disabled = true;
						}
					}
			});
	}
	
	function seaMoreToday(){
		seaMoreInfoToday($("#today_last_id").val());
		document.getElementById("moreTodaytbtn").disabled = true;	
	}
	
	function seaMoreInfoToday(last_id){
			$.ajax({
					type: 'post',
					url: 'ajax.php',
					data: {
						last_id: last_id,page: 'more_today',page_btn:1
					},
					 beforeSend: function () {
						$("#load_img_today").show();
						$("#load_img_today").html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						$("#load_img_today").hide();
						if(response!=2){
						$("#todays_delivery_ord").append(response);
						$("#today_last_id").val((parseInt(last_id)+10));
						document.getElementById("moreTodaytbtn").disabled = false;	
						}else{
							$("#today_last_id").val(0);
							document.getElementById("moreTodaytbtn").disabled = true;
						}
					}
			});
	}
	
	function seaMoreTomorrow(){
		seaMoreInfoTomorrow($("#tomorrow_last_id").val());
		document.getElementById("moreTomorrowtbtn").disabled = true;	
	}
	
	function seaMoreInfoTomorrow(last_id){
			$.ajax({
					type: 'post',
					url: 'ajax.php',
					data: {
						last_id: last_id,page: 'more_tomorrow',page_btn:1
					},
					 beforeSend: function () {
						$("#load_img_tomorrow").show();
						$("#load_img_tomorrow").html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						$("#load_img_tomorrow").hide();
						if(response!=2){
						$("#romorrow_display").append(response);
						$("#tomorrow_last_id").val((parseInt(last_id)+10));
						document.getElementById("moreTomorrowtbtn").disabled = false;	
						}else{
							$("#tomorrow_last_id").val(0);
							document.getElementById("moreTomorrowtbtn").disabled = true;
						}
					}
			});
	}
	
	function seaMoreExpiredDelivery(){
		seaMoreExpiredDeliveryInfo($("#expired_delivery_last_id").val());
		document.getElementById("moreExpiredtbtn").disabled = true;	
	}
	
	function seaMoreExpiredDeliveryInfo(last_id){
			$.ajax({
					type: 'post',
					url: 'ajax.php',
					data: {
						last_id: last_id,page: 'more_expired',page_btn:1
					},
					 beforeSend: function () {
						$("#load_img_expired").show();
						$("#load_img_expired").html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						$("#load_img_expired").hide();
						if(response!=2){
						$("#expired_display").append(response);
						$("#expired_delivery_last_id").val((parseInt(last_id)+10));
						document.getElementById("moreExpiredtbtn").disabled = false;	
						}else{
							$("#expired_delivery_last_id").val(0);
							document.getElementById("moreExpiredtbtn").disabled = true;
						}
					}
			});
	}
	
	function seaMoreN3d(){
		seaMoreInfoN3d($("#n3d_last_id").val());
		document.getElementById("moreN3dtbtn").disabled = true;	
	}
	
	function seaMoreInfoN3d(last_id){
			$.ajax({
					type: 'post',
					url: 'ajax.php',
					data: {
						last_id: last_id,page: 'more_n3d',page_btn:1
					},
					 beforeSend: function () {
						$("#load_img_n3d").show();
						$("#load_img_n3d").html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						$("#load_img_n3d").hide();
						if(response!=2){
						$("#n3d_display").append(response);
						$("#n3d_last_id").val((parseInt(last_id)+10));
						document.getElementById("moreN3dtbtn").disabled = false;	
						}else{
							$("#n3d_last_id").val(0);
							document.getElementById("moreN3dtbtn").disabled = true;
						}
					}
			});
	}
	
	function onlyDateUpdateBtn(sl){
		var date1=$("#date2"+sl).val();
		var date_org=$("#date_org"+sl).val();
		var hide_sms_id=$("#hide_sms_ids"+sl).val();
		var mobile=$("#mobilet"+sl).val();
		if(date1==""){
			$("#date1"+sl).css("border-color","red");
			exit();
		}else{
			$("#date1"+sl).css("border-color","#CCCCCC");
			document.getElementById("only_dateupdate"+sl).disabled = true;	
	if(confirm("আপনি কি কাস্টমার এর মোবাইল নম্বর এ SMS পাঠাতে চান?")){	
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						mobile:mobile,date_org:date_org,hide_sms_id: hide_sms_id,date1:date1,only_date_update:1
					},
					 beforeSend: function () {
						$("#only_date_update_sms"+sl).show();
						$("#only_date_update_sms"+sl).html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						//$("#only_date_update_sms"+sl).hide();
						if(response==10000000){
							$("#only_date_update_sms"+sl).html("Insufficient (SMS) Balance").css("color","red");;
							document.getElementById("only_dateupdate"+sl).disabled = true;
						}
						else if(response==1){
							$("#only_date_update_sms"+sl).html("Update Not Success").css("color","red");;
							document.getElementById("only_dateupdate"+sl).disabled = true;
						
						}else if(response==20000000){
							$("#only_date_update_sms"+sl).html("Warning! Server Busy.").css("color","red");;
							document.getElementById("only_dateupdate"+sl).disabled = true;
						}else if(response==40000000){
							$("#only_date_update_sms"+sl).html("No Internet Connection").css("color","red");;
							document.getElementById("only_dateupdate"+sl).disabled = true;
						}else{
							//$("#date1"+sl).val(response);
							$("#only_date_update_sms"+sl).html("Update Success").css("color","green");;
							document.getElementById("only_dateupdate"+sl).disabled = false;	
						}
					}
			});
	}
		}
	}
	
	function productionReceiveBtn(div_id){
		var hide_sms_id=$("#hide_sms_id"+div_id).val();
		document.getElementById("order_receive"+div_id).disabled = true;
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						div_id:div_id,hide_sms_id:hide_sms_id,productionReceiveBtn:1
					},
					 beforeSend: function () {
						$("#order_deny_sms"+div_id).show();
						$("#order_deny_sms"+div_id).html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						
						if(response==1){
							$("#order_deny_sms"+div_id).html("Receive Success!").css("color","green");
						}else{
							$("#order_deny_sms"+div_id).html("Not Success!").css("color","red");
						}
					 }
			});
	}
	
	function productionReceiveBtns(div_id){
		var hide_sms_id=$("#hide_sms_ids"+div_id).val();
		document.getElementById("order_receives"+div_id).disabled = true;
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						div_id:div_id,hide_sms_id:hide_sms_id,productionReceiveBtn:1
					},
					 beforeSend: function () {
						$("#order_deny_smss"+div_id).show();
						$("#order_deny_smss"+div_id).html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						
						if(response==1){
							$("#order_deny_smss"+div_id).html("Receive Success!").css("color","green");
						}else{
							$("#order_deny_smss"+div_id).html("Not Success!").css("color","red");
						}
					 }
			});
	}
	
	
</script>

<style>
.chkbox{
	 -ms-transform: scale(2); /* IE */
  -moz-transform: scale(2); /* FF */
  -webkit-transform: scale(2); /* Safari and Chrome */
  -o-transform: scale(2); /* Opera */
  transform: scale(2);
  padding: 10px;
}

.checkboxtext
{
  /* Checkbox text */
  font-size: 120%;
  display: inline;
  padding-left: 6px;
  padding-right: 40px;
}
#tblhight{
			overflow-y: scroll;
		overflow-x: hidden;
</style>

<?php
	}else{
		header("location:index.php?id=1");
	}
?>
