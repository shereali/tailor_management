<?php 
ini_set('max_execution_time', 600); //300 seconds = 5
include'db.php';
include'library.php';

if(isset($_REQUEST['executeQuery'])){
		$ex_query=$_REQUEST['ex_query'];
		$query_all=$conn->query($ex_query);
		if($query_all){
			echo 1;
		}
	}
	
	if(isset($_REQUEST['clearDb'])){
		@$drive_name=trim($_REQUEST['drive_name']);
		$loc=':\wamp64\www\btmsav1\dbclear_dbbackup.bat';
		if(exec($drive_name.$loc)){
			$conn->query("truncate table accounting");
			$conn->query("truncate table customer");
			$conn->query("truncate table direct_sale");
			$conn->query("truncate table direct_sale_head");
			$conn->query("truncate table dsms");
			$conn->query("truncate table dsms_mobile");
			$conn->query("truncate table dsms_mobile_occasion");
			$conn->query("truncate table dsms_occasion");
			$conn->query("truncate table emp_salary");
			$conn->query("truncate table expenses");
			$conn->query("truncate table extra_mobile");
			$conn->query("truncate table feg_order");
			$conn->query("truncate table order_details");
			$conn->query("truncate table order_num");
			$conn->query("truncate table order_record");
			$conn->query("truncate table point_tbl");
			$conn->query("truncate table security");
			$conn->query("truncate table transaction");
			$conn->query("truncate table update_due");
			$conn->query("truncate table user");
			$conn->query("truncate table stock_adjustment");
			
			echo 1;
		}
	}
	
	
	
	if(isset($_REQUEST['saveSetUpInfo'])){
		if(check_internet_connection()==1){
			$com_id=$_REQUEST['shop_id'];
			$response = file_get_contents("http://bmmsbd.com/api/data.php?com_id=$com_id&chk=9"); //chk=2 means check sms
			$json = json_decode($response, true);
		
		if($json['info']!="not"){
			@$shop_id=$json['info']['id'];
			@$com_name=$json['info']['com_name'];
			@$address= $json['info']['address'];
			@$backup=$json['info']['backup'];
			@$is_stock=$json['info']['is_stock'];
			@$status=$json['info']['status'];
			@$owner_name=$json['info']['owner_name'];
			@$mobile_num=$json['info']['mobile_num'];
			@$email=$json['info']['email'];
			@$api=$json['info']['api'];
			
			$conn->query("truncate table order_num");
			$conn->query("truncate table user");
			
			$check_shop=$conn->query("SELECT * FROM `company` WHERE id=$com_id and is_active=1");
			$conn->query("insert into user(com_id,
				user_name,
				mobile,
				log_user,
				pass,
				user_type) values($shop_id,'$owner_name','$mobile_num','5050','5060','2')");
				$conn->query("insert into order_num(com_id,
				order_number) values($shop_id,1)");
			if(mysqli_num_rows($check_shop)>0){ // update 
			  $conn->query("update `company` set com_name='$com_name',mobile_num='$mobile_num',owner_name='$owner_name',address='$address',daddress='$address',is_stock=$is_stock,backup='$backup',email='$email' where id=$com_id");
			  echo '<span style="color:green">Setup Success.</span>';
			}else{ // insert 
				$conn->query("insert into company(id,
				com_name,
				address,
				status,
				daddress,
				sms_charge,
				soft_type,
				sms_service,
				api,
				owner_name,
				mobile_num,
				email,
				backup,
				is_stock) values($shop_id,'$com_name','$address','$status','$address','.40','2','1','$api','$owner_name','$mobile_num','$email','$backup','$is_stock')");
				echo '<span style="color:green">Setup Success.</span>';
			}
		}else{
			echo '<span style="color:red">Cloud Server Problem.</span>';
		}
		}else{
			echo '<span style="color:red">No Internet Connection</span>';
		} 
	}
?>