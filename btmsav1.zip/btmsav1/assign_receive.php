
<?php 
	if(isset($_SESSION['COM_ID'])){
		date_default_timezone_set("Asia/Dhaka");
		$com_id=$_SESSION['COM_ID'];
		$cutting_pending=$conn->query("SELECT ord.*,(ord.item_qty-ord.master_cutting_qty) item_qtys,(select product_name from product where id=ord.item_id limit 0,1) item_name,(select cus_name from dsms where id=ord.dsms_id limit 0,1) cus_name FROM `order_record` ord WHERE ord.is_active=1 and ord.item_qty!=ord.`master_cutting_qty` and com_id=$com_id");
		//$sewing_pending=$conn->query("SELECT ord.*,(ord.master_cutting_qty-ord.receive_qty) item_qtys,(select product_name from product where id=ord.item_id limit 0,1) item_name,(select cus_name from dsms where id=ord.dsms_id limit 0,1) cus_name FROM `order_record` ord WHERE ord.is_active=1 and ord.receive_qty!=ord.`master_cutting_qty` and com_id=$com_id");
		$master_list=$conn->query("SELECT ord.* FROM `user` ord WHERE ord.is_active=1 and com_id=$com_id and emp_type=1");
		$karigor_list=$conn->query("SELECT ord.* FROM `user` ord WHERE ord.is_active=1 and com_id=$com_id and emp_type=2");
		$karigorss=$conn->query("select id,user_name,mobile,emp_type from user where is_active=1 and emp_type in(1,2) and com_id=$com_id and salary_type=1 order by emp_type asc");
		$all_emp_list=$conn->query("select user.* from user where is_active=1 and com_id=$com_id and emp_type in(1,2,3) order by emp_type asc");
		$all_emp_list2=$conn->query("select user.* from user where is_active=1 and com_id=$com_id and emp_type in(1,2,3) order by emp_type asc");

		mysqli_close($conn);		
?>

<ul class="nav nav-tabs">
	
    <li class="active"><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" href="#home">Cutting</a></li>
	
    <li><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" onclick="rearrangeKarigorPendingList();" href="#menu1">Sewing</a></li>
	
    <li><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" onclick="rearrangeReceivePendingList();" href="#menu2">Receive</a></li>
    <li><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" onclick="showAllPayment();" href="#menu3">Warker Payment</a></li>
	<?php 
	if(@$_SESSION['daily_attendance']==1){
	?>
	<li><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" onclick="getAllEmployeeList();" href="#menu4">Daily Attendance</a></li>
	<li><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" onclick="showAllStaffPayment();" href="#menu5">Staff Payment</a></li>
	<?php } ?>
</ul>

<div class="tab-content">
    <div id="home" class="tab-pane fade in active">
	<br/>
     
	<div class="panel-group">
		 <div id="show_history">
	  
		   <div class='panel panel-info' style="color: black; box-shadow: inset 0 0 1em gray; padding: 15px;margin-left: 0px;margin-right: 0px;">
			  <div class="panel-heading">
			  <div style="overflow:hidden">
				<select class="form-control" id="master_id" onchange="getMasterPending();" style="width: 40%;color:red;float:left">
					<option value="">মাস্টার নাম সিলেক্ট করুন..</option>
					<option value="all">All</option>
					<?php 
						$sl2=1;$order_tk2=0;
						if(mysqli_num_rows($master_list)>0){
							while($rows=mysqli_fetch_array($master_list)){
								?>
								<option value="<?php echo $rows['id']; ?>"><?php echo $rows['user_name']; ?></option>
								<?php 
							}
						}
					?>
				</select>
				<select class="form-control" id="on_handwork" onchange="getMasterPending();" style="width: 40%;color:red;float:left">
					<option value="">All Task</option>
					<option value="1">On Hand Task</option>
				</select>
				<span style="float: right;font-size: 22px;">কাটিং (মাস্টার)</span>
				</div>
			  </div>
			 
			  <div class="panel-body">
					<div class="row">
						<div class="col-xs-12 col-sm-6">
							<label>কাটিং পেন্ডিং List</label>
							<div class="row">
								<div class="col-xs-12 col-sm-12">
								<input type="text" style="width: 76%;; float: left;" class="form-control" id="myInput" onkeyup="myFunction()" placeholder="Search by Order" title="Type in a name">
								<button style="float: right;" onclick="assignToMasterItem();" name="btn" value="sub" id="assign_to_masterbtn" class="btn btn-success">Assign to Master</button>
								</div>
							</div>
							<table id="myTable" class="table table-striped table-bordered table-hover">
								<thead>
									<thead>
									<tr style="background: antiquewhite;">
										<th style="width: 6%;text-align:center">Sl</th>
										<th style="width: 13%;text-align:center">Order No.</th>
										<th style="width: 25%;">Customer</th>
										<th style="width: 15%;text-align:center">Item</th>
										<th style="width: 10%;text-align:center">Item Qty</th>
										<th style="width: 10%;text-align:center">Assign Qty</th>
										
									</tr>
								</thead>
								<tbody id="pending_list">
									<?php 
										$sl2=1;$order_tk2=0;$c=0;
										if(mysqli_num_rows($cutting_pending)>0){
											while($row=mysqli_fetch_array($cutting_pending)){
												$c=$sl2++;
												?>
												<tr id="cleft_row<?php echo $c; ?>">
												<td style="text-align:center"><?php echo $c; ?></td>
												<td style="text-align:center;font-weight:bold"><?php echo $row['order_number']; ?></td>
												<td>
													<?php echo $row['cus_name']; ?>
												</td>
												<td style="text-align:center">
													<?php echo $row['item_name']; ?>
												</td>
												<td style="text-align:center;font-weight:bold">
													<?php echo $row['item_qtys']; ?>
													<input type="hidden" id="citem_name<?php echo $c; ?>" value="<?php echo $row['item_name']; ?>"/>
													<input type="hidden" id="citem_qty<?php echo $c; ?>" value="<?php echo $row['item_qtys']; ?>"/>
													<input type="hidden" id="corder_num<?php echo $c; ?>" value="<?php echo $row['order_number']; ?>"/>
													<input type="hidden" id="corder_tbl_id<?php echo $c; ?>" value="<?php echo $row['id']; ?>"/>
													<input type="hidden" id="citem_id<?php echo $c; ?>" value="<?php echo $row['item_id']; ?>"/>
													<input type="hidden" id="call_ok<?php echo $c; ?>"/>
												</td>
												
												<td>
													<input onkeyup="checkAssignQty('<?php echo $c; ?>');" style="text-align:center;font-weight:bold" type="text" class="form-control" id="assign_qty<?php echo $c; ?>"/>
												</td>
												</tr>
												<?php 
											}
										}
									?>
									<input type="hidden" value="<?php echo $c; ?>" id="pending_total"/>
								</tbody>
								
							</table>
						</div>
						<div class="col-xs-12 col-sm-6">
						<div id="master_printing_area"></div>
							<label>Master Cutting List <span id="del_sms"></span> <span id="master_clear_area" onclick="masterAreaClear();" style="color:red;cursor:pointer"><i>Clear</i></span></label>
							<div class="row">
								<div class="col-xs-12 col-sm-12">
									<input type="text" style="width: 23%;float: left; margin-right: 5px;" autocomplete="off" placeholder="Start Date" id="mstart_date" class="form-control" />	
									<input type="text" style="width: 23%;float: left; margin-right: 1px;" autocomplete="off" placeholder="End Date" id="mend_date" class="form-control" />	
									<input type="text" style="width: 20%;float: left; margin-right: 2px;text-align:center" placeholder="Order Num." id="msearch_order" class="form-control" />	
									<select style="width: 20%;float: left;" class="form-control" id="msearching_type">
										<option value="1">Item Wise</option>
										<option value="2">Memo Number Wise</option>
										<option value="3">Day Wise</option>
									</select>
									<button style="float: right;" onclick="masterSearchingBtn();" name="btn" value="sub" id="m_searching_btn" class="btn btn-info">Search</button>
								</div>
							</div>
							<table id="myTable" class="table table-striped table-bordered table-hover">
								<thead>
									<thead>
									<tr style="background: aquamarine;">
										<th style="width: 6%;text-align:center">Sl</th>
										<th style="width: 12%;text-align:center">Order No.</th>
										<th style="width: 18%;text-align:center">Assgin Date</th>
										<th style="width: 15%;">Item</th>
										<th style="width: 10%;text-align:center">Assign Qty</th>
										<th style="width: 10%;text-align:right">Taka</th>
										
									</tr>
								</thead>
								<tbody id="master_tbl">
									
								</tbody>
								
							</table>
						</div>
					</div>
					
			  </div>
			 
		   </div>
		
	   </div>	
	</div>
</div>
	 <div id="menu1" class="tab-pane fade">
       <br/>
		 <div class="panel-group">
			 <div id="show_history">
		  
			   <div class='panel panel-success' style="color: black; box-shadow: inset 0 0 1em gray; padding: 15px;margin-left: 0px;margin-right: 0px;">
				  <div class="panel-heading">
				  <div style="overflow:hidden">
					<select class="form-control" id="karigor_id" onchange="getKarigorPending();" style="width: 40%;color:red;float:left">
						<option value="">কারিগর নাম সিলেক্ট করুন..</option>
						<option value="all">All</option>
						<?php 
							$sl2=1;$order_tk2=0;
							if(mysqli_num_rows($karigor_list)>0){
								while($rows=mysqli_fetch_array($karigor_list)){
									?>
									<option value="<?php echo $rows['id']; ?>"><?php echo $rows['user_name']; ?></option>
									<?php 
								}
							}
						?>
					</select>
					<select class="form-control" id="on_handwork_karigor" onchange="getKarigorPending();" style="width: 40%;color:red;float:left">
						<option value="">All Task</option>
						<option value="1">On Hand Task</option>
					</select>
					<span style="float: right;font-size: 22px;">সুইং (কারিগর)</span>
					</div>
				  </div>
				 
				  <div class="panel-body">
						<div class="row">
							<div class="col-xs-12 col-sm-6">
								<label>সেলাই পেন্ডিং List</label>
								<div class="row">
									<div class="col-xs-12 col-sm-12">
									<input type="text" style="width: 76%; float: left;" class="form-control" id="myInput2" onkeyup="myFunction2()" placeholder="Search by Order" title="Type in a name">
									<button style="float: right;" onclick="assignToKarigorItem();" name="btn" value="sub" id="assign_to_karigorbtn" class="btn btn-success">Assign to Karigor</button>
									</div>
								</div>
								<table id="myTable2" class="table table-striped table-bordered table-hover">
									<thead>
										<thead>
										<tr style="background: burlywood;">
											<th style="width: 5%;text-align:center">Sl</th>
											<th style="width: 10%;text-align:center">Order No.</th>
											<th style="width: 25%;">Customer</th>
											<th style="width: 15%;text-align:center">Item</th>
											<th style="width: 6%;text-align:center">Qty</th>
											<th style="width: 10%;text-align:center;color:blue">Assign Qty</th>
											<th style="width: 10%;text-align:right">Design Tk.</th>
											
										</tr>
									</thead>
									<tbody id="kpending_list">
									</tbody>
									
								</table>
							</div>
							<div class="col-xs-12 col-sm-6">
								<div id="karigor_printing_area"></div>
								<label>Karigor Sewing List <span id="del_sms_karigor"></span><span id="karigor_clear_area" onclick="masterAreaClear();" style="color:red;cursor:pointer"><i>Clear</i></span></label>
								<div class="row">
									<div class="col-xs-12 col-sm-12">
										<input type="text" style="width: 23%;float: left; margin-right: 5px;" autocomplete="off" placeholder="Start Date" id="kstart_date" class="form-control" />	
										<input type="text" style="width: 23%;float: left; margin-right: 2px;" autocomplete="off" placeholder="End Date" id="kend_date" class="form-control" />	
										<input type="text" style="width: 20%;float: left; margin-right: 1px;text-align:center" placeholder="Order Num." id="ksearch_order" class="form-control" />	
										<select style="width: 20%;float: left;" class="form-control" id="ksearching_type">
											<option value="1">Item Wise</option>
											<option value="2">Memo Number Wise</option>
											<option value="3">Day Wise</option>
										</select>
										<button style="float: right;" onclick="karigorSearchingBtn();" name="btn" value="sub" id="k_searching_btn" class="btn btn-info">Search</button>
									</div>
								</div>
								<table id="myTable" class="table table-striped table-bordered table-hover">
									<thead>
										<thead>
										<tr style="background: yellowgreen;">
											<th style="width: 6%;text-align:center">Sl</th>
											<th style="width: 12%;text-align:center">Order No.</th>
											<th style="width: 18%;text-align:center">Assgin Date</th>
											<th style="width: 15%;">Item</th>
											<th style="width: 10%;text-align:center">Assign Qty</th>
											<th style="width: 10%;text-align:right">Taka</th>
											
										</tr>
									</thead>
									<tbody id="karigor_tbl">
										
									</tbody>
									
								</table>
							</div>
						</div>
						
				  </div>
				 
			   </div>
			
		   </div>	
		</div>
   </div>
	<div id="menu2" class="tab-pane fade">
     <br/>
		 <div class="panel-group">
			 <div id="show_history">
		  
			   <div class='panel panel-danger' style="color: black; box-shadow: inset 0 0 1em gray; padding: 15px;margin-left: 0px;margin-right: 0px;">
				  <div class="panel-heading">
				  <div style="overflow:hidden">
					
					<span style="float: right;font-size: 22px;">রিসিভ</span>
					</div>
				  </div>
				 
				  <div class="panel-body">
						<div class="row">
							<div class="col-xs-12 col-sm-6">
								<label>Delivery পেন্ডিং List</label>
								<div class="row">
									<div class="col-xs-12 col-sm-12">
									<input type="text" style="width: 76%; float: left;" class="form-control" id="myInput3" onkeyup="myFunction3()" placeholder="Search by Order" title="Type in a name">
									<button style="float: right;" onclick="factoryReceiveItem();" name="btn" value="sub" id="factory_to_receive" class="btn btn-success">Factory Receive</button>
									</div>
								</div>
								<table id="myTable3" class="table table-striped table-bordered table-hover">
									<thead>
										<thead>
										<tr style="background: aquamarine;">
											<th style="width: 6%;text-align:center">Sl</th>
											<th style="width: 13%;text-align:center">Order No.</th>
											<th style="width: 25%;">Customer</th>
											<th style="width: 15%;text-align:center">Item</th>
											<th style="width: 10%;text-align:center">Item Qty</th>
											<th style="width: 11%;text-align:center">Receive Qty</th>
											
										</tr>
									</thead>
									<tbody id="rpending_list">
									</tbody>
									
								</table>
							</div>
							<div class="col-xs-12 col-sm-6">
								<label>Received Item List <span id="del_sms_receive"></span></label>
								<div class="row">
									<div class="col-xs-12 col-sm-12">
										<input type="text" style="width: 29%;float: left; margin-right: 5px;" autocomplete="off" placeholder="Start Date" id="rstart_date" class="form-control" />	
										<input type="text" style="width: 29%;float: left; margin-right: 1px;" autocomplete="off" placeholder="End Date" id="rend_date" class="form-control" />	
										<input type="text" style="width: 28%;float: left; margin-right: 2px;text-align: center;" placeholder="Order Num." id="rsearch_order" class="form-control" />	
										
										<button style="float: right;" onclick="receiveSearchingBtn();" name="btn" value="sub" id="r_searching_btn" class="btn btn-info">Search</button>
									</div>
								</div>
								<table id="myTable" class="table table-striped table-bordered table-hover">
									<thead>
										<thead>
										<tr style="background: darksalmon;">
											<th style="width: 6%;text-align:center">Sl</th>
											<th style="width: 11%;text-align:center">Order No.</th>
											<th style="width: 18%;text-align:center">Received Date</th>
											<th style="width: 15%;text-align:center">Item</th>
											<th style="width: 10%;text-align:center">Received Qty</th>
											
										</tr>
									</thead>
									<tbody id="received_tbl">
										
									</tbody>
									
								</table>
							</div>
						</div>
						
				  </div>
				 
			   </div>
			
		   </div>	
		</div>
    </div>
	<div id="menu3" class="tab-pane fade">
		 <br/>
		 <div class="panel-group">
		
		<div class='panel panel-success'>
		
		  <div class="panel-heading">
					<div style="overflow:hidden">
					<span style="float: right;font-size: 22px;">ওয়ার্কার পেমেন্ট</span>
					</div>
		  </div>
		 
		  <div class="panel-body">
				<div class="row">
				<div class="col-xs-12 col-sm-12">	
					<div class="col-xs-12 col-sm-2">
				<label for="comment">Status<sup style="color:red">*</sup>:</label>
				<select class="form-control" id="emp_statuss">
					<option value="earning">মজুরি(জমা)</option>
					<!--<option value="payable">মজুরি প্রদান</option>-->
				</select>
			</div>
			<div class="col-xs-12 col-sm-3">
				<label for="comment">Employee List<sup style="color:red">*</sup>:</label>
				<div style="margin-bottom: 5px;">
				<select class="form-control" id="emp_lists">
				<option value="">All</option>
				<?php 
					while($rows=mysqli_fetch_array($karigorss)){
					if($rows['emp_type']==1){
							$emp_type='মাস্টার';
					}else if($rows['emp_type']==2){
						$emp_type='কারিগর';
					}else{
						$emp_type='স্টাফ';
					}						
				?>
				<option style='color: <?php if($rows['emp_type']==1){ echo 'blue'; }else if($rows['emp_type']==3){ echo '#b60bc1';} ?>' value="<?php echo $rows['id']; ?>"><?php echo $rows['user_name']."(".$rows['mobile'].")-".$emp_type; ?></option>
				<?php 
					
				}
				?>
				</select>
				</div>
			</div>
			<div class="col-xs-12 col-sm-2" id="firsts">
				<label for="comment">Start Date<sup style="color:red">*</sup>:</label>
				<input type="text" autocomplete="off" name="date1" id="pstart_date" class="form-control">
			</div>
			<div class="col-xs-12 col-sm-2" id="fours">
				<label for="comment">To Date:</label>
				<input type="text" autocomplete="off"  value="<?php echo date("d/m/Y"); ?>" name="pend_date" id="pend_date" class="form-control">
			</div>
			<div class="col-xs-12 col-sm-2">
				<button onclick="dateWisePrint();" style="margin-top: 24px;" name="btn" id="srcbymob_print" value="sub" class="btn btn-success">Search</button>		
			</div>
			
				</div>
				<div class="col-xs-12 col-sm-12">
					<span id="summery_report2"></span>
				</div>
				
				</div>
					
				</div>
		  </div>
		 
		</div>
    </div>
	<div id="menu4" class="tab-pane fade">
     <br/>
		 <div class="panel-group">
			 <div id="show_history">
		  
			   <div class='panel panel-warning' style="color: black; box-shadow: inset 0 0 1em gray; padding: 15px;margin-left: 0px;margin-right: 0px;">
				  <div class="panel-heading">
				  <div style="overflow:hidden">
					
					<span style="float: right;font-size: 22px;">Daily Attendance & Salary Process Panel</span>
					</div>
				  </div>
				 
				  <div class="panel-body">
						<div class="row">
							<div class="col-xs-12 col-sm-6">
								<label>All Employee List</label>
								
								<div class="row">
									<div class="col-xs-12 col-sm-12">
										<input type="text" style="width: 48%; float: left;margin-right: 6px;" class="form-control" id="myInput4" onkeyup="myFunction4()" placeholder="Search by Order" title="Type in a name">
									
										<input type="text" style="width: 37%;float: left; margin-right: 5px;" autocomplete="off" placeholder="Start Date" value="<?php echo date('d/m/Y'); ?>" id="attendance_date" class="form-control" />	
										
										<button style="float: right;" onclick="getAllEmployeeList();" name="btn" value="sub" id="dattendance_btn" class="btn btn-info">Search</button>
									</div>
								</div>
								<table id="myTable4" class="table table-striped table-bordered table-hover">
									<thead>
										<thead>
										<tr style="background: aquamarine;">
											<th style="width: 6%;text-align:center">Sl</th>
											<th style="width: 32%;">Employee Name</th>
											<th style="width: 16%;text-align:center">Emp. Type</th>
											<th style="width: 16%;text-align:center">Salary Type</th>
											<th style="text-align:center">Status</th>
											
										</tr>
									</thead>
									<tbody id="attendance_list">
									</tbody>
									
								</table>
							</div>
							<div class="col-xs-12 col-sm-6">
								<label>Attendance List <span id="del_sms_receive"></span></label>
								<div class="row">
									<div class="col-xs-12 col-sm-12">
										<input type="text" style="width: 23%;float: left; margin-right: 5px;" autocomplete="off" placeholder="Start Date" id="attenstart_date" class="form-control" />	
										<input type="text" style="width: 23%;float: left; margin-right: 5px;" autocomplete="off" placeholder="End Date" id="attenend_date" class="form-control" />	
										<select class="form-control select2" id="attendance_emp_id" onchange="getMasterPending();" style="width: 40%;color:red;float:left">
											<option value="">এমপ্লয়ী নাম সিলেক্ট করুন..</option>
											<option value="all">All</option>
											<?php 
											$emp_type="";
												while($rows=mysqli_fetch_array($all_emp_list)){
												if($rows['emp_type']==1){
														$emp_type='মাস্টার';
												}else if($rows['emp_type']==2){
													$emp_type='কারিগর';
												}else{
													$emp_type='স্টাফ';
												}						
											?>
											<option style='color: <?php if($rows['emp_type']==1){ echo 'blue'; }else if($rows['emp_type']==3){ echo '#b60bc1';} ?>' value="<?php echo $rows['id']; ?>"><?php echo $rows['user_name']."(".$rows['mobile'].")-".$emp_type; ?></option>
											<?php 
												
											}
											?>
										</select>
										<button style="float: right;" onclick="getEmpAttendance();" name="btn" value="sub" id="r_searching_btn" class="btn btn-info">Search</button>
									</div>
								</div>
								<span id="process_btn"></span>
								<table id="myTable" class="table table-striped table-bordered table-hover">
									<thead>
										<thead>
										<tr style="background: cornflowerblue;">
											<th style="width: 6%;text-align:center">Sl</th>
											<th style="width: 24%;">Employee Name</th>
											<th style="width: 13%;text-align:center">Type</th>
											<th style="width: 12%;text-align:right">Salary</th>
											<th style="width: 12%;text-align:right">Deduction</th>
											<th style="width: 18%;text-align:center">Remarks</th>
											<th style="width: 10%;text-align:center">Status</th>
											
										</tr>
									</thead>
									<tbody id="attendance_tbl">
										
									</tbody>
									
								</table>
							</div>
						</div>
						
				  </div>
				 
			   </div>
			
		   </div>	
		</div>
    </div>
	<div id="menu5" class="tab-pane fade">
		 <br/>
		 <div class="panel-group">
		
		<div class='panel panel-success'>
		
		  <div class="panel-heading">
		  <div style="overflow:hidden">
			<span style="float: right;font-size: 22px;">স্টাফ পেমেন্ট</span>
			</div>
		  </div>
		 
		  <div class="panel-body">
				<div class="row">
				<div class="col-xs-12 col-sm-12">	
					<div class="col-xs-12 col-sm-2">
				<label for="comment">Status<sup style="color:red">*</sup>:</label>
				<select class="form-control" id="staff_statuss">
					<option value="earning">বেতন জমা</option>
					<option value="payable">বেতন প্রদান</option>
				</select>
			</div>
			<div class="col-xs-12 col-sm-3">
				<label for="comment">Employee List<sup style="color:red">*</sup>:</label>
				<div style="margin-bottom: 5px;">
				<select class="form-control" id="staff_lists">
				<option value="">All</option>
				<?php 
					while($rows=mysqli_fetch_array($all_emp_list2)){
					if($rows['emp_type']==1){
							$emp_type='মাস্টার';
					}else if($rows['emp_type']==2){
						$emp_type='কারিগর';
					}else{
						$emp_type='স্টাফ';
					}						
				?>
				<option style='color: <?php if($rows['emp_type']==1){ echo 'blue'; }else if($rows['emp_type']==3){ echo '#b60bc1';} ?>' value="<?php echo $rows['id']; ?>"><?php echo $rows['user_name']."(".$rows['mobile'].")-".$emp_type; ?></option>
				<?php 
					
				}
				?>
				</select>
				</div>
			</div>
			<div class="col-xs-12 col-sm-2" id="firsts">
				<label for="comment">Start Date<sup style="color:red">*</sup>:</label>
				<input type="text" autocomplete="off" name="date1" id="sstart_date" class="form-control">
			</div>
			<div class="col-xs-12 col-sm-2" id="fours">
				<label for="comment">To Date:</label>
				<input type="text" autocomplete="off"  value="<?php echo date("d/m/Y"); ?>" name="send_date" id="send_date" class="form-control">
			</div>
			<div class="col-xs-12 col-sm-2">
				<button onclick="dateWiseStaffPrint();" style="margin-top: 24px;" name="btn" id="staffrcbymob_print" value="sub" class="btn btn-success">Search</button>		
			</div>
			
				</div>
				<div class="col-xs-12 col-sm-12">
					<span id="summery_report4"></span>
				</div>
				
				</div>
					
				</div>
		  </div>
		 
		</div>
    </div>
</div>

 <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg" id="modal_width">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" id="heading_id"></h4>
        </div>
        <div class="modal-body">
          <span id="smeasurement"></span>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
  
  <script>
  
  $(function() {
		$( "#sstart_date,#send_date,#attenstart_date,#attenend_date,#attendance_date,#mstart_date,#kstart_date,#kend_date,#rstart_date,#rend_date,#pstart_date,#pend_date" ).datepicker({
			dateFormat: 'dd/mm/yy' 
		});
		$("#mend_date" ).datepicker({
			dateFormat: 'dd/mm/yy' 
		});
		
	});
	
$(document).ready(function(){
		$(".select2").select2();
		$("#master_clear_area").hide();
});

function masterAreaClear(){
	$("#master_printing_area,#karigor_printing_area").html(null);
	$("#master_clear_area,#karigor_clear_area").hide();
}
	
  function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }  

  }
}

function myFunction2() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput2");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable2");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }  

  }
}

function myFunction3() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput3");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable3");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }  

  }
}

function myFunction4() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput4");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable4");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }  

  }
}

function checkAssignQty(sl_no){
	var order_qty=parseInt($("#citem_qty"+sl_no).val());
	var assign_qty=parseInt($("#assign_qty"+sl_no).val());
	if(assign_qty>order_qty){
		$("#cleft_row"+sl_no).css('background-color','#f43d3d');
		$("#assign_qty"+sl_no).val(null);
	}else if(assign_qty>0 && assign_qty<=order_qty){
		$("#cleft_row"+sl_no).css('background-color','aqua');
		if(assign_qty==order_qty){
			$("#call_ok"+sl_no).val(1);
		}else{
			$("#call_ok"+sl_no).val(0);
		}
	}else if(assign_qty<0){
		$("#cleft_row"+sl_no).css('background-color','#f43d3d');
		$("#assign_qty"+sl_no).val(null);
	}else{
		$("#cleft_row"+sl_no).css('background-color','white');
		$("#assign_qty"+sl_no).val(null);
	}
}

function checkAssignQtyKarigor(sl_no){
	var order_qty=parseInt($("#kitem_qty"+sl_no).val());
	var assign_qty=parseInt($("#kassign_qty"+sl_no).val());
	if(assign_qty>order_qty){
		$("#kleft_row"+sl_no).css('background-color','#f43d3d');
		$("#kassign_qty"+sl_no).val(null);
	}else if(assign_qty>0 && assign_qty<=order_qty){
		$("#kleft_row"+sl_no).css('background-color','aqua');
		if(assign_qty==order_qty){
			$("#kall_ok"+sl_no).val(1);
		}else{
			$("#kall_ok"+sl_no).val(0);
		}
	}else if(assign_qty<0){
		$("#kleft_row"+sl_no).css('background-color','#f43d3d');
		$("#kassign_qty"+sl_no).val(null);
	}else{
		$("#kleft_row"+sl_no).css('background-color','white');
		$("#kassign_qty"+sl_no).val(null);
	}
}

function checkAssignQtyReceive(sl_no){
	var order_qty=parseInt($("#ritem_qty"+sl_no).val());
	var assign_qty=parseInt($("#rassign_qty"+sl_no).val());
	if(assign_qty>order_qty){
		$("#rleft_row"+sl_no).css('background-color','#f43d3d');
		$("#rassign_qty"+sl_no).val(null);
	}else if(assign_qty>0 && assign_qty<=order_qty){
		$("#rleft_row"+sl_no).css('background-color','aqua');
		if(assign_qty==order_qty){
			$("#rall_ok"+sl_no).val(1);
		}else{
			$("#rall_ok"+sl_no).val(0);
		}
	}else if(assign_qty<0){
		$("#rleft_row"+sl_no).css('background-color','#f43d3d');
		$("#rassign_qty"+sl_no).val(null);
	}else{
		$("#rleft_row"+sl_no).css('background-color','white');
		$("#rassign_qty"+sl_no).val(null);
	}
}

function getMasterPending(){
	$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				master_id: $("#master_id").val(),
				on_handwork: $("#on_handwork").val(),
				getMasterPending:1
			},
			 beforeSend: function () {
				$("#master_tbl").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
				console.log(response);
				$("#master_tbl").html(null);
				if(response==""){
					$("#master_tbl").html(null);
				}else{
					$("#master_tbl").html(response);
				}
			 }
	});
}

function getKarigorPending(){
	$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				master_id: $("#karigor_id").val(),
				on_handwork: $("#on_handwork_karigor").val(),
				getKarigorPending:1
			},
			 beforeSend: function () {
				$("#karigor_tbl").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
				console.log(response);
				$("#karigor_tbl").html(null);
				if(response==""){
					$("#karigor_tbl").html(null);
				}else{
					$("#karigor_tbl").html(response);
				}
			 }
	});
}

window.citem_name = [];
	window.cassign_qty = [];
	window.kdesign_tk = [];
	window.corder_num = [];
	window.corder_tbl_id = [];
	window.citem_id = [];
	window.call_ok = [];
function assignToMasterItem(){
	if(confirm("Do you want to assign?")){
		var pending_total=$("#pending_total").val();
		var master_id=$("#master_id").val();
		if(master_id=="" || master_id=="all"){
			alert("মাস্টার নাম সিলেক্ট করুন!");
			$("#master_id").focus();
			return;
		}
		
		for(var i=1; i<=pending_total; i++){
			var assign_qty=$("#assign_qty"+i).val();
			if(assign_qty!=0 && assign_qty!=""){
				citem_name.push($("#citem_name"+i).val());
				cassign_qty.push($("#assign_qty"+i).val());
				kdesign_tk.push('0');
				corder_num.push($("#corder_num"+i).val());
				corder_tbl_id.push($("#corder_tbl_id"+i).val());
				citem_id.push($("#citem_id"+i).val());
				call_ok.push($("#call_ok"+i).val());
			}
		}
		
		var citem_namea = citem_name.join('#sep#');
		var cassign_qtya = cassign_qty.join('#sep#');
		var ckdesign_tka = kdesign_tk.join('#sep#');
		var corder_numa = corder_num.join('#sep#');
		var corder_tbl_ida = corder_tbl_id.join('#sep#');
		var citem_ida = citem_id.join('#sep#');
		
		$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					citem_namea: citem_namea,
					cassign_qtya: cassign_qtya,
					ckdesign_tka: ckdesign_tka,
					corder_numa: corder_numa,
					corder_tbl_ida: corder_tbl_ida,
					citem_ida: citem_ida,
					master_id: master_id,
					get_emp_type: 1,
					status: 0,
					assignToMasterItem:1
				},
				 beforeSend: function () {
					$("#assign_to_masterbtn").html('Wait..');
					document.getElementById("assign_to_masterbtn").disabled = true;
				},
				 success: function (response) {
					console.log(response);
					$("#master_tbl").prepend(response);
					$("#myInput").val(null);
					$("#master_id").val(null);
					rearrangePendingList();
					$("#assign_to_masterbtn").html('Assign to Master');
					document.getElementById("assign_to_masterbtn").disabled = false;
					window.kdesign_tk = [];
					window.citem_name = [];
					window.cassign_qty = [];
					window.corder_num = [];
					window.corder_tbl_id = [];
					window.citem_id = [];
					window.call_ok = [];
				 }
		});
	}
} 


window.kitem_name = [];
	window.kassign_qty = [];
	window.kdesign_tk = [];
	window.korder_num = [];
	window.korder_tbl_id = [];
	window.kitem_id = [];
	window.kall_ok = [];
function assignToKarigorItem(){
	if(confirm("Do you want to assign?")){
		var pending_total=$("#kpending_total").val();
		var karigor_id=$("#karigor_id").val();
		if(karigor_id=="" || karigor_id=="all"){
			alert("কারিগর নাম সিলেক্ট করুন!");
			$("#karigor_id").focus();
			return;
		}
		
		for(var i=1; i<=pending_total; i++){
			var assign_qty=$("#kassign_qty"+i).val();
			if(assign_qty!=0 && assign_qty!=""){
				kitem_name.push($("#kitem_name"+i).val());
				kassign_qty.push($("#kassign_qty"+i).val());
				kdesign_tk.push(($("#kdesign_tk"+i).val()=="")? '0' : $("#kdesign_tk"+i).val());
				korder_num.push($("#korder_num"+i).val());
				korder_tbl_id.push($("#korder_tbl_id"+i).val());
				kitem_id.push($("#kitem_id"+i).val());
				kall_ok.push($("#kall_ok"+i).val());
			}
		}
		
		var citem_namea = kitem_name.join('#sep#');
		var cassign_qtya = kassign_qty.join('#sep#');
		var ckdesign_tka = kdesign_tk.join('#sep#');
		var corder_numa = korder_num.join('#sep#');
		var corder_tbl_ida = korder_tbl_id.join('#sep#');
		var citem_ida = kitem_id.join('#sep#');
		//console.log(cassign_qtya); exit;
		$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					citem_namea: citem_namea,
					cassign_qtya: cassign_qtya,
					ckdesign_tka: ckdesign_tka,
					corder_numa: corder_numa,
					corder_tbl_ida: corder_tbl_ida,
					citem_ida: citem_ida,
					master_id: karigor_id,
					get_emp_type: 2,
					status: 0,
					assignToMasterItem:1
				},
				 beforeSend: function () {
					$("#assign_to_karigorbtn").html('Wait..');
					document.getElementById("assign_to_karigorbtn").disabled = true;
				},
				 success: function (response) {
					console.log(response);
					$("#karigor_tbl").prepend(response);
					$("#myInput2").val(null);
					$("#karigor_id").val(null);
					rearrangeKarigorPendingList();
					$("#assign_to_karigorbtn").html('Assign to Karigor');
					document.getElementById("assign_to_karigorbtn").disabled = false;
					window.kitem_name = [];
					window.kassign_qty = [];
					window.kdesign_tk = [];
					window.korder_num = [];
					window.korder_tbl_id = [];
					window.kitem_id = [];
					window.kall_ok = [];
				 }
		});
	}
}  


window.rcus_name = [];
window.rcus_mobile = [];
window.ritem_name = [];
	window.rassign_qty = [];
	window.rorder_num = [];
	window.rorder_tbl_id = [];
	window.ritem_id = [];
	window.rall_ok = [];
function factoryReceiveItem(){
	if(confirm("Do you want to factory receive?")){
		var pending_total=$("#rpending_total").val();
		
		for(var i=1; i<=pending_total; i++){
			var assign_qty=$("#rassign_qty"+i).val();
			if(assign_qty!=0 && assign_qty!=""){
				rcus_name.push($("#rcus_name"+i).val());
				rcus_mobile.push($("#rcus_mobile"+i).val());
				ritem_name.push($("#ritem_name"+i).val());
				rassign_qty.push($("#rassign_qty"+i).val());
				rorder_num.push($("#rorder_num"+i).val());
				rorder_tbl_id.push($("#rorder_tbl_id"+i).val());
				ritem_id.push($("#ritem_id"+i).val());
				rall_ok.push($("#rall_ok"+i).val());
			}
		}
		
		var crcus_namea = rcus_name.join('#sep#');
		var crcus_mobilea = rcus_mobile.join('#sep#');
		var citem_namea = ritem_name.join('#sep#');
		var cassign_qtya = rassign_qty.join('#sep#');
		var corder_numa = rorder_num.join('#sep#');
		var corder_tbl_ida = rorder_tbl_id.join('#sep#');
		var citem_ida = ritem_id.join('#sep#');
		//console.log(corder_tbl_ida); exit;
		$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					cus_name: crcus_namea,
					cus_mobile: crcus_mobilea,
					citem_namea: citem_namea,
					cassign_qtya: cassign_qtya,
					corder_numa: corder_numa,
					corder_tbl_ida: corder_tbl_ida,
					citem_ida: citem_ida,
					factoryReceiveItem:1
				},
				 beforeSend: function () {
					$("#factory_to_receive").html('Wait..');
					document.getElementById("factory_to_receive").disabled = true;
				},
				 success: function (response) {
					console.log(response);
					$("#received_tbl").prepend(response);
					rearrangeReceivePendingList();
					$("#factory_to_receive").html('Factory Receive');
					document.getElementById("factory_to_receive").disabled = false;
					window.rcus_name = [];
					window.rcus_mobile = [];
					window.ritem_name = [];
					window.rassign_qty = [];
					window.rorder_num = [];
					window.rorder_tbl_id = [];
					window.ritem_id = [];
					window.rall_ok = [];
				 }
		});
	}
}  

function rearrangePendingList(){
	$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				rearrangePendingList:1
			},
			 beforeSend: function () {
				$("#pending_list").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
				console.log(response);
				$("#pending_list").html(response);
			}
	});
} 

function rearrangeKarigorPendingList(){
	$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				rearrangeKarigorPendingList:1
			},
			 beforeSend: function () {
				$("#kpending_list").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
				console.log(response);
				$("#kpending_list").html(response);
			}
	});
}

function rearrangeReceivePendingList(){
	$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				rearrangeReceivePendingList:1
			},
			 beforeSend: function () {
				$("#rpending_list").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
				//console.log(response);
				$("#rpending_list").html(response);
				getReceivedItem();
			}
	});
}

function getReceivedItem(){
	$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				getReceivedItem:1
			},
			 beforeSend: function () {
				$("#received_tbl").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
				//console.log(response);
				$("#received_tbl").html(response);
			}
	});
}


function delItemPayment(tbl_id,emp_type,taka,emp_id,status,order_rec_tblid){
		if(confirm("Do you want to delete it?")){
			var job_type=status;
			if(emp_type==1){
				document.getElementById("delbtns"+tbl_id).disabled = true;
			}else if(emp_type==2){
				document.getElementById("delbtnskarigor"+tbl_id).disabled = true;
			}else{
				document.getElementById("delpaybtns"+tbl_id).disabled = true;
			}
			$.ajax({
						type: 'post',
						url: 'sql.php',
						data: {
							tbl_id:tbl_id,
							sl_no:0,
							taka:taka,
							emp_id:emp_id,
							status:status,
							job_type:job_type,
							order_rec_tblid:order_rec_tblid,
							get_emp_type:emp_type,
							delItemPayment:1
						},
						 
						 success: function (response) {
							console.log(response);
							if(emp_type==1){
								if(response==1){
									$("#del_sms").html("Delete success!").css('color','blue');
									$("#row_master"+tbl_id).css('color','#8080808a');
									rearrangePendingList();
									}else{
									document.getElementById("delbtns"+tbl_id).disabled = false;
								}
							}
							if(emp_type==2){
								if(response==1){
									$("#del_sms_karigor").html("Delete success!").css('color','blue');
									$("#row_karigor"+tbl_id).css('color','#8080808a');
									rearrangeKarigorPendingList();
									}else{
									document.getElementById("delbtnskarigor"+tbl_id).disabled = false;
								}
							}
							if(emp_type==3){
								if(response==1){
									$("#payment_sms").html("Delete success!");
									}else{
									document.getElementById("delpaybtns"+tbl_id).disabled = false;
								}
							}
						 }
				});
		}
	}
	
function delItemStaffPayment(tbl_id,emp_type,taka,emp_id,status){
		if(confirm("Do you want to delete it?")){
			var job_type=status;
			if(emp_type==1){
				document.getElementById("delbtns"+tbl_id).disabled = true;
			}else if(emp_type==2){
				document.getElementById("delbtnskarigor"+tbl_id).disabled = true;
			}else{
				document.getElementById("delpaybtns"+tbl_id).disabled = true;
			}
			$.ajax({
						type: 'post',
						url: 'sql.php',
						data: {
							tbl_id:tbl_id,
							sl_no:0,
							taka:taka,
							emp_id:emp_id,
							status:status,
							job_type:job_type,
							get_emp_type:emp_type,
							delItemStaffPayment:1
						},
						 
						 success: function (response) {
							console.log(response);
							if(emp_type==1){
								if(response==1){
									$("#del_sms").html("Delete success!").css('color','blue');
									$("#row_master"+tbl_id).css('color','#8080808a');
									rearrangePendingList();
									}else{
									document.getElementById("delbtns"+tbl_id).disabled = false;
								}
							}
							if(emp_type==2){
								if(response==1){
									$("#del_sms_karigor").html("Delete success!").css('color','blue');
									$("#row_karigor"+tbl_id).css('color','#8080808a');
									rearrangeKarigorPendingList();
									}else{
									document.getElementById("delbtnskarigor"+tbl_id).disabled = false;
								}
							}
							if(emp_type==3){
								if(response==1){
									$("#payment_sms").html("Delete success!");
									}else{
									document.getElementById("delpaybtns"+tbl_id).disabled = false;
								}
							}
						 }
				});
		}
	}

function delDeliveryItem(order_tbl_id,delivery_qty){
	if(confirm("Do you want to delete it?")){
			document.getElementById("delbtns_receive"+order_tbl_id).disabled = true;
			
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						order_tbl_id:order_tbl_id,
						delivery_qty:delivery_qty,
						delDeliveryItem:1
					},
					 success: function (response) {
							console.log(response);
							if(response==1){
								$("#del_sms_receive").html("Delete success!").css('color','blue');
								$("#row_received"+order_tbl_id).css('color','#8080808a');
								rearrangeReceivePendingList();
								}else{
								document.getElementById("delbtns_receive"+order_tbl_id).disabled = false;
							}
						
						 }
				});
		}
}
	
function masterSearchingBtn(){
	var mstart_date=$("#mstart_date").val();
	var mend_date=$("#mend_date").val();
	var msearch_order=$("#msearch_order").val();
	var msearching_type=$("#msearching_type").val();
	var master_id=$("#master_id").val();
	if(master_id==""){
		alert("মাস্টার নাম সিলেক্ট করুন!");
		$("#master_id").focus();
		return;
	}
	if(mstart_date=="" && mend_date=="" && msearch_order=="" && msearching_type==""){
		alert("Select any searching parameter...");
		return;
	}
	
	if(msearching_type==2){
		if(mstart_date=="" && mend_date==""){
			alert("Select any searching parameter...");
			return;
		}
	}
	
	$.ajax({
		type: 'post',
		url: 'sql.php',
		data: {
			mstart_date:mstart_date,
			mend_date:mend_date,
			msearch_order:msearch_order,
			msearching_type:msearching_type,
			master_id:master_id,
			emp_type:1,
			masterSearchingBtn:1
		},
		beforeSend: function () {
			$("#del_sms").html('Wait..').css('color','blue');
			document.getElementById("m_searching_btn").disabled = true;
		},
		 success: function (response) {
			 console.log(response);
			 if(response==""){
				 $("#master_tbl").html(null);
			 }else{
				$("#master_tbl").html(response); 
			 }
			$("#del_sms").html(null);
			document.getElementById("m_searching_btn").disabled = false;
		}
	});
}

function karigorSearchingBtn(){
	var mstart_date=$("#kstart_date").val();
	var mend_date=$("#kend_date").val();
	var msearch_order=$("#ksearch_order").val();
	var msearching_type=$("#ksearching_type").val();
	var master_id=$("#karigor_id").val();
	if(master_id==""){
		alert("কারিগর নাম সিলেক্ট করুন!");
		$("#karigor_id").focus();
		return;
	}
	if(mstart_date=="" && mend_date=="" && msearch_order=="" && msearching_type==""){
		alert("Select any searching parameter...");
		return;
	}
	
	if(msearching_type==2){
		if(mstart_date=="" && mend_date==""){
			alert("Select any searching parameter...");
			return;
		}
	}
	
	$.ajax({
		type: 'post',
		url: 'sql.php',
		data: {
			mstart_date:mstart_date,
			mend_date:mend_date,
			msearch_order:msearch_order,
			msearching_type:msearching_type,
			master_id:master_id,
			emp_type:1,
			karigorSearchingBtn:1
		},
		beforeSend: function () {
			$("#del_sms_karigor").html('Wait..').css('color','blue');
			document.getElementById("k_searching_btn").disabled = true;
		},
		 success: function (response) {
			 console.log(response);
			 if(response==""){
				 $("#karigor_tbl").html(null);
			 }else{
				$("#karigor_tbl").html(response); 
			 }
			$("#del_sms_karigor").html(null);
			document.getElementById("k_searching_btn").disabled = false;
		}
	});
}

function receiveSearchingBtn(){
	var mstart_date=$("#rstart_date").val();
	var mend_date=$("#rend_date").val();
	var msearch_order=$("#rsearch_order").val();
	
	if(mstart_date=="" && mend_date=="" && msearch_order==""){
		alert("Select any searching parameter...");
		return;
	}
	
	$.ajax({
		type: 'post',
		url: 'sql.php',
		data: {
			mstart_date:mstart_date,
			mend_date:mend_date,
			msearch_order:msearch_order,
			receiveSearchingBtn:1
		},
		beforeSend: function () {
			$("#del_sms_receive").html('Wait..').css('color','blue');
			document.getElementById("r_searching_btn").disabled = true;
		},
		 success: function (response) {
			 console.log(response);
			 if(response==""){
				 $("#received_tbl").html(null);
			 }else{
				$("#received_tbl").html(response); 
			 }
			$("#del_sms_receive").html(null);
			document.getElementById("r_searching_btn").disabled = false;
		}
	});
}

function showMasterMemo(emp_type,memo_id,emp_name,mdate){
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					emp_type:emp_type,
					memo_id:memo_id,
					emp_name:emp_name,
					mdate:mdate,
					showMasterMemo:1
				},
				 beforeSend: function () {
					$("#smeasurement").html('<img src="img/loading.gif"/>');
				},
				 success: function (response) {
					console.log(response);
					$("#modal_width").css('width','30%');
					$("#heading_id").html("মেমো বিবরণ");
					$("#smeasurement").html(response);
				}
		});
	}
	
	function showMasterDayWise(emp_type,emp_id,emp_mobile,emp_name,start_date,end_date){
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					emp_type:emp_type,
					emp_id:emp_id,
					emp_mobile:emp_mobile,
					emp_name:emp_name,
					start_date:start_date,
					end_date:end_date,
					showMasterDayWise:1
				},
				 beforeSend: function () {
					 if(emp_type==1){
						$("#master_printing_area").html('<img src="img/loading.gif"/>');
					 }else{
						$("#karigor_printing_area").html('<img src="img/loading.gif"/>');
					 }
				},
				 success: function (response) {
					console.log(response);
					if(emp_type==1){
						$("#master_printing_area").html(response);
						$("#master_clear_area").show();
					 }else{
						$("#karigor_printing_area").html(response);
						$("#karigor_clear_area").show();
					 }
				}
		});
	}
	
	function showKarigorDayWise(emp_type,emp_id,emp_mobile,emp_name,start_date,end_date){
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					emp_type:emp_type,
					emp_id:emp_id,
					emp_mobile:emp_mobile,
					emp_name:emp_name,
					start_date:start_date,
					end_date:end_date,
					showMasterDayWise:1
				},
				 beforeSend: function () {
					 if(emp_type==1){
						$("#master_printing_area").html('<img src="img/loading.gif"/>');
					 }else{
						$("#karigor_printing_area").html('<img src="img/loading.gif"/>');
					 }
				},
				 success: function (response) {
					console.log(response);
					//$("#modal_width").css('width','30%');
					 if(emp_type==1){
						$("#master_printing_area").html(response);
						$("#master_clear_area").show();
					 }else{
						$("#karigor_printing_area").html(response);
						$("#karigor_clear_area").show();
					 }
				}
		});
	}
	
	function showKarigorDayWiseLaser(emp_type,emp_id,emp_mobile,emp_name,start_date,end_date){
		
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					emp_type:emp_type,
					emp_id:emp_id,
					emp_mobile:emp_mobile,
					emp_name:emp_name,
					start_date:start_date,
					end_date:end_date,
					showKarigorDayWiseLaser:1
				},
				 beforeSend: function () {
					 if(emp_type==1){
						$("#master_printing_area").html('<img src="img/loading.gif"/>');
					 }else{
						$("#karigor_printing_area").html('<img src="img/loading.gif"/>');
					 }
				},
				 success: function (response) {
					console.log(response);
					 if(emp_type==1){
						$("#master_printing_area").html(response);
						$("#master_clear_area").show();
					 }else{
						$("#karigor_printing_area").html(response);
						$("#karigor_clear_area").show();
					 }
				}
		});
	}
	
	
		function dateWisePrint(){
		var date1="";
		var date2="",extra_item="",karigor_list="",order_type="",expense_type="";
		var mobile="",order_number="",serial_no="",extra_item="";
		var month="",year="";
		
			karigor_list=$("#emp_lists").val();
			extra_item=$("#emp_statuss").val();
			date1=$("#pstart_date").val();
			date2=$("#pend_date").val();
		var print_type=19;
		
			$.ajax({
						type: 'post',
						url: 'ajax.php',
						data: {
							month:month,
							year:year,
							print_type:print_type,
							date1:date1,
							date2:date2,
							mobile:mobile,
							order_number:order_number,
							serial_no:serial_no,
							extra_item:extra_item,
							karigor_list:karigor_list,
							order_type:order_type,
							expense_type:expense_type,
							dateWisePrint:1
						},
						 beforeSend: function () {
							$("#summery_report2").html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							if(response==2){
								$("#summery_report2").html("No Result Found!").css("color","red");
							}else{
								$("#summery_report2").html(response).css("color","black");
							}
						}
			});
		
		
	}
	
	function dateWiseStaffPrint(){
		var date1="";
		var date2="",extra_item="",karigor_list="",order_type="",expense_type="";
		var mobile="",order_number="",serial_no="",extra_item="";
		var month="",year="";
		
			karigor_list=$("#staff_lists").val();
			extra_item=$("#staff_statuss").val();
			date1=$("#sstart_date").val();
			date2=$("#send_date").val();
			var print_type=19;
		
			$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					month:month,
					year:year,
					print_type:print_type,
					date1:date1,
					date2:date2,
					mobile:mobile,
					order_number:order_number,
					serial_no:serial_no,
					extra_item:extra_item,
					karigor_list:karigor_list,
					order_type:order_type,
					expense_type:expense_type,
					dateWiseStaffPrint:1
				},
				 beforeSend: function () {
					$("#summery_report4").html('<img src="img/loading.gif"/>');
				},
				 success: function (response) {
					console.log(response);
					if(response==2){
						$("#summery_report4").html("No Result Found!").css("color","red");
					}else{
						$("#summery_report4").html(response).css("color","black");
					}
				}
			});
		
		
	}
	
function showEmployeesDetails(d1,d2,search_type,emp_id,emp_name){
	$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				d1:d1,
				d2:d2,
				search_type:search_type,
				emp_id:emp_id,
				emp_name:emp_name,
				showEmployeesDetails:1
			},
			 beforeSend: function () {
				$("#smeasurement").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
				console.log(response);
				$("#modal_width").css('width','50%');
				$("#heading_id").html("Employee Payment");
				$("#smeasurement").html(response);
			}
	});
}

function showEmployeesStaffDetails(d1,d2,search_type,emp_id,emp_name){
	$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				d1:d1,
				d2:d2,
				search_type:search_type,
				emp_id:emp_id,
				emp_name:emp_name,
				showEmployeesStaffDetails:1
			},
			 beforeSend: function () {
				$("#smeasurement").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
				console.log(response);
				$("#modal_width").css('width','50%');
				$("#heading_id").html("Employee Payment");
				$("#smeasurement").html(response);
			}
	});
}

	function autoCalculator(){
		var total_balance_taka=parseFloat(($("#total_balance_taka").val()=="")? 0 : $("#total_balance_taka").val());
		var payment_taka=parseFloat(($("#payment_taka").val()=="")? 0 : $("#payment_taka").val());
		if(payment_taka>total_balance_taka || payment_taka<0){
			//$("#payment_taka").val(null);
			$("#due_taka").html((total_balance_taka-payment_taka));
		}else{
			$("#due_taka").html((total_balance_taka-payment_taka));
		}
	}
	
	function savePaymentLive(){
		var total_balance_taka=parseFloat(($("#total_balance_taka").val()=="")? 0 : $("#total_balance_taka").val());
		var payment_taka=parseFloat(($("#payment_taka").val()=="")? 0 : $("#payment_taka").val());
		var payemnt_remarks=$("#payemnt_remarks").val();
	 if(payment_taka==0){
		$("#payment_taka").css("border-color","red");
		$("#payment_taka").val(null);
		return;		
	 }
	var payment_emp_id=$("#payment_emp_id").val();
	
	$.ajax({
		type: 'post',
		url: 'ajax.php',
		data: {
			emp_id:payment_emp_id,
			total_balance_taka:total_balance_taka,
			payemnt_remarks:payemnt_remarks,
			payment_taka:payment_taka,
			savePaymentLive:1
		},
		beforeSend: function () {
			$("#blnc_success").html('<img src="img/loading.gif"/>');
		},
		 success: function (response) {
			 
			if(response==1){
				$("#blnc_success").html("Save Success!").css("color","green"); 
				$("#payment_taka").css("border-color","gray");
				$("#payment_taka").val(null);
				$("#set_balance").html((total_balance_taka-payment_taka));
				$("#total_balance_taka").val((total_balance_taka-payment_taka));
				$("#due_taka").html(null);
				$("#payemnt_remarks").val(null);
			}else{
				$("#blnc_success").html("Not Success!").css("color","red"); 
			 }
		}
	});
 }
 
 function saveStaffPaymentLive(){
		var total_balance_taka=parseFloat(($("#total_balance_taka").val()=="")? 0 : $("#total_balance_taka").val());
		var payment_taka=parseFloat(($("#payment_taka").val()=="")? 0 : $("#payment_taka").val());
		var payemnt_remarks=$("#payemnt_remarks").val();
	 if(payment_taka==0){
		$("#payment_taka").css("border-color","red");
		$("#payment_taka").val(null);
		return;		
	 }
	var payment_emp_id=$("#payment_emp_id").val();
	
	$.ajax({
		type: 'post',
		url: 'ajax.php',
		data: {
			emp_id:payment_emp_id,
			total_balance_taka:total_balance_taka,
			payemnt_remarks:payemnt_remarks,
			payment_taka:payment_taka,
			saveStaffPaymentLive:1
		},
		beforeSend: function () {
			$("#blnc_success").html('<img src="img/loading.gif"/>');
		},
		 success: function (response) {
			 
			if(response==1){
				$("#blnc_success").html("Save Success!").css("color","green"); 
				$("#payment_taka").css("border-color","gray");
				$("#payment_taka").val(null);
				$("#set_balance").html((total_balance_taka-payment_taka));
				$("#total_balance_taka").val((total_balance_taka-payment_taka));
				$("#due_taka").html(null);
				$("#payemnt_remarks").val(null);
			}else{
				$("#blnc_success").html("Not Success!").css("color","red"); 
			 }
		}
	});
 }
 
  function getAllEmployeeList(){
	  var attendance_date=$("#attendance_date").val();
	 $.ajax({
		type: 'post',
		url: 'sql.php',
		data: {
			attendance_date:attendance_date,
			getAllEmployeeList:1
		},
		beforeSend: function () {
			$("#attendance_list").html('<img src="img/loading.gif"/>');
		},
		 success: function (response) {
			 console.log(response);
			if(response!=2){
				$("#attendance_list").html(response); 
				setAttendanceTable(attendance_date);
			}else{
				$("#attendance_list").html("No Result Found!"); 
			 }
		}
	});
 }
 
 function setAttendanceTable(attendance_date){
	 $.ajax({
		type: 'post',
		url: 'sql.php',
		data: {
			attendance_date:attendance_date,
			setAttendanceTable:1
		},
		beforeSend: function () {
			$("#attendance_tbl").html('<img src="img/loading.gif"/>');
		},
		 success: function (response) {
			 console.log(response);
			if(response!=2){
				$("#attendance_tbl").html(response); 
			}else{
				$("#attendance_tbl").html("No Result Found!"); 
			 }
		}
	});
 }
 
 function processMonthlySalary(emp_id,start_date,end_date){
	 if(confirm('Do you want confirm to process?')){
		 var tot_monthly_salary=$("#tot_monthly_salary").val();
		 if(tot_monthly_salary==0 || tot_monthly_salary==""){
			 alert("Warning! Enter monthly salary.");
			 $("#tot_monthly_salary").click();
			 return;
		 }
		 $.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				emp_id:emp_id,
				start_date:start_date,
				end_date:end_date,
				tot_monthly_salary:tot_monthly_salary,
				processMonthlySalary:1
			},
			 success: function (response) {
				 console.log(response);
				if(response==1){
					$("#tot_monthly_salary").css('border-color','blue'); 
					document.getElementById("monthly_process_btn").disabled = true;
				}else{
					$("#tot_monthly_salary").css('border-color','red'); 
				}
			}
		});
 }
 }
 
 function salaryProcessedBtn(tbl_id,emp_id,emp_type,salary_type,emp_name,emp_mobile,attendence_date,org_salary){
	 if(confirm('Do you want to process salary?')){
	 $.ajax({
		type: 'post',
		url: 'sql.php',
		data: {
			tbl_id:tbl_id,
			emp_id:emp_id,
			emp_type:emp_type,
			salary_type:salary_type,
			emp_name:emp_name,
			emp_mobile:emp_mobile,
			attendence_date:attendence_date,
			org_salary:org_salary,
			deduction_salary:($("#deduction_salary"+tbl_id).val()=="")? 0 : $("#deduction_salary"+tbl_id).val(),
			remarks:($("#remarks"+tbl_id).val()=="")? '-' : $("#remarks"+tbl_id).val(),
			salaryProcessedBtn:1
		},
		beforeSend: function () {
			document.getElementById("salary_process"+tbl_id).disabled = true;
		},
		 success: function (response) {
			 console.log(response);
			if(response!=1){
				document.getElementById("salary_process"+tbl_id).disabled = false;
			}
		}
	});
 }
 }
 
 function setEmpStatus(asstatus,emp_id,emp_type,salary_type,user_name,mobile,attendance_date,salary){
	 var emp_status=(asstatus=="present")? 'উপস্থিতি স্টেটাস দিতে চান?' : 'অনুপস্থিতি স্টেটাস দিতে চান?';
	 if(confirm(emp_status)){
		 $.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				asstatus:asstatus,
				emp_id:emp_id,
				emp_type:emp_type,
				salary_type:salary_type,
				user_name:user_name,
				mobile:mobile,
				attendance_date:attendance_date,
				salary:salary,
				setEmpStatus:1
			},
			beforeSend: function () {
				$("#attendance_tbl").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
				 console.log(response);
				if(response!=2){
					getAllEmployeeList();
					//$("#attendance_list").html(response); 
				}else{
					$("#attendance_tbl").html("Something error. Please try again."); 
				 }
			}
		});
	 }
 }
 
 function delPresentStatus(table_id){
	 if(confirm("ডিলিট করতে চান?")){
		 $.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				tbl_id:table_id,
				delPresentStatus:1
			},
			 success: function (response) {
				 console.log(response);
				if(response==1){
					getAllEmployeeList();
				}else{
					$("#attendance_tbl").html("Something error. Please try again."); 
				}
			}
		});
	 }
 }
 
  function updateAnyColumn(field_name,tbl_id,tbl_name){
	 	 $.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				tbl_id:tbl_id,
				field_name:field_name,
				tbl_name:tbl_name,
				field_value:$("#"+field_name+tbl_id).val(),
				updateAnyColumn:1
			},
			 success: function (response) {
				 console.log(response);
				if(response==1){
					$("#"+field_name+tbl_id).css('border-color','blue');
				}else{
					$("#"+field_name+tbl_id).css('border-color','red');
				}
			}
		});
	}
	
	function getEmpAttendance(){
		var sdate=$("#attenstart_date").val();
		var edate=$("#attenend_date").val();
		if(sdate=="" || edate==""){
			alert("Please select date calendar.");
			$("#attenstart_date").focus();
			return;
		}
		var attendance_emp_id=$("#attendance_emp_id").val();
		if(attendance_emp_id==""){
			alert("Please select any employee.");
			return;
		}
	 	 $.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				sdate:sdate,
				edate:edate,
				attendance_emp_id:attendance_emp_id,
				getEmpAttendance:1
			},
			 beforeSend: function () {
				$("#attendance_tbl").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
				 console.log(response);
				if(response!=2){
					$("#attendance_tbl").html(response); 
				}else{
					$("#attendance_tbl").html("Something error. Please try again."); 
				 }
				 
				 setMonthlyProcess(attendance_emp_id,sdate,edate);
			}
		});
	}
	
	function setMonthlyProcess(attendance_emp_id,sdate,edate){
		$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				sdate:sdate,
				edate:edate,
				attendance_emp_id:attendance_emp_id,
				setMonthlyProcess:1
			},
			 success: function (response) {
				console.log(response);
				if(response!=2){
					$("#process_btn").html(response);
				}
			}
		});
  }
	
	function showAllPayment(){
		$("#srcbymob_print").click();
	}
	
	function showAllStaffPayment(){
		$("#staffrcbymob_print").click();
	}
	
	function printOrder(print_area){
		var order_number="";
		
		printDiv(print_area);
	}
	
	function printDiv(divName) {
		var printContents = document.getElementById(divName).innerHTML;
		var originalContents = document.body.innerHTML;
		document.body.innerHTML = printContents;
		window.print();
		document.body.innerHTML = originalContents;
		
	}
	
	
</script>

<style>
.chkbox{
	 -ms-transform: scale(2); /* IE */
  -moz-transform: scale(2); /* FF */
  -webkit-transform: scale(2); /* Safari and Chrome */
  -o-transform: scale(2); /* Opera */
  transform: scale(2);
  padding: 10px;
}

.checkboxtext
{
  /* Checkbox text */
  font-size: 120%;
  display: inline;
  padding-left: 6px;
  padding-right: 40px;
}
#tblhight{
			overflow-y: scroll;
		overflow-x: hidden;
</style>

<?php
	}else{
		header("location:index.php?id=1");
	}
?>
