
<?php 

$psmsquery=$conn->query("select c.id,c.com_name,
CASE
	WHEN c.com_head_id>0 THEN (select com_name from company where id=c.com_head_id)
		ELSE '' END haed_name
from company c where c.is_active=1");
?>
<div class="login-form">
    <form action="#" method="post">
       
		<div class="form-group">
            <select class="chosen-select form-control" id="com_id" name="com_id" data-placeholder="Choose a State..." required>
			<?php
				if(mysqli_num_rows($psmsquery)>0){
					while($row=mysqli_fetch_array($psmsquery)){
						if($row['haed_name']!=""){
							$head=$row['haed_name']."(".$row['com_name'].")";
						}else{
							$head=$row['com_name'];
						}
			?>
                <option  value="<?php echo $row['id']; ?>"><?php echo $head; ?></option>
            <?php 
				}
			} 
					?>                           
           </select>
        </div>
		
		<div class="form-group">
            <input type="text" name="trxn" autocomplete="off" maxlength="11" class="form-control" placeholder="Enter TRXN Number" required="required">
        </div>
		<div class="form-group">
            <input type="text" name="sms_qty" autocomplete="off" maxlength="11" class="form-control" placeholder="SMS Qty" required="required">
        </div>		
        
        <div class="form-group">
            <button type="submit" name="btn" value="btn" class="btn btn-primary btn-block">Submit</button>
        </div>
		</form>
		
		<?php 
		
			if(isset($_REQUEST['btn'])){
				$com_id=trim($_REQUEST['com_id']);
				$trxn=trim($_REQUEST['trxn']);
				$sms_qty=trim($_REQUEST['sms_qty']);
			}
		?>
        <div class="clearfix">
            <label class="pull-left checkbox-inline">
			<?php 
			if(isset($_REQUEST['btn'])){
				
			if($conn->query("insert into purchase_sms(com_id,purchase_sms_qty,trxn) values('$com_id',$sms_qty,'$trxn')")){
				$chk_sms=$conn->query("select rem_sms from rem_sms where com_id=$com_id");
				$row=mysqli_fetch_array($chk_sms);
				$tsms=$row['rem_sms']+$sms_qty;
				$conn->query("update rem_sms set rem_sms=$tsms where com_id=$com_id");
				mysqli_close($conn);
				echo "Success!";
			}
			}
			
			?>
			</label>
            <!--<a href="#" class="pull-right">Forgot Password?</a>-->
        </div>        
    
	
	
   
</div>
