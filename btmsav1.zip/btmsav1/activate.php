<?php 
	function permission(){
		include'library.php';
		if(check_internet_connection()==1)
			return 1;
			return 0;
	}
	
	if(isset($_POST['umobile'])){
		$uname=trim($_POST['uname']);
		$umobile=trim($_POST['umobile']);
			if (permission()=='1'){
				$getData = getData(2);
				$response = file_get_contents($_SESSION['API']."api/activate.php?uname=$uname&umobile=$umobile&maca=$getData&chk=1"); 
				$json = json_decode($response, true);
				$auth=$json['auth'];
				if($auth==1){
					$getData=md5($getData);
					db($uname,$umobile,$getData,1);
					header("location:index.php?id=5");
				}else{
					header("location:index.php?id=6&it=2&load=1");
				}
			}else{
				header("location:index.php?id=6&it=1&it=1&load=1");
			}
	}
	
	if(isset($_POST['scode'])){
		permission();
		$scode=md5($_POST['scode']);
		$chk=db('','',$scode,2);
		if($chk){
			header("location:index.php?id=1");
		}else{
			header("location:index.php?id=5");
		}
	}
	
	if(isset($_POST['chk_activate'])){
		$permission=permission();
		$getData = getData(1);
		if ($permission=='1'){
			$chk=db('','',$getData,3);
			echo $chk;
		}else{
			$chk=db('','',$getData,3);
			if($chk=='1')
				echo $chk;
			else
				echo 3;
		} 
	}
	
	
	
?>
