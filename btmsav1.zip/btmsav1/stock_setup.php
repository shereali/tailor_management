<?php 
	date_default_timezone_set("Asia/Dhaka");
	$smonth=date("m");
	$com_id=($_SESSION['COM_ID']);
	$expense=$conn->query("select * from expense_type where is_active=1");
	$expense2=$conn->query("select * from expense_type where is_active=1");
	$product=$conn->query("select * from product where is_active=1 and com_id=$com_id and ptype=1 order by steps asc limit 0,500");
	$karigors=$conn->query("select id,user_name,mobile,emp_type from user where is_active=1 and com_id=$com_id and emp_type in(1,2) order by emp_type asc");
	$karigorss=$conn->query("select id,user_name,mobile,emp_type from user where is_active=1 and com_id=$com_id and emp_type in(1,2) order by emp_type asc");
	//$emp_info=$conn->query("SELECT mh.user_name,mh.id,mh.mobile,mh.emp_type,(select taka from wages_head where emp_id=mh.id and com_id=mh.com_id) wages FROM `user` mh WHERE mh.com_id=$com_id and mh.is_active=1 and mh.emp_type in(1,2) order by mh.emp_type asc");
	
?>
<ul class="nav nav-tabs" style="display: none;">
	
	<?php 
	if($_SESSION['SETTINGS']==1){ ?>
	<li class="active"><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" href="#menu4">Settings</a></li>
	<?php }
	?>
	<!--<li><a data-toggle="tab" href="#menu5">Old Order</a></li>-->
  </ul>
	
  <div class="tab-content">
    <div id="home" class="tab-pane">
	<br/>
    <div class="panel-group">
		
		<div class='panel panel-info'>
		
		  <div class="panel-heading">Search by mobile/Order/Serial No.</div>
		 
		  <div class="panel-body">
				
				<div class="row">
				<div class="col-xs-12 col-sm-6">
					<p for="comment">Mobile/Order/Serial Number:</p>
						<input type="text" maxlength="11" style="font-weight: bold;font-size:18px;font-style: italic;text-transform:uppercase" name="mobile" onkeyup="getEditableOrder();" autocomplete="off" placeholder="Enter Mobile/Order/Serial Number" id="mobile" class="form-control">
					<span id="allsearchable_auto_mobile" style="z-index: 99999999999999;overflow: hidden;position: fixed;width: 240px;">
					</span>
					<br/>
					
					<!--<button onclick="searchOrder();" name="btn" id="srcbymob" value="sub" class="btn btn-success">Search</button>-->
					<span id="sms"></span>
					
				</div>
				<div class="col-xs-12 col-sm-6">
				
					<span id="previous_due_tab">
					<p for="comment" style="text-align:right">Previous Total Due:</p>
						<input readonly type="text" style="font-weight: bold;font-size:18px;font-style: italic;text-align:right" name="previous_due" id="previous_due" class="form-control">
					</span>
				</div>
				</div>
				<br/>
				<div id="src_result">
				</div>
				<input type="hidden" id="last_id_hide" value="3"/>
				<div class="form-group" style="margin-top:15px">
					<button onclick="seaMore();" name="btn" id="morebtn" class="btn btn-danger">More+</button><span id="load_img"></span>
				</div>
						
				</div>
		  </div>
		 
		</div>
	

	</div>
	<div id="menu2" class="tab-pane">
      <br/>
	  <div class="row">
			<div class="col-xs-12 col-sm-2" id="extrafirsts">
				<label for="comment">Monthly<sup style="color:red">*</sup>:</label>
				<select class="form-control" id="month">
					<option <?php echo ($smonth=='01')? 'selected' : ''; ?> value="1">January</option>
					<option <?php echo ($smonth=='02')? 'selected' : ''; ?> value="2">February</option>
					<option <?php echo ($smonth=='03')? 'selected' : ''; ?> value="3">March</option>
					<option <?php echo ($smonth=='04')? 'selected' : ''; ?> value="4">April</option>
					<option <?php echo ($smonth=='05')? 'selected' : ''; ?> value="5">May</option>
					<option <?php echo ($smonth=='06')? 'selected' : ''; ?> value="6">June</option>
					<option <?php echo ($smonth=='07')? 'selected' : ''; ?> value="7">July</option>
					<option <?php echo ($smonth=='08')? 'selected' : ''; ?> value="8">August</option>
					<option <?php echo ($smonth=='09')? 'selected' : ''; ?> value="9">September</option>
					<option <?php echo ($smonth=='10')? 'selected' : ''; ?> value="10">October</option>
					<option <?php echo ($smonth=='11')? 'selected' : ''; ?> value="11">November</option>
					<option <?php echo ($smonth=='12')? 'selected' : ''; ?> value="12">December</option>
				</select>
			</div>
			<div class="col-xs-12 col-sm-2" id="extrafirsts2">
				<label for="comment">Year<sup style="color:red">*</sup>:</label>
				<select class="form-control" id="year">
					<option value="2021">2021</option>
					<option value="2022">2022</option>
					<option value="2023">2023</option>
					<option value="2024">2024</option>
					<option value="2025">2025</option>
					<option value="2026">2026</option>
					<option value="2027">2027</option>
					<option value="2028">2028</option>
					<option value="2029">2029</option>
					<option value="2030">2030</option>
				</select>
			</div>
			<div class="col-xs-12 col-sm-2" id="extraitem">
				<label for="comment">Item List<sup style="color:red">*</sup>:</label>
				<select class="form-control" id="extra_item">
				<option value="all">All Item</option>
				<?php 
					while($rows=mysqli_fetch_array($product)){
				?>
				<option value="<?php echo $rows['id']; ?>"><?php echo $rows['product_name']; ?></option>
				<?php 
				}
				?>
				</select>
			</div>
			<div class="col-xs-12 col-sm-2" id="item_status">
				<label for="comment">Status<sup style="color:red">*</sup>:</label>
				<select class="form-control" id="item_statuss">
				<option value="order">Order Status</option>
				<option value="receive">From Factory Receive Status</option>
				<option value="factory_delivery">Full Delivery Status</option>
				<option value="only_delivery">Will be Delivered</option>
				<!--<option value="delivery">Physical Delivery Status</option>-->
				
				</select>
			</div>
			<div class="col-xs-12 col-sm-2" id="employee_list">
				<label for="comment">Expense Type<sup style="color:red">*</sup>:</label>
				<select class="form-control" id="employee_lists">
				<option value="">All</option>
				<?php 
					while($rows=mysqli_fetch_array($expense)){
				?>
				<option value="<?php echo $rows['id']; ?>"><?php echo $rows['expense']; ?></option>
				<?php 
				}
				?>
				</select>
			</div>
			<div class="col-xs-12 col-sm-2" id="expensetype">
				<label for="comment">Expense Type<sup style="color:red">*</sup>:</label>
				<select class="form-control" id="expense_type">
				<option value="">All</option>
				<?php 
					while($rows=mysqli_fetch_array($expense2)){
				?>
				<option value="<?php echo $rows['id']; ?>"><?php echo $rows['expense']; ?></option>
				<?php 
				}
				?>
				</select>
			</div>
			<div class="col-xs-12 col-sm-4" id="order_status">
				<label for="comment">Order Status<sup style="color:red">*</sup>:</label>
				<select class="form-control" id="order_type">
				
				<option value="pending">Pending Order (Stay in Showroom)</option>
				<option value="inprogress">Receive Order (From Factory)</option>
				<option value="complete">Fully Deliverd Order (Customer Delivery)</option>
				
				</select>
			</div>
			<div class="col-xs-12 col-sm-2" id="karigors">
				<label for="comment">Karigor List<sup style="color:red">*</sup>:</label>
				<select class="form-control" id="karigor_list">
				<?php 
					while($rowss=mysqli_fetch_array($karigors)){
						$emp_types=($rowss['emp_type']==1)? 'Master' : 'Karigor';	
				?>
				<option style='color: <?php echo ($rowss['emp_type']==1)? 'blue' : ''; ?>' value="<?php echo $rowss['id']."#sep#".$rowss['emp_type']; ?>"><?php echo $rowss['user_name']."(".$rowss['mobile'].")-".$emp_types; ?></option>
				<?php 
					
				}
				?>
				</select>
			</div>
			<div class="col-xs-12 col-sm-2" id="decision_area">
				<label for="comment">Decision Type<sup style="color:red">*</sup>:</label>
				<select class="form-control" id="decision_list">
				<option style='' value="urgent">আর্জেন্ট অর্ডার</option>
				<option style='' value="todays">আজকের অর্ডার</option>
				<option style='' value="tomorrow">আগামী কালকের অর্ডার</option>
				<option style='' value="twodays">২ দিন পরের অর্ডার</option>
				<option style='' value="expireddelivery">Expired ডেলিভারি অর্ডার</option>
				</select>
			</div>
			<div class="col-xs-12 col-sm-1" id="emp_status">
				<label for="comment">Status<sup style="color:red">*</sup>:</label>
				<select class="form-control" id="emp_statuss">
					<option value="earning">Earning</option>
					<option value="payable">Payable</option>
				</select>
			</div>
			<div class="col-xs-12 col-sm-2" id="emp_list">
				<label for="comment">Employee List<sup style="color:red">*</sup>:</label>
				<select class="form-control" id="emp_lists">
				<option value="">All</option>
				<?php 
					while($rows=mysqli_fetch_array($karigorss)){
					$emp_type=($rows['emp_type']==1)? 'Master' : 'Karigor';	
				?>
				<option style='color: <?php echo ($rows['emp_type']==1)? 'blue' : ''; ?>' value="<?php echo $rows['id']; ?>"><?php echo $rows['user_name']."(".$rows['mobile'].")-".$emp_type; ?></option>
				<?php 
					
				}
				?>
				</select>
			</div>
			<div class="col-xs-12 col-sm-2" id="firsts">
				<label for="comment">From Date<sup style="color:red">*</sup>:</label>
				<input type="text" autocomplete="off" name="date1" id="date1" class="form-control" data-select="date">
			</div>
			<div class="col-xs-12 col-sm-2" id="seconds">
				<label for="comment">Mobile Number<sup style="color:red">*</sup>:</label>
				<input type="text" class="form-control" maxlength="11" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" name="smobile" id="smobile" />
			</div>
			<div class="col-xs-12 col-sm-2" id="thirds">
				<label for="comment">Order/Serial Number:</label>
				<input type="text" class="form-control" autocomplete="off" maxlength="30" style="font-weight: bold;font-size:18px;font-style: italic;text-transform:uppercase" placeholder="Order Numbe." name="order_number" id="order_number" />
				<span id="code_print_check" style="color:red;font-size: 11px;"></span>
			</div>
			<div class="col-xs-12 col-sm-2" id="fours">
				<label for="comment">To Date:</label>
				<input type="text" autocomplete="off"  value="<?php echo date("d/m/Y"); ?>" name="date2" id="date2" class="form-control" data-select="date">
			</div>
				<input type="hidden" class="form-control" autocomplete="off" maxlength="30" style="font-weight: bold;font-size:18px;font-style: italic;" name="serial_no" id="serial_no" />
			
			<div class="col-xs-12 col-sm-3">
				<label for="comment">Print Type:</label>
				<select class="form-control" name="print_type" style="font-weight: bold;font-size:18px;font-style: italic;" onchange="selectType();" id="print_type">
					<?php
						if($_SESSION['MEASURE_TYPE']!=0){					
					?>
						<option value="2">Production Copy</option>
						<option value="1">Customer Copy</option>
					<?php 
						}else{
					?>
						<!--<option value="1">Customer Copy</option>-->
						<option value="2">Print Copy</option>
						<!--<option value="20">Only Customer Copy</option>
						<option value="21">Only Measurement Copy</option>
						<option value="13">Office Copy</option>
						<option value="22">Print Code</option>-->
						<option value="10">Money Receipt</option>
					<?php } ?>
					<option value="3">Daily Report</option>
					<!--<option value="4">Empty Customer Copy</option>-->
					<?php
						if($_SESSION['ORD_SETTINGS']==1){ //1=show, 0=hide
					?>
					<option value="8">Monthly Report</option>
					<!--<option value="18">Item Status</option>
					<option value="15">Order Status</option>-->
					<!--<option value="7">Monthly Employee Salary</option>-->
					<!--<option value="12">Item Not Making(In Showroom)</option>
					<option value="17">Item Not Making(In Factory)</option>-->
					<!--<option value="23">Master/Karigor Pending Report</option>-->
					<!--<option value="14">Karigor Order Report</option>-->
					<!--<option value="19">Employees Report</option>-->
					<option value="16">Expense Report</option>
					<option value="11">Item Report(Fabrics Profit)</option>
					<option value="9">Stock Report</option>
					<option value="24">Decision</option>
					<option value="5">Monthly Total Order</option>
					<option value="6">Monthly Total Delivery</option>
					<?php } ?>
				</select>
			</div>
			<div class="col-xs-12 col-sm-2" style="padding-top: 24px;">
					
					<button onclick="dateWisePrint();" name="btn" id="srcbymob_print" value="sub" class="btn btn-success">Search</button>
					<?php
						if($_SESSION['MEASURE_TYPE']==0){ //Standard copy print
					?>
					<button onclick="printOrder();" name="btn" id="printBtns" value="sub" class="btn btn-info">Print</button>
					<?php
						}else{
					?>
					<button onclick="printOrderOthers();" name="btn" id="printBtns" value="sub" class="btn btn-info">Print</button>
					<?php
						}
						if(@$_SESSION['EMAIL']!=""){ //email
					?>
					<span id="send_email_load"><button onclick="sendEmail();" name="btn" id="send_email" value="sub" class="btn btn-warning">Send Email</button></span>
						<?php } ?>
					<span id="sms2"></span>
				
			</div>
		</div>
		<br/>
		<span id="summery_report2"></span>
	 
		</div>
	
  
    <div id="menu3" class="tab-pane fade">
      <br/>
     <span id="arc">
		<div class="panel-group">
		
		<div class='panel panel-info'>
		
		  <div class="panel-heading">Search by Year</div>
		 
		  <div class="panel-body">
				
				
				<label for="comment">Year:</label>
					<select class="form-control" id="searching_year">
						<option value="all">All</option>
						<option value="2019">2019</option>
						<option value="2020">2020</option>
						<option value="2021">2021</option>
						<option value="2022">2022</option>
						<option value="2023">2023</option>
						<option value="2024">2024</option>
						<option value="2025">2025</option>
						
					</select>	
				
				<div class="input-group">
				<label for="comment"></label>
							
				</div>
				<button onclick="searchAllOrder();" name="btn" id="asrcbtn" value="sub" class="btn btn-success">Search</button>
				<span id="sms_arc"></span>
				
		  </div>
		 
		</div>
		<span id="allorder">
		</span>
		

	</div>
	 </span>
    </div>
	<div id="menu4" class="tab-pane fade in active">
      <br/>
	  <div class="row" style="background: white;">
		<div class="col-xs-12 col-sm-2">
			
			<button onclick="settingsData(12);" style="margin: 5px;" name="btn" value="sub" class="btn btn-primary form-control"><?php echo ($_SESSION['IS_STOCK']==1)? "Item Setup" : "Fabrics Item"; ?></button>
			<?php
				if($_SESSION['IS_STOCK']==1){
			?>
			<button onclick="settingsData(15);" style="margin: 5px;" name="btn" value="sub" class="btn btn-danger form-control">Item Receive</button>
			<button onclick="settingsData(16);" style="margin: 5px;" name="btn" value="sub" class="btn btn-success form-control">Stock Adjustment</button>

			<?php } ?>
			
		</div>
		<div id="form_tbl">
			
		</div>
		</div>	
	</div>
	
	<div id="menu5" class="tab-pane fade">
      <br/>
	  <div class="row">
		<div class="col-xs-12 col-sm-4">
			<label for="comment">Physical Order Number<sup style="color:red">*</sup>:</label>
				<input type="text" class="form-control" autocomplete="off" name="order_numbers" id="oorder_numbers" />
				<label for="comment">Mobile Number<sup style="color:red">*</sup>:</label>
				<input type="text" class="form-control" autocomplete="off" maxlength="11" name="omobile_num" id="omobile_num" />
				<button onclick="saveOldOrder();" style="margin-top:15px" name="btn" value="sub" class="btn btn-warning form-control">Save</button>
				<span id="old_load"></span>
		</div>
		
			<div class="col-xs-12 col-sm-8">
				<div style='margin-bottom: 15px;overflow: hidden;'>
					<div class="col-xs-12 col-sm-4">
						<label for="comment">Physical Order/Mobile Number<sup style="color:red">*</sup>:</label>
						<input type="text" class="form-control" autocomplete="off" name="order_numbers" id="oorder_numberormobile" />
					</div>
					<div class="col-xs-12 col-sm-2">
						<label for="comment">*</label>
						<button onclick="searchOldOrder();" style="" name="btn" value="sub" class="btn btn-success form-control">Search</button>
					</div>
					<div class="col-xs-12 col-sm-6">
						<span id="old_load2"></span>
					</div>
				</div>
				<div id="row">
					<table id="example2" class="table table-striped table-bordered">
						<thead>
							<tr>
								<th>SL</th>
								<th>Order Number</th>
								<th>Mobile Number</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody id="otbl_one">
						</tbody>
					</table>
				</div>
			</div>
		
	</div>
  </div>
 </div> 
 
 <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" id="heading_id"></h4>
        </div>
        <div class="modal-body">
          <span id="smeasurement"></span>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
  <script>
  
  function selectType(){
	  if($("#print_type").val()==22){
		  $("#code_print_check").html("Oder Numer-Code-Qty");
	  }else{
		  $("#code_print_check").html(null);
	  }
	  if($("#print_type").val()==3){
		  $("#decision_area,#emp_status,#emp_list,#extrafirsts,#extrafirsts2,#seconds,#thirds,#fours,#extraitem,#karigors,#order_status,#expensetype,#item_status").hide("slow");
		  $("#firsts").show("slow");
		  $("#date1").click();
		  $("#date1").focus();
	  }else if($("#print_type").val()==9){
		  $("#decision_area,#firsts,#emp_status,#emp_list,#extrafirsts,#extrafirsts2,#seconds,#thirds,#fours,#extraitem,#karigors,#order_status,#expensetype,#item_status").hide("slow");
		  $("#date1").val(null);
	  }else if($("#print_type").val()==1 || $("#print_type").val()==2 || $("#print_type").val()==20 || $("#print_type").val()==21 || $("#print_type").val()==22){
		  $("#decision_area,#emp_status,#emp_list,#extrafirsts,#extrafirsts2,#send_email,#fours,#extraitem,#karigors,#order_status,#expensetype,#item_status").hide("slow");
		  $("#firsts,#seconds,#thirds").show("slow");
		  $("#date1").val(null);
	  }else if($("#print_type").val()==4){
		  $("#decision_area,#emp_status,#emp_list,#extrafirsts,#extrafirsts2,#firsts,#seconds,#thirds,#send_email,#fours,#extraitem,#karigors,#order_status,#expensetype,#item_status").hide("slow");
	  }else if($("#print_type").val()==5 || $("#print_type").val()==6 || $("#print_type").val()==7){
		   $("#decision_area,#emp_status,#emp_list,#firsts,#seconds,#thirds,#send_email,#fours,#extraitem,#karigors,#order_status,#expensetype,#item_status").hide("slow");
		   $("#extrafirsts,#extrafirsts2").show("slow");
	 }else if($("#print_type").val()==10){
		 $("#decision_area,#emp_status,#emp_list,#firsts,#seconds,#extrafirsts,#extrafirsts2,#send_email,#fours,#extraitem,#karigors,#order_status,#expensetype,#item_status").hide("slow");
		 $("#thirds").show("slow");
	 }else if($("#print_type").val()==11 || $("#print_type").val()==8){
		 $("#decision_area,#emp_status,#emp_list,#seconds,#extrafirsts,#extrafirsts2,#send_email,#thirds,#extraitem,#karigors,#order_status,#expensetype,#item_status").hide("slow");
		 $("#firsts,#fours").show("slow");
	 }else if($("#print_type").val()==12 || $("#print_type").val()==17){
		 $("#decision_area,#emp_status,#emp_list,#seconds,#extrafirsts,#extrafirsts2,#send_email,#thirds,#karigors,#order_status,#expensetype,#item_status").hide("slow");
		 $("#firsts,#fours,#extraitem").show("slow");
	 }else if($("#print_type").val()==14 || $("#print_type").val()==23){
		 $("#decision_area,#emp_status,#emp_list,#seconds,#extrafirsts,#extrafirsts2,#send_email,#thirds,#firsts,#fours,#extraitem,#order_status,#expensetype,#item_status").hide("slow");
		 $("#karigors").show("slow");
	 }else if($("#print_type").val()==15){
		 $("#decision_area,#emp_status,#emp_list,#seconds,#extrafirsts,#extrafirsts2,#send_email,#thirds,#firsts,#fours,#extraitem,#karigors,#expensetype,#item_status").hide("slow");
		 $("#order_status").show("slow");
	 }else if($("#print_type").val()==16){
		 $("#decision_area,#emp_status,#emp_list,#seconds,#extrafirsts,#extrafirsts2,#send_email,#thirds,#karigors,#order_status,#extraitem,#item_status").hide("slow");
		 $("#firsts,#fours,#expensetype").show("slow");
	 }else if($("#print_type").val()==18){
		 $("#decision_area,#emp_status,#emp_list,#seconds,#extrafirsts,#extrafirsts2,#send_email,#thirds,#karigors,#order_status,#expensetype,#extraitem").hide("slow");
		 $("#firsts,#fours,#item_status").show("slow");
	 }else if($("#print_type").val()==19){
		 $("#decision_area,#item_status,#seconds,#extrafirsts,#extrafirsts2,#send_email,#thirds,#karigors,#order_status,#expensetype,#extraitem").hide("slow");
		 $("#firsts,#fours,#emp_status,#emp_list").show("slow");
	 }else if($("#print_type").val()==24){
		 $("#firsts,#fours,#emp_status,#emp_list,#item_status,#seconds,#extrafirsts,#extrafirsts2,#send_email,#thirds,#karigors,#order_status,#expensetype,#extraitem").hide("slow");
		 $("#decision_area").show("slow");
	 }
  }
  
  function getMeasurementType(){
	$.ajax({
		type: 'post',
		url: 'ajax.php',
		data: {
		getMeasurementType:1
		},
			success: function (response) {
			console.log(response);
			$("#measurement_type").html(response);
			}

	});
  }
  
  function sendEmail(){
	  if(confirm("Do you want to send email?")){
		var order_sql=$("#order_sql").val();
		var order_del=$("#order_del").val();
		var receivable_list=$("#receivable_list").val();
		var direct_sale=$("#direct_sale").val();
		var expense=$("#expense").val();
		console.log(order_sql);
		console.log(order_del);
		console.log(receivable_list);
		console.log(direct_sale);
		console.log(expense);
		//exit();
		  $.ajax({
			type: 'post',
			url: 'mail.php',
			data: {
				order_sql:order_sql,order_del:order_del,receivable_list:receivable_list,direct_sale:direct_sale,expense:expense,send_email:1
			},
				beforeSend: function () {
					$("#send_email_load").html('<img src="img/loading.gif"/>');
				},
				success: function (response) {
					console.log(response);
					if(response==1){
						$("#send_email_load").html('<button onclick="sendEmail();" name="btn" id="send_email" value="sub" class="btn btn-warning">Send Email</button> <p><b>Mail has been sent!</b></p>').css("color","green");
					}else if(response==2){ //internet problem
						$("#send_email_load").html('<button onclick="sendEmail();" name="btn" id="send_email" value="sub" class="btn btn-warning">Send Email</button> <p><b>Mail no sent. Internet problem!</b></p>').css("color","red");
					}else{
						$("#send_email_load").html('<button onclick="sendEmail();" name="btn" id="send_email" value="sub" class="btn btn-warning">Send Email</button> <p><b>Mail did not sent!</b></p>').css("color","red");
					}
				}
						
			});
	  }
  }
  
  	function getEditableOrder(){
		var edit_ord_number=$("#mobile").val();
		var first_digit = edit_ord_number.charAt(0);
		 if (first_digit.toLowerCase() != '0') {
			 $.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					chk_searchable_number: 1, 
					mobile:edit_ord_number,
					autoCompleteMobileSearchable:1
				},
				 success: function (response) {
					 
					 if(mobile!=""){
						$("#allsearchable_auto_mobile").html(response); 
					 }else{
						$("#allsearchable_auto_mobile").html(null);  
					 }
				}
			});
		 }else{
				var mobile=edit_ord_number;
				if(mobile=="" || mobile.length<11 || mobile.length>11){
					$("#cus_name").val(null);
					$.ajax({
						type: 'post',
						url: 'ajax.php',
						data: {
							chk_searchable_number: 2,
							mobile:mobile,
							autoCompleteMobileSearchable:1
						},
						 success: function (response) {
							 
							 if(mobile!=""){
								$("#allsearchable_auto_mobile").html(response); 
							 }else{
								$("#allsearchable_auto_mobile").html(null);  
							 }
						}
					});
					
				}else{
					$.ajax({
						type: 'post',
						url: 'ajax.php',
						data: {
							chk_searchable_number: 2,
							mobile:mobile,
							autoCompleteMobileSearchable:1
						},
						 success: function (response) {
							// $("#editable_auto_mobile").html(null);  
							 if(mobile!=""){
								$("#allsearchable_auto_mobile").html(response); 
							 }else{
								$("#allsearchable_auto_mobile").html(null);  
							 }
								
						}
					});
				}
			}
	}
  
  function orderChangeOption(id){
	  if(confirm("আপনি কি Settings পরিবর্তন করতে চান?")){
		  if(id==1){
		   var order_change_option=$("#order_change_option").val();
		  }
		  if(id==2){
		   var order_change_option=$("#order_change_option2").val();
		  }
		  if(id==3){
		   var order_change_option=$("#order_change_option3").val();
		  }
		  if(id==4){
		   var order_change_option=$("#order_change_option4").val();
		  }
		  if(id==5){
		   var order_change_option=$("#order_change_option5").val();
		  }
		  if(id==6){
		   var order_change_option=$("#order_change_option6").val();
		  }
		  if(id==7){
		   var order_change_option=$("#order_change_option7").val();
			   if(order_change_option==""){
				  alert("Select Year"); 
			   }
		  }
		  if(id==8){
		   var order_change_option=$("#order_change_option8").val();
		  }
		  if(id==9){
		   var order_change_option=$("#order_change_option9").val();
		  }
		  if(id==10){
		   var order_change_option=$("#order_change_option10").val();
			   if(order_change_option==0){
				   $("#ref_amount_title,#reference_amount").hide();
			   }else{
				   var amount=<?php echo @$_SESSION['REFERENCE_AMOUNT']; ?>;
				   $("#show_amount").html('<label id="ref_amount_title">Reference Point</label><input type="text" onkeyup="updateReferenceAmount();" value="'+amount+'" maxlength="4" name="reference_amount" autocomplete="off" placeholder="Enter Amount(Tk)" id="reference_amount" class="form-control">');
			   }
		  }
		  if(id==11){
		   var order_change_option=$("#order_change_option11").val();
		  }
		  if(id==12){
		   var order_change_option=$("#order_change_option12").val();
		  }
		  if(id==13){
		   var order_change_option=$("#order_change_option13").val();
		  }
		  if(id==14){
		   var order_change_option=$("#order_change_option14").val();
		  }
		  if(id==15){
		   var order_change_option=$("#order_change_option15").val();
		  }
		  $.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						id:id,order_change_option:order_change_option,orderChangeOption:1
					},
						beforeSend: function () {
							$("#load_order_change").html('<img src="img/loading.gif"/>');
						},
						success: function (response) {
							console.log(response);
							if(id!=7){
								$("#load_order_change").html("<b>Success!</b>").css("color","green");
							}else{
								$("#show_ord").html("<b>"+response+"</b>").css("color","green");
								$("#load_order_change").html(null);
								$("#fegordbtn").html("<button onclick='saveFegOrd();' name='btn' id='' value='sub' class='btn btn-success'>Save</button>");
							}
						}
						
			});
		}
  }
  
   function readURL(input) {
		if (input.files && input.files[0]) {
			var reader = new FileReader();

			reader.onload = function (e) {
				$('#blah')
					.attr('src', e.target.result);
			};

			reader.readAsDataURL(input.files[0]);
		}
	}
  
  function updateReferenceAmount(){
	  var reference_amount=$("#reference_amount").val();
	  if(reference_amount==""){
		  reference_amount=0;
	  }
	  $.ajax({
		type: 'post',
		url: 'sql.php',
		data: {
			reference_amount:reference_amount,
			updateReferenceAmount:1
		},
		success: function (response) {
				console.log(response);
				if(response==1){
					$("#reference_amount").css("color","blue");
				}else{
					$("#reference_amount").css("color","red");
				}
			}
					
		});
  }
  
  function saveFegOrd(){
	  var ord_qty=$("#ord_qty").val();
	  var year=$("#order_change_option7").val();
	  if(confirm("আপনি কি আপডেট করতে চান?")){
		  $.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					ord_qty:ord_qty,year:year,saveFegOrd:1
				},
					beforeSend: function () {
						$("#load_order_change").html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						if(response==1){
							$("#show_ord").html("<b>"+ord_qty+"</b>").css("color","green");
							$("#load_order_change").html("<b>Save Success!</b>").css("color","green");
							$("#ord_qty").val(null);
						}
					}
					
		});
	  }
  }
  
  function setOrderNum(){
	  var mobile=$("#mobile").val();
	  if(mobile!="" && mobile.length!=11){
		  $("#order_number").val(mobile);
	  }
  }
  
  function getOrdList(date,sl,dvtype){
	  var dvid=$("#dvid").val();
		$("#dvdate"+sl).css("color",'red');
		$("#dvcount"+sl).css("color",'red');
		$("#dvdate"+dvid).css("color",'#337AB7');
		$("#dvcount"+dvid).css("color",'#337AB7');
		$("#dvid").val(sl);
		var etype="",month_year="";
		if(dvtype==3){
			etype=$("#emp_type"+sl).val();
			month_year=$("#month_year"+sl).val();
			
		}
	   $.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					date:date,dvtype:dvtype,etype:etype,month_year:month_year,getOrdList:1
				},
					beforeSend: function () {
						$("#ord_list").html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						$("#ord_list").html(response).css("color","black");
					}
					
		});
  }
  
  function delOldOrder(id){
	  document.getElementById("del_ord_btn"+id).disabled = true;	
	  $.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					id:id,delOldOrder:1
				},
					success: function (response) {
						console.log(response);
						$(otbl_one).html(response);
					}
					
		});
  }
  
  function searchOldOrder(){
	  var oorder_numberormobile=$("#oorder_numberormobile").val();
	  if(oorder_numberormobile!=""){
		   $("#oorder_numberormobile").css("border-color","#CCCCCC");
	   $.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					oorder_numberormobile:oorder_numberormobile,searchOldOrder:1
				},
					beforeSend: function () {
						$("#old_load2").html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						$("#old_load2").hide();
						$(otbl_one).html(response);
					}
					
		});
	  }else{
		  $("#oorder_numberormobile").css("border-color","red");
	  }
  }
  
  function saveOldOrder(){
	  var oorder_numbers=$("#oorder_numbers").val();
	  var omobile_num=$("#omobile_num").val();
	  if(oorder_numbers!="" && omobile_num!=""){
		  $("#oorder_numbers").css("border-color","#CCCCCC");
		  $("#omobile_num").css("border-color","#CCCCCC");
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						oorder_numbers:oorder_numbers,omobile_num:omobile_num,saveOldOrder:1
					},
						beforeSend: function () {
							$("#old_load").html('<img src="img/loading.gif"/>');
						},
						success: function (response) {
							console.log(response);
							$("#old_load").hide();
							$(otbl_one).html(response);
							$("#oorder_numbers").val(null);
							$("#omobile_num").val(null);
						}
						
			});
		}else{
			$("#omobile_num").css("border-color","red");
			$("#oorder_numbers").css("border-color","red");
		
		}
  
  }
  
  function changeSalaryType(){
	  var salary_type=$("#salary_type").val();
	  if(salary_type==1){
		  $("#stitle").html("No Salary");
		  document.getElementById("emp_salary").disabled = true;
	  }
	  if(salary_type==2){
		  $("#stitle").html("Daily Salary");
		  document.getElementById("emp_salary").disabled = false;
		   $("#emp_salary").focus();
	  }
	  if(salary_type==3){
		  $("#stitle").html("Monthly Salary");
		  document.getElementById("emp_salary").disabled = false;
		  $("#emp_salary").focus();
		}
  }
  
   function saveMasterKarigor(){
	  var emp_type=$("#emp_type").val(); //master karigor
	  var emp_name=$("#emp_name").val();
	  var emp_mobile=$("#emp_mobile").val();
	  var salary_type=$("#salary_type").val();
	  var emp_address=$("#emp_address").val();
	  var emp_salary=$("#emp_salary").val();
	  var tbl_last_id=parseInt($("#tbl_last_id").val())+1;
	  var et="",en="";
	  if(emp_type==""){
		 $("#emp_type").css("border-color","red");
			et=1;
		}else{
			$("#emp_type").css("border-color","#CCCCCC");
		}
		
		if(salary_type==""){
		 $("#salary_type").css("border-color","red");
			return;
		}else{
			if(salary_type==2 || salary_type==3){ // daily and monthly 
				if(emp_salary==""){
					$("#emp_salary").css("border-color","red");
					$("#emp_salary").focus();
					return;
				}else{
					$("#emp_salary").css("border-color","#CCCCCC");
				}
			}
			$("#salary_type").css("border-color","#CCCCCC");
		}
		
		if(emp_name==""){
		 $("#emp_name").css("border-color","red");
			en=1;
		}else{
			$("#emp_name").css("border-color","#CCCCCC");
		}
	  if(et==1 || en==1){
		 exit(); 
	  }else{
		document.getElementById("saveMasKaeBtn").disabled = true;
		$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				tbl_last_id:tbl_last_id,
				emp_type:emp_type,
				emp_name:emp_name,
				emp_mobile:emp_mobile,
				salary_type:salary_type,
				emp_address:emp_address,
				emp_salary:emp_salary,
				saveMasterKarigor:1
			},
				beforeSend: function () {
					$("#save_load").html('<img src="img/loading.gif"/>');
				},
				success: function (response) {
					console.log(response);
					if(response!=2){
						$("#emp_tbl").append(response);
						$("#save_load").html("Save Success!").css("color","green");
						$("#emp_name").val(null);
						$("#emp_mobile").val(null);
						$("#tbl_last_id").val(tbl_last_id+1);
						}else{
							$("#save_load").html("Not Success").css("color","red");
						}
						document.getElementById("saveMasKaeBtn").disabled = false;
				}
		});
	  }
  }
  
   function delEmployee(tbl_id,auto_inc){
	    if(confirm("Do you want to delete it?")){
			var tbl_last_id=$("#tbl_last_id").val();
			document.getElementById("delbtn"+auto_inc).disabled = true;
			$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					tbl_last_id:tbl_last_id,tbl_id:tbl_id,delEmployee:1
				},
				 beforeSend: function () {
					$("#save_load").show();
					$("#save_load").html('<img src="img/loading.gif"/>');
				},
				 success: function (response) {
					console.log(response);
					if(response==1){
						$("#save_load").html('Delete Success!').css("color","green");
					}else{
						$("#save_load").html('Not Success!').css("color","red");
						document.getElementById("delbtn"+auto_inc).disabled = false;
					}
				}
			});
		}
  }
  
  function delCustomer(tbl_id,auto_inc){
	    if(confirm("Do you want to delete it?")){
			var tbl_last_id=$("#tbl_last_id").val();
			document.getElementById("delbtn"+auto_inc).disabled = true;
			$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					tbl_last_id:tbl_last_id,
					tbl_id:tbl_id,
					delCustomer:1
				},
				 success: function (response) {
					console.log(response);
					if(response==1){
						document.getElementById("cus_name"+auto_inc).disabled = true;
						document.getElementById("cus_address"+auto_inc).disabled = true;
					}else{
						$("#save_load").html('Not Success!').css("color","red");
						document.getElementById("delbtn"+auto_inc).disabled = false;
					}
				}
			});
		}
  }
  
  
  
  
  /*--------------------------------------------------------------------*/
  
  function settingsData(id){
	  
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					id:id,settingsData:1
				},
					beforeSend: function () {
						$("#form_tbl").html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						if(response!=2){
							$("#form_tbl").html(response);
							}else{
								$("#form_tbl").html("No Result Found!").css("color","red");
							}
							if(id==5){
								 $(document).bind("contextmenu",function(e){
									return false;
								});  
							}
							if(id==11){
								document.getElementById("last_days").disabled = true;
							}
							if(id==16){ // stock adjustment id
								document.getElementById("previous_avg_price").disabled = true;
							}
							if(id==12){ // stock adjustment id
								$("#item_name").click();
								$("#item_name").focus();
								typwWiseItem(2);
							}
					}
		});
  }
  
  function showJobType(){
	  var job_type=$("#job_type").val();
	  $.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				job_type:job_type,
				showJobType:1
			},
				beforeSend: function () {
					$("#show_job_form").html('<img src="img/loading.gif"/>');
				},
				success: function (response) {
					console.log(response);
					$("#show_job_form").html(response);
					
				}
		});
  }
  
  function getDetailsPending(user_type,user_id){
	  $.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				user_type:user_type,
				user_id:user_id,
				getDetailsPending:1
			},
				beforeSend: function () {
					$("#get_details_pending").html('<img src="img/loading.gif"/>');
				},
				success: function (response) {
					console.log(response);
					$("#get_details_pending").html(response);
				}
		});
  }
  
  function getDetailsPendingOrder(item_id,user_type,user_id){
	  $.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				item_id:item_id,
				user_type:user_type,
				user_id:user_id,
				getDetailsPendingOrder:1
			},
				beforeSend: function () {
					$("#loading_icode"+item_id).html('<img src="img/loading.gif"/>');
				},
				success: function (response) {
					console.log(response);
					//$("#loading_icode"+item_id).html(null);
					$("#loading_icode"+item_id).html(response);
				}
		});
  }
  
  function searchEmpDueStatus(){
	  var emp_due_statuss=$("#emp_due_statuss").val();
	  if(emp_due_statuss!=""){
	  $.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				emp_due_statuss:emp_due_statuss,
				searchEmpDueStatus:1
			},
				beforeSend: function () {
					$("#search_mobile").html('<img src="img/loading.gif"/>');
				},
				success: function (response) {
					console.log(response);
					$("#search_mobile").html(response);
					$("#total_dues").html(null);
					document.getElementById('morebtns').disabled=true;
					
				}
		});
	  }else{
		 alert("Please select any one."); 
	  }
  }
  
  function getSrcableOrder(){
		var edit_ord_number=$("#src_ord_number").val();
		if(edit_ord_number==""){
			 $("#srcable_auto_mobile").html(null);
		}
		var first_digit = edit_ord_number.charAt(0);
		 if (first_digit.toLowerCase() == 'a') {
			 $.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					chk_searchable_number: 1, 
					mobile:edit_ord_number,
					autoCompleteMobileSearchableForJob:1
				},
				 success: function (response) {
					 
					 if(response!=""){
						$("#srcable_auto_mobile").html(response); 
					 }else{
						$("#srcable_auto_mobile").html(null);  
					 }
				}
			});
		 }
	}
	
 function srchForOrdDetails(ord_number){
	 console.log(ord_number);
	 if($("#get_emp_type").val()==""){
		 alert("Please select employee type!");
		 $("#get_emp_type").focus();
		 return;
	 }
	 $("#srcable_auto_mobile").html(null);
	 $("#src_ord_number").val(ord_number);
	 
	 $.ajax({
		type: 'post',
		url: 'ajax.php',
		data: {
			ord_number:ord_number,
			get_emp_type:$("#get_emp_type").val(),
			srchForOrdDetails:1
		},
		 success: function (response) {
			 
			 if(response!=2){
				$("#show_order_info").html(response); 
				setItemPrice('1');
			 }else{
				$("#show_order_info").html(null);  
				setItemPrice('2');
			 }
		}
	});
	
 }
 
 function setItemPrice(param){
	if(param==1){
		var tot_rate=parseFloat($("#tot_rate").val());
		var i=1,tot=0;
		for(i=1; i<=tot_rate; i++){
		var srcitem_qty=($("#srcitem_qty"+i).val()!="")? parseFloat($("#srcitem_qty"+i).val()) : 0;
		var rate= parseFloat($("#rate"+i).val());
		
		tot+=(rate*srcitem_qty);
		}
		$("#emp_wages").val(tot);
	}else{
		$("#emp_wages").val(null);
	}
 }
 
window.wages_item = [];
window.wages_id = [];
window.wages_ids = [];
window.wages_item_qty = [];
 function saveJobAssign(param){
	 var emp_name_details=$("#emp_name_details").val();
	 var get_emp_type=$("#get_emp_type").val();
	 var right_tbl_id=$('#right_tbl_id').val();
	 if(emp_name_details==""){
		$("#emp_name_details").css("border-color","red");
		return;		
	 }
	 var src_ord_number=$("#src_ord_number").val();
	 var emp_wages=$("#emp_wages").val();
	 var remarks=$("#remarks").val();
	 if(emp_wages==""){
		$("#emp_wages").css("border-color","red");
		return;		
	 }
	var tot_rate=parseFloat($("#tot_rate").val());
	var i=1,tot=0;
	for(i=1; i<=tot_rate; i++){
		if($("#srcitem_qty"+i).val()!=""){
			var srcitem_qty=($("#srcitem_qty"+i).val()!="")? parseFloat($("#srcitem_qty"+i).val()) : 0;
			wages_item_qty.push(srcitem_qty);
			
			var src_item_name= $("#src_item_name"+i).val();
			var src_ord_tbl_id= $("#src_ord_tbl_id"+i).val();
			var src_item_id= $("#src_item_id"+i).val();
			wages_item.push(src_item_name);
			wages_id.push(src_ord_tbl_id);
			wages_ids.push(src_item_id);
		}
		
	}
	var item_qty = wages_item_qty.join(',');
	var item = wages_item.join(',');
	var ord_tbl_id = wages_id.join(',');
	var ord_item_id = wages_ids.join(',');
	$.ajax({
		type: 'post',
		url: 'ajax.php',
		data: {
			emp_id:emp_name_details,
			order_num:src_ord_number,
			get_emp_type:get_emp_type,
			taka:emp_wages,
			remarks:remarks,
			item_name:item,
			ord_tbl_id:ord_tbl_id,
			item_id:ord_item_id,
			item_qty:item_qty,
			param:param,
			right_tbl_id:right_tbl_id,
			saveJobAssign:1
		},
		beforeSend: function () {
			$("#save_load").html('<img src="img/loading.gif"/>');
		},
		 success: function (response) {
			 
			 if(response==1){
				$("#save_load").html("Save Success!").css("color","green"); 
				$("#emp_name_details,#emp_wages").css("border-color","gray");
				$("#emp_wages,#src_ord_number,#remarks").val(null);
				$("#show_order_info").html(null);
				getDueDetails('0');
			 }else{
				$("#save_load").html("Not Success!").css("color","red"); 
			 }
			window.wages_item_qty = [];
			window.wages_item = [];
			window.wages_id = [];
			window.wages_ids = [];
		}
	});
 } 
 function savePaymet(param){
	 var emp_name_details=$("#emp_name_details").val();
	 var right_tbl_id=$('#right_tbl_id').val();
	 if(emp_name_details==""){
		$("#emp_name_details").css("border-color","red");
		return;		
	 }
	 var emp_wages=$("#emp_wages").val();
	 var remarks=$("#remarks").val();
	 if(emp_wages==""){
		$("#emp_wages").css("border-color","red");
		return;		
	 }
	
	$.ajax({
		type: 'post',
		url: 'ajax.php',
		data: {
			emp_id:emp_name_details,
			taka:emp_wages,
			remarks:remarks,
			param:param,
			right_tbl_id:right_tbl_id,
			savePaymet:1
		},
		beforeSend: function () {
			$("#save_load").html('<img src="img/loading.gif"/>');
		},
		 success: function (response) {
			 
			 if(response==1){
				$("#save_load").html("Save Success!").css("color","green"); 
				$("#emp_name_details,#emp_wages").css("border-color","gray");
				$("#emp_wages,#remarks").val(null);
				getDueDetails('1');
			 }else{
				$("#save_load").html("Not Success!").css("color","red"); 
			 }
		}
	});
 }
 
 function getDueDetails(param){
	 var emp_id=$("#emp_name_details").val();
	 var job_type=$("#job_type").val();
	 $.ajax({
		type: 'post',
		url: 'ajax.php',
		data: {
			emp_id:emp_id,
			param:param,
			job_type:job_type,
			getDueDetails:1
		},
		 success: function (response) {
			$("#right_result").html(response); 
		}
	});
 }
 
 function getEmp(){
	 var get_emp_type=$("#get_emp_type").val();
	$.ajax({
		type: 'post',
		url: 'ajax.php',
		data: {
			get_emp_type:get_emp_type,
			getEmp:1
		},
		 success: function (response) {
			$("#emp_name_details").html(response); 
		}
	});
 }
 
 function onlyBoxUpdateBtn(id,order_number){
	var box_number=$("#box_number"+id).val();
	if(confirm('Do you want save it?')){
		$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				box_number:box_number,
				order_number:order_number,
				onlyBoxUpdateBtn:1
			},
			 success: function (response) {
				 if(response==2){
					$("#box_update_sms"+id).html("Save Success!").css('color','green'); 
				 }else{
					$("#box_update_sms"+id).html("Not Success!").css('color','red'); 
				 }
			}
		});
	}
 }
 
 
  function getSelectHead(){
	  var item_type=$("#item_type").val(); //gent,lady
	  var item_id=$("#item_id").val();
	  //$("#measurement_type").hide();
	  $.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					item_type:item_type,item_id:item_id,getSelectHead:1
				},
					beforeSend: function () {
						$("#measurement_type").html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						 //$("#measurement_type").show();
						if(response!=2){
							$("#measurement_type").html(response);
							}else{
								$("#measurement_type").html(null);
								//$("#measurement_type").html("No Result Found!").css("color","red");
							}
						}
		});
  }
  
  function changeType(){
		var item_type=$("#item_type").val();
		$.ajax({
						type: 'post',
						url: 'ajax.php',
						data: {
							item_type:item_type,
							select_item_type:1
						},
						 beforeSend: function () {
							$("#item_id").show();
							$("#item_id").html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							$("#item_id").html(response);
						}
			});
	}
	
	function showLiveDiscount(sl_no){
		var due_tk=($("#hide_due"+sl_no).val()=="")? 0 : $("#hide_due"+sl_no).val();
		var present_tk=($("#paytxt"+sl_no).val()=="")? 0 : $("#paytxt"+sl_no).val();
		
		$("#discount_tks"+sl_no).html(parseFloat(due_tk)-parseFloat(present_tk)+" Tk.");
		$("#exdiscount"+sl_no).val(null);
	}
	
	function setDiscountTk(sl_no){
		var due_tk=($("#hide_due"+sl_no).val()=="")? 0 : $("#hide_due"+sl_no).val();
		var present_tk=($("#paytxt"+sl_no).val()=="")? 0 : $("#paytxt"+sl_no).val();
		$("#exdiscount"+sl_no).val(parseFloat(due_tk)-parseFloat(present_tk));
	}
	
	function chkCustomer(){
		var mobile=$("#cus_mobile").val();
		if(mobile=="" || mobile.length<11 || mobile.length>11){
			$("#previous_due").val(0.0);
			
			$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					mobile:mobile,autoCompleteMobile2:1
				},
				 success: function (response) {
					 console.log(response);
					 if(mobile!=""){
						$("#cus_info").html(response); 
					 }else{
						$("#cus_info").html(null);  
					 }
				}
			});
			
		}else{
			$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					mobile:mobile,authCustomer:1
				},
				 success: function (response) {
					  $("#cus_info").html(null);  
					  if(response!=2){
						 var sp=response.split("#sep#"); 
						 setMobileNumber(mobile,sp[0],sp[1]);
					  }
				}
			});
		}
	}
	
	function setMobileNumber(mobile,cus_name,cus_id){
		$("#cus_mobile").val(mobile);
		$("#cus_info").html(null);  
		$("#scus_mobile").html(mobile); 
		$("#scus_name").html(cus_name);  
		$("#hide_cus_id").val(cus_id);  
		$("#hscus_name").val(cus_name);  
		getLastResult(cus_id,"");
	}
	
	function getLastResult(cus_id,days){
		$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				cus_id:cus_id,
				days:days,
				getLastResult:1
			},
			 success: function (response) {
				 console.log(response);
				 $("#result_tbl").html(response);  
				 document.getElementById("last_days").disabled = false;
			}
		});
	}
	
	function getOrderNumber(){
		$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				getOrder_Number:1
			},
			 success: function (response) {
				 console.log(response);
				 if(response!=2){
					$("#order_number").val(response); 
					$("#srcbymob_print").click(); 
				 }else{
					$("#order_number").val(null);  
				 }
			}
		});
	}
	
	function lastDaysResult(){
		getLastResult($("#hide_cus_id").val(),$("#last_days").val());
	}
	
	function dueAdjustment(){
		if(confirm("আপনি কি বাকি এডজাস্ট করতে চান?")){
			var cus_id=$("#hide_cus_id").val(); 
			var tk_type=$("#tk_type").val(); 
			var cus_mobile=$("#cus_mobile").val(); 
			var cus_last_due=$("#cus_last_due").val(); 
			var payment_type=$("#payment_type").val(); 
			if(tk_type==""){
				$("#tk_type").css("border-color","red");
				exit;
			}
			var adjust_tk=$("#adjust_tk").val(); 
			if(adjust_tk=="" || parseFloat(adjust_tk)<=0){
				$("#adjust_tk").css("border-color","red");
				exit;
			}
			var tk_remarks=$("#tk_remarks").val();
			$("#tk_type").css("border-color","#CCCCCC");		
			$("#adjust_tk").css("border-color","#CCCCCC");	
			$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					cus_id:cus_id,
					tk_type:tk_type,
					adjust_tk:adjust_tk,
					tk_remarks:tk_remarks,
					payment_type:payment_type,
					cus_last_due:cus_last_due,
					cus_mobile:cus_mobile,
					hscus_name:$("#hscus_name").val(),
					dueAdjustment:1
				},
				beforeSend: function () {
					$("#adjust_sms").html('Loading...');
				},
				 success: function (response) {
					 console.log(response);
					 if(response==1){
						$("#adjust_sms").html("Success").css("color","green");
						$("#adjust_sms").fadeOut(2500);
						$("#adjust_sms").fadeIn(1000);
						$("#adjust_sms").html('<button onclick="dueAdjustment();" style="" name="btn" value="sub" id="save_order" class="btn btn-success">Save</button>');						
						$("#tk_remarks").val(null);
						$("#adjust_tk").val(0); 
						getLastResult(cus_id);
					}else{
						$("#adjust_sms").html("Not Success").css("color","red");  
					 }					 
				}
			});
		}
	}
	
	function srchByMobileNum(mobile){
		$("#mobile").val(mobile);
		$("#allsearchable_auto_mobile").html(null);  
		searchOrder();
	}
	
	function searchOrder(){
		var mobile=$("#mobile").val().trim();
		$("#last_id_hide").val(3);
		var m="";
		if(mobile==""){
			$("#mobile").css("border-color","red");
			m=1;
		}else{
			$("#mobile").css("border-color","#CCCCCC");
		}
		
		
		if(m==1){
			exit();
		}else{
		//document.getElementById("srcbymob").disabled = true;	
		
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						mobile:mobile,search_btn:1
					},
					 beforeSend: function () {
						$("#sms").show();
						$("#sms").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						//document.getElementById("srcbymob").disabled = false;
						if(response==1){
							$("#sms").html("No result found!").css("color","red");
							$("#src_result").html(null);
							$("#morebtn").hide();
							
							
						}else{
							$("#src_result").html(response);
							document.getElementById("morebtn").disabled = false;
							$("#morebtn").show();
							$("#sms").hide();
							getUpdateDue();
						}
					 }
			});
		}
	}
	
	function delCustomerDue(amount,tbl_id,sl,pstatus){
		if(confirm("Do you want to delete it?")){
			$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					tbl_id:tbl_id,
					amount:amount,
					pstatus:pstatus,
					cus_id: $("#hide_cus_id").val(),
					delCustomerDue:1
				},
				 success: function (response) {
					setMobileNumber($("#cus_mobile").val(),$("#hscus_name").val(),$("#hide_cus_id").val())
				}
			});
		}
	}
	
	function getUpdateDue(){
		var customer_id=$("#customer_id").val();
		$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				cus_id:customer_id,get_update_due:1
			},
			 success: function (response) {
				var update_due=parseFloat(response).toFixed(2);
				$("#previous_due_tab").show(); // set individual customers previous due
				$("#previous_due").val(update_due.trim()); // set individual customers previous due
			}
		});
	}
	
	function updateFabricsPrice(id,up_status){
		var dsms_ids=$("#dsms_ids"+id).val();
		var ds_item_id=$("#ds_item_id"+id).val();
		var itemqty=$("#itemqty"+id).val();
		var editfabricprice=$("#editfabricprice"+id).val();
		var total_tk=$("#total_tk"+id).val();
		//alert(total_tk); exit();
		var discount=$("#discount"+id).val();
		var discount_tot=$("#discount_tot"+id).val();
		var com;
		if(up_status=='0'){
			 com="আপনি Fabrics Price কমাতে চান?";
		}else{
			 com="আপনি Fabrics Price বাড়াতে চান?";
		}
		if(editfabricprice!="" && ds_item_id!=""){
		 if(confirm(com)){
			 $.ajax({
						type: 'post',
						url: 'sql.php',
						data: {
							editfabricprice:editfabricprice,
							total_tk:total_tk,
							dsms_ids:dsms_ids,
							update_status:up_status,
							discount:discount,
							discount_tot:discount_tot,
							div_id:id,
							ds_item_id:ds_item_id,
							itemqty:itemqty,
							updateFabricsPrice:1
						},
						 success: function (response) {
							 console.log(response);
							 if(response!=2){
							$("#itemqty"+id).val(null)
							 $("#editfabricprice"+id).val(null);
							 $("#payment_tbl"+id).html(response);
							 }else{
								 alert("Order Number Not Found.");
							 }
						 }
			 });
		 }
		}else{
			alert("Please enter fabrics price.");
		}
	}
	
	function showExpenseBreakdown(expense_title,expense_type,sdate,tdate){
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					expense_title:expense_title,
					expense_type:expense_type,
					sdate:sdate,
					tdate:tdate,
					showExpenseBreakdown:1
				},
				 beforeSend: function () {
					$("#smeasurement").html('<img src="img/loading.gif"/>');
				},
				 success: function (response) {
					console.log(response);
					$("#heading_id").html("Expense Breakdown");
					$("#smeasurement").html(response);
				}
		});
	}
	
	function showMeasurement(sl,ord_num){
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					ord_num:ord_num,smeasurement:1
				},
				 beforeSend: function () {
					$("#smeasurement").html('<img src="img/loading.gif"/>');
				},
				 success: function (response) {
					console.log(response);
					$("#heading_id").html("Measurement");
					$("#smeasurement").html(response);
				}
		});
	}
	
	function showEmployeesDetails(d1,d2,search_type,emp_id,emp_name){
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					d1:d1,
					d2:d2,
					search_type:search_type,
					emp_id:emp_id,
					emp_name:emp_name,
					showEmployeesDetails:1
				},
				 beforeSend: function () {
					$("#smeasurement").html('<img src="img/loading.gif"/>');
				},
				 success: function (response) {
					console.log(response);
					$("#heading_id").html("Measurement");
					$("#smeasurement").html(response);
				}
		});
	}
	
	function showPurchaseDetails(tbl_id){
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					tbl_id:tbl_id,showPurchaseDetails:1
				},
				 success: function (response) {
					console.log(response);
					$("#heading_id").html("Sales Item");
					$("#smeasurement").html(response);
				}
		});
	}
	
	function showOnlyFabricsPrice(todays_date,total_tk){
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					todays_date:todays_date,
					total_tk:total_tk,
					showOnlyFabricsPrice:1
				},
				 success: function (response) {
					console.log(response);
					$("#heading_id").html("Fabrics Taka");
					$("#smeasurement").html(response);
				}
		});
	}
	
	function showOnlyFabricsPriceTotal(todays_date,end_date,total_tk){
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					todays_date:todays_date,
					end_date:end_date,
					total_tk:total_tk,
					showOnlyFabricsPriceTotal:1
				},
				 success: function (response) {
					console.log(response);
					$("#heading_id").html("Fabrics Taka");
					$("#smeasurement").html(response);
				}
		});
	}
	
	function showPoint(cus_id,mobile,sl){
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					cus_id:cus_id,
					mobile:mobile,
					show_point_details:1
				},
				 beforeSend: function () {
					$("#sms_point").html('<img src="img/loading.gif"/>');
				},
				 success: function (response) {
					console.log(response);
					$("#sms_point").html("");
					$("#sms_point").html(response);
				}
		});
	}
	
	function widthDrawBtn(id,cus_id){
		var width_draw=parseFloat($("#width_draw"+id).val());
		var last_point=parseFloat($("#last_point"+id).text());
		if(width_draw>last_point || width_draw==0 || $("#width_draw"+id).val()==""){
			alert("Warning! Not Possible");
		}else{
				if(confirm("আপনি কি কাস্টমার কে পয়েন্ট Return করতে চান?")){
					document.getElementById("widthdarawBtn"+id).disabled = true;
					$.ajax({
							type: 'post',
							url: 'ajax.php',
							data: {
								cus_id:cus_id,
								width_draw:width_draw,
								last_point:last_point,
								widthDrawBtn:1
							},
							 success: function (response) {
								console.log(response);
								if(response==1){
									$("#last_point"+id).html((last_point-width_draw));
									document.getElementById("widthdarawBtn"+id).disabled = false;
								}
							}
					});
				}
			}
	}
	
	function CalculatePerPrice(){
		var purchase_qty=($("#purchase_qty").val()=="")? 0 : parseFloat($("#purchase_qty").val());
		var purchase_price=($("#purchase_price").val()=="")? 0 : parseFloat($("#purchase_price").val());
		$("#total_price").val((purchase_qty*purchase_price));
	}
	
	function checkItemCode(){
		var item_code=$("#item_code").val();
		$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					item_code:item_code,
					checkItemCode:1
				},
				 beforeSend: function () {
					$("#save_load").html('<img style="margin-top: 25px;width: 75px;" src="img/loading.gif"/>');
				},
				 success: function (response) {
					console.log(response);
					if(response!=2){
						//alert("আইটেম কোড ডুপ্লিকেট হয়েছে! "+item_code);
						$("#duplicte_code").html('Duplicate!');
						$("#item_code").css("border-color","red");
						$("#item_code").click();
						$("#item_code").focus();
						$("#save_load").html('<button onclick="saveFabrics();" style="margin-top: 25px;" name="btn" value="sub" id="saveFabricsBtn" class="btn btn-success form-control">Save</button>');
					}else{
						$("#duplicte_code").html(null);
						$("#item_code").css("border-color","green");
						$("#save_load").html('<button onclick="saveFabrics();" style="margin-top: 25px;" name="btn" value="sub" id="saveFabricsBtn" class="btn btn-success form-control">Save</button>');
					}
					
				}
			});
	}
	
	function enterEventSelection(id_name,next_id){
		var input = document.getElementById(id_name);
		var next_id=next_id;
		console.log(next_id+"=========");
		input.addEventListener("keyup", function(event) {
		  if (event.keyCode === 13) {
			$("#"+next_id).click();
			$("#"+next_id).focus();
			var tag_num = document.getElementById(next_id);
			tag_num.select();
		  }
		});
	}
	
	function saveFabrics(){
		var check_stock=$("#check_stock").val();
		var item_type=$("#item_type").val();
		var item_name=$("#item_name").val();
		var purchase_price=$("#purchase_price").val();
		var selling_price=$("#selling_price").val();
		var item_code="";
		var item_unit="";
		var ilast_id=$("#ilast_id").val();
		if(confirm("আপনি কি ফ্যাব্রিক্স আইটেম সেভ করতে চান?")){
		if(item_type==""){
			$("#item_type").css("border-color","red");
			return;
		}else{
			$("#item_type").css("border-color","#CCCCCC");
		}
		
		if(purchase_price==""){
			$("#purchase_price").css("border-color","red");
			return;
		}else{
			$("#purchase_price").css("border-color","#CCCCCC");
		}
		
		if(item_name==""){
			$("#item_name").css("border-color","red");
			return;
		}else{
			$("#item_name").css("border-color","#CCCCCC");
		}
		
		if(check_stock==1){ //1=means maintain stock
			var chkAutItem=$("#chkAutItem").val();
			if(chkAutItem!=""){
				alert("আইটেম নাম ডুপ্লিকেট হয়েছে!");
				$("#item_name").css("border-color","red");
				return;
			}
			 item_code=$("#item_code").val();
			 item_unit=$("#item_unit").val();
			if(item_unit==""){
				$("#item_unit").css("border-color","red");
				return;
			}else{
				$("#item_unit").css("border-color","#CCCCCC");
			}
		}
	
		$("#saveFabricsBtn").hide();
		$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					item_type:item_type,
					item_name:item_name,
					item_code:item_code,
					item_unit:item_unit,
					purchase_price:purchase_price,
					selling_price:selling_price,
					ilast_id:ilast_id,
					saveFabrics:1
				},
				 beforeSend: function () {
					$("#save_load").html('<img style="margin-top: 25px;width: 75px;" src="img/loading.gif"/>');
				},
				 success: function (response) {
					console.log(response);
					if(response!=2){
					$("#item_tbl").prepend(response);
					$("#save_load").html('<button onclick="saveFabrics();" style="margin-top: 25px;" name="btn" value="sub" id="saveFabricsBtn" class="btn btn-success form-control">Save</button>');
					$("#saveFabricsBtn").show();
					$("#item_name,#purchase_price,#selling_price").val(null);
					$("#item_code").val(null);
					$("#ilast_id").val(parseInt(ilast_id)+1);
					}else{
						$("#summery_report2").html("Save Not Success!").css("color","red");
					}
				}
			});
		}
	}
	
	function saveFabricsInStock(){
		var check_stock=$("#check_stock").val();
		var item_name=$("#item_name").val();
		var item_unit=$("#item_unit").val();
		var item_code=$("#item_code").val();
		var purchase_qty=$("#purchase_qty").val();
		var purchase_price=$("#purchase_price").val(); //purchase per price 
		var total_price=$("#total_price").val();
		var previous_stock_qty=$("#previous_stock_qty").val();
		var previous_avg_price=$("#previous_avg_price").val();
		var previous_total_price=$("#previous_total_price").val();
		var supplier_mobile=$("#supplier_mobile").val();
		var ilast_id=$("#ilast_id").val();
		if(confirm("আপনি কি স্টক ইন করতে চান?")){
		var chkAutItem=$("#chkAutItem").val(); //item id 
			if(chkAutItem==""){
				alert("Invalid Item Name!");
				$("#save_load").html("Invalid Item Name!").css("color","red");
				$("#item_name").css("border-color","red");
				return;
			}
		
		if(item_name==""){
			$("#item_name").css("border-color","red");
			return;
		}else{
			$("#item_name").css("border-color","#CCCCCC");
		}
		
		if(purchase_qty==""){
			$("#purchase_qty").css("border-color","red");
			return;
		}else{
			$("#purchase_qty").css("border-color","#CCCCCC");
		}
		
		if(total_price==""){
			$("#total_price").css("border-color","red");
			return;
		}else{
			$("#total_price").css("border-color","#CCCCCC");
		}
		
		$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					item_id:chkAutItem,
					item_name:item_name,
					item_unit:item_unit,
					item_code:item_code,
					purchase_qty:purchase_qty,
					purchase_price:purchase_price,
					total_price:total_price,
					previous_stock_qty:previous_stock_qty,
					previous_total_price:previous_total_price,
					previous_avg_price:previous_avg_price,
					supplier_mobile:supplier_mobile,
					ilast_id:ilast_id,
					saveFabricsInStock:1
				},
				 beforeSend: function () {
					$("#save_load").html('<img src="img/loading.gif"/>');
					document.getElementById("saveFabricsBtn").disabled = true;
				},
				 success: function (response) {
					console.log(response);
					if(response!=2){
					$("#item_tbl").prepend(response);
					$("#save_load").html("Save Success!").css("color","green");
					document.getElementById("saveFabricsBtn").disabled = false;
					$("#chkAutItem,#item_name,#item_unit,#item_code,#purchase_qty,#purchase_price,#total_price,#supplier_mobile").val(null);
					$("#previous_stock_qty,#previous_total_price,#previous_avg_price").val(0);
					$("#ilast_id").val(parseInt(ilast_id)+1);
					}else{
						$("#save_load").html("Save Not Success!").css("color","red");
					}
					$('#item_name').click();
					$('#item_name').focus();
				}
			});
		}
	}
	
	function saveStockAdjustment(){
		var item_name=$("#item_name").val();
		var item_unit=$("#item_unit").val();
		var item_code=$("#item_code").val();
		var adjustment_qty=$("#adjustment_qty").val();
		var final_qty=$("#final_qty").val(); //purchase per price 
		var total_price=$("#total_price").val();
		var previous_stock_qty=$("#previous_stock_qty").val();
		var previous_avg_price=$("#previous_avg_price").val();
		var ilast_id=$("#ilast_id").val();
		
		var chkAutItem=$("#chkAutItem").val(); //item id 
			if(chkAutItem==""){
				alert("Invalid Item Name!");
				$("#save_load").html("Invalid Item Name!").css("color","red");
				return;
			}
		
		if(item_name==""){
			$("#item_name").css("border-color","red");
			return;
		}else{
			$("#item_name").css("border-color","#CCCCCC");
		}
		
		if(adjustment_qty==""){
			$("#adjustment_qty").css("border-color","red");
			return;
		}else{
			$("#adjustment_qty").css("border-color","#CCCCCC");
		}
		
		if(previous_avg_price=="" || parseFloat(previous_avg_price)<0){
			$("#previous_avg_price").css("border-color","red");
			return;
		}else{
			$("#previous_avg_price").css("border-color","#CCCCCC");
		}
		
		$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					item_id:chkAutItem,
					item_name:item_name,
					item_unit:item_unit,
					item_code:item_code,
					purchase_qty:final_qty,
					total_price:total_price,
					adjustment_qty:adjustment_qty,
					previous_avg_price:previous_avg_price,
					ilast_id:ilast_id,
					saveStockAdjustment:1
				},
				 beforeSend: function () {
					$("#save_load").html('<img src="img/loading.gif"/>');
					document.getElementById("saveFabricsBtn").disabled = true;
				},
				 success: function (response) {
					console.log(response);
					if(response!=2){
					$("#item_tbl").prepend(response);
					$("#save_load").html("Save Success!").css("color","green");
					document.getElementById("saveFabricsBtn").disabled = false;
					$("#chkAutItem,#item_name,#item_unit,#item_code,#adjustment_qty,#final_qty,#total_price").val(null);
					$("#previous_stock_qty,#previous_total_price,#previous_avg_price").val(0);
					$("#ilast_id").val(parseInt(ilast_id)+1);
					}else{
						$("#save_load").html("Save Not Success!").css("color","red");
					}
				}
			});
	}
	
	function CalculateAdjustmentQty(){
		var previous_stock_qty=($("#previous_stock_qty").val()=="")? 0 : parseFloat($("#previous_stock_qty").val());
		var adjustment_qty=($("#adjustment_qty").val()=="")? 0 : parseFloat($("#adjustment_qty").val());
		var previous_avg_price=($("#previous_avg_price").val()=="")? 0 : parseFloat($("#previous_avg_price").val());
		$("#final_qty").val((previous_stock_qty+adjustment_qty));
		var final_qty=($("#final_qty").val()=="")? 0 : parseFloat($("#final_qty").val());
		if(final_qty==0){
			$("#previous_avg_price").val(0);
		}
		$("#total_price").val((final_qty*previous_avg_price));
	}
	
	/* function gateDate(){
		var date3=$("#date3").val();
		alert(date3);
	} */
	
	function hideShowBtn(){
		var btn_hide_show=$("#btn_hide_show").val();
		if(btn_hide_show==0){
			$("#stock_area").hide("slow");
			$("#btn_hide_show").val(1);
			$("#hide_show_btn").html("Show");
		}else{
			$("#stock_area").show("slow");
			$("#btn_hide_show").val(0);
			$("#hide_show_btn").html("Hide");
		}
	}
	
	function saveUserInfo(){
	  var user_type=$("#user_type").val();
	  var user_name=$("#user_name").val();
	  var user_mobile=$("#user_mobile").val();
	  var login_user=$("#login_user").val();
	  var login_password=$("#login_password").val();
	  var ilast_id=$("#ilast_id").val();
		if(user_type==""){
		  $("#user_type").css("border-color","red");
		  exit;
		}else{
		  $("#user_type").css("border-color","#CCCCCC");
		}

		if(user_name==""){
		  $("#user_name").css("border-color","red");
		  exit;
		}else{
		  $("#user_name").css("border-color","#CCCCCC");
		}

		if(user_mobile=="" || user_mobile.length>11 || user_mobile.length<11){
		  $("#user_mobile").css("border-color","red");
		  exit;
		}else{
		  $("#user_mobile").css("border-color","#CCCCCC");
		}
		
		if(login_user==""){
		  $("#login_user").css("border-color","red");
		  exit;
		}else{
		  $("#login_user").css("border-color","#CCCCCC");
		}
		
		if(login_password==""){
		  $("#login_password").css("border-color","red");
		  exit;
		}else{
		  $("#login_password").css("border-color","#CCCCCC");
		}
		$("#saveUserBtn").hide();
		$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
			user_type:user_type,
			user_name:user_name,
			user_mobile:user_mobile,
			login_user:login_user,
			login_password:login_password,
			ilast_id:ilast_id,
			saveUserInfo:1
			},
				beforeSend: function () {
				$("#save_load").html('<img src="img/loading.gif"/>');
			},
			success: function (response) {
				console.log(response);
				if(response==2){
					$("#summery_report2").html("Save Not Success!").css("color","red");
				}else if(response==3){
					$("#save_load").html("Warning! Duplicate password.").css("color","red");
				} else{
					$("#item_tbl").append(response);
					$("#save_load").html("Save Success!").css("color","green");
					$("#user_name").val(null);
					$("#user_mobile").val(null);
					$("#login_user").val(null);
					$("#login_password").val(null);
					$("#ilast_id").val(parseInt(ilast_id)+1);
				}
				$("#saveUserBtn").show();
			}
		});
  }

	function saveItem(){
		var item_type=$("#item_type").val();
		var item_name=$("#item_name").val();
		var ilast_id=$("#ilast_id").val();
		var i="",cp="",mp="",kp="",it="";
		
		if(item_type==""){
			$("#item_type").css("border-color","red");
			it=1;
		}else{
			$("#item_type").css("border-color","#CCCCCC");
		}
		
		if(item_name==""){
			$("#item_name").css("border-color","red");
			i=1;
		}else{
			$("#item_name").css("border-color","#CCCCCC");
		}
		var group_id=$("#group_id").val();
		var cus_price=$("#cus_price").val();
		if(cus_price==""){
			$("#cus_price").css("border-color","red");
			cp=1;
		}else{
			$("#cus_price").css("border-color","#CCCCCC");
		}
		var master_price=$("#master_price").val();
		if(master_price==1){
			$("#master_price").css("border-color","red");
			mp=1;
		}else{
			$("#master_price").css("border-color","#CCCCCC");
		}
		var karigor_price=$("#karigor_price").val();
		if(karigor_price==""){
			$("#karigor_price").css("border-color","red");
			kp=1;
		}else{
			$("#karigor_price").css("border-color","#CCCCCC");
		}
		if(i==1 || cp==1 || mp==1 || kp==1 || it==1){
			exit();
		}else{
			$("#saveItemBtn").hide();
		$.ajax({
						type: 'post',
						url: 'sql.php',
						data: {
							item_type:item_type,
							item_name:item_name,
							group_id:group_id,
							cus_price:cus_price,
							master_price:master_price,
							karigor_price:karigor_price,
							ilast_id:ilast_id,
							saveItem:1
						},
						 beforeSend: function () {
							$("#save_load").html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							if(response!=2){
							$("#item_tbl").append(response);
							$("#save_load").html("Save Success!").css("color","green");
							$("#saveItemBtn").show();
							$("#item_name").val(null);
							$("#master_price").val(null);
							$("#karigor_price").val(null);
							$("#cus_price").val(null);
							$("#ilast_id").val(parseInt(ilast_id)+1);
							}else{
								$("#summery_report2").html("Save Not Success!").css("color","red");
							}
						}
			});
		}
	}
	
	function savePropertices(){
		var item_type=$("#item_type").val();
		var item_id=$("#item_id").val();
		var ilast_id=$("#ilast_id").val();
		var measurement_type=$("#measurement_type").val();
		var propertice_title=$("#propertice_title").val();
		var i="",it="",pt="",mt="";
		
		if(item_type==""){
			$("#item_type").css("border-color","red");
			it=1;
		}else{
			$("#item_type").css("border-color","#CCCCCC");
		}
		
		if(item_id==""){
			$("#item_id").css("border-color","red");
			i=1;
		}else{
			$("#item_id").css("border-color","#CCCCCC");
		}
		if(propertice_title==""){
			$("#propertice_title").css("border-color","red");
			pt=1;
		}else{
			$("#propertice_title").css("border-color","#CCCCCC");
		}
		
		if(measurement_type==""){
			$("#measurement_type").css("border-color","red");
			mt=1;
		}else{
			$("#measurement_type").css("border-color","#CCCCCC");
		}
		
		
		if(i==1 || it==1 || pt==1 || mt==1){
			exit();
		}else{
			$("#saveProperticesBtn").hide();
		$.ajax({
						type: 'post',
						url: 'sql.php',
						data: {
							item_type:item_type,
							item_id:item_id,
							measurement_type:measurement_type,
							propertice_title:propertice_title,
							ilast_id:ilast_id,
							savePropertices:1
						},
						 beforeSend: function () {
							$("#save_load").html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							if(response!=2){
							$("#item_tbl").append(response);
							$("#save_load").html("Save Success!").css("color","green");
							$("#saveProperticesBtn").show();
							//$("#item_name").val(null);
							//$("#master_price").val(null);
							$("#propertice_title").val(null);
							$("#ilast_id").val(parseInt(ilast_id)+1);
							}else{
								$("#summery_report2").html("Save Not Success!").css("color","red");
							}
						}
			});
		}
	}
	
	function saveProperticesExtra(){
		var item_type=$("#item_type").val();
		var item_id=$("#item_id").val();
		var ilast_id=$("#ilast_id").val();
		var measurement_type=$("#measurement_type").val();
		var propertice_title=$("#chk_title").val();
		var i="",it="",pt="",mt="";
		
		if(item_type==""){
			$("#item_type").css("border-color","red");
			it=1;
		}else{
			$("#item_type").css("border-color","#CCCCCC");
		}
		
		if(item_id==""){
			$("#item_id").css("border-color","red");
			i=1;
		}else{
			$("#item_id").css("border-color","#CCCCCC");
		}
		if(propertice_title==""){
			$("#chk_title").css("border-color","red");
			pt=1;
		}else{
			$("#chk_title").css("border-color","#CCCCCC");
		}
		
		if(measurement_type==""){
			$("#measurement_type").css("border-color","red");
			mt=1;
		}else{
			$("#measurement_type").css("border-color","#CCCCCC");
		}
		
		
		if(i==1 || it==1 || pt==1 || mt==1){
			exit();
		}else{
			$("#saveProperticesExtraBtn").hide();
		$.ajax({
						type: 'post',
						url: 'sql.php',
						data: {
							item_type:item_type,
							item_id:item_id,
							measurement_type:measurement_type,
							propertice_title:propertice_title,
							ilast_id:ilast_id,
							saveProperticesExtra:1
						},
						 beforeSend: function () {
							$("#save_load").html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							if(response!=2){
							$("#item_tbl").append(response);
							$("#save_load").html("Save Success!").css("color","green");
							$("#saveProperticesExtraBtn").show();
							//$("#item_name").val(null);
							//$("#master_price").val(null);
							$("#chk_title").val(null);
							$("#ilast_id").val(parseInt(ilast_id)+1);
							}else{
								$("#summery_report2").html("Save Not Success!").css("color","red");
							}
						}
			});
		}
	}
	
	function delItem(tblid,sl){
		if(confirm("Do you want to delete it?")){
			document.getElementById("delbtn"+sl).disabled = true;
			$.ajax({
						type: 'post',
						url: 'sql.php',
						data: {
							id:tblid,delbtn:1
						},
						 
						 success: function (response) {
							console.log(response);
							if(response==1){
								document.getElementById("delbtn"+sl).disabled = true;
								document.getElementById("product_name"+sl).disabled = true;
								document.getElementById("cus_price"+sl).disabled = true;
								document.getElementById("mas_price"+sl).disabled = true;
								document.getElementById("kar_price"+sl).disabled = true;
								document.getElementById("order"+sl).disabled = true;
							}else{
								document.getElementById("delbtn"+sl).disabled = false;
							}
						 }
				});
		}
	}
	
	function delInStockItem(top_id,sl,purchase_qty,total_price,item_id){
		if(confirm("Do you want to delete it?")){
			document.getElementById("delbtn"+sl).disabled = true;
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						tbl_id:top_id,
						sl:sl,
						purchase_qty:purchase_qty,
						total_price:total_price,
						item_id:item_id,
						delInStockItem:1
					},
					 
					 success: function (response) {
						console.log(response);
						if(response==1){
							document.getElementById("delbtn"+sl).disabled = true;
						}else{
							document.getElementById("delbtn"+sl).disabled = false;
						}
					 }
				});
		}
	}
	
	function delItemPayment(tbl_id,sl_no,taka,emp_id,status,order_rec_tblid){
		if(confirm("Do you want to delete it?")){
			var job_type=$("#job_type").val();
			document.getElementById("delbtns"+sl_no).disabled = true;
			$.ajax({
						type: 'post',
						url: 'sql.php',
						data: {
							tbl_id:tbl_id,
							sl_no:sl_no,
							taka:taka,
							emp_id:emp_id,
							status:status,
							job_type:job_type,
							order_rec_tblid:order_rec_tblid,
							get_emp_type:$("#get_emp_type").val(),
							delItemPayment:1
						},
						 
						 success: function (response) {
							console.log(response);
							if(response==1){
								getDueDetails(job_type);
								}else{
								document.getElementById("delbtns"+sl_no).disabled = false;
							}
						 }
				});
		}
	}
	
	
	function delItemTwo(tblid,sl){
		if(confirm("Do you want to delete it?")){
			document.getElementById("delbtnTwo"+sl).disabled = true;
			$.ajax({
						type: 'post',
						url: 'sql.php',
						data: {
							id:tblid,delbtn2:1
						},
						 
						 success: function (response) {
							console.log(response);
							if(response==1){
								document.getElementById("delbtnTwo"+sl).disabled = true;
								document.getElementById("mheadordertitle"+sl).disabled = true;
								document.getElementById("mheadorder"+sl).disabled = true;
							}else{
								document.getElementById("delbtnTwo"+sl).disabled = false;
							}
						 }
				});
		}
	}
	
	function delItemThree(tblid,sl){
		if(confirm("Do you want to delete it?")){
			document.getElementById("delbtnThree"+sl).disabled = true;
			$.ajax({
						type: 'post',
						url: 'sql.php',
						data: {
							id:tblid,delbtn3:1
						},
						 
						 success: function (response) {
							console.log(response);
							if(response==1){
								document.getElementById("delbtnThree"+sl).disabled = true;
								document.getElementById("mheadordertitle"+sl).disabled = true;
								document.getElementById("mheadorder"+sl).disabled = true;
							}else{
								document.getElementById("delbtnThree"+sl).disabled = false;
							}
						 }
				});
		}
	}
	
	
	function addNewCustomer(){
		if(confirm("আপনি কি নতুন কাস্টমার সংযুক্ত করতে চান?")){
			$.ajax({
					type: 'post',
					url: 'ajax.php',
					data: {
						customerForm:1
					},
					  success: function (response) {
						$("#customer_form").html(response).show("slow");
					 }
				});
		}
	}
	
	function canceForm(){
		$("#customer_form").html(null).show("slow");
	}
	
	function saveCustomer(){
		var customer_name=$("#customer_name").val().trim();
		var customer_mobile=$("#customer_mobile").val().trim();
		var customer_address=$("#customer_address").val().trim();
		
		if(confirm("আপনি কি কাস্টমার এর ইনফরমেশন সেভ করে রাখতে চান?")){
			if(customer_mobile==""){
				alert("Customer mobile number missing.");
				$("#customer_mobile").css("border-color","red");
				$("#customer_mobile").focus();
				$("#customer_mobile").click();
				exit();
			}
		$("#customer_mobile").css("border-color","#CCCCCC");
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						customer_name:customer_name,
						customer_mobile:customer_mobile,
						customer_address:customer_address,
						saveCustomer:1
					},
					  success: function (response) {
						  if(response==1){
							  $("#save_sms").html("Save Success.").css("color","green");
							  $("#save_sms").fadeOut(3500);
							  setTimeout(function() {
									$("#customer_form").hide("slow");
									 settingsData(10);
										}, 2000);
							
						  }else if(response==3){
							  $("#save_sms").html("Warning! This mobile number already inserted.").css("color","red");  
						  }else{
							$("#save_sms").html("Save Not Success.").css("color","red");  
						  }
					 }
				});
		}
	}
	
	
	function setOrder(sl,tblid,chk_head,updatetype){
		var mheadorder;
		if(updatetype==1){
			mheadorder=$("#mheadordertitle"+sl).val().trim();
		}else if(updatetype==2){
			mheadorder=$("#mheadorder"+sl).val().trim();
		}else if(updatetype==3){
			mheadorder=$("#mheadamount"+sl).val().trim();
		}
		$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				mheadorder:mheadorder,tblid:tblid,chk_head:chk_head,updatetype:updatetype,setOrder:1
			},
			 
			 success: function (response) {
				console.log(response);
				//if(){
				if(response==1){
					if(updatetype==1){
						$("#mheadordertitle"+sl).css("color","blue");
					}else if(updatetype==2){
						$("#mheadorder"+sl).css("color","blue");
					}else if(updatetype==3){
						$("#mheadamount"+sl).css("color","blue");
					}
				}else{
					if(updatetype==1){
						$("#mheadordertitle"+sl).css("color","red");
					}else if(updatetype==2){
						$("#mheadorder"+sl).css("color","red");
					}else if(updatetype==3){
						$("#mheadamount"+sl).css("color","red");
					}
				}
				
			 }
		});
	}
	
	function typwWiseItem(ptype){
		var item_type=$("#item_type").val();
		$.ajax({
					type: 'post',
					url: 'ajax.php',
					data: {
						item_type:item_type,
						ptype:ptype,
						typwWiseItem:1
					},
					 
					 success: function (response) {
						console.log(response);
						if(response!=2){
							$("#item_tbl").html(response);
						}else{
							$("#item_tbl").html(response);
						}
					 }
			});
	}
	
	function typwWiseUser(){
		var user_type=$("#user_type").val();
		$.ajax({
					type: 'post',
					url: 'ajax.php',
					data: {
						user_type:user_type,
						typwWiseUser:1
					},
					 
					 success: function (response) {
						console.log(response);
						if(response!=2){
							$("#item_tbl").html(response);
						}else{
							$("#item_tbl").html(response);
						}
					 }
			});
	}
	
	function getPropertice(){
		var item_type=$("#item_type").val();
		var item_id=$("#item_id").val();
		var measurement_type=$("#measurement_type").val();
		if(item_type=="" || item_id=="" || measurement_type==""){
			$("#item_tbl").html(null);	
		}else{
		$.ajax({
					type: 'post',
					url: 'ajax.php',
					data: {
						measurement_type:measurement_type,item_id:item_id,item_type:item_type,typwWiseItem2:1
					},
					 
					 success: function (response) {
						console.log(response);
						if(response!=2){
							$("#item_tbl").html(response);
						}else{
							$("#item_tbl").html(response);
						}
					 }
			});
		}
	}
	
		function getPropertice2(){
		var item_type=$("#item_type").val();
		var item_id=$("#item_id").val();
		var measurement_type=$("#measurement_type").val();
		if(item_type=="" || item_id=="" || measurement_type==""){
			$("#item_tbl").html(null);	
		}else{
		$.ajax({
					type: 'post',
					url: 'ajax.php',
					data: {
						measurement_type:measurement_type,item_id:item_id,item_type:item_type,typwWiseItem3:1
					},
					 
					 success: function (response) {
						console.log(response);
						if(response!=2){
							$("#item_tbl").html(response);
						}else{
							$("#item_tbl").html(response);
						}
					 }
			});
		}
	}
	
	function dateWisePrint(){
		var date1=$("#date1").val();
		var date2="",extra_item="",karigor_list="",order_type="",expense_type="";
		var mobile=$("#smobile").val().trim();
		var order_number=$("#order_number").val().trim();;
		var serial_no=$("#serial_no").val().trim();
		var print_type=$("#print_type").val();
		extra_item=$("#extra_item").val();
		var month="",year="";
		if(print_type==14 || print_type==23){
			karigor_list=$("#karigor_list").val();
			date1="2023/01/01";
		}
		if(print_type==24){
			order_type=$("#decision_list").val();
			order_number=1;
		}
		if(print_type==15){
			order_type=$("#order_type").val();
			date1="2023/01/01";
		}
		if(print_type==16){
			expense_type=$("#expense_type").val();
			date1=$("#date1").val();
		}
		if(print_type==18){
			extra_item=$("#item_statuss").val();
			date1=$("#date1").val();
		}
		if(print_type==19){
			karigor_list=$("#emp_lists").val();
			extra_item=$("#emp_statuss").val();
			date1=$("#date1").val();
		}
		if(print_type==4 || print_type==5 || print_type==6 || print_type==7){
			order_number="123";
			month=$("#month").val();
			year=$("#year").val();
		}
		if(print_type==9){
			date1="2023/01/01";
			mobile="1";
			order_number="1";
			serial_no="1";
		}
		if(print_type==3){
			if(date1==""){
				$("#date1").css("border-color","red");
				$("#date1").focus();
				exit;
			}else{
				$("#date1").css("border-color","#CCCCCC");
				$("#send_email").show("slow");
			}
		}
		if(print_type==11 || print_type==12 || print_type==16 || print_type==8 || print_type==17 || print_type==18 || print_type==19){
			if(date1==""){
				$("#date1").css("border-color","red");
				$("#date1").focus();
				exit;
			}else{
				$("#date1").css("border-color","#CCCCCC");
				$("#send_email").show("slow");
			}
			date2=$("#date2").val();
			if(date2==""){
				$("#date2").css("border-color","red");
				$("#date2").focus();
				exit;
			}else{
				$("#date2").css("border-color","#CCCCCC");
				//$("#send_email").show("slow");
			}
		}
		if(date1=="" && mobile=="" && order_number=="" && serial_no==""){
			$("#summery_report2").html("Enter Date/Mobile/Order No.").css("color","red");
		}else{
			$.ajax({
						type: 'post',
						url: 'ajax.php',
						data: {
							month:month,
							year:year,
							print_type:print_type,
							date1:date1,
							date2:date2,
							mobile:mobile,
							order_number:order_number,
							serial_no:serial_no,
							extra_item:extra_item,
							karigor_list:karigor_list,
							order_type:order_type,
							expense_type:expense_type,
							dateWisePrint:1
						},
						 beforeSend: function () {
							$("#summery_report2").html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							if(response==2){
								$("#summery_report2").html("No Result Found!").css("color","red");
							}else{
								$("#summery_report2").html(response).css("color","black");
							}
						}
			});
		}
		
	}
	
	
	
	function showOrderNumberItemWise(item_id,d1,d2,search_type){
		$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					search_type:search_type,
					item_id:item_id,
					start_date:d1,
					end_date:d2,
					showOrderNumberItemWise:1
				},
				 beforeSend: function () {
					$("#show_ord_num"+item_id).html('<img src="img/loading.gif"/>');
				},
				 success: function (response) {
					console.log(response);
					$("#show_ord_num"+item_id).html(response);
				}
			});
	}
	
	function setEmployee(sl){ //user_type= 1=master,2=karigor
		var karigor_hidden_id=$("#karigor_hidden_id"+sl).val().split("#sep#");
		var userid=karigor_hidden_id[0];
		var user_type=karigor_hidden_id[1];
		var order_num_id=karigor_hidden_id[2];
		$("#karigor_select_box"+sl).show();
		$.ajax({
						type: 'post',
						url: 'ajax.php',
						data: {
							order_num_id:order_num_id,sl:sl,userid:userid,user_type:user_type,setEmployee:1
						},
						 beforeSend: function () {
							$("#karigor"+sl).html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							$("#karigor"+sl).hide(null);
							$("#karigor_select_box"+sl).html(response);
							
						}
			});
	
	}
	
	function seaMoreCustomer(){
	$.ajax({
		type: 'post',
		url: 'ajax.php',
		data: {
			last_id: $("#last_id").val(),
			seaMoreCustomer:1
		},
		 beforeSend: function () {
			$("#load_imgs").show();
			$("#load_imgs").html('<img src="img/loading.gif"/>');
			document.getElementById("morebtns").disabled = true;	
		},
		success: function (response) {
			console.log(response);
			if(response.trim()!=2){
				$("#load_imgs").html(null);
				$("#search_mobile").append(response);
				$("#last_id").val((parseInt($("#last_id").val())+100));
				document.getElementById("morebtns").disabled = false;
			}else{
				$("#load_imgs").html(' No result found!').css('color','red');
			}
				
			
		}
	});
}
	
	function selectItemName(search_type){
		var item_name=$("#item_name").val();
		if(item_name!=""){
			$("#chkAutItem").val(null); //founded user id
			if(search_type==2){ // in stock 
				$("#item_unit").val(null);
				$("#item_code").val(null);
				$("#previous_stock_qty").val(0);
				$("#previous_total_price").val(0);
				$("#previous_avg_price").val(0);
			}
			$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					item_name:item_name,
					search_type:search_type,
					selectItemName:1
				},
				 success: function (response) {
					 if(item_name!=""){
						$("#auto_item").html(response); 
					 }else{
						$("#auto_item").html(null);  
					 }
				}
			});
		}else{
			$("#chkAutItem").val(null); //founded user id
			$("#auto_item").html(null);  
		}
	}
	
	function barcodeScan(){
		var item_name=$("#item_name").val();
	   
		
		if (event.keyCode === 13) {

		$.ajax({//url will be related class name
			type: 'post',
			url: 'sql.php',
			data: {
				ds_item_id: item_name,
				barcodeScanStockIn:1
			},
			beforeSend: function () {
				$("#stk_in").html('Searching...').css('color','red');
			},
			success: function (response) {
				console.log(response);
				if(response==2){
					$("#stk_in").html('Not Found').css('color','red');
				}else{
					var sp=response.split('#sep#');
					console.log(sp[0]);
					var item_code=sp[0].trim();
					setItemId(item_code,sp[1],sp[2],sp[3],sp[4],sp[5],sp[6],sp[7],sp[8]);
					$("#stk_in").html('success.').css('color','green');
				}
				$('#purchase_qty').click();
				$('#purchase_qty').focus();
			 }
		});
		}
	}
	
	function setItemId(item_id,item_name,item_code,uom,selling_price,stock_qty,total_price,avg_price,search_type){
		$("#item_name").val(item_name);
		$("#auto_item").html(null);
		$("#chkAutItem").val(item_id); //founded user id
		if(search_type==2 || search_type==3){ // in stock and ajustment stock
			$("#item_unit").val(uom);
			$("#item_code").val(item_code);
			$("#previous_stock_qty").val(stock_qty);
			$("#previous_total_price").val(total_price);
			$("#previous_avg_price").val(avg_price);
			
			if(parseFloat(avg_price)>0){ // ajustment stock
				document.getElementById("previous_avg_price").disabled = true;
			}else{
				document.getElementById("previous_avg_price").disabled = false;
			}
			$("#final_qty").val(null);
			$("#total_price").val(null);
			$("#adjustment_qty").val(null);
		}
		
	}
	
	function enterEvent(id_name,next_id){
		var input = document.getElementById(id_name);
		input.addEventListener("keyup", function(event) {
		  if (event.keyCode === 13) {
			  if(next_id=="saveFabricsBtn"){
				  $("#"+next_id).focus();
			  }else{
				$("#"+next_id).click();
				//$("#"+next_id).focus();
				var tag_num = document.getElementById(next_id);
				tag_num.select();
			  }
		  }
		});
	}
	
	
	function setEmployee2(sl){ //user_type= 1=master,2=karigor
		var master_hidden_id=$("#master_hidden_id"+sl).val().split("#sep#");
		var userid=master_hidden_id[0];
		var user_type=master_hidden_id[1];
		var order_num_id=master_hidden_id[2];
		//console.log(userid+"=="+user_type+"=="+order_num_id); exit();
		$("#master_select_box"+sl).show();
		$.ajax({
						type: 'post',
						url: 'ajax.php',
						data: {
							order_num_id:order_num_id,sl:sl,userid:userid,user_type:user_type,setEmployee:1
						},
						 beforeSend: function () {
							$("#master"+sl).html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							$("#master"+sl).hide(null);
							$("#master_select_box"+sl).html(response);
							
						}
			});
	
	}
	
	function changeUser(sl,ord_num_id,old_userid){
		var get_select_karigor=$("#get_select_karigor"+sl).val();
		var sp=get_select_karigor.split("#sep#");
		var new_useri_id=sp[0];
		var useri_name=sp[1];
		var useri_name2=sp[1];
		var karigor_hidden_id=new_useri_id+"#sep#2#sep#"+ord_num_id;
		$.ajax({
						type: 'post',
						url: 'sql.php',
						data: {
							ord_num_id:ord_num_id,old_userid:old_userid,new_useri_id:new_useri_id,changeUser:1
						},
						 beforeSend: function () {
							$("#karigor"+sl).show();
							$("#karigor"+sl).html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							if(response==1){
								$("#karigor"+sl).html(useri_name);
								$("#karigors"+sl).html(useri_name2);
								$("#karigor_select_box"+sl).hide();
								$("#karigor_hidden_id"+sl).val(karigor_hidden_id);
							}else{
								
							}
							
						}
			});
	}
	
	function changeUser2(sl,ord_num_id,old_userid){
		var get_select_master=$("#get_select_master"+sl).val();
		var sp=get_select_master.split("#sep#");
		var new_useri_id=sp[0];
		var useri_name=sp[1];
		var useri_name2=sp[1];
		var master_hidden_id=new_useri_id+"#sep#1#sep#"+ord_num_id;
		$.ajax({
						type: 'post',
						url: 'sql.php',
						data: {
							ord_num_id:ord_num_id,old_userid:old_userid,new_useri_id:new_useri_id,changeUser2:1
						},
						 beforeSend: function () {
							$("#master"+sl).show();
							$("#master"+sl).html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							if(response==1){
								$("#master"+sl).html(useri_name);
								$("#masters"+sl).html(useri_name2);
								$("#master_hidden_id"+sl).val(master_hidden_id);
								$("#master_select_box"+sl).hide();
							}else{
								
							}
							
						}
			});
	}
	
	
	
	
	
	function delPay(accounting_tbl_id,div_id){
		var customer_id=$("#customer_id").val();
		var dsms_ids=$("#dsms_ids"+div_id).val();
		var total_tk=$("#total_tk"+div_id).val(); // total tk
		var discount=$("#discount"+div_id).val(); // discount tk
		var discount_tot=$("#discount_tot"+div_id).val(); // after discount tk
		var ord_no=$("#copying"+div_id).val();
		
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						discount:discount,
						discount_tot:discount_tot,
						div_id:div_id,
						total_tk:total_tk,
						dsms_ids:dsms_ids,
						accounting_tbl_id:accounting_tbl_id,
						customer_id:customer_id,
						ord_no:ord_no,
						delPay:1
					},
					 beforeSend: function () {
						$("#stksms"+div_id).show();
						$("#stksms"+div_id).html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						if(response!=2){
							$("#payment_tbl"+div_id).html(response);
							getUpdateDue();
						}else{
							$("#stksms"+div_id).html("Not Success!").css("color","red");
						}
					 }
			});
	}
	
	
	function orderDenyBtn(div_id){
		if(confirm("আপনি কি অর্ডার ক্যানসেল করতে চান?")){
		var hide_sms_id=$("#hide_sms_id"+div_id).val();
		document.getElementById("order_deny"+div_id).disabled = true;
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						div_id:div_id,hide_sms_id:hide_sms_id,orderDenyBtn:1
					},
					 beforeSend: function () {
						$("#order_deny_sms"+div_id).show();
						$("#order_deny_sms"+div_id).html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						
						if(response==1){
							$("#order_deny_sms"+div_id).html("Order Canceled!").css("color","green");
							document.getElementById("order_delivery"+div_id).disabled = true;
							document.getElementById("paybtns"+div_id).disabled = true;
						}else{
							$("#order_deny_sms"+div_id).html("Not Canceled!").css("color","red");
							document.getElementById("order_deny"+div_id).disabled = false;
						}
					 }
			});
		}else{
			
		}
	}
	
	function productionReceiveBtn(div_id,sms_status){
		var hide_sms_id=$("#hide_sms_id"+div_id).val();
		var mobile=$("#mobile3"+div_id).val();
		var ord_no=$("#copying"+div_id).val();
		//document.getElementById("order_receive"+div_id).disabled = true;
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						div_id:div_id,
						hide_sms_id:hide_sms_id,
						mobile:mobile,
						ord_no:ord_no,
						sms_status:sms_status,
						productionReceiveBtn:1
					},
					 beforeSend: function () {
						$("#order_deny_sms"+div_id).show();
						$("#order_deny_sms"+div_id).html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						
						if(response==1){
							$("#order_deny_sms"+div_id).html("Receive Success!").css("color","green");
						}else{
							$("#order_deny_sms"+div_id).html("Not Success!").css("color","red");
						}
					 }
			});
	}
	
	function recCuttingBtn(sl){
		var hidebtn=$("#chidebtn"+sl).val();
		var dressQtys=$("#cdressQtys"+sl).val();
		
		var sp=hidebtn.split("#sep#");
		var totid=$("#totid"+sp[2]).val();
		var t="";
		if(dressQtys<=0 || dressQtys==""){
			t=1;
			$("#cdressQtys"+sl).css("border-color","red");
			$("#cdressQtys"+sl).val("");
		}else{
			$("#cdressQtys"+sl).css("border-color","#CCCCCC");
			document.getElementById("dressCuttingBtn"+sl).disabled = true;
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						hidebtn:hidebtn,
						dressQtys:dressQtys,
						cuttingDressBtn:1
					},
					 beforeSend: function () {
						$("#order_deny_sms"+sp[2]).show();
						$("#order_deny_sms"+sp[2]).html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						document.getElementById("dressCuttingBtn"+sl).disabled = false;
						$("#order_deny_sms"+sp[2]).hide();
						if(response==10000000){
							$("#cdressQtys"+sl).css("border-color","red");
							$("#cdressQtys"+sl).val("");
						}else{
							var split=response.split("#sep#");
							if(split[0]==1){ // dress receive complete
								for(var ij=1;ij<=totid;ij++){
								$("#cdressQtys"+ij+sp[2]).hide();
								$("#dressCuttingBtn"+ij+sp[2]).hide();
								$("#cqty"+sl).html("("+split[1]+")");
								}
								//productionReceiveBtn(sp[2],0);
							}
							if(split[0]==0){
								$("#cqty"+sl).html("("+split[1]+")");
								$("#cdressQtys"+sl).val("");
							}
						}
					 }
			});
		}
		
	}
	
	function recDressBtn(sl){
		var hidebtn=$("#hidebtn"+sl).val();
		var dressQtys=$("#dressQtys"+sl).val();
		
		var sp=hidebtn.split("#sep#");
		var totid=$("#totid"+sp[2]).val();
		var t="";
		if(dressQtys<=0 || dressQtys==""){
			t=1;
			$("#dressQtys"+sl).css("border-color","red");
			$("#dressQtys"+sl).val("");
		}else{
			$("#dressQtys"+sl).css("border-color","#CCCCCC");
			document.getElementById("dressReceiveBtn"+sl).disabled = true;
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						hidebtn:hidebtn,dressQtys:dressQtys,recDressBtn:1
					},
					 beforeSend: function () {
						$("#order_deny_sms"+sp[2]).show();
						$("#order_deny_sms"+sp[2]).html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						document.getElementById("dressReceiveBtn"+sl).disabled = false;
						$("#order_deny_sms"+sp[2]).hide();
						if(response==10000000){
							$("#dressQtys"+sl).css("border-color","red");
							$("#dressQtys"+sl).val("");
						}else{
							var split=response.split("#sep#");
							if(split[0]==1){ // dress receive complete
								for(var ij=1;ij<=totid;ij++){
								$("#dressQtys"+ij+sp[2]).hide();
								$("#dressReceiveBtn"+ij+sp[2]).hide();
								$("#dqty"+sl).html("("+split[1]+")");
								}
								productionReceiveBtn(sp[2],0);
							}
							if(split[0]==0){
								$("#dqty"+sl).html("("+split[1]+")");
								$("#dressQtys"+sl).val("");
							}
						}
					 }
			});
		}
		
	}
	
	function pdeliveryBtn(sl){
		var hidebtn=$("#pdelivery"+sl).val();
		var dressQtys=$("#pdeliveryQtys"+sl).val();
		
		var sp=hidebtn.split("#sep#");
		var totid=$("#totid"+sp[2]).val();
		var t="";
		if(dressQtys<=0 || dressQtys==""){
			t=1;
			$("#pdeliveryQtys"+sl).css("border-color","red");
			$("#pdeliveryQtys"+sl).val("");
		}else{
			$("#pdeliveryQtys"+sl).css("border-color","#CCCCCC");
			document.getElementById("pdeliveryBtn"+sl).disabled = true;
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						hidebtn:hidebtn,dressQtys:dressQtys,pdeliveryBtn:1
					},
					 beforeSend: function () {
						$("#order_deny_sms"+sp[2]).show();
						$("#order_deny_sms"+sp[2]).html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						document.getElementById("pdeliveryBtn"+sl).disabled = false;
						$("#order_deny_sms"+sp[2]).hide();
						if(response==10000000){
							$("#pdeliveryQtys"+sl).css("border-color","red");
							$("#pdeliveryQtys"+sl).val("");
						}else{
							var split=response.split("#sep#");
							if(split[0]==1){ // dress receive complete
								for(var ij=1;ij<=totid;ij++){
								$("#pdeliveryQtys"+ij+sp[2]).hide();
								$("#pdeliveryBtn"+ij+sp[2]).hide();
								$("#ddqty"+sl).html("("+split[1]+")");
								}
								productionReceiveBtn(sp[2],1);
							}
							if(split[0]==0){
								$("#ddqty"+sl).html("("+split[1]+")");
								$("#pdeliveryQtys"+sl).val("");
							}
						}
					 }
			});
		}
		
	}
	
	function employeePriceSetup(item_id,item_name){
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					item_id:item_id,
					item_name:item_name,
					employeePriceSetup:1
				},
				 beforeSend: function () {
					$("#smeasurement").html('<img src="img/loading.gif"/>');
				},
				 success: function (response) {
					console.log(response);
					$("#heading_id").html("Employee's Price Setup");
					$("#smeasurement").html(response);
				}
		});
	}
	

 
	function fillOutAll(){
		var initial_price=$("#emp_price1").val();
		for(var i=1; i<=100; i++){
			$("#emp_price"+i).val(initial_price);
		}
	}
	
	function addEmpPrice(item_id){
		var total_emp=parseInt($("#total_emp").val());
		var stop="";
		for(var i=1; i<=total_emp; i++){
			if($("#emp_price"+i).val()==""){
				$("#emp_price"+i).css('border-color','red');
				$("#emp_price"+i).focus();
				$("#emp_price"+i).click();
				stop=i;
				break;
			}
		}
		if(stop!=""){
			alert("warning! Enter Employee Price.");
			$("#emp_price"+stop).css('border-color','red');
			$("#emp_price"+stop).focus();
			$("#emp_price"+stop).click();
			return;
		}
		
		for(var i=1; i<=total_emp; i++){
			var emp_id=$("#emp_id"+i).val();
			var emp_type=$("#emp_type"+i).val();
			$("#emp_price"+i).css('border-color','blue');
			$.ajax({
					type: 'post',
					url: 'ajax.php',
					data: {
						item_id:item_id,
						emp_id:emp_id,
						emp_type:emp_type,
						emp_price:$("#emp_price"+i).val(),
						addEmpPrice:1
					},
					 success: function (response) {
						console.log(response);
						if(response==1){
							//$("#emp_price"+i).css('border-color','blue');
						}else{
							$("#emp_price"+i).css('border-color','red');
						}
					}
			});
		}
	}
	
	function onlyDateUpdateBtn(sl){
		if(confirm("আপনি কি কাস্টমার এর মোবাইল নম্বর এ SMS পাঠাতে চান?")){
		var date1=$("#date3"+sl).val();
		var date_org=$("#date_org3"+sl).val();
		var hide_sms_id=$("#hide_sms_ids"+sl).val();
		var mobile=$("#mobile3"+sl).val();
		
		if(date1==""){
			$("#date1"+sl).css("border-color","red");
			exit();
		}else{
			$("#date1"+sl).css("border-color","#CCCCCC");
			document.getElementById("only_dateupdate"+sl).disabled = true;	
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						mobile:mobile,
						date_org:date_org,
						hide_sms_id: hide_sms_id,
						date1:date1,
						after_receive_only_date_update:1
					},
					 beforeSend: function () {
						$("#only_date_update_sms"+sl).show();
						$("#only_date_update_sms"+sl).html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						//$("#only_date_update_sms"+sl).hide();
						if(response==10000000){
							$("#only_date_update_sms"+sl).html("Insufficient (SMS) Balance").css("color","red");;
							document.getElementById("only_dateupdate"+sl).disabled = true;
						}
						else if(response==1){
							$("#only_date_update_sms"+sl).html("SMS has not sent!").css("color","red");;
							document.getElementById("only_dateupdate"+sl).disabled = true;
						
						}else if(response==20000000){
							$("#only_date_update_sms"+sl).html("Warning! Server Busy.").css("color","red");;
							document.getElementById("only_dateupdate"+sl).disabled = true;
						}else if(response==40000000){
							$("#only_date_update_sms"+sl).html("No Internet Connection").css("color","red");;
							document.getElementById("only_dateupdate"+sl).disabled = true;
						}else if(response==50000000){
							$("#only_date_update_sms"+sl).html("সবগুলি আইটেম এখনো রিসিভ হয় নাই.").css("color","red");;
							document.getElementById("only_dateupdate"+sl).disabled = true;
						}else{
							$("#dv_date"+sl).html(date1);
							$("#only_date_update_sms"+sl).html("SMS has been sent!").css("color","green");;
							document.getElementById("only_dateupdate"+sl).disabled = false;	
						}
					}
			});
		}
		}else{
			
		}
	}
	
	function payTk(div_id){
		var customer_id=$("#customer_id").val();
		var ord_number=$("#copying"+div_id).val();
		var previous_due=$("#previous_due").val();
		var hide_due=$("#hide_due"+div_id).val();
		var paytxt=$("#paytxt"+div_id).val();
		var payment_type=$("#payment_type"+div_id).val();
		var mobile=$("#mobile3"+div_id).val();
		var dsms_ids=$("#dsms_ids"+div_id).val();
		var total_tk=$("#total_tk"+div_id).val();
		var discount=$("#discount"+div_id).val();
		var discount_tot=$("#discount_tot"+div_id).val();
		var exdiscount=$("#exdiscount"+div_id).val();
		var order_number=$("#copying"+div_id).val();
		var fab_total_tk=$("#fab_total_tk"+div_id).val();
		
			if(exdiscount!=""){
				if((parseFloat(paytxt)+parseFloat(exdiscount))>parseFloat(hide_due)){
					$("#stksms"+div_id).html("Invalid! Enter correct amount.").css("color","red");
					exit;
				}
			}
			
		document.getElementById("paybtns"+div_id).disabled = true;
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						discount_tot:discount_tot,
						discount:discount,
						div_id:div_id,
						total_tk:total_tk,
						order_number:order_number,
						exdiscount:exdiscount,
						ord_number:ord_number,
						dsms_ids:dsms_ids,
						customer_id:customer_id,
						payment_type:payment_type,
						previous_due:previous_due,
						hide_due:hide_due,
						fab_total_tk:fab_total_tk,
						mobile:mobile,
						paytxt:paytxt,
						payTk:1
					},
					 beforeSend: function () {
						$("#stksms"+div_id).show();
						$("#stksms"+div_id).html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						if(response!=2){
							$("#payment_tbl"+div_id).html(response);
							getUpdateDue();
						}else{
							$("#stksms"+div_id).html("Not Success!").css("color","red");
						}
					 }
			});
	}
	
	function orderDeliveryBtn(div_id){
		if(confirm("আপনি কি অর্ডার টি ডেলিভারি দিতে চান?")){
			var hide_sms_id=$("#hide_sms_id"+div_id).val();
			var customer_id=$("#customer_id").val();
			var hide_due=$("#hide_due"+div_id).val();
			var payment_type=$("#payment_type"+div_id).val();
			var total_tk=$("#total_tk"+div_id).val();
			var discount=$("#discount"+div_id).val();
			var discount_tot=$("#discount_tot"+div_id).val();
			var order_number=$("#copying"+div_id).val();
			var fab_total_tk=$("#fab_total_tk"+div_id).val();
			var ord_number=$("#copying"+div_id).val();
			var paytxt="", exdiscount="";
			if(hide_due!=0){
				if($("#paytxt"+div_id).val()==""){
				$("#order_delivery_sms"+div_id).html("Enter Due!").css("color","red");
				exit;
				}else{
					paytxt=$("#paytxt"+div_id).val();
					exdiscount=$("#exdiscount"+div_id).val();
				}
			}
		
			if(parseFloat(hide_due)<0){
				$("#order_delivery_sms"+div_id).html("Invalid! Delete any amount.").css("color","red");
				exit;
			}
			
			if(exdiscount!=""){
				if((parseFloat(paytxt)+parseFloat(exdiscount))>parseFloat(hide_due)){
					$("#order_delivery_sms"+div_id).html("Invalid! Enter correct amount.").css("color","red");
					exit;
				}
			}
		
			if(parseFloat(paytxt)>parseFloat(hide_due)){
				$("#order_delivery_sms"+div_id).html("Invalid! Enter correct amount.").css("color","red");
				exit;
			}
		
			document.getElementById("order_delivery"+div_id).disabled = true;
			$.ajax({
						type: 'post',
						url: 'sql.php',
						data: {
							discount_tot:discount_tot,
							discount:discount,
							div_id:div_id,
							total_tk:total_tk,
							paytxt:paytxt,
							exdiscount:exdiscount,
							payment_type:payment_type,
							hide_due:hide_due,
							hide_sms_id:hide_sms_id,
							customer_id:customer_id,
							order_number:order_number,
							fab_total_tk:fab_total_tk,
							orderDeliveryBtn:1
						},
						 beforeSend: function () {
							$("#order_delivery_sms"+div_id).show();
							$("#order_delivery_sms"+div_id).html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							//document.getElementById("order_delivery").disabled = false;
							if(response!=2){
								$("#order_delivery_sms"+div_id).html("Success!").css("color","green");
								var sp=response.split("#sep#");
								$("#phy_dv_date"+div_id).html(sp[0]);
								$("#payment_tbl"+div_id).html(sp[1]);
								getUpdateDue();
								setTimeout(function() {
								  srchByMobileNum($("#mobile").val());
								},500);
							}else{
								$("#order_delivery_sms"+div_id).html("Not Success!").css("color","red");
							}
						 }
				});
		}
	}
	
	
	function seaMore(){
		seaMoreInfo($("#last_id_hide").val(),$("#mobile").val());
		document.getElementById("morebtn").disabled = true;	
	}

function seaMoreInfo(last_id,mobile){
			$.ajax({
					type: 'post',
					url: 'ajax.php',
					data: {
						mobile:mobile,last_id: last_id,more_srch:1
					},
					 beforeSend: function () {
						$("#load_img").show();
						$("#load_img").html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						$("#load_img").hide();
						if(response!=2){
						$("#src_result").append(response);
						$("#last_id_hide").val((parseInt(last_id)+3));
						document.getElementById("morebtn").disabled = false;	
						}else{
							$("#last_id_hide").val(0);
							document.getElementById("morebtn").disabled = true;
						}
					}
			});
	}

	
	function searchAllOrder(){
		var year=$("#searching_year").val();
		document.getElementById("asrcbtn").disabled = true;
		console.log(year);
		$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					year:year,arcbtn:1
				},
				 beforeSend: function () {
					$("#sms_arc").show();
					$("#sms_arc").html('<img src="img/loading.gif"/>');
				},
					success: function (response) {
						console.log(response);
						document.getElementById("asrcbtn").disabled = false;
						if(response==1){
							$("#sms_arc").html("No result found!").css("color","red");
							$("#allorder").html(null);
						}else{
							$("#sms_arc").hide();
							$("#allorder").html(response);
						}
						$("#sms_op").hide();
					 }
			});
	}
	
	function sendSmsOccasion(){
		
		var txt_sms=$("#otxt_sms").val();
		var mobile=$("#omobile").val();
		var m="",t="";
			
		
		if(txt_sms==""){
			$("#otxt_sms").css("border-color","red");
			t=1;
		}else{
			$("#otxt_sms").css("border-color","#CCCCCC");
		}
		
		if(mobile==""){
			$("#omobile").css("border-color","red");
			m=1;
		}else{
			$("#omobile").css("border-color","#CCCCCC");
		}
		
		if(m==1 || t==1){
			exit();
		}else{
		document.getElementById("allockbtn").disabled = true;
		
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						mobile:mobile,txt_sms:txt_sms,sendOcasionbtn:1
					},
					 beforeSend: function () {
						$("#sms_save").show();
						$("#sms_save").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						//document.getElementById("allockbtn").disabled = false;
						if(response==40000000){
							$("#sms_save").html("Send Success!").css("color","green");
							$("#otxt_sms").css("border-color","#CCCCCC");
						}else if(response==20000000){
							$("#sms_save").html("Not Success!").css("color","red");
						}else if(response==10000000){
							$("#sms_save").html("Warning! Not enough sms.").css("color","red");
						}else if(response==30000000){
							$("#sms_save").html("Warning! Invalid Business.").css("color","red");
						}else if(response==50000000){
							$("#otxt_sms").css("border-color","red");
							$("#sms_save").html("Warning! Please enter english text.").css("color","red");
						}else if(response==60000000){
							$("#otxt_sms").css("border-color","red");
							$("#sms_save").html("Warning! SMS length is so more.").css("color","red");
						}
					 }
			});
		}
	}
	
	function sendToServerOrder(){
		if(confirm("আপনি কি Customer কে SMS এর মাধ্যমে Notify করতে চান?")){	
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						sendToServerOrder:1
					},
					 beforeSend: function () {
						$("#send_to_server_order").hide();
						$("#send_to_server_load").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						//document.getElementById("allockbtn").disabled = false;
						if(response==10000000){
							$("#send_to_server_load").html("Send Success!").css("color","green");
							$("#tbl_one").html(null);
							settingsData(4);
						}
						if(response==20000000){
							$("#send_to_server_load").html("Warning! Server Busy!").css("color","red");
						}
						if(response==30000000){
							$("#send_to_server_load").html("Not Enough SMS!").css("color","red");
						}
						if(response==40000000){
							$("#send_to_server_load").html("Not Internet Connection!").css("color","red");
						}
					 }
			});
		}
	}
	
	function sendToServerReceivedOrder(id){
		if(confirm("আপনি কি Customer কে SMS এর মাধ্যমে Notify করতে চান?")){	
		var factory_mobile=$("#factory_mobile"+id).val().trim();
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						factory_mobile:factory_mobile,sendToServerReceivedOrder:1
					},
					 beforeSend: function () {
						$("#send_to_server_load2"+id).html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						//document.getElementById("allockbtn").disabled = false;
						if(response==10000000){
							$("#send_to_server_load2"+id).html("Send Success!").css("color","green");
							$("#tbl_two2").html(null);
						}
						if(response==20000000){
							$("#send_to_server_load2"+id).html("Warning! Server Busy!").css("color","red");
						}
						
						if(response==40000000){
							$("#send_to_server_load2"+id).html("Not Internet Connection!").css("color","red");
						}
					 }
			});
		}
	}
	
	function getSmsDetails(){
		document.getElementById("sms_details").disabled = true;
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						getSmsDetails:1
					},
					 beforeSend: function () {
						$("#sms_tbl").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						 console.log(response);
						if(response==20000000){
							$("#sms_tbl").html("Server Busy!").css("color","red");
						}else if(response==40000000){
							$("#sms_tbl").html("No Internet Connection!").css("color","red");
						}else{
							$("#sms_tbl").html(response);
						}
				document.getElementById("sms_details").disabled = false;		
			}
		});
	}
	
	function setAddress(tbl_id,status){ //status=1 means cus name and 2 means address
		if(status==1){
			var cus_address=$("#cus_name"+tbl_id).val().trim();
		}else{
		var cus_address=$("#cus_address"+tbl_id).val().trim();
		}
		$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				cus_address:cus_address,
				tbl_id:tbl_id,
				status:status,
				setAddress:1
			},
			 success: function (response) {
				 if(status==1){
					if(response==1){
						$("#cus_name"+tbl_id).css("color","blue");
						$("#cus_name"+tbl_id).css("border-color","#CCCCCC");
					}else if(response==2){
						$("#cus_name"+tbl_id).css("border-color","red");
					}	 
				 }else{
					if(response==1){
						$("#cus_address"+tbl_id).css("color","blue");
						$("#cus_address"+tbl_id).css("border-color","#CCCCCC");
					}else if(response==2){
						$("#cus_address"+tbl_id).css("border-color","red");
					}	
				 }
			}
		});
	}
	
	function searhMobileNumber(){
		var src_cus_mobile=$("#src_cus_mobile").val().trim();
		$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				src_cus_mobile:src_cus_mobile,
				searhMobileNumber:1
			},
			 success: function (response) {
				$("#search_mobile").html(response);
			}
		});
	}
	
	function searchStockItem(search_page_type){
		var item_type="dd";
		var date3="";
		var search_item_name=$("#search_item_name").val().trim();
		if(search_page_type==1){
			var item_type=$("#item_type").val().trim();
		}
		if(search_page_type==2 || search_page_type==3){
			var date3=$("#date3").val().trim();
		}
		var search_sort_type=$("#search_sort_type").val().trim();
		if(item_type!=""){
			$("#item_type").css("border-color","#CCCCCC");
			$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					search_item_name:search_item_name,
					search_sort_type:search_sort_type,
					item_type:item_type,
					date3:date3,
					search_page_type:search_page_type,
					searchStockItem:1
				},
				 success: function (response) {
					 console.log(response);
					$("#item_tbl").html(response);
				}
			});
		}else{
			alert("Select Item Type!");
			$("#item_type").css("border-color","red");
		}
		
	}
	
	function printOrder(){
		var order_number="";
		if($("#print_type").val()==1 || $("#print_type").val()==2){
			order_number=$("#order_number").val().trim();
		}
		printDiv("summery_report2",order_number);
	}
	
	function printDiv(divName,order_number) {
		var printContents = document.getElementById(divName).innerHTML;
		var originalContents = document.body.innerHTML;
		document.body.innerHTML = printContents;
		window.print();
		document.body.innerHTML = originalContents;
		if($("#print_type").val()==1 || $("#print_type").val()==2){
			$("#order_number").val(order_number);
		}
	}
	
	function printOrderOthers(){
		var order_number="";
		if($("#print_type").val()==1 || $("#print_type").val()==2){
			order_number=$("#order_number").val().trim();
		}
		printDivOthers("summery_report2",order_number);
	}
	
	function printDivOthers(divName,order_number) {
		var printContents = document.getElementById(divName).innerHTML;
		var originalContents = document.body.innerHTML;
		document.body.innerHTML = printContents;
		window.print();
		document.body.innerHTML = originalContents;
		if($("#print_type").val()==1 || $("#print_type").val()==2){
			printStatusUpdate(order_number);
		}
	}
	
	function printStatusUpdate(ord_number){
		$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				ord_number:ord_number,
				printStatusUpdate:1
			},
			 success: function (response) {
				if(response==1){
					getOrderNumber();
				}
			}
		});
	}
	
	function txtbtn(){
		$("#sms_op").show();
		$("#condition").hide();
	}
	
	function setCusPrice(sl,tbl_id,updatetype){
			if(updatetype==1){
				var price=$("#cus_price"+sl).val().trim();
			}else if(updatetype==2){
				var price=$("#mas_price"+sl).val().trim();
			}else if(updatetype==3){
				var price=$("#kar_price"+sl).val().trim();
			}else if(updatetype==4){
				var price=$("#order"+sl).val().trim();
			}else if(updatetype==5){
				var price=$("#product_name"+sl).val().trim();
			}else if(updatetype==6){
				var price=$("#product_code"+sl).val().trim();
			}else if(updatetype==7){
				var price=$("#selling_price"+sl).val().trim();
			}else if(updatetype==8){
				var price=$("#purchase_price"+sl).val().trim();
			}
			
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						updatetype:updatetype,
						tbl_id:tbl_id,
						cus_price:price,
						updateItemPrice:1
					},
					success: function (response){
						console.log(response);
						if(response==1){
							if(updatetype==1){
								$("#cus_price"+sl).css("color","blue");
							}else if(updatetype==2){
								$("#mas_price"+sl).css("color","blue");
							}else if(updatetype==3){
								$("#kar_price"+sl).css("color","blue");
							}else if(updatetype==4){
								$("#order"+sl).css("color","blue");
							}else if(updatetype==5){
								$("#product_name"+sl).css("color","blue");
							}else if(updatetype==6){
								$("#product_code"+sl).css("color","blue");
							}else if(updatetype==7){
								$("#selling_price"+sl).css("color","blue");
							}else if(updatetype==8){
								$("#purchase_price"+sl).css("color","blue");
							}
						}else{
							if(updatetype==1){
								$("#cus_price"+sl).css("color","red");
							}else if(updatetype==2){
								$("#mas_price"+sl).css("color","red");
							}else if(updatetype==3){
								$("#kar_price"+sl).css("color","red");
							}else if(updatetype==4){
								$("#order"+sl).css("color","red");
							}else if(updatetype==5){
								$("#product_name"+sl).css("color","red");
							}else if(updatetype==6){
								$("#product_code"+sl).css("color","red");
							}else if(updatetype==7){
								$("#selling_price"+sl).css("color","red");
							}else if(updatetype==8){
								$("#purchase_price"+sl).css("color","red");
							}
						}
					}
			});
	}
	
	function clickToSelect(txtboxid) {
		const txtbox = document.getElementById(txtboxid);
		txtbox.focus();
		txtbox.select();
 
	}
	
	function copyFunction() {
		var omobile = document.getElementById("omobile");
		omobile.select();
		omobile.setSelectionRange(0, 99999)
		document.execCommand("copy");
	}
	
	function copyOrderNumber(id) {
		var tag_num = document.getElementById("copying"+id);
		tag_num.select();
		tag_num.setSelectionRange(0, 99999)
		document.execCommand("copy");
	}
	
	$(document).ready(function(){
		$("#decision_area,#emp_status,#emp_list,#order_deny,#extrafirsts,#extrafirsts2,#send_email,#previous_due_tab,#ref_amount_title,#reference_amount,#fours,#extraitem,#karigors,#order_status,#expensetype,#item_status,#employee_list").hide();
		$(".select2").select2();
		$("#order_delivery").hide();
		$("#sms_op").hide();
		$("#morebtn").hide();
		//$('#example').DataTable();
		
	});
	
  </script>
   <style>
  #customer_scroll{
	overflow-y: scroll;
	overflow-x: hidden;
}
  </style>
  
  
  