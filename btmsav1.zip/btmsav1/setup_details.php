
<script src="file/jquery.min.js"></script>
<script src="file/bootstrap.min.js"></script> 
Clear Database:
<select id="drive_name">
	<option value="D">D</option>
	<option value="E">E</option>
	<option value="F">F</option>
	<option value="G">G</option>
	<option value="H">H</option>
	<option value="I">I</option>
	<option value="J">J</option>
	<option value="K">K</option>
	<option value="L">L</option>
	<option value="M">M</option>
</select> <button onclick="clearDatabase();" id="cleabtn" name="btn">Clear Database</button>
<span id="sms_tbl2"></span>
<br/><br/>

Shop ID: <input type="text" id="shop_id" />
<button onclick="saveSetUpInfo();" id="ssupbtn">Save</button>
<span id="sms_tbl"></span>
<br/><br/>

<input type="text" id="ex_query" style="width: 700px;" placeholder="Query" />
<button onclick="executeQuery();" id="okbtn">Ok</button>
<p>update product set com_id=12 WHERE com_id=10</p>
<p>update select_detail set com_id=12 WHERE com_id=10</p>
<span id="sms_tbl3"></span>
<br/><br/>
<form action="index.php" method="post">
	<input type="submit" name="sub_btn" value="Home"/>
</form>



<script>

	function executeQuery(){
		if(confirm("আপনি কি কুয়েরি রান করতে চান?")){
			$.ajax({
				type: 'post',
				url: 'external_ajax.php',
				data: {
					ex_query: $("#ex_query").val(),
					executeQuery: 1
				},
				 beforeSend: function () {
					$("#sms_tbl3").html('<img src="img/loading.gif"/>');
					document.getElementById("okbtn").disabled = true;
				},
				 success: function (response) {
					console.log(response);
					if(response==1){
						$("#sms_tbl3").html("কুয়েরি রান সাকসেস হয়েছে.").css("color","green");
						$("#ex_query").val(null);
					}else{
						//$("#sms_tbl2").html(response);
					} 
					document.getElementById("okbtn").disabled = false;
				}
			});
		}
	}
	function clearDatabase(){
		if(confirm("আপনি কি ডাটাবেস ক্লিয়ার করতে চান?")){
			$.ajax({
				type: 'post',
				url: 'external_ajax.php',
				data: {
					drive_name: $("#drive_name").val(),
					clearDb: 1
				},
				 beforeSend: function () {
					$("#sms_tbl2").html('<img src="img/loading.gif"/>');
					document.getElementById("cleabtn").disabled = true;
				},
				 success: function (response) {
					console.log(response);
					if(response==1){
						$("#sms_tbl2").html("ডাটাবেস ক্লিয়ার সাকসেস হয়েছে.").css("color","green");
					}else{
						//$("#sms_tbl2").html(response);
					} 
				}
			});
		}
	}
	
	function saveSetUpInfo(){
		if($("#shop_id").val()!=""){
			$.ajax({
				type: 'post',
				url: 'external_ajax.php',
				data: {
					shop_id: $("#shop_id").val(),
					saveSetUpInfo:1
				},
				 beforeSend: function () {
					$("#sms_tbl").html('<img src="img/loading.gif"/>');
					document.getElementById("ssupbtn").disabled = true;
				},
				 success: function (response) {
					console.log(response);
					$("#sms_tbl").html(response);
					document.getElementById("ssupbtn").disabled = false;		
				}
			});
		}else{
			$("#sms_tbl").html("Warning! Please Enter Your Shop ID.").css("color","red");
		}
	}
</script>