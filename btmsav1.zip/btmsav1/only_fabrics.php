
<?php 
	if(isset($_SESSION['COM_ID'])){
		$com_id=$_SESSION['COM_ID'];
		date_default_timezone_set("Asia/Dhaka");
		$date=date("Y-m-d");
		$sales_details=$conn->query("SELECT id,cus_mobile,insert_date,f_total,others_tk,discount_tk,total_receive,(select cus_name from customer where cus_mobile=direct_sale_head.cus_mobile limit 0,1) cus_name,(select id from customer where cus_mobile=direct_sale_head.cus_mobile limit 0,1) cus_id,(select order_number from direct_sale where dstid=direct_sale_head.id and is_active=1 limit 0,1) ord_num FROM `direct_sale_head` WHERE com_id=$com_id and date(insert_date)='$date' and is_active!=0 and in_out_status=0 and is_order=0 order by id desc limit 0,200");
		
		mysqli_close($conn);		
?>

<ul class="nav nav-tabs" style="display: none;">
	
    <li class="active"><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" href="#home">Customer</a></li>
	
   <!-- <li><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" onclick="sclick();" id="attach_tbl" href="#menu1">Order Details</a></li>
	
    <li><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" id="order_print_area" href="#menu2">Print</a></li>-->
    
</ul>

<div class="tab-content" id="tabs">
    <div id="home" class="tab-pane fade in active">
	<br/>
     
	<div class="panel-group">
		 <div id="show_history">
	  
		   <div class='panel panel-info' style="color: black; box-shadow: inset 0 0 1em gray; padding: 15px;margin-left: 0px;margin-right: 0px;">
			  <div class="panel-heading">
			  <div style="overflow:hidden">
				<input type="text" onkeyup="getCustomerFabricsOrderList('search_ord_num');" placeholder="অর্ডার নম্বর" class="form-control" style="font-weight: bold;font-size:18px;font-style: italic;color: #5e5ea2;width: 12%;float:left;margin-right: 5px;" autocomplete="off" name="total_due" id="search_ord_num"/>
				<input type="text" onkeyup="getCustomerFabricsOrderList('cus_name_mobile');" placeholder="মোবাইল" class="form-control" style="font-weight: bold;font-size:18px;font-style: italic;color: #5e5ea2;width: 18%;float:left;margin-right: 5px;" autocomplete="off" name="total_due" id="cus_name_mobile"/>
				<input type="text" onchange="getCustomerFabricsOrderList('kstart_date');" style="width: 18%;float: left; margin-right: 5px;font-weight: bold;font-size:18px;" autocomplete="off" placeholder="Start Date" id="kstart_date" class="form-control" />	
				<input type="text" onchange="getCustomerFabricsOrderList('kend_date');" style="width: 18%;float: left; margin-right: 5px;font-weight: bold;font-size:18px;" autocomplete="off" placeholder="End Date" id="kend_date" class="form-control" />	
				
				<span style="float: right;font-size: 22px;">ফ্যাব্রিক্স সেলস প্যানেল</span>
				</div>
			  </div>
			 
			  <div class="panel-body">
					<div class="row" style="background: white;">
					
					<div class="col-xs-12 col-sm-12" style="">
						<span id="sales_return_print_page"></span>
						<span id="sales_return_page">
							<button onclick="printOrder();" style="margin-right:15px" name="btn" id="printBtns" value="sub" class="btn btn-info">Print</button>
							<span id="clear_action" onclick="closeArea();" style="color:red;font-weight:bold;cursor:pointer">Clear</span>
							<table id="example" class="table table-striped table-bordered">
							<thead>
								<tr>
									<th style="text-align:center">Fabrics Order</th>
									<th style="">Customer</th>
									<th style="text-align:center">Mobile</th>
									<th>Sales Date</th>
									<th style="text-align:right">Net Total</th>
									<th style="text-align:right">discount(Tk)</th>
									<th style="text-align:right">Total(Tk)</th>
									<th style="text-align:right">Advance</th>
									<th style="text-align:right">Due</th>
									<th style="text-align:center">Action</th>
								</tr>
							</thead>
							<tbody id="tbl_two2">
								<?php 
								$gtotal=0;
								if(mysqli_num_rows($sales_details)>0){
									$i=1;$ttk=0;$others=0;$total=0;$gtotal=0;
									while($row=mysqli_fetch_array($sales_details)){
										$ttk=$row['f_total'];
										$total_receive=$row['total_receive'];
										$others=$row['others_tk'];
										$discount=$row['discount_tk'];
										$total=($ttk+$others)-$discount;
										$due=$total-$total_receive;
										$gtotal+=$total;
										?>
											<tr id="frow<?php echo $row['id']; ?>">
												<td style="text-align:center">
													<?php echo $row['id']; ?>
												</td>
												<th style=""><?php echo $row['cus_name']; ?></th>
												<th style="text-align:center;width: 12%;" id="cus_mobile_row<?php echo $row['id']; ?>"><span style="text-decoration: underline dashed red;cursor: pointer;" onclick="updateAnyColumn('<?php echo $row['id']; ?>','<?php echo $row['cus_mobile']; ?>','<?php echo $row['cus_id']; ?>');"><?php echo $row['cus_mobile']; ?></span></th>
												<th><?php echo $row['insert_date']; ?></th>
												<th style="text-align:right" id="netpay<?php echo $row['id']; ?>"><?php echo $ttk; ?></th>
												<th style="text-align:right" id="tbl_discount_tk<?php echo $row['id']; ?>"><?php echo $discount; ?></th>
												<th style="text-align:right" id="tbl_total_tk<?php echo $row['id']; ?>"><?php echo $total; ?></th>
												<th style="text-align:right"><?php echo $total_receive; ?></th>
												<th style="text-align:right"><?php echo $due; ?></th>
												
												<th style="text-align:center;"><?php 
													if($row['ord_num']=="" || $row['ord_num']=="0"){
														?>
														<span style="cursor: pointer;color:#ff0000c7;" onclick="showDetailSales('<?php echo $row['id']; ?>');"><i>Edit</i></span> | 
														<span style="cursor: pointer;color:#0000ffd1;" onclick="dateWisePrint('<?php echo $row['id']; ?>','10');"><i>View</i></span>
														<?php 
													}
													?>
												</th>
											</tr>
										<?php 
									}
								}
								
								?>
								<tr>
									<th colspan="7" style="text-align:right">Total: </th>
									<th style="text-align:right"><?php echo $gtotal; ?></th>
								</tr>
								
							</tbody>
						</table>
						</span>
						
					</div>
				</div>
					
			  </div>
			 
		   </div>
		
	   </div>	
	</div>
</div>

	 <div id="menu1" class="tab-pane">
       <br/>
	
   </div>
 
	<div id="menu2" class="tab-pane">
     <br/>
		
    </div>
	
</div>

 <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg" id="modal_width">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" id="heading_id"></h4>
        </div>
        <div class="modal-body">
          <span id="smeasurement"></span>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  
  <script>
  
  $(function() {
		$( "#attenstart_date,#attenend_date,#attendance_date,#mstart_date,#kstart_date,#kend_date,#rstart_date,#rend_date,#pstart_date,#pend_date" ).datepicker({
			dateFormat: 'dd/mm/yy' 
		});
		$("#mend_date" ).datepicker({
			dateFormat: 'dd/mm/yy' 
		});
		
		
	});
	
$(document).ready(function(){
		$(".select2").select2();
		$("#head_measurement,#edit_measurement,#clear_action,#printBtns").hide();
});

function closeArea(){
	$("#sales_return_print_page").html(null);
	$("#clear_action,#printBtns").hide();
}


function getCustomerFabricsOrderList(searh_status){
	var search_ord_num=$("#search_ord_num").val();
	var cus_name_mobile=$("#cus_name_mobile").val();
	var kstart_date=$("#kstart_date").val();
	var kend_date=$("#kend_date").val();
	
	$.ajax({
		type: 'post',
		url: 'sql.php',
		data: {
			search_ord_num: search_ord_num,
			cus_name_mobile: cus_name_mobile,
			kstart_date: kstart_date,
			kend_date: kend_date,
			getCustomerFabricsOrderList:1
		},
		 beforeSend: function () {
			$("#sales_return_page").html('Wait..');
		},
		 success: function (response) {
			console.log(response);
			if(response!=2){
				$("#sales_return_page").html(response);
			}else{
				$("#sales_return_page").html("Warning! No result found.");
			}
			$("#clear_action,#printBtns").hide();
		 }
});
}

	function showDetailSales(dstblid){
		$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				dstblid:dstblid,showDetailSales:1
			},
			 beforeSend: function () {
				$("#sales_return_print_page").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
				if(response!=2){
					$("#sales_return_print_page").html(response).css("color","black");
				}else{
					$("#sales_return_print_page").html("No Result Found!").css("color","red");
				}
				$("#clear_action").show();
				document.body.scrollTop = 0;
				document.documentElement.scrollTop = 0;
			}
		});
	}
	
	function delDetailSales(deltblid,price,headid,ord_num,item_id,item_qty,cus_mobile){
		 if(confirm("আপনি কি Item টি  Return নিতে চান?")){
			 if(ord_num=="" || ord_num=='0'){
				document.getElementById("delid"+deltblid).disabled = true;	
				$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						headid:headid,
						price:price,
						ord_num:ord_num,
						deltblid:deltblid,
						item_id:item_id,
						item_qty:item_qty,
						cus_mobile:cus_mobile,
						delDetailSales:1
					},
					 beforeSend: function () {
						$("#del_sms").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						 console.log(response);
						if(response==1){
							$("#del_sms").html("Delete Success!").css("color","green");
						}else{
							$("#del_sms").html("Not Success!").css("color","red");
						}
						
					}
				});
			 }else{
				 //alert("Sales return is not possible. Please exchange it!!");
				document.getElementById("delid"+deltblid).disabled = true;	
				$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						headid:headid,
						price:price,
						ord_num:ord_num,
						deltblid:deltblid,
						item_id:item_id,
						item_qty:item_qty,
						cus_mobile:cus_mobile,
						delDetailSales:1
					},
					 beforeSend: function () {
						$("#del_sms").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						 console.log(response);
						if(response==1){
							$("#del_sms").html("Delete Success!").css("color","green");
						}else{
							$("#del_sms").html("Not Success!").css("color","red");
						}
						
					}
				});
			 }
		  }
	}
	
	function dateWisePrint(order_number,print_type){
		var date1='';
		var date2="",extra_item="",karigor_list="",order_type="",expense_type="";
		var mobile='';
		var order_number=order_number;
		var serial_no="";
		var print_type=print_type;
		extra_item='';
		var month="",year="";
		if(print_type==14 || print_type==23){
			karigor_list=$("#karigor_list").val();
			date1="2023/01/01";
		}
		if(print_type==24){
			order_type=$("#decision_list").val();
			order_number=1;
		}
		if(print_type==15){
			order_type=$("#order_type").val();
			date1="2023/01/01";
		}
		if(print_type==16){
			expense_type=$("#expense_type").val();
			date1=$("#date1").val();
		}
		if(print_type==18){
			extra_item=$("#item_statuss").val();
			date1=$("#date1").val();
		}
		if(print_type==19){
			karigor_list=$("#emp_lists").val();
			extra_item=$("#emp_statuss").val();
			date1=$("#date1").val();
		}
		if(print_type==4 || print_type==5 || print_type==6 || print_type==7){
			order_number="123";
			month=$("#month").val();
			year=$("#year").val();
		}
		if(print_type==9){
			date1="2023/01/01";
			mobile="1";
			order_number="1";
			serial_no="1";
		}
		if(print_type==3){
			if(date1==""){
				$("#date1").css("border-color","red");
				$("#date1").focus();
				exit;
			}else{
				$("#date1").css("border-color","#CCCCCC");
				$("#send_email").show("slow");
			}
		}
		if(print_type==11 || print_type==12 || print_type==16 || print_type==8 || print_type==17 || print_type==18 || print_type==19){
			if(date1==""){
				$("#date1").css("border-color","red");
				$("#date1").focus();
				exit;
			}else{
				$("#date1").css("border-color","#CCCCCC");
				$("#send_email").show("slow");
			}
			date2=$("#date2").val();
			if(date2==""){
				$("#date2").css("border-color","red");
				$("#date2").focus();
				exit;
			}else{
				$("#date2").css("border-color","#CCCCCC");
				//$("#send_email").show("slow");
			}
		}
		if(date1=="" && mobile=="" && order_number=="" && serial_no==""){
			$("#summery_report2").html("Enter Date/Mobile/Order No.").css("color","red");
		}else{
			$.ajax({
						type: 'post',
						url: 'ajax.php',
						data: {
							month:month,
							year:year,
							print_type:print_type,
							date1:date1,
							date2:date2,
							mobile:mobile,
							order_number:order_number,
							serial_no:serial_no,
							extra_item:extra_item,
							karigor_list:karigor_list,
							order_type:order_type,
							expense_type:expense_type,
							dateWisePrint:1
						},
						 beforeSend: function () {
							$("#sales_return_print_page").html('<img src="img/loading.gif"/>');
						},
						 success: function (response) {
							console.log(response);
							if(response==2){
								$("#sales_return_print_page").html("No Result Found!").css("color","red");
							}else{
								$("#sales_return_print_page").html(response).css("color","black");
								$("#printBtns").show();
							}
							$("#clear_action").show();
						}
			});
		}
		
	}
	
	function updateAnyColumn(id,mobile,cus_id){
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					id:id,
					cus_id:cus_id,
					mobile:mobile,
					updateAnyColumn:1
				},
				success: function (response) {
					console.log(response);
					$("#cus_mobile_row"+id).html(response);
				}
		});
	}
	
	function updateFabMobile(tbl_id,cus_id){
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					id:tbl_id,
					cus_id:cus_id,
					mobile:$("#cus_mobile_edit_field"+tbl_id).val(),
					updateFabMobile:1
				},
				success: function (response) {
					console.log(response);
					if(response==1){
						$("#cus_mobile_edit_field"+tbl_id).css('border-color','blue');
					}
					
				}
		});
	}
	
	function updateFabQty(item_id,item_qty,item_per_price,sales_tbl_id,sales_head_id,cus_id,ord_number){
		if($("#edit_fab_qty"+sales_tbl_id).val()==0 || $("#edit_fab_qty"+sales_tbl_id).val()==""){
			alert('Warning! Enter at least one item.');
			$("#edit_fab_qty"+sales_tbl_id).css('border-color','red');
			$("#edit_fab_qty"+sales_tbl_id).focus();
			return;
		}
		
		if(parseFloat(item_qty)==parseFloat($("#edit_fab_qty"+sales_tbl_id).val())){
			$("#edit_fab_qty"+sales_tbl_id).css('border-color','blue');
			return;
		}
		$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				item_id:item_id,
				item_qty:item_qty,
				edit_fab_qty:$("#edit_fab_qty"+sales_tbl_id).val(),
				item_per_price:item_per_price,
				sales_tbl_id:sales_tbl_id,
				sales_head_id:sales_head_id,
				cus_id:cus_id,
				ord_num:ord_number,
				updateFabQty:1
			},
			 success: function (response) {
				if(response==1){
					$("#edit_fab_qty"+sales_tbl_id).css("border-color","blue");
					document.getElementById("update_btn"+sales_tbl_id).disabled = true;
				}else{
					$("#edit_fab_qty"+sales_tbl_id).css("border-color","red");
				}
				
			}
		});
	}
	
	function liveCheckStockQty(tbl_id,item_id,item_qty){
		$.ajax({
			type: 'post',
			url: 'sql.php',
			data: {
				tbl_id:tbl_id,
				item_id:item_id,
				item_qty:item_qty,
				edit_fab_qty:$("#edit_fab_qty"+tbl_id).val(),
				liveCheckStockQty:1
			},
			 success: function (response) {
				if(response==3){
					alert('Item stock not available.');
					$("#edit_fab_qty"+tbl_id).val(item_qty);
					$("#edit_fab_qty"+tbl_id).css("border-color","red");
				}else{
					$("#edit_fab_qty"+tbl_id).css("border-color","blue");
				}
				
			}
		});
	}


	
	function printOrder(){
		var order_number="";
		
		printDiv("sales_return_print_page",order_number);
	}
	
	function printDiv(divName,order_number) {
		var printContents = document.getElementById(divName).innerHTML;
		var originalContents = document.body.innerHTML;
		document.body.innerHTML = printContents;
		window.print();
		document.body.innerHTML = originalContents;
		
	}
	
	
</script>

<style>
.chkbox{
	 -ms-transform: scale(2); /* IE */
  -moz-transform: scale(2); /* FF */
  -webkit-transform: scale(2); /* Safari and Chrome */
  -o-transform: scale(2); /* Opera */
  transform: scale(2);
  padding: 10px;
}

.checkboxtext
{
  /* Checkbox text */
  font-size: 120%;
  display: inline;
  padding-left: 6px;
  padding-right: 40px;
}
#tblhight{
			overflow-y: scroll;
		overflow-x: hidden;
</style>

<?php
	}else{
		header("location:index.php?id=1");
	}
?>
