
<?php 

	$com_id=$_SESSION['COM_ID'];
	$dates=date("Y-m-d");
	date_default_timezone_set("Asia/Dhaka");
	
?>

<div class="tab-content">

	<div class="panel-group">
	
	<div class="panel panel-info">
      <div class="panel-heading">Tutorial List</div>
      <div class="panel-body">
			<div class="col-xs-12 col-sm-12">
				<h4 for="comment">Software Customization</h4>
				<p style="color:red">আপনার প্রতিষ্ঠানে  Tailoring Software টি  Run করার পূর্বে অবশ্যই Customize করে নিতে হবে.</p>
					<p> Customization Tutorials: </p>
					<p><a target="_blank" href="https://www.youtube.com/watch?v=9dN3aIvfATI">1. আইটেম এর নাম Customize</a></p>
					<p><a target="_blank" href="https://www.youtube.com/watch?v=Pfxt-BKaLds">2. Measurement Box Customize</a></p>
					<p><a target="_blank" href="https://www.youtube.com/watch?v=gwP0Bkzb31I">3. Left Menu(Select Box) Customize</a></p>
					<p><a target="_blank" href="https://www.youtube.com/watch?v=TUhve6ryE4Q">4. Right Side Design Box(Check Box) Customize</a></p>
					<p><a target="_blank" href="https://www.youtube.com/watch?v=uevcSyttq_Y">5. Bottom Box Setup</a></p>
				<br/>
				
				<h4 for="comment">Software's Basic Training</h4>
				<p style="color:red">Basic Training Tutorials গুলি দেখলে যে কোনো ব্যাক্তি খুব সহজেই এই সফটওয়্যার টি Operate করতে পারবেন.</p>
					<p> Basic Training Tutorials: </p>
					<p><a target="_blank" href="https://www.youtube.com/watch?v=WgCX6o1bQ4g&t=36s">1. কিভাবে একটি New Order নিবেন?</a></p>
					<p><a target="_blank" href="https://www.youtube.com/watch?v=PHhYVAzddxI">2. কিভাবে একটি Item এর Measurement Edit করা যায়?</a></p>
					<p><a target="_blank" href="https://www.youtube.com/watch?v=6yyg-k5SWAY">3. কিভাবে Customer এর মোবাইল নম্বর দিয়ে অর্ডার নম্বর খুঁজে পাওয়া যায়?</a></p>
					<p><a target="_blank" href="https://www.youtube.com/watch?v=4oqSW_9mp8Q">4. কিভাবে শুধু ফ্যাব্রিক্স Sale এর হিসাব রাখা যায়?</a></p>
					<p><a target="_blank" href="https://www.youtube.com/watch?v=JmJ_JNcg1bM&t=58s">5. কিভাবে কোনো একটি অর্ডার এর Item গুলি Making হওয়ার সাথে সাথেই কাস্টমার কে <b>SMS</b> এর মাধ্যমে Notify করতে পারবেন?</a></p>
					<p><a target="_blank" href="https://www.youtube.com/watch?v=_7iuZH0n03g">6. কোনো একটি অর্ডার কিভাবে সফটওয়্যার থেকে ডেলিভারি দেওয়া যায়?</a></p>
					
				
			</div>
	  </div>
    </div>
	
	</div>
</div>


  
  
  <script>
	
</script>

<style>
.chkbox{
	 -ms-transform: scale(2); /* IE */
  -moz-transform: scale(2); /* FF */
  -webkit-transform: scale(2); /* Safari and Chrome */
  -o-transform: scale(2); /* Opera */
  transform: scale(2);
  padding: 10px;
}

.checkboxtext
{
  /* Checkbox text */
  font-size: 120%;
  display: inline;
  padding-left: 6px;
  padding-right: 40px;
}
#tblhight{
			overflow-y: scroll;
		overflow-x: hidden;
</style>

