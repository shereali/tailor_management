

<?php 

	include'db.php';
  
	$com_id=$_SESSION['COM_ID'];
	
	@$textsql=$conn->query("select * from set_text where com_id=$com_id order by id desc limit 0,15");
?>


  <div class="panel-group">
   <div class="panel panel-info">
      <div class="panel-heading">Set Text For SMS</div>
      <div class="panel-body">
		
				
			<div class="form-group">
			  <label for="comment">Message(English/Bangla):</label>
			  <textarea class="form-control" rows="5" name="txt_sms" id="txt_sms" required></textarea>
			</div>
			
			<button onclick="setSms();" name="btn" value="sub" class="btn btn-success">Set</button>
			<span id="sms"></span><br/><br/>
			
			<div id="setpanel">
			<?php 
				$m=1;
				while($row=mysqli_fetch_array($textsql)){
					if($row['is_active']==1){
					?>
					<div class="panel panel-success">
					  <div class="panel-heading"><?php echo $m++; ?></div>
					  <div class="panel-body"><?php echo $row['sms_text']; ?></div>
					  
					   <a href="javascript:void(0)" style="margin:15px" class="btn btn-success">Active</a>
					  
					</div>
					<?php 
					}else{
						?>
						<div class="panel panel-warning">
						  <div class="panel-heading"><?php echo $m++; ?></div>
						  <div class="panel-body"><?php echo $row['sms_text']; ?></div>
						   <a href="javascript:void(0)" onclick="activeInactive('<?php echo $row['id']; ?>','1')" style="margin:15px" class="btn btn-warning">In Active</a>
						</div>
					<?php 
					}
				}
				?>
			</div>
	  </div>
    </div>

  </div>
  
  <script>
	
	function setSms(){
		var txt_sms=$("#txt_sms").val();
		
		var t="",m="";
		if(txt_sms==""){
			$("#txt_sms").css("border-color","red");
			t=1;
		}else{
			$("#txt_sms").css("border-color","#CCCCCC");
		}
		
		if(t==1){
			exit();
		}else{
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						txt_sms: txt_sms,set_btn:1
					},
					 beforeSend: function () {
						$("#sms").show();
						$("#sms").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response==20000000){
							$("#sms").html("Invalid Text SMS!").css("color","red");
						}else{
						$("#sms").html("Set Success!").css("color","green");
						$("#txt_sms").val(null);
						$("#setpanel").html(response);
						
						}
					 }
			});
		}
		
	}
	
	
	function activeInactive(id,acinac){
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						text_id: id,acinac:acinac,activeInactive:1
					},
					 beforeSend: function () {
						$("#sms").show();
						$("#sms").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response==20000000){
							$("#sms").html("SMS Text Set Invalid!").css("color","red");
						}else{
						$("#sms").html("Set Success!").css("color","green");
						$("#txt_sms").val(null);
						$("#setpanel").html(response);
						
						}
					 }
			});
	}
	
	
	
</script>
