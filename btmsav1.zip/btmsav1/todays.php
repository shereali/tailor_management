
<?php 

	$com_id=$_SESSION['COM_ID'];
	$branch_id=$_SESSION['BRANCH_ID'];
	if(isset($branch_id)){
		$ex=explode("_",$branch_id);
		$com_id=implode(",",$ex);
	}
	$date=date("Y-m-d");
	//echo "SELECT count(ds.id) torder,(select com_name from company where id=ds.com_id) com_name FROM `dsms` ds WHERE ds.`is_active`=1 and ds.`occasion`=0 and ds.`phy_dv_date` is null and date(ds.`insert_date`)='$date' and ds.com_id in ($com_id) GROUP by ds.com_id";
	$todays=$conn->query("SELECT count(ord.order_number) torder,(select com_name from company where id=ds.com_id) com_name FROM `dsms` ds, order_record ord WHERE ds.id=ord.dsms_id and ds.`is_active`=1 and ord.is_active=1 and ds.`occasion`=0 and date(ds.`insert_date`)='$date' and ds.com_id in ($com_id) GROUP by ds.com_id");
	mysqli_close($conn);
	if(mysqli_num_rows($todays)>0){
	
?>

<ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">Order</a></li>
    <li><a data-toggle="tab" onclick="getTodaysDelivery();" href="#menu1">Delivery</a></li>
</ul>

<div class="tab-content">
    <div id="home" class="tab-pane fade in active">
	<br/>
		<div class="panel-group">
			<div class="panel panel-info">
			  <div class="panel-heading">Todays</div>
				<div class="panel-body">
				
				<table id="example" class="table table-striped table-bordered" style="width:100%">
				<thead>
					<tr>
						<th>SL</th>
						<th>Branch Name</th>
						<th>Order Qty</th>
					</tr>
				</thead>
				<tbody id="pbodytbl">
					<?php
						$i=1;
					$sum=0;	
				while($row=mysqli_fetch_array($todays)){
					$j=$i++;
					$sum+=$row['torder'];	
					?>
					<tr>
						<td style="width:15%">
							<b><?php echo $j; ?></b>
						</td>
						<td><b><?php 
							echo $row['com_name'];
						?></b>
						</td>
						<td><b><?php 
							echo $row['torder'];
						?></b>
						</td>
					
					</tr>
						<?php 
						
						} ?>
						<tr>
						<td colspan="2" style="text-align:right">Total Order</td>
						<td><b><?php echo $sum; ?></b></td>
						</tr>
					
				</tbody>
			</table>
					
				</div>
			</div>
		</div>
	</div>
	 <div id="menu1" class="tab-pane fade">
      <br/>
    <span id="summery_report"></span>
	 
    </div>
	
</div>


  
  
  <script>

	
	function getTodaysDelivery(){
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						getTodaysDelivery:1
					},
					 beforeSend: function () {
						$("#summery_report").show();
						$("#summery_report").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response==1){
							$("#summery_report").html("No result found!").css("color","red");
						}else{
							$("#summery_report").html(response).css("color","black");;
						}
					}
		});
	}
	

	
</script>

<style>
.chkbox{
	 -ms-transform: scale(2); /* IE */
  -moz-transform: scale(2); /* FF */
  -webkit-transform: scale(2); /* Safari and Chrome */
  -o-transform: scale(2); /* Opera */
  transform: scale(2);
  padding: 10px;
}

.checkboxtext
{
  /* Checkbox text */
  font-size: 120%;
  display: inline;
  padding-left: 6px;
  padding-right: 40px;
}
</style>

<?php
	}else{
		echo "No Result Found!";
	}
?>
