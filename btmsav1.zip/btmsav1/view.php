

<?php 
function getcomname($com_id){
	include 'db.php';
	$get_name_usql=$conn->query("select com_name from company where id=$com_id");
	$get_name=mysqli_fetch_array($get_name_usql);
	return $get_name['com_name'];
}
	$usql=$conn->query("select c.id,c.email,c.com_name,c.com_head_id,(select rem_sms from rem_sms where com_id=c.id) sms_qty,(select CONCAT(user_name,'(',mobile,')#sep#',log_user,'#sep#',pass) from user where com_id=c.id order by id asc limit 0,1) user_name,
		(select purchase_sms_qty from purchase_sms where com_id=c.id order by id desc limit 0,1) last_purchase from company c where c.is_active=1");
	mysqli_close($conn);
?>

  <div class="panel-group">
   <div class="panel panel-info">
      <div class="panel-heading">User List</div>
      <div class="panel-body">
		<table class="table table-bordered">
    <thead>
		<?php
		$i=1;
			if(mysqli_num_rows($usql)>0){
				while($row=mysqli_fetch_array($usql)){
					if($row['id']==1){
					$ex=array("Atompac(01311240085)","*****","*****");
					}else{
						$ex=explode("#sep#",$row['user_name']);
					}
		?>
      <tr>
        <td>
		<?php echo $i++."<br/>"; ?>
		<?php echo ($row['com_head_id']!=0)? "<b/>".getcomname($row['com_head_id'])."</b><br/>":"<b/>".$row['com_name']."</b><br/>"; ?>
		<?php 
			if($row['com_head_id']!=0){
				echo "(".$row['com_name'].")<br/>"; 
			}
		
		?>
		<?php echo @$ex[0]."<br/>"; ?>
		<?php echo ($row['email']!="")? "Email: ".$row['email']."<br/>" : "Email: ------"."<br/>"; ?>
		<?php echo "Login User: ".@$ex[1]." , Password: ".@$ex[2]."<br/>"; ?>
		<?php echo "Last Purchase: ".@$row['last_purchase']." Sms<br/>"; ?>
		<?php echo "Blance: ".@$row['sms_qty']." Sms"; ?>
		</td>
        
      </tr>
				<?php } } ?>
    </thead>
   
  </table>
	  </div>
    </div>

  </div>

