
<?php 
	if(isset($_SESSION['COM_ID'])){
		date_default_timezone_set("Asia/Dhaka");
	$dates=date("Y-m-d");
		$com_id=$_SESSION['COM_ID'];
		$expense=$conn->query("select * from expense_type where is_active=1");
		$expenses=$conn->query("select * from expense_type where is_active=1");
	$expense_detail=$conn->query("select ex.id,ex.expense_type,ex.expense,ex.remarks,(select expense from expense_type where id=ex.expense_type) ex_title,ex.insert_date from expenses ex where ex.is_active=1 and date(ex.insert_date)='$dates'");
		mysqli_close($conn);		
?>

<ul class="nav nav-tabs" style="display: none;">
	
    <li class="active"><a style="font-weight: bold;font-size: 16px;" data-toggle="tab" href="#home">Customer</a></li>
	
</ul>

<div class="tab-content" id="tabs">
    <div id="home" class="tab-pane fade in active">
	<br/>
     
	<div class="panel-group">
		 <div id="show_history">
	  
		   <div class='panel panel-info' style="color: black; box-shadow: inset 0 0 1em gray; padding: 15px;margin-left: 0px;margin-right: 0px;">
			  <div class="panel-heading">
			  <div style="overflow:hidden">
				<input type="text" onchange="getExpenseList('kstart_date');" style="width: 18%;float: left; margin-right: 5px;font-weight: bold;font-size:18px;" autocomplete="off" placeholder="Start Date" id="kstart_date" class="form-control" />	
				<input type="text" onchange="getExpenseList('kend_date');" style="width: 18%;float: left; margin-right: 5px;font-weight: bold;font-size:18px;" autocomplete="off" placeholder="End Date" id="kend_date" class="form-control" />	
										
				<select class="form-control" id="searching_status" onchange="getExpenseList('searching_status');" style="width: 18%;color:red;float:left">
					<option value="">All</option>
					<?php
						while($row=mysqli_fetch_array($expense)){
					?>
						<option value="<?php echo $row['id']."#sep#".$row['expense']; ?>"><?php echo $row['expense']; ?></option>
					<?php } ?>
									
				</select>
				<span style="float: right;font-size: 22px;">এক্সপেন্স প্যানেল</span>
				</div>
			  </div>
			 
			  <div class="panel-body">
					<div class="row">
						<div class="col-xs-12 col-sm-4">
							<label for="comment">ব্যয়ের ধরণ</label>
								<select id="expense_type" class="form-control">
								<option value="">Select One</option>
								<?php
									while($row=mysqli_fetch_array($expenses)){
								?>
									<option value="<?php echo $row['id']."#sep#".$row['expense']; ?>"><?php echo $row['expense']; ?></option>
								<?php } ?>
									
								</select>
									<label for="comment">ব্যয়(টাকা)</label>
									<input type="text" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" autocomplete="off" name="" id="expense_tk" required/>
								
									<label for="comment">মন্তব্য</label>
									<input type="text"  class="form-control"  style="font-weight: bold;font-size:18px;font-style: italic;color: blue;" autocomplete="off" name="remarks" id="remarks" required/>
								<button onclick="saveExpense();" style="margin-top: 12px;margin-right:5px" name="btn" value="sub" id="save_expense" class="btn btn-success">Save</button>
								<span id="expense_sms"></span>
						</div>
						<div class="col-xs-12 col-sm-8" id="searching_expense">
						
						<table id="dynamic-table" class="table table-striped table-bordered table-hover">
								<thead>
									<tr>
										<th style="width: 16%;">ক্রমিক নং</th>
										<th style="text-align:center;width: 20%;">তারিখ</th>
										<th style="">ব্যয়ের ধরণ</th>
										<th style="">মন্তব্য</th>
										<th style="text-align:right">টাকা</th>
									</tr>
								</thead>
							
								<tbody id="searching_tbl">
									<?php 
										$sl=0;$i=1;$tot=0;
										if(mysqli_num_rows($expense_detail)>0){
											while($row=mysqli_fetch_array($expense_detail)){
												$sl=$i++;
												$tbl_id=$row['id'];
												$tot+=$row['expense'];
												?>
												<tr id="delrow<?php echo $tbl_id; ?>">
												<td>
												<button onclick="delExpense('<?php echo $tbl_id; ?>','<?php echo $sl; ?>')" class="btn btn-danger form-control" id="delExbtn<?php echo $sl; ?>"><?php echo $sl; ?></button>
												</td>
												<td style="text-align:center"><?php echo $row['insert_date']; ?></td>
												<td><?php echo $row['ex_title']; ?></td>
												<td><?php echo $row['remarks']; ?></td>
												<td style="text-align:right"><?php echo $row['expense'] ?></td>
												</tr>
												<?php 
											}
										}
									?>
									<tr style="font-weight: bold;">
										<td colspan="4" style="text-align:right">Total</td>
										<td style="text-align:right"><?php echo $tot; ?></td>
									</tr>
								</tbody>
								<input type="hidden" id="ex_last_id" value="<?php echo $sl; ?>"/>
							
						</table>
							<div id="expense_not_found"></div>
						</div>	
				
					</div>
					
			  </div>
			 
		   </div>
		
	   </div>	
	</div>
</div>

	 <div id="menu1" class="tab-pane">
       <br/>
	
   </div>
 
	<div id="menu2" class="tab-pane">
     <br/>
		
    </div>
	
</div>

 <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg" id="modal_width">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" id="heading_id"></h4>
        </div>
        <div class="modal-body">
          <span id="smeasurement"></span>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  
  <script>
  
  $(function() {
		$( "#attenstart_date,#attenend_date,#attendance_date,#mstart_date,#kstart_date,#kend_date,#rstart_date,#rend_date,#pstart_date,#pend_date" ).datepicker({
			dateFormat: 'dd/mm/yy' 
		});
		$("#mend_date" ).datepicker({
			dateFormat: 'dd/mm/yy' 
		});
		
		
	});
	
$(document).ready(function(){
		$(".select2").select2();
		$("#head_measurement,#edit_measurement").hide();
});

function saveExpense(){
		var expense_type=$("#expense_type").val();
		var expense_tk=$("#expense_tk").val();
		var remarks=$("#remarks").val();
		var ex_last_id=$("#ex_last_id").val();
		var ex="",tk="";
		if(expense_type==""){
			$("#expense_type").css("border-color","red");
			ex=1;
		}else{
			$("#expense_type").css("border-color","#CCCCCC");
		}
		if(expense_tk==""){
			$("#expense_tk").css("border-color","red");
			tk=1;
		}else{
			$("#expense_tk").css("border-color","#CCCCCC");
		}
		if(ex==1 || tk==1){ //m==1 || 
			exit();
		}else{
			
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						expense_type:expense_type,
						expense_tk:expense_tk,
						remarks:remarks,
						ex_last_id:ex_last_id,
						saveExpense:1
					},
					 beforeSend: function () {
						$("#expense_sms").show();
						$("#expense_sms").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						 if(response==2){
							 $("#expense_sms").html('Warning! Not Success.').css("border-color","red");
						 }else{
							 $("#expense_sms").html(null);
							 $("#searching_tbl").append(response);
							 $("#ex_last_id").val(parseInt(ex_last_id)+1);
							 $("#expense_tk").val(null);
							$("#remarks").val(null);
						 }
						 
					 }
			});
		}
		
	}
	
	function delExpense(tbl_id,auto_inc){
	    if(confirm("Do you want to delete it?")){
			//var tbl_last_id=$("#tbl_last_id").val();
			document.getElementById("delExbtn"+auto_inc).disabled = true;
			$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					tbl_id:tbl_id,
					delExpense:1
				},
				 success: function (response) {
					console.log(response);
					if(response==1){
						document.getElementById("delExbtn"+auto_inc).disabled = true;
					}else{
						document.getElementById("delExbtn"+auto_inc).disabled = false;
					}
				}
			});
		}
  }
  
  function getExpenseList(searh_status){
	var kstart_date=$("#kstart_date").val();
	var kend_date=$("#kend_date").val();
	var searching_status=$("#searching_status").val();
	
	$.ajax({
		type: 'post',
		url: 'sql.php',
		data: {
			kstart_date: kstart_date,
			kend_date: kend_date,
			searching_status: searching_status,
			getExpenseList:1
		},
		 beforeSend: function () {
			$("#searching_expense").html('Wait..');
		},
		 success: function (response) {
			console.log(response);
			$("#searching_expense").html(response);
		 }
	});
}
	
	
</script>

<style>
.chkbox{
	 -ms-transform: scale(2); /* IE */
  -moz-transform: scale(2); /* FF */
  -webkit-transform: scale(2); /* Safari and Chrome */
  -o-transform: scale(2); /* Opera */
  transform: scale(2);
  padding: 10px;
}

.checkboxtext
{
  /* Checkbox text */
  font-size: 120%;
  display: inline;
  padding-left: 6px;
  padding-right: 40px;
}
#tblhight{
			overflow-y: scroll;
		overflow-x: hidden;
</style>

<?php
	}else{
		header("location:index.php?id=1");
	}
?>
