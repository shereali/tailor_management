<?php
session_start();
ob_start();
include'library.php';
if(isset($_REQUEST['send_email'])){
		if(check_internet_connection()==1){
			if(sendEmail(generateMail($_REQUEST['order_sql'],$_REQUEST['order_del'],$_REQUEST['receivable_list'],$_REQUEST['direct_sale'],$_REQUEST['expense'],$_SESSION['COM'],$_SESSION['COM_ADDRESS'],$_SESSION['COM_MOBILE']))=='1'){
				echo 1; // mail send success
			}else{
				echo 3;
				}
		}else{
			echo 2; // internet problem
		}
	}

function sendEmail($mail_body){
	date_default_timezone_set("Asia/Dhaka");
	$cdate=date('d/m/Y');
	require 'phpmailer/PHPMailerAutoload.php';
	$mail=new PHPMailer;
	$mail->isSMTP();
	$mail->Host='smtp.gmail.com';
	$mail->Port=587;
	$mail->SMTPAuth=true;
	$mail->SMTPSecure='tls';
	$mail->Username='atompac2020@gmail.com';
	$mail->Password='atompac2020!@';
	$mail->setFrom('atompac2020@gmail.com','Daily Report-'.$cdate);
	$mail->addAddress($_SESSION['EMAIL']);
	$mail->addReplyTo($_SESSION['EMAIL']);
	$mail->isHTML(true);
	$mail->Subject='Daily Report';
	$mail->Body=$mail_body;
	if(!$mail->send()){
		return 2;
	}else{
		return 1;
	}
}
?>