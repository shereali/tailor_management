<?php 
session_start();
ob_start();
include'library.php';
ini_set('max_execution_time', 600); //300 seconds = 5
if(isset($_SESSION['USER']) && isset($_SESSION['COM'])){
	include'db.php';
   date_default_timezone_set("Asia/Dhaka");
	
	if(isset($_REQUEST['btn'])){ 
		$txt_sms=$_REQUEST['txt_sms'];
		$cus_dv_date=$date1=$_REQUEST['date1'];
		$chkAuthUserid=$_REQUEST['chkAuthUser'];
		$previous_due=$_REQUEST['previous_due'];
		$total_due=$_REQUEST['total_due'];
		$design_charge=$_REQUEST['design_charge'];
		$others_tk=$_REQUEST['others_tk']; //others tk
		$discount_tk=$_REQUEST['discount_tk']; //overall discount tk
		$due_tk=$_REQUEST['due_tk'];
		$all_groupnamea=$_REQUEST['all_groupnamea'];
		$order_type=$_REQUEST['order_type'];
		$taginc=$_REQUEST['tag'];
		$payment_type=$_REQUEST['payment_type'];
		$total_tk=$_REQUEST['total_tk'];
		$discount=$_REQUEST['discount']; //overall discount
		$all_itemqtya=$_REQUEST['all_itemqtya'];
		$all_itema=$_REQUEST['all_itema'];
		@$karigor_dv_date=$_REQUEST['urdate'];
		@$urtime=$_REQUEST['urtime'];
		@$ref_user_id=$_REQUEST['ref_user_id'];
		@$old_order_status=$_SESSION['OLD_ORDER_STATUS'];
		$cus_name=trim(str_replace("'", "",$_REQUEST['cus_name']));
		$hidden_cus_name=trim(str_replace("'", "",$_REQUEST['hidden_cus_name']));
		
		$get_mobile=trim($_REQUEST['mobile']);
		if($cus_name!=$hidden_cus_name){ // if customer is edited
			$conn->query("update dsms set cus_name='$cus_name' where cus_mobile='$get_mobile'");
			$conn->query("update customer set cus_name='$cus_name' where cus_mobile='$get_mobile'");
		}
		
		$status=2; // stock out status 
		if($_REQUEST['advance_tk']==""){
			$advance_tk=0;
		}else{
			$advance_tk=$_REQUEST['advance_tk'];
		}
		
		if($_REQUEST['tblid']>0){
			if(isset($_REQUEST['all_fitempricea'])){
				$all_fitempricea=$_REQUEST['all_fitempricea'];
				$all_fitemqtya=$_REQUEST['all_fitemqtya'];
				$all_item_idca=$_REQUEST['all_item_idca'];
				$ex_all_itema=explode("#sep#",$all_itema);
				$ex_all_item_idca=explode("#sep#",$all_item_idca);
				$ex_all_fitemqtya=explode("#sep#",$all_fitemqtya);
				$ex_all_fitempricea=explode("#sep#",$all_fitempricea);
				$ex_present_stocka=explode("#sep#",$_REQUEST['all_stock']);
				$ex_avg_pricea=explode("#sep#",$_REQUEST['all_avg_price']);
				
				$all_items=implode(',',$ex_all_itema);
				
				$fab_total=$_REQUEST['fab_total']; 
				$fabrics_discount_tk=$_REQUEST['fabrics_discount_tk']; 
				$febdis=$_REQUEST['febdis']; // fabrics discount
				$sub_tot_f_val=$_REQUEST['sub_tot_f_val']; 
				if($total_tk>0 || $total_tk!=""){
					$ta_and_fab=$total_tk=$_REQUEST['ta_and_fab'];  // grant total tk
					$advance_tk=$advance_tk;
					$discount=0;
				}
				
			}
			
		}else{
			$ta_and_fab=0;
			$febdis=0;
			$total_tk=$_REQUEST['ta_and_fab']; // grant total tk
		}
		
		if(isset($date1)){
			$ex=explode("/",$date1);
			$date1=$ex[2]."-".$ex[1]."-".$ex[0];
			if($karigor_dv_date==""){
				@$set_fac_dv=$_SESSION['FAC_DELIVERY'];
				@$karigor_dv_date=date('Y-m-d', strtotime($date1. " - $set_fac_dv days"));
				$ex2=explode("-",$karigor_dv_date);
				$karigor_dv_date=$ex2[2]."/".$ex2[1]."/".$ex2[0];
			}else{
				@$karigor_dv_date=$karigor_dv_date;
			}
			$cus_order_date=date("d/m/Y");
		}
		
		$com_id=($_SESSION['COM_ID']);
		$com_name=($_SESSION['COM']);
		$com_address=($_SESSION['COM_ADDRESS']);
		$user_id=($_SESSION['USER_ID']);
		$year=date("Y");
		$tag="";
		if($_SESSION['SOFT_TYPE']==1 && $_SESSION['SVERSION']!=2){ //For online software
			$chk_com=$conn->query("select c.id,tt.order_number from company c,order_num tt where c.id=tt.com_id and c.is_active=1 and c.id=$com_id");
			if(mysqli_num_rows($chk_com)>0){
				
					$remsql=$conn->query("select rem_sms from rem_sms where com_id=$com_id");
					$rrow=mysqli_fetch_array($remsql);
					$rem_sms_hidden=$rrow['rem_sms'];
					if($rem_sms_hidden>0){
					
					if($_SESSION['SVERSION']==0){ //0=courrent copy,1=old copy
						$tag_ex=explode("#sep#",getOrderNumber($com_id));
						$update_tag=$tag_ex[1];
						$tag="A".$tag_ex[0];
					}else{
						$tag=getOrderNumber($com_id);
					}
				
				
				$mobile=explode(",",trim($_REQUEST['mobile']));
				if(($rem_sms_hidden-count($mobile))>=0){
					@$rem_sms=$rem_sms_hidden-count($mobile);
					$gettxtsql=$conn->query("select * from set_text where is_active=1 and com_id=$com_id");
					if(mysqli_num_rows($gettxtsql)>0){
						$txtrow=mysqli_fetch_array($gettxtsql);
						$txt_sms=$txtrow['sms_text']."\n".$com_name."\n".$com_address;
					}
					
					
					
					@$text=$conn->query("insert into dsms(txt_sms,com_id,dv_date,order_type,tagnum,insert_by,phy_ord_num,amount,cus_name,cus_mobile,year,discount,paymentType,tai_and_fab_tk,fdtime,fddate,old_order_status,design_cost,others_tk,previous_total_due) values('$txt_sms','$com_id','$date1',$order_type,'$tag','$user_id','$tag','$total_tk','$cus_name','$get_mobile','$year','$discount_tk','$payment_type','$ta_and_fab','$urtime','$karigor_dv_date',$old_order_status,'$design_charge','$others_tk','$previous_due')");
					if($text){
						@$top_id = $conn->insert_id;
						
						$conn->query("insert into accounting(dsms_id,com_id,amount,insert_by,pay_status) values($top_id,$com_id,'$advance_tk',$user_id,1)");
						
						$conn->query("update order_record set is_active=1,dsms_id=$top_id,order_number='$tag' where com_id=$com_id and is_active=0 and dsms_id IS NULL");
						$conn->query("update emp_salary set is_active=1,dsms_id=$top_id where com_id=$com_id and is_active=0 and dsms_id IS NULL");
						$conn->query("update order_details set is_active=1 where com_id=$com_id and is_active=0");
						$conn->query("update rem_sms set rem_sms=$rem_sms where com_id=$com_id");
						if($_REQUEST['tblid']>0){
								$direct_sale_head=$conn->query("insert into direct_sale_head(com_id,f_total,cus_mobile,insert_by) values($com_id,'$fab_total','$get_mobile',$user_id)");
								if($direct_sale_head){
									@$direct_sale_head_top_id = $conn->insert_id;
									
									for($di=0;$di<count($ex_all_item_idca); $di++){
										$item_id=$ex_all_item_idca[$di];
										$item_qtys=$ex_all_fitemqtya[$di];
										$item_price=$ex_all_fitempricea[$di];
										
										if($_SESSION['IS_STOCK']==1){ // maintain stock 
											$previous_stock_qty=$ex_present_stocka[$di];
											$avg_price=$ex_avg_pricea[$di];
											$selling_qty=$item_qtys;
											$conn->query("insert into direct_sale(dstid,com_id,item_id,item_qty,price,purchase_price,insert_by,order_number) values($direct_sale_head_top_id,$com_id,$item_id,$item_qtys,'$item_price','$avg_price',$user_id,'$tag')");
											$return_data=updateStockTbl($item_id,$selling_qty,$avg_price,$previous_stock_qty,'',$status);
										}else{
											$conn->query("insert into direct_sale(dstid,com_id,item_id,item_qty,price,insert_by,order_number) values($direct_sale_head_top_id,$com_id,$item_id,$item_qtys,'$item_price',$user_id,'$tag')");
										}
									}
								}

						
						}
						if($chkAuthUserid==""){
						$conn->query("insert into customer(cus_name,cus_mobile,cus_address,com_id) values('$cus_name','$get_mobile','',$com_id)");
						@$chkAuthUserid = $conn->insert_id;
						$conn->query("insert into update_due(cus_id,com_id,last_due) values($chkAuthUserid,$com_id,0)");
						}
						if($_REQUEST['tblid']>0){ //making with fabrics
							$remarks1="ফ্যাব্রিক্স কেনা এবং ড্রেস মেকিং বাবদ";
							$remarks2="ফ্যাব্রিক্স কেনা এবং ড্রেস মেকিং বাবদ বাকি পরিশোধ";
							dueTblUpdate($chkAuthUserid,$total_tk,0,$remarks1,'0'); // due
							dueTblUpdate($chkAuthUserid,$advance_tk,1,$remarks2,'0'); // advance
						}else{ // only making
							$remarks1="ড্রেস মেকিং বাবদ";
							$remarks2="ড্রেস মেকিং বাবদ বাকি পরিশোধ";
							dueTblUpdate($chkAuthUserid,$total_tk,0,$remarks1,'0'); // due
							dueTblUpdate($chkAuthUserid,$advance_tk,1,$remarks2,'0'); // advance
						}
						if($taginc==1){
							if($_SESSION['SVERSION']==0){ //0=courrent copy,1=old copy
								$taginc=intval($update_tag)+1;
								$conn->query("update order_num set order_number=$taginc where com_id=$com_id");
							}
						}
						mysqli_close($conn);
						echo @$rem_sms."#sep#".$cus_order_date."#sep#".$karigor_dv_date." ".$urtime."#sep#".getCustomerRecept($tag,$cus_dv_date,$cus_order_date,$get_mobile,$total_tk,$advance_tk,$cus_name,$all_itemqtya,$all_itema,$discount);
					}else{
						echo 20000000;
					}
				}else{
					echo 10000000;
				}
			}else{
				echo 40000000;
			}
			}else{
				echo 30000000;
			}
		}
		
		if($_SESSION['SOFT_TYPE']==2 && $_SESSION['SVERSION']!=2){ //For offline software
			$chk_com=$conn->query("select c.id,tt.order_number from company c,order_num tt where c.id=tt.com_id and c.is_active=1 and c.id=$com_id");
			if(mysqli_num_rows($chk_com)>0){
				if($_SESSION['SVERSION']==0){ //0=courrent copy,1=old copy
					$tag_ex=explode("#sep#",getOrderNumber($com_id));
					$update_tag=$tag_ex[1];
					$tag="A".$tag_ex[0];
				}else{
					$tag=getOrderNumber($com_id);
				}
				
					//$get_mobile=trim($_REQUEST['mobile']);
					$gettxtsql=$conn->query("select * from set_text where is_active=1 and com_id=$com_id");
					$txt_sms="";
					if(mysqli_num_rows($gettxtsql)>0){
						$txtrow=mysqli_fetch_array($gettxtsql);
						$txt_sms=$txtrow['sms_text']."\n".$com_name."\n".$com_address;
					}
					
					
					
					@$text=$conn->query("insert into dsms(com_id,dv_date,order_type,tagnum,insert_by,phy_ord_num,amount,cus_name,cus_mobile,year,discount,paymentType,tai_and_fab_tk,fdtime,fddate,old_order_status,design_cost,others_tk,previous_total_due) values('$com_id','$date1',$order_type,'$tag','$user_id','$tag','$total_tk','$cus_name','$get_mobile','$year','$discount_tk','$payment_type','$ta_and_fab','$urtime','$karigor_dv_date',$old_order_status,'$design_charge','$others_tk','$previous_due')");
					if($text){
						@$top_id = $conn->insert_id;
						
						$conn->query("insert into accounting(dsms_id,com_id,amount,insert_by,pay_status,payment_type) values($top_id,$com_id,'$advance_tk',$user_id,1,'$payment_type')");
						
						$conn->query("update order_record set is_active=1,dsms_id=$top_id,order_number='$tag' where com_id=$com_id and is_active=0 and dsms_id IS NULL");
						$conn->query("update emp_salary set is_active=1,dsms_id=$top_id where com_id=$com_id and is_active=0 and dsms_id IS NULL");
						$conn->query("update order_details set is_active=1 where com_id=$com_id and is_active=0");
						if($_REQUEST['tblid']>0){
							$direct_sale_head=$conn->query("insert into direct_sale_head(com_id,f_total,cus_mobile,insert_by,is_order,total_receive) values($com_id,'$fab_total','$get_mobile',$user_id,1,'$advance_tk')");
								if($direct_sale_head){
									@$direct_sale_head_top_id = $conn->insert_id;
									for($di=0;$di<count($ex_all_item_idca); $di++){
										$item_id=$ex_all_item_idca[$di];
										$item_qtys=$ex_all_fitemqtya[$di];
										$item_price=$ex_all_fitempricea[$di];
										
										if($_SESSION['IS_STOCK']==1){ // maintain stock 
											$previous_stock_qty=$ex_present_stocka[$di];
											$avg_price=$ex_avg_pricea[$di];
											$selling_qty=$item_qtys;
											$conn->query("insert into direct_sale(dstid,com_id,item_id,item_qty,price,purchase_price,insert_by,order_number) values($direct_sale_head_top_id,$com_id,$item_id,$item_qtys,'$item_price','$avg_price',$user_id,'$tag')");
											$return_data=updateStockTbl($item_id,$selling_qty,$avg_price,$previous_stock_qty,'',$status);
										}else{
											$conn->query("insert into direct_sale(dstid,com_id,item_id,item_qty,price,insert_by,order_number) values($direct_sale_head_top_id,$com_id,$item_id,'$item_qtys','$item_price',$user_id,'$tag')");
										}
									}
								}
						}
						
						if($chkAuthUserid==""){
						$conn->query("insert into customer(cus_name,cus_mobile,cus_address,com_id) values('$cus_name','$get_mobile','',$com_id)");
						@$chkAuthUserid = $conn->insert_id;
						$conn->query("insert into update_due(cus_id,com_id,last_due) values($chkAuthUserid,$com_id,0)");
						}
						if($_SESSION['ACTIVE_REFERENCE']==1){ // Reference id
							if($ref_user_id!=""){
								$earn_point=round(($total_tk*$_SESSION['REFERENCE_AMOUNT'])/100);
								$conn->query("insert into point_tbl(cus_id,com_id,point) values($ref_user_id,$com_id,'$earn_point')");
							}
							
							if($_REQUEST['ref_point_check']==1){
								@$deduct_point=$_REQUEST['earn_point'];
								$conn->query("insert into point_tbl(cus_id,com_id,point) values($chkAuthUserid,$com_id,'-$deduct_point')");
							}
						}
						if($_REQUEST['tblid']>0){ //making with fabrics
							
							$remarks1="ফ্যাব্রিক্স কেনা এবং ড্রেস মেকিং বাবদ | $all_items";
							$remarks2="ফ্যাব্রিক্স কেনা এবং ড্রেস মেকিং বাবদ বাকি পরিশোধ | $all_items |-$payment_type";
							dueTblUpdate($chkAuthUserid,$total_tk,0,$remarks1,'0'); // due
							dueTblUpdate($chkAuthUserid,$advance_tk,1,$remarks2,'0'); // advance
						}else{ // only making
							$remarks1="ড্রেস মেকিং বাবদ";
							$remarks2="ড্রেস মেকিং বাবদ বাকি পরিশোধ-$payment_type";
							dueTblUpdate($chkAuthUserid,$total_tk,0,$remarks1,'0'); // due
							dueTblUpdate($chkAuthUserid,$advance_tk,1,$remarks2,'0'); // advance
						}
						
						$transaction_last_id=$conn->query("SELECT id FROM `transaction` mh WHERE mh.is_active=1 order by mh.id desc limit 0,1"); // and mh.com_id=$com_id
						$transaction_last_id_row=mysqli_fetch_array($transaction_last_id);
						$transaction_tbl_id=$transaction_last_id_row['id'];
						$conn->query("update transaction set accounting_id=$top_id where id=$transaction_tbl_id");
						$conn->query("update transaction set accounting_id=$top_id where id=($transaction_tbl_id-1)");
						
						if($taginc==1){
							if($_SESSION['SVERSION']==0){ //0=courrent copy,1=old copy
								$taginc=intval($update_tag)+1;
								$conn->query("update order_num set order_number=$taginc where com_id=$com_id");
							}
						}
						mysqli_close($conn);
						if($order_live_sms==1){ // 1=means active order live smsm 
							if(check_internet_connection()==1){
								$response = file_get_contents($_SESSION['API']."api/data.php?com_id=$com_id&cus_mobile=$get_mobile&order_no=$tag&dv_date=$date1&chk=10"); //chk=2 means check sms
								$json = json_decode($response, true);
							}
						}
						//echo @$rem_sms."#sep#".$cus_order_date."#sep#".$karigor_dv_date." ".$urtime."#sep#".getCustomerRecept($tag,$cus_dv_date,$cus_order_date,$get_mobile,$total_tk,$advance_tk,$cus_name,$all_itemqtya,$all_itema,$discount);
						if($_SESSION['MEASURE_TYPE']==0){ //0= standard copy
							echo printMoneyReceipt($cus_name,$get_mobile,$total_tk,$discount_tk,$design_charge,$others_tk,$tag,$date1,$advance_tk,$previous_due,$karigor_dv_date);
						}else{ //1= local coppy, 2=normal copy
							echo printMoneyReceiptNormal($cus_name,$get_mobile,$total_tk,$discount_tk,$design_charge,$others_tk,$tag,$date1,$advance_tk,$previous_due,$karigor_dv_date);
						}
					}else{
						echo 20000000;
					}
				
			}else{
				echo 30000000;
			}
		}else if($_SESSION['SOFT_TYPE']==2 && $_SESSION['SVERSION']==2){ //merge order stutus
			//for merge order number
			$tag=$phy_ord_num=trim($_REQUEST['phy_ord_num']);
			$chk_com=$conn->query("select c.id,tt.order_number from company c,order_num tt where c.id=tt.com_id and c.is_active=1 and c.id=$com_id");
			if(mysqli_num_rows($chk_com)>0){
					//$get_mobile=trim($_REQUEST['mobile']);
					@$get_order_sql=$conn->query("select * from dsms where phy_ord_num='$phy_ord_num' and is_active=1 and com_id=$com_id");
					$rows=mysqli_fetch_array($get_order_sql);
						$top_id=$rows['id'];
						$amount=$rows['amount'];
						$discount=$rows['discount'];
						$design_cost=$rows['design_cost'];
						$tai_and_fab_tk=$rows['tai_and_fab_tk'];
						$others_tk_tbl=$rows['others_tk'];
						$total_tks=$total_tk+$amount;
						$discount_tk+=$discount;
						$ta_and_fab+=$tai_and_fab_tk;
						$design_charge+=$design_cost;
						$others_tk+=$others_tk_tbl;
					@$update_dsms=$conn->query("update dsms set amount='$total_tks',discount='$discount_tk',tai_and_fab_tk='$ta_and_fab',design_cost='$design_charge',others_tk='$others_tk' where is_active=1 and phy_ord_num='$phy_ord_num' and com_id=$com_id");
					if($update_dsms){
						
						$conn->query("insert into accounting(dsms_id,com_id,amount,insert_by,pay_status,payment_type) values($top_id,$com_id,'$advance_tk',$user_id,1,'$payment_type')");
						
						$conn->query("update order_record set is_active=1,dsms_id=$top_id,order_number='$tag' where com_id=$com_id and is_active=0 and dsms_id IS NULL");
						$conn->query("update emp_salary set is_active=1,dsms_id=$top_id where com_id=$com_id and is_active=0 and dsms_id IS NULL");
						$conn->query("update order_details set is_active=1 where com_id=$com_id and is_active=0");
						if($_REQUEST['tblid']>0){
							@$direct_sale_sql=$conn->query("select (select f_total from direct_sale_head where id=direct_sale.dstid) f_total,(select total_receive from direct_sale_head where id=direct_sale.dstid) total_receives,dstid  from direct_sale where order_number='$phy_ord_num' and is_active=1 and com_id=$com_id limit 0,1");
							if(mysqli_num_rows($direct_sale_sql)>0){
								$drows=mysqli_fetch_array($direct_sale_sql);
								$f_totals=$fab_total+$drows['f_total'];
								$total_receives=$advance_tk+$drows['total_receives'];
								$dstid=$drows['dstid'];
								$direct_sale_head=$conn->query("update direct_sale_head set f_total='$f_totals',total_receive='$total_receives' where com_id=$com_id and id=$dstid");
									if($advance_tk<=$fab_total){
										$only_fab_tk=$advance_tk;
									}else{
										$only_fab_tk=$fab_total;
									}
									$conn->query("insert into only_febrics_tk(ord_number,taka)values('$tag','$only_fab_tk')");
									
									if($direct_sale_head){
										@$direct_sale_head_top_id = $dstid;
										for($di=0;$di<count($ex_all_item_idca); $di++){
											$item_id=$ex_all_item_idca[$di];
											$item_qtys=$ex_all_fitemqtya[$di];
											$item_price=$ex_all_fitempricea[$di];
											
											if($_SESSION['IS_STOCK']==1){ // maintain stock 
												$previous_stock_qty=$ex_present_stocka[$di];
												$avg_price=$ex_avg_pricea[$di];
												$selling_qty=$item_qtys;
												$conn->query("insert into direct_sale(dstid,com_id,item_id,item_qty,price,purchase_price,insert_by,order_number) values($direct_sale_head_top_id,$com_id,$item_id,$item_qtys,'$item_price','$avg_price',$user_id,'$tag')");
												$return_data=updateStockTbl($item_id,$selling_qty,$avg_price,$previous_stock_qty,'',$status);
											}else{
												$conn->query("insert into direct_sale(dstid,com_id,item_id,item_qty,price,insert_by,order_number) values($direct_sale_head_top_id,$com_id,$item_id,'$item_qtys','$item_price',$user_id,'$tag')");
											}
										}
									}
							}else{
								$direct_sale_head=$conn->query("insert into direct_sale_head(com_id,f_total,cus_mobile,insert_by,is_order,total_receive) values($com_id,'$fab_total','$get_mobile',$user_id,1,'$advance_tk')");
								if($advance_tk<=$fab_total){
										$only_fab_tk=$advance_tk;
									}else{
										$only_fab_tk=$fab_total;
									}
									$conn->query("insert into only_febrics_tk(ord_number,taka)values('$tag','$only_fab_tk')");
								if($direct_sale_head){
									@$direct_sale_head_top_id = $conn->insert_id;
									for($di=0;$di<count($ex_all_item_idca); $di++){
										$item_id=$ex_all_item_idca[$di];
										$item_qtys=$ex_all_fitemqtya[$di];
										$item_price=$ex_all_fitempricea[$di];
										
										if($_SESSION['IS_STOCK']==1){ // maintain stock 
											$previous_stock_qty=$ex_present_stocka[$di];
											$avg_price=$ex_avg_pricea[$di];
											$selling_qty=$item_qtys;
											$conn->query("insert into direct_sale(dstid,com_id,item_id,item_qty,price,purchase_price,insert_by,order_number) values($direct_sale_head_top_id,$com_id,$item_id,$item_qtys,'$item_price','$avg_price',$user_id,'$tag')");
											$return_data=updateStockTbl($item_id,$selling_qty,$avg_price,$previous_stock_qty,'',$status);
										}else{
											$conn->query("insert into direct_sale(dstid,com_id,item_id,item_qty,price,insert_by,order_number) values($direct_sale_head_top_id,$com_id,$item_id,'$item_qtys','$item_price',$user_id,'$tag')");
										}
									}
								}
							}
						}
						
						if($chkAuthUserid==""){
						$conn->query("insert into customer(cus_name,cus_mobile,cus_address,com_id) values('$cus_name','$get_mobile','',$com_id)");
						@$chkAuthUserid = $conn->insert_id;
						$conn->query("insert into update_due(cus_id,com_id,last_due) values($chkAuthUserid,$com_id,0)");
						}
						if($_SESSION['ACTIVE_REFERENCE']==1){ // Reference id
							if($ref_user_id!=""){
								$earn_point=round(($total_tk*$_SESSION['REFERENCE_AMOUNT'])/100);
								$conn->query("insert into point_tbl(cus_id,com_id,point) values($ref_user_id,$com_id,'$earn_point')");
							}
							
							if($_REQUEST['ref_point_check']==1){
								@$deduct_point=$_REQUEST['earn_point'];
								$conn->query("insert into point_tbl(cus_id,com_id,point) values($chkAuthUserid,$com_id,'-$deduct_point')");
							}
						}
						if($_REQUEST['tblid']>0){ //making with fabrics
							$remarks1="ফ্যাব্রিক্স কেনা এবং ড্রেস মেকিং বাবদ | $all_items";
							$remarks2="ফ্যাব্রিক্স কেনা এবং ড্রেস মেকিং বাবদ বাকি পরিশোধ | $all_items |-$payment_type";
							dueTblUpdate($chkAuthUserid,$total_tk,0,$remarks1,'0'); // due
							dueTblUpdate($chkAuthUserid,$advance_tk,1,$remarks2,'0'); // advance
						}else{ // only making
							$remarks1="ড্রেস মেকিং বাবদ";
							$remarks2="ড্রেস মেকিং বাবদ বাকি পরিশোধ  |-$payment_type";
							dueTblUpdate($chkAuthUserid,$total_tk,0,$remarks1,'0'); // due
							dueTblUpdate($chkAuthUserid,$advance_tk,1,$remarks2,'0'); // advance
						}
						
						mysqli_close($conn);
						//echo @$rem_sms."#sep#".$cus_order_date."#sep#".$karigor_dv_date." ".$urtime."#sep#".getCustomerRecept($tag,$cus_dv_date,$cus_order_date,$get_mobile,$total_tk,$advance_tk,$cus_name,$all_itemqtya,$all_itema,$discount);
						echo "Save Success!!!";
					}else{
						echo 20000000;
					}
				
			}else{
				echo 30000000;
			}
		}
	}
	
	if(isset($_REQUEST['reloadItemList'])){
		$product_fabrics=$conn->query("select * from product where is_active=2 order by id asc");
		?>
			<select class="form-control select2" onchange="getDetails();" style="font-weight: bold;font-size:18px;font-style: italic;background:#f9d9a8" id="ds_item_id">
				<option value="">Select One</option>
				<?php 
				while($rows=mysqli_fetch_array($product_fabrics)){
					@$item_code=($rows['item_code']=="")? '' : ' ['.$rows['item_code'].']';
					@$unit=($rows['uom']=="")? '' : '-('.$rows['uom'].')';
					@$avg_price="";//($rows['avg_price']=="")? '0' : '-'.$rows['avg_price'].'/=';
					@$selling_price=($rows['selling_price']=="")? '0' : '-Rate: '.$rows['selling_price'].'/=';
					@$stock_qty=($rows['stock_qty']=="")? '0' : ' Stock: '.$rows['stock_qty'];
					if($_SESSION['IS_STOCK']==0){
					?>
					<option value="<?php echo $rows['id']."#sep#".$rows['product_name']."#sep#".$rows['uom']."#sep#".$rows['selling_price']."#sep#".$rows['stock_qty']."#sep#".$rows['avg_price']."#sep#".$rows['item_code']; ?>"><?php echo $rows['product_name']; ?></option>
					<?php
					}
					if($_SESSION['IS_STOCK']==1){ // maintain stock
					?>
					<option value="<?php echo $rows['id']."#sep#".$rows['product_name']."#sep#".$rows['uom']."#sep#".$rows['selling_price']."#sep#".$rows['stock_qty']."#sep#".$rows['avg_price']."#sep#".$rows['item_code']; ?>"><?php echo $rows['product_name'].$item_code.$unit.$avg_price.$selling_price.$stock_qty; ?></option>
					<?php
					}
				} 
				?>
				
			</select>
			
			<script>
			$(document).ready(function(){
				$(".select2").select2();
			});
			</script>
		<?php 
	}
	
	if(isset($_REQUEST['resend_btn'])){
		$date2=$date1=$_REQUEST['date1'];
		$sms_id=$_REQUEST['sms_id'];
		$org_dv_date=$_REQUEST['org_dv_date'];
		$cus_name=$_REQUEST['cus_name'];
		$com_id=($_SESSION['COM_ID']);
		$user_id=($_SESSION['USER_ID']);
		$update_dv_status=0; // for online
		$year=date("Y");
						
		$totalamount=($_REQUEST['totalamount']=="") ? '0' : $_REQUEST['totalamount'];
		$advancePay=($_REQUEST['advancePay']=="") ? '0' : $_REQUEST['advancePay'];
		$hidemobile=$_REQUEST['hidemobile'];
		$hidden_cus_name=$_REQUEST['hidden_cus_name'];
		$old_cus_id=$_REQUEST['cus_id'];
		$cus_mobile=$_REQUEST['mobile'];
		$mobile=explode(",",trim($_REQUEST['mobile'])); //update_dv_status
		if($_SESSION['SOFT_TYPE']==1){ //for online
			if($date2!=$org_dv_date){
					$remsql=$conn->query("select rem_sms from rem_sms where com_id=$com_id");
					$rrow=mysqli_fetch_array($remsql);
					$rem_sms=$rrow['rem_sms'];
					if(($rem_sms-count($mobile))>=0){
					@$rem_sms=$rem_sms-count($mobile);
					$conn->query("update rem_sms set rem_sms=$rem_sms where com_id=$com_id");
					sendSms($cus_mobile,$date1);
					}else{
						echo 10000000;
						exit();
					}
			}
		}
		if($_SESSION['SOFT_TYPE']==2){ //for offline
			$update_dv_status=1;
		}
		
		if(isset($date1)){
			$ex=explode("/",$date1);
			$date1_original=$date1;
			$date1=$ex[2]."-".$ex[1]."-".$ex[0];
		}
		
		$com_name=($_SESSION['COM']);
		$com_address=($_SESSION['COM_ADDRESS']);
		$chk_com=$conn->query("select * from company where is_active=1 and id=$com_id");
		$txt_sms="";
		if(mysqli_num_rows($chk_com)>0){
			
			if(count($mobile)!=0 || count($mobile)>1){
				if($hidemobile!=$cus_mobile){
					$cus_mobilesql=$conn->query("select * from customer where is_active=1 and cus_mobile='$cus_mobile'");
					$remarks3="কাস্টমার আপডেট(অ্যাডজাস্ট)(-)";
					if(mysqli_num_rows($cus_mobilesql)>0){
						// already exists;
						$rrow=mysqli_fetch_array($cus_mobilesql);
						$existing_cus_id=$rrow['id'];  //insert hobe due table a
						$remarks1="ড্রেস মেকিং বাবদ";
						$remarks2="ড্রেস মেকিং বাবদ বাকি পরিশোধ";
						dueTblUpdate($existing_cus_id,$totalamount,0,$remarks1,'0'); // due
						dueTblUpdate($existing_cus_id,$advancePay,1,$remarks2,'0'); // advance
						dueTblUpdate($old_cus_id,($totalamount-$advancePay),1,$remarks3,'0'); // advance
					}else{
						$customer=$conn->query("insert into customer(cus_name,cus_mobile,com_id) values('$cus_name','$cus_mobile',$com_id)");
						@$customerid = $conn->insert_id;
						$remarks1="ড্রেস মেকিং বাবদ";
						$remarks2="ড্রেস মেকিং বাবদ বাকি পরিশোধ";
						
						dueTblUpdate($customerid,$totalamount,0,$remarks1,'0'); // due
						dueTblUpdate($customerid,$advancePay,1,$remarks2,'0'); // advance
						dueTblUpdate($old_cus_id,($totalamount-$advancePay),1,$remarks3,'0'); // advance
					}
				}else{
					if($cus_name!=$hidden_cus_name){
						$conn->query("update dsms set cus_name='$cus_name' where cus_mobile='$cus_mobile'");
						$conn->query("update customer set cus_name='$cus_name' where cus_mobile='$cus_mobile'");
					}
				}
				
				@$set_fac_dv=$_SESSION['FAC_DELIVERY'];
				@$karigor_dv_date=date('Y-m-d', strtotime($date1. " - $set_fac_dv days"));
				$ex2=explode("-",$karigor_dv_date);
				$karigor_dv_date=$ex2[2]."/".$ex2[1]."/".$ex2[0];
				//echo $date1."==".$karigor_dv_date; exit;
				@$text=$conn->query("update dsms set dv_date='$date1',fddate='$karigor_dv_date',cus_name='$cus_name',cus_mobile='$cus_mobile',update_dv_status=$update_dv_status where id=$sms_id and com_id=$com_id and is_active=1");
				if($text){
					mysqli_close($conn);
					echo 1;
				}else{
					echo 20000000;
				}
			
			}else{
				echo 40000000;
			}
		}else{
			echo 30000000;
		}
	}
	
	if(isset($_REQUEST['onlyFabrics'])){
		
	$com_id=($_SESSION['COM_ID']);
	$user_id=$_SESSION['USER_ID'];
	$phy_ord_num=$_REQUEST['phy_ord_num'];
	$mobile=$_REQUEST['mobile'];
	$cus_name=$_REQUEST['cus_name'];
	$hidden_cus_name=$_REQUEST['hidden_cus_name'];
	$chkAuthUserid=$_REQUEST['chkAuthUser'];
	$previous_due=$_REQUEST['previous_due'];
	
	if($cus_name!=$hidden_cus_name){
		$conn->query("update dsms set cus_name='$cus_name' where cus_mobile='$mobile'");
		$conn->query("update customer set cus_name='$cus_name' where cus_mobile='$mobile'");
	}
	
	$total_tk=$_REQUEST['ta_and_fab'];
	$others_tk=$_REQUEST['others_tk'];
	@$discount_tk=$_REQUEST['fabrics_discount_tk'];//(floatval($fab_total)-floatval($sub_tot_f_val));
	$advance_tk=$_REQUEST['advance_tk'];
	$total_due=$_REQUEST['total_due'];
	
	
	$discount=$_REQUEST['febdis'];
	$fab_total=$_REQUEST['fab_total'];
	
	$sub_tot_f_val=$_REQUEST['sub_tot_f_val'];
	//$fabrics_discount_tk=$_REQUEST['fabrics_discount_tk'];
	
	$payment_type=$_REQUEST['payment_type'];
	$all_fitempricea=$_REQUEST['all_fitempricea'];
	$all_fitemqtya=$_REQUEST['all_fitemqtya'];
	$all_item_idca=$_REQUEST['all_item_idca'];
	$itema=explode("#sep#",$_REQUEST['itema']); 
	$ex_all_item_idca=explode("#sep#",$all_item_idca);
	$ex_all_fitemqtya=explode("#sep#",$all_fitemqtya);
	$ex_all_fitempricea=explode("#sep#",$all_fitempricea);
	$ex_present_stocka=explode("#sep#",$_REQUEST['all_stock']);
	$ex_avg_pricea=explode("#sep#",$_REQUEST['all_avg_price']);
	
	$ex_all_itema=implode(",",$itema); 
	$status=2; // Stock out status 
		if(count($ex_all_item_idca)>0){
			if($_SESSION['SVERSION']!=2){
				$direct_sale_head=$conn->query("insert into direct_sale_head(com_id,f_total,discount,discount_tk,cus_mobile,insert_by,payment_type,others_tk,total_receive) values($com_id,'$fab_total','$discount','$discount_tk','$mobile',$user_id,'$payment_type','$others_tk','$advance_tk')");
				if($direct_sale_head){
					@$direct_sale_head_top_id = $conn->insert_id;
					
					for($di=0;$di<count($ex_all_item_idca); $di++){
						$item_id=$ex_all_item_idca[$di];
						$item_qtys=$ex_all_fitemqtya[$di];
						$item_price=$ex_all_fitempricea[$di];
						
						if($_SESSION['IS_STOCK']==1){ // maintain stock 
							$previous_stock_qty=$ex_present_stocka[$di];
							$avg_price=$ex_avg_pricea[$di];
							$selling_qty=$item_qtys;
							$fab=$conn->query("insert into direct_sale(dstid,com_id,item_id,item_qty,price,purchase_price,insert_by,order_number) values($direct_sale_head_top_id,$com_id,$item_id,'$item_qtys','$item_price','$avg_price',$user_id,'$phy_ord_num')");
							$return_data=updateStockTbl($item_id,$selling_qty,$avg_price,$previous_stock_qty,'',$status);
						}else{
							$fab=$conn->query("insert into direct_sale(dstid,com_id,item_id,item_qty,price,insert_by,order_number) values($direct_sale_head_top_id,$com_id,$item_id,'$item_qtys','$item_price',$user_id,'$phy_ord_num')");
						}
					}
					if($chkAuthUserid==""){
						$conn->query("insert into customer(cus_name,cus_mobile,cus_address,com_id) values('$cus_name','$mobile','',$com_id)");
						@$chkAuthUserid = $conn->insert_id;
						$conn->query("insert into update_due(cus_id,com_id,last_due) values($chkAuthUserid,$com_id,0)");
					}
					if($_SESSION['ACTIVE_REFERENCE']==1){ // Reference id
						@$ref_user_id=$_REQUEST['ref_user_id'];
						if($ref_user_id!=""){
							$earn_point=round(($total_tk*$_SESSION['REFERENCE_AMOUNT'])/100);
							$conn->query("insert into point_tbl(cus_id,com_id,point) values($ref_user_id,$com_id,'$earn_point')");
						}
						
						if($_REQUEST['ref_point_check']==1){
							@$deduct_point=$_REQUEST['earn_point'];
							$conn->query("insert into point_tbl(cus_id,com_id,point) values($chkAuthUserid,$com_id,'-$deduct_point')");
						}
					}
					
					$remarks1="ফ্যাব্রিক্স কেনা বাবদ | $ex_all_itema";
					$remarks2="ফ্যাব্রিক্স কেনা বাবদ বাকি পরিশোধ | $ex_all_itema |-$payment_type";
					dueTblUpdate($chkAuthUserid,$total_tk,0,$remarks1,'0'); // due
					dueTblUpdate($chkAuthUserid,$advance_tk,1,$remarks2,'0'); // advance
					
					$transaction_last_id=$conn->query("SELECT id FROM `transaction` mh WHERE mh.is_active=1 order by mh.id desc limit 0,1"); // and mh.com_id=$com_id
					$transaction_last_id_row=mysqli_fetch_array($transaction_last_id);
					$transaction_tbl_id=$transaction_last_id_row['id'];
					$conn->query("update transaction set accounting_id=$direct_sale_head_top_id where id=$transaction_tbl_id");
					$conn->query("update transaction set accounting_id=$direct_sale_head_top_id where id=($transaction_tbl_id-1)");
					
					if($fab){
						//echo 40000000;
						echo printOnlyFabricsMoneyReceipt($direct_sale_head_top_id,$cus_name,$mobile,$fab_total,$discount,$discount_tk,$user_id,$payment_type,$others_tk,$advance_tk,$itema,$ex_all_fitemqtya,$ex_all_fitempricea,$total_due);
					}
				}else{
					echo 30000000;
				}
			}else{
				// For merge order fabrics calculation
					$tag=$phy_ord_num=$_REQUEST['phy_ord_num'];
				
					@$get_order_sql=$conn->query("select * from dsms where phy_ord_num='$phy_ord_num' and is_active=1 and com_id=$com_id");
					$rows=mysqli_fetch_array($get_order_sql);
						$top_id=$rows['id'];
						$amount=$rows['amount'];
						$discounts=$rows['discount'];
						$tai_and_fab_tk=$rows['tai_and_fab_tk'];
						$others_tk_tbl=$rows['others_tk'];
						$total_tks=$total_tk+$amount;
						$discount_tk+=$discounts;
						$ta_and_fab=$total_tk+$tai_and_fab_tk;
						$others_tk+=$others_tk_tbl;
						@$update_dsms=$conn->query("update dsms set amount='$total_tks',discount='$discount_tk',tai_and_fab_tk='$ta_and_fab',others_tk='$others_tk' where is_active=1 and phy_ord_num='$phy_ord_num' and com_id=$com_id");
				
				@$direct_sale_sql=$conn->query("select (select f_total from direct_sale_head where id=direct_sale.dstid) f_total,dstid  from direct_sale where order_number='$phy_ord_num' and is_active=1 and com_id=$com_id limit 0,1");
				$conn->query("insert into accounting(dsms_id,com_id,amount,insert_by,pay_status) values($top_id,$com_id,'$advance_tk',$user_id,1)");
				
				if(mysqli_num_rows($direct_sale_sql)>0){
					$drows=mysqli_fetch_array($direct_sale_sql);
					$f_totals=$fab_total+$drows['f_total'];
					$dstid=$drows['dstid'];
					$direct_sale_head=$conn->query("update direct_sale_head set f_total='$f_totals' where com_id=$com_id and id=$dstid");
					if($advance_tk<=$fab_total){
							$only_fab_tk=$advance_tk;
						}else{
							$only_fab_tk=$fab_total;
						}
						$conn->query("insert into only_febrics_tk(ord_number,taka)values('$tag','$only_fab_tk')");
						
						if($direct_sale_head){
							@$direct_sale_head_top_id = $dstid;
							for($di=0;$di<count($ex_all_item_idca); $di++){
								$item_id=$ex_all_item_idca[$di];
								$item_qtys=$ex_all_fitemqtya[$di];
								$item_price=$ex_all_fitempricea[$di];
								
								if($_SESSION['IS_STOCK']==1){ // maintain stock 
									$previous_stock_qty=$ex_present_stocka[$di];
									$avg_price=$ex_avg_pricea[$di];
									$selling_qty=$item_qtys;
									$fab=$conn->query("insert into direct_sale(dstid,com_id,item_id,item_qty,price,purchase_price,insert_by,order_number) values($direct_sale_head_top_id,$com_id,$item_id,'$item_qtys','$item_price','$avg_price',$user_id,'$tag')");
									$return_data=updateStockTbl($item_id,$selling_qty,$avg_price,$previous_stock_qty,'',$status);
								}else{
									$conn->query("insert into direct_sale(dstid,com_id,item_id,item_qty,price,insert_by,order_number) values($direct_sale_head_top_id,$com_id,$item_id,'$item_qtys','$item_price',$user_id,'$tag')");
								}
							}
						}
				}else{
					$direct_sale_head=$conn->query("insert into direct_sale_head(com_id,f_total,cus_mobile,insert_by,is_order) values($com_id,'$fab_total','$mobile',$user_id,1)");
					if($advance_tk<=$fab_total){
							$only_fab_tk=$advance_tk;
						}else{
							$only_fab_tk=$fab_total;
						}
						$conn->query("insert into only_febrics_tk(ord_number,taka)values('$tag','$only_fab_tk')");
						
					if($direct_sale_head){
						@$direct_sale_head_top_id = $conn->insert_id;
						for($di=0;$di<count($ex_all_item_idca); $di++){
							$item_id=$ex_all_item_idca[$di];
							$item_qtys=$ex_all_fitemqtya[$di];
							$item_price=$ex_all_fitempricea[$di];
							
							if($_SESSION['IS_STOCK']==1){ // maintain stock 
								$previous_stock_qty=$ex_present_stocka[$di];
								$avg_price=$ex_avg_pricea[$di];
								$selling_qty=$item_qtys;
								$fab=$conn->query("insert into direct_sale(dstid,com_id,item_id,item_qty,price,purchase_price,insert_by,order_number) values($direct_sale_head_top_id,$com_id,$item_id,'$item_qtys','$item_price','$avg_price',$user_id,'$tag')");
								$return_data=updateStockTbl($item_id,$selling_qty,$avg_price,$previous_stock_qty,'',$status);
							}else{
								$conn->query("insert into direct_sale(dstid,com_id,item_id,item_qty,price,insert_by,order_number) values($direct_sale_head_top_id,$com_id,$item_id,'$item_qtys','$item_price',$user_id,'$tag')");
							}
						}
					}
				}
				
				
				if($direct_sale_head){
					
					if($chkAuthUserid==""){
						$conn->query("insert into customer(cus_name,cus_mobile,cus_address,com_id) values('$cus_name','$mobile','',$com_id)");
						@$chkAuthUserid = $conn->insert_id;
						$conn->query("insert into update_due(cus_id,com_id,last_due) values($chkAuthUserid,$com_id,0)");
					}
					if($_SESSION['ACTIVE_REFERENCE']==1){ // Reference id
						@$ref_user_id=$_REQUEST['ref_user_id'];
						if($ref_user_id!=""){
							$earn_point=round(($total_tk*$_SESSION['REFERENCE_AMOUNT'])/100);
							$conn->query("insert into point_tbl(cus_id,com_id,point) values($ref_user_id,$com_id,'$earn_point')");
						}
						
						if($_REQUEST['ref_point_check']==1){
							@$deduct_point=$_REQUEST['earn_point'];
							$conn->query("insert into point_tbl(cus_id,com_id,point) values($chkAuthUserid,$com_id,'-$deduct_point')");
						}
					}
					
					$remarks1="ফ্যাব্রিক্স কেনা বাবদ  | $ex_all_itema";
					$remarks2="ফ্যাব্রিক্স কেনা বাবদ বাকি পরিশোধ | $ex_all_itema |-$payment_type";
					dueTblUpdate($chkAuthUserid,$total_tk,0,$remarks1,'0'); // due
					dueTblUpdate($chkAuthUserid,$advance_tk,1,$remarks2,'0'); // advance
					
					if($direct_sale_head){
						echo 40000000;
					}
				}else{
					echo 30000000;
				}
			}
		}else{
			echo 2000000;
		}
	}
	
if(isset($_REQUEST['rentOnlyFabrics'])){
		
	$com_id=($_SESSION['COM_ID']);
	$user_id=$_SESSION['USER_ID'];
	$phy_ord_num=$_REQUEST['phy_ord_num'];
	$mobile=$_REQUEST['mobile'];
	$cus_name=$_REQUEST['cus_name'];
	@$cus_address=$_REQUEST['cus_address'];
	@$order_date1=$_REQUEST['order_date1'];
	$submission_date="";
	if(@$order_date1!=""){
			$ex3=explode("/",$order_date1);
			$order_date1=$ex3[2]."-".$ex3[1]."-".$ex3[0];
			$submission_date=$order_date1;
	}
				
	if($cus_address!=""){
		$message=str_replace("'", "", $cus_address);
		$message=explode("\n",$message);
		$message=implode("<br/>&nbsp;&nbsp;&nbsp;",$message);
		$cus_address = $message;
	}
	
	$hidden_cus_name=$_REQUEST['hidden_cus_name'];
	$chkAuthUserid=$_REQUEST['chkAuthUser'];
	$previous_due=$_REQUEST['previous_due'];
	
	if($cus_name!=$hidden_cus_name){
		$conn->query("update dsms set cus_name='$cus_name' where cus_mobile='$mobile'");
		$conn->query("update customer set cus_name='$cus_name' where cus_mobile='$mobile'");
	}
	
	$total_tk=$_REQUEST['ta_and_fab'];
	$others_tk=$_REQUEST['others_tk'];
	@$discount_tk=$_REQUEST['fabrics_discount_tk'];//(floatval($fab_total)-floatval($sub_tot_f_val));
	$advance_tk=$_REQUEST['advance_tk'];
	$total_due=$_REQUEST['total_due'];
	
	
	$discount=$_REQUEST['febdis'];
	$fab_total=$_REQUEST['fab_total'];
	
		
	$sub_tot_f_val=$_REQUEST['sub_tot_f_val'];
	//$fabrics_discount_tk=$_REQUEST['fabrics_discount_tk'];
	
	$payment_type=$_REQUEST['payment_type'];
	$all_fitempricea=$_REQUEST['all_fitempricea'];
	$all_fitemqtya=$_REQUEST['all_fitemqtya'];
	$all_item_idca=$_REQUEST['all_item_idca'];
	$itema=explode("#sep#",$_REQUEST['itema']); 
	$ex_all_item_idca=explode("#sep#",$all_item_idca);
	$ex_all_fitemqtya=explode("#sep#",$all_fitemqtya);
	$ex_all_fitempricea=explode("#sep#",$all_fitempricea);
	$ex_present_stocka=explode("#sep#",$_REQUEST['all_stock']);
	$ex_avg_pricea=explode("#sep#",$_REQUEST['all_avg_price']);
	
	$ex_all_itema=implode(",",$itema); 
	$status=2; // Stock out status 
		if(count($ex_all_item_idca)>0){
				$direct_sale_head=$conn->query("insert into direct_sale_head(com_id,f_total,discount,discount_tk,cus_mobile,insert_by,payment_type,others_tk,total_receive,cus_name,cus_address,is_active,submission_date) values($com_id,'$fab_total','$discount','$discount_tk','$mobile',$user_id,'$payment_type','$others_tk','$advance_tk','$cus_name','$cus_address','2','$submission_date')");
				if($direct_sale_head){
					@$direct_sale_head_top_id = $conn->insert_id;
					
					for($di=0;$di<count($ex_all_item_idca); $di++){
						$item_id=$ex_all_item_idca[$di];
						$item_qtys=$ex_all_fitemqtya[$di];
						$item_price=$ex_all_fitempricea[$di];

							$fab=$conn->query("insert into direct_sale(dstid,com_id,item_id,item_qty,price,insert_by,order_number,is_active) values($direct_sale_head_top_id,$com_id,$item_id,'$item_qtys','$item_price',$user_id,'$phy_ord_num','2')");
					
					}
					if($chkAuthUserid==""){
						$conn->query("insert into customer(cus_name,cus_mobile,cus_address,com_id) values('$cus_name','$mobile','',$com_id)");
						@$chkAuthUserid = $conn->insert_id;
					}
					if($_SESSION['ACTIVE_REFERENCE']==1){ // Reference id
						@$ref_user_id=$_REQUEST['ref_user_id'];
						if($ref_user_id!=""){
							$earn_point=round(($total_tk*$_SESSION['REFERENCE_AMOUNT'])/100);
							$conn->query("insert into point_tbl(cus_id,com_id,point) values($ref_user_id,$com_id,'$earn_point')");
						}
						
						if($_REQUEST['ref_point_check']==1){
							@$deduct_point=$_REQUEST['earn_point'];
							$conn->query("insert into point_tbl(cus_id,com_id,point) values($chkAuthUserid,$com_id,'-$deduct_point')");
						}
					}
					
					
					if($fab){
						//echo 40000000;
					echo printOnlyFabricsMoneyReceiptRent($direct_sale_head_top_id,$cus_name,$mobile,$fab_total,$discount_tk,$advance_tk,$itema,$ex_all_fitemqtya,$ex_all_fitempricea,$total_due,$submission_date);
					}
				}else{
					echo 30000000;
				}
			
		}else{
			echo 2000000;
		}
	}
	
	if(isset($_REQUEST['getMasterPending'])){
		$com_id=$_SESSION['COM_ID'];
		$master_id=trim($_REQUEST['master_id']);
		@$on_handwork=trim($_REQUEST['on_handwork']);
		if($master_id!=""){
			if($on_handwork==1){ // on hand work 
				if($master_id=="all"){
			
				$master_sql=$conn->query("SELECT DISTINCT(ws.emp_id), date(ws.insert_date) insert_date,ord.id,ord.`order_number`,(select product_name from product where id=ord.item_id) item_name, (select user_name from user where id=(select emp_id from wages_details where ord_record_tblid=ord.id and emp_type=1 limit 0,1)) emp_name, (master_cutting_qty-receive_qty) on_hand_qty FROM `order_record` ord,wages_details ws WHERE ord.id=ws.ord_record_tblid and ord.is_active=1 and ws.emp_type=1 and ord.`master_cutting_qty`!=ord.`receive_qty`");
				
			}else{
			$master_sql=$conn->query("SELECT DISTINCT(ws.emp_id), date(ws.insert_date) insert_date,ord.id,ord.`order_number`,(select product_name from product where id=ord.item_id) item_name, (select user_name from user where id=(select emp_id from wages_details where ord_record_tblid=ord.id and emp_type=1 limit 0,1)) emp_name, (master_cutting_qty-receive_qty) on_hand_qty FROM `order_record` ord,wages_details ws WHERE ord.id=ws.ord_record_tblid and ord.is_active=1 and ws.emp_type=1 and ord.`master_cutting_qty`!=ord.`receive_qty` and ws.emp_id='$master_id'");
			}
			mysqli_close($conn);
				if(mysqli_num_rows($master_sql)>0){
				
				$c=0;$sl2=0;
					while($rows=mysqli_fetch_array($master_sql)){
						$c=++$sl2;
					?>
					<tr id="row_master<?php echo $rows['id']; ?>">
						<td style="text-align:center">
							<?php echo $c; ?>
						</td>
						<td style="text-align:center;font-weight:bold">
							<?php echo $rows['order_number']; ?>
						</td>
						<td style="text-align:center">
							<?php echo $rows['insert_date']; ?><br/>
							<i style="color:blue"><?php echo $rows['emp_name']; ?></i>
						</td>
						<td style="">
							<?php echo $rows['item_name']; ?>
						</td>
						<td style="text-align:center">
							<?php echo $rows['on_hand_qty']; ?>
						</td>
						<td style="text-align:right;font-weight:bold">
							***
						</td>
						
					</tr>
						<?php 
					}
			
			}else{
				echo "";
			}
			}else{
			if($master_id=="all"){
			
				$master_sql=$conn->query("SELECT wd.*,(select user_name from user where id=wd.emp_id limit 0,1) emp_name FROM `wages_details` wd WHERE wd.`is_active`=1 and wd.`status`=0 and wd.`emp_type`=1 order by id desc limit 0,200");
				
			}else{
			$master_sql=$conn->query("SELECT wd.*,(select user_name from user where id=wd.emp_id limit 0,1) emp_name FROM `wages_details` wd WHERE wd.`is_active`=1 and wd.`status`=0 and wd.`emp_type`=1 and `emp_id`='$master_id' order by id desc limit 0,200");
			}
			mysqli_close($conn);
			if(mysqli_num_rows($master_sql)>0){
				
				$c=0;$sl2=0;
					while($rows=mysqli_fetch_array($master_sql)){
						$c=++$sl2;
					?>
					<tr id="row_master<?php echo $rows['id']; ?>">
						<td style="text-align:center">
							<button onclick="delItemPayment('<?php echo $rows['id']; ?>','<?php echo $rows['emp_type']; ?>','<?php echo $rows['taka']; ?>','<?php echo $rows['emp_id']; ?>','<?php echo $rows['status']; ?>','<?php echo $rows['ord_record_tblid']; ?>');" name='btn' id='delbtns<?php echo $rows['id']; ?>' class="btn btn-danger form-control"><?php echo $c; ?></button>
						</td>
						<td style="text-align:center;font-weight:bold">
							<?php echo $rows['order_num']; ?>
						</td>
						<td style="text-align:center">
							<?php echo $rows['insert_date']; ?><br/>
							<i style="color:blue"><?php echo $rows['emp_name']; ?></i>
						</td>
						<td style="">
							<?php echo $rows['item_name']; ?>
						</td>
						<td style="text-align:center">
							<?php echo $rows['item_qty']; ?>
						</td>
						<td style="text-align:right;font-weight:bold">
							<?php echo $rows['taka']; ?>
						</td>
						
					</tr>
						<?php 
					}
			
			}else{
				echo "";
			}
			}
		}else{
			echo "";
		}
	}
	
	if(isset($_REQUEST['getKarigorPending'])){
		$com_id=$_SESSION['COM_ID'];
		$master_id=trim($_REQUEST['master_id']);
		$on_handwork=trim($_REQUEST['on_handwork']);
		if($master_id!=""){
			if($on_handwork==1){ // on hand work 
				if($master_id=="all"){
				
				$master_sql=$conn->query("SELECT DISTINCT(ws.emp_id), date(ws.insert_date) insert_date,ord.id,ord.`order_number`,(select product_name from product where id=ord.item_id) item_name, (select user_name from user where id=(select emp_id from wages_details where ord_record_tblid=ord.id and emp_type=2 limit 0,1)) emp_name, (receive_qty-delivery_qty) on_hand_qty FROM `order_record` ord,wages_details ws WHERE ord.id=ws.ord_record_tblid and ord.is_active=1 and ws.emp_type=2 and ord.`receive_qty`!=ord.`delivery_qty`");
					
				}else{
				$master_sql=$conn->query("SELECT DISTINCT(ws.emp_id), date(ws.insert_date) insert_date,ord.id,ord.`order_number`,(select product_name from product where id=ord.item_id) item_name, (select user_name from user where id=(select emp_id from wages_details where ord_record_tblid=ord.id and status=0 and emp_type=2 order by id desc limit 0,1)) emp_name, (receive_qty-delivery_qty) on_hand_qty FROM `order_record` ord,wages_details ws WHERE ord.id=ws.ord_record_tblid and ord.is_active=1 and ws.emp_type=2 and ord.`receive_qty`!=ord.`delivery_qty` and ws.emp_id='$master_id'");
				}
				mysqli_close($conn);
				if(mysqli_num_rows($master_sql)>0){
					
					$c=0;$sl2=0;
						while($rows=mysqli_fetch_array($master_sql)){
							$c=++$sl2;
						?>
						<tr id="<?php echo ($master_id==1)? 'row_master' : 'row_karigor'; ?><?php echo $rows['id']; ?>">
							<td style="text-align:center">
								<?php echo $c; ?>
							</td>
							<td style="text-align:center;font-weight:bold">
								<?php echo $rows['order_number']; ?>
							</td>
							<td style="text-align:center">
								<?php echo $rows['insert_date']; ?><br/>
								<i style="color:blue"><?php echo $rows['emp_name']; ?></i>
							</td>
							<td style="">
								<?php echo $rows['item_name']; ?>
							</td>
							<td style="text-align:center">
								<?php echo $rows['on_hand_qty']; ?>
							</td>
							<td style="text-align:right;font-weight:bold">
								***
							</td>
							
						</tr>
							<?php 
						}
				
				}else{
					echo "";
				}

			}else{
				if($master_id=="all"){
				
					$master_sql=$conn->query("SELECT wd.*,(select user_name from user where id=wd.emp_id limit 0,1) emp_name FROM `wages_details` wd WHERE wd.`is_active`=1 and wd.`status`=0 and wd.`emp_type`=2 order by id desc limit 0,200");
					
				}else{
				$master_sql=$conn->query("SELECT wd.*,(select user_name from user where id=wd.emp_id limit 0,1) emp_name FROM `wages_details` wd WHERE wd.`is_active`=1 and wd.`status`=0 and wd.`emp_type`=2 and `emp_id`='$master_id' order by id desc limit 0,200");
				}
				mysqli_close($conn);
				if(mysqli_num_rows($master_sql)>0){
					
					$c=0;$sl2=0;
						while($rows=mysqli_fetch_array($master_sql)){
							$c=++$sl2;
						?>
						<tr id="<?php echo ($master_id==1)? 'row_master' : 'row_karigor'; ?><?php echo $rows['id']; ?>">
							<td style="text-align:center">
								<button onclick="delItemPayment('<?php echo $rows['id']; ?>','<?php echo $rows['emp_type']; ?>','<?php echo $rows['taka']; ?>','<?php echo $rows['emp_id']; ?>','<?php echo $rows['status']; ?>','<?php echo $rows['ord_record_tblid']; ?>');" name='btn' id='delbtnskarigor<?php echo $rows['id']; ?>' class="btn btn-danger form-control"><?php echo $c; ?></button>
							</td>
							<td style="text-align:center;font-weight:bold">
								<?php echo $rows['order_num']; ?>
							</td>
							<td style="text-align:center">
								<?php echo $rows['insert_date']; ?><br/>
								<i style="color:blue"><?php echo $rows['emp_name']; ?></i>
							</td>
							<td style="">
								<?php echo $rows['item_name']; ?>
							</td>
							<td style="text-align:center">
								<?php echo $rows['item_qty']; ?>
							</td>
							<td style="text-align:right;font-weight:bold">
								<?php echo $rows['taka']; ?>
							</td>
							
						</tr>
							<?php 
						}
				
				}else{
					echo "";
				}
			}
		}else{
			echo "";
		}
	}
	
	if(isset($_REQUEST['assignToMasterItem'])){
		date_default_timezone_set("Asia/Dhaka");
		$assign_date=date("d/m/Y");
		
		$com_id=$_SESSION['COM_ID'];
		$user_id=($_SESSION['USER_ID']);
		$emp_id=$_REQUEST['master_id'];
		$get_emp_type=$_REQUEST['get_emp_type'];
		$status=$_REQUEST['status'];
		$citem_namea=explode("#sep#",$_REQUEST['citem_namea']);
		$cassign_qtya=explode("#sep#",$_REQUEST['cassign_qtya']);
		$ckdesign_tka=explode("#sep#",$_REQUEST['ckdesign_tka']);
		$corder_numa=explode("#sep#",$_REQUEST['corder_numa']);
		$corder_tbl_ida=explode("#sep#",$_REQUEST['corder_tbl_ida']);
		$citem_ida=explode("#sep#",$_REQUEST['citem_ida']);
		$chk_employee=$conn->query("select user_name from user where salary_type in (2,3) and id=$emp_id");
		if(mysqli_fetch_array($chk_employee)>0){
			$multiply=0;
		}else{
			$multiply=1;
		}
		$wages_memo=$conn->query("insert into wages_memo(emp_id,emp_type,insert_by) values ('$emp_id','$get_emp_type','$user_id')");
		@$wages_memo_id = $conn->insert_id;
		for($i=0; $i<count($citem_namea);$i++){
			
			@$order_num=$corder_numa[$i];
			
			$remarks="";
			@$item_name=$citem_namea[$i];
			@$item_id=$citem_ida[$i];
			@$ord_tbl_id=$corder_tbl_ida[$i];
			
			@$item_qty=$cassign_qtya[$i];
			@$design_tk=($ckdesign_tka[$i]=="")? 0 : $ckdesign_tka[$i];
			////*************************************************///
			$employees_price=$conn->query("SELECT price,(select user_name from user where id=employees_price_setup.emp_id limit 0,1) emp_name from employees_price_setup where is_active=1 and emp_id='$emp_id' and item_id=$item_id order by id desc limit 0,1");
			$employees_price_row=mysqli_fetch_array($employees_price);
			$emp_price=$employees_price_row['price'];
			$emp_name=$employees_price_row['emp_name'];
			$taka=((($emp_price*$item_qty)+$design_tk)*$multiply);
			$emp_info=$conn->query("SELECT id,taka from wages_head where emp_id=$emp_id and com_id=$com_id");
		if(mysqli_num_rows($emp_info)>0){
			$row=mysqli_fetch_array($emp_info);
			$id=$row['id'];
			$utaka=($row['taka']+$taka);
			$last_insert_head=$conn->query("update wages_head set taka='$utaka' where id=$id");
		}else{
			$last_insert_head=$conn->query("insert into wages_head(com_id,emp_id,taka) values ($com_id,$emp_id,'$taka')");
			
		}
		

			if($get_emp_type==2){ //karigor 
				$rec_qty=$conn->query("SELECT * from order_record where id=$ord_tbl_id and is_active=1");
				$row=mysqli_fetch_array($rec_qty);
				$receive_qty=$row['receive_qty'];
				$work_tk=$taka;
				$conn->query("update order_record set assign_date='$assign_date',receive_qty=($item_qty+$receive_qty),maker=$emp_id,emp_type=$get_emp_type where id=$ord_tbl_id");
			}else{ // master=1
				$rec_qty=$conn->query("SELECT * from order_record where id=$ord_tbl_id and is_active=1");
				$row=mysqli_fetch_array($rec_qty);
				$receive_qty=$row['master_cutting_qty'];
				$work_tk=$taka;
				$conn->query("update order_record set master_assign_date='$assign_date',master_cutting_qty=($item_qty+$receive_qty),master_emp_id=$emp_id where id=$ord_tbl_id");
			}
			
			$last_insert=$conn->query("insert into wages_details(com_id,
						emp_id,
						order_num,
						taka,
						design_tk,
						remarks,
						item_name,
						item_qty,
						status,
						item_ids,
						emp_type,
						ord_record_tblid,
						memo_id,
						insert_by
						) values($com_id,
						$emp_id,
						'$order_num',
						'$work_tk',
						'$design_tk',
						'$remarks',
						'$item_name',
						'$item_qty',
						'$status',
						'$item_id',
						'$get_emp_type',
						'$ord_tbl_id',
						'$wages_memo_id',
						$user_id)");
				
		@$wages_tbl_id = $conn->insert_id;
			?>
			<tr id="<?php echo ($get_emp_type==1)? 'row_master' : 'row_karigor'; ?><?php echo $wages_tbl_id; ?>">
				<td style="text-align:center">
					<button onclick="delItemPayment('<?php echo $wages_tbl_id; ?>','<?php echo $get_emp_type; ?>','<?php echo $work_tk; ?>','<?php echo $emp_id; ?>','<?php echo $status; ?>','<?php echo $ord_tbl_id; ?>');" name='btn' id='<?php echo ($get_emp_type==1)? 'delbtns' : 'delbtnskarigor'; ?><?php echo $wages_tbl_id; ?>' class="btn btn-danger form-control">***</button>
				</td>
				<td style="text-align:center;font-weight:bold">
					<?php echo $order_num; ?>
				</td>
				<td style="text-align:center">
					<?php echo date('Y-m-d h:i:s'); ?><br/>
					<i style="color:blue"><?php echo $emp_name; ?></i>
				</td>
				<td style="">
					<?php echo $item_name; ?>
				</td>
				<td style="text-align:center">
					<?php echo $item_qty; ?>
				</td>
				<td style="text-align:right;font-weight:bold">
					<?php echo $work_tk; ?>
				</td>
				
			</tr>
				<?php 
			/* if($order_num!=""){
				$ord_tbl_select=$conn->query("select itbl.iitem_qty,rtbl.rreceive_qty from (SELECT sum(item_qty) iitem_qty FROM `order_record` WHERE `com_id`=$com_id and is_active=1 and order_number='$order_num') itbl, (SELECT sum(receive_qty) rreceive_qty FROM `order_record` WHERE `com_id`=$com_id and is_active=1 and order_number='$order_num' and `emp_type`=2) rtbl");
				$ord_tbl_selecta=mysqli_fetch_array($ord_tbl_select);
				if($ord_tbl_selecta['iitem_qty']==$ord_tbl_selecta['rreceive_qty']){
					$date=date("Y-m-d");
					$chk_com=$conn->query("update dsms set factory_status=1,factory_receive_date='$date' where tagnum='$order_num' and com_id=$com_id");
						if($from_factory_recive_live_sms==1){ // 1=means active order live smsm 
							if($get_emp_type==2){ //karigor 
								if(check_internet_connection()==1){
									$cus_mobiles=$conn->query("SELECT cus_mobile FROM `dsms` WHERE `com_id`=$com_id and is_active=1 and tagnum='$order_num'");
									$cus_mobilea=mysqli_fetch_array($cus_mobiles);
									$mobile=$cus_mobilea['cus_mobile'];
									$response = file_get_contents($_SESSION['API']."api/data.php?com_id=$com_id&cus_mobile=$mobile&order_no=$order_num&chk=11"); //chk=2 means check sms
									$json = json_decode($response, true);
								}
							}
						}
					
				}
			} */
			////*************************************************///
		}
	}
	
		if(isset($_REQUEST['rearrangePendingList'])){
		$com_id=$_SESSION['COM_ID'];
		$cutting_pending=$conn->query("SELECT ord.*,(ord.item_qty-ord.master_cutting_qty) item_qtys,(select product_name from product where id=ord.item_id limit 0,1) item_name,(select cus_name from dsms where id=ord.dsms_id limit 0,1) cus_name FROM `order_record` ord WHERE ord.item_qty!=ord.`master_cutting_qty` and ord.is_active=1 and com_id=$com_id");
		mysqli_close($conn);	
		
			$sl2=1;$order_tk2=0;$c=0;
			if(mysqli_num_rows($cutting_pending)>0){
				while($row=mysqli_fetch_array($cutting_pending)){
					$c=$sl2++;
					?>
					<tr id="cleft_row<?php echo $c; ?>">
					<td style="text-align:center"><?php echo $c; ?></td>
					<td style="text-align:center;font-weight:bold"><?php echo $row['order_number']; ?></td>
					<td>
						<?php echo $row['cus_name']; ?>
					</td>
					<td style="text-align:center">
						<?php echo $row['item_name']; ?>
					</td>
					<td style="text-align:center;font-weight:bold">
						<?php echo $row['item_qtys']; ?>
						<input type="hidden" id="citem_name<?php echo $c; ?>" value="<?php echo $row['item_name']; ?>"/>
						<input type="hidden" id="citem_qty<?php echo $c; ?>" value="<?php echo $row['item_qtys']; ?>"/>
						<input type="hidden" id="corder_num<?php echo $c; ?>" value="<?php echo $row['order_number']; ?>"/>
						<input type="hidden" id="corder_tbl_id<?php echo $c; ?>" value="<?php echo $row['id']; ?>"/>
						<input type="hidden" id="citem_id<?php echo $c; ?>" value="<?php echo $row['item_id']; ?>"/>
						<input type="hidden" id="call_ok<?php echo $c; ?>"/>
					</td>
					
					<td>
						<input onkeyup="checkAssignQty('<?php echo $c; ?>');" style="text-align:center;font-weight:bold" type="text" class="form-control" id="assign_qty<?php echo $c; ?>"/>
					</td>
					</tr>
					<?php 
				}
			}
		?>
		<input type="hidden" value="<?php echo $c; ?>" id="pending_total"/>
		<?php 
	}
	
	if(isset($_REQUEST['rearrangeKarigorPendingList'])){
		$com_id=$_SESSION['COM_ID'];
		$cutting_pending=$conn->query("SELECT ord.*,(ord.master_cutting_qty-ord.receive_qty) item_qtys,(select product_name from product where id=ord.item_id limit 0,1) item_name,(select cus_name from dsms where id=ord.dsms_id limit 0,1) cus_name FROM `order_record` ord WHERE ord.is_active=1 and ord.receive_qty!=ord.`master_cutting_qty` and com_id=$com_id");
		mysqli_close($conn);	
		
			$sl2=1;$order_tk2=0;$c=0;
			if(mysqli_num_rows($cutting_pending)>0){
				while($row=mysqli_fetch_array($cutting_pending)){
					$c=$sl2++;
					?>
					<tr id="kleft_row<?php echo $c; ?>">
					<td style="text-align:center"><?php echo $c; ?></td>
					<td style="text-align:center;font-weight:bold"><?php echo $row['order_number']; ?></td>
					<td>
						<?php echo $row['cus_name']; ?>
					</td>
					<td style="text-align:center">
						<?php echo $row['item_name']; ?>
					</td>
					<td style="text-align:center;font-weight:bold">
						<?php echo $row['item_qtys']; ?>
						<input type="hidden" id="kitem_name<?php echo $c; ?>" value="<?php echo $row['item_name']; ?>"/>
						<input type="hidden" id="kitem_qty<?php echo $c; ?>" value="<?php echo $row['item_qtys']; ?>"/>
						<input type="hidden" id="korder_num<?php echo $c; ?>" value="<?php echo $row['order_number']; ?>"/>
						<input type="hidden" id="korder_tbl_id<?php echo $c; ?>" value="<?php echo $row['id']; ?>"/>
						<input type="hidden" id="kitem_id<?php echo $c; ?>" value="<?php echo $row['item_id']; ?>"/>
						<input type="hidden" id="kall_ok<?php echo $c; ?>"/>
					</td>
					
					<td>
						<input onkeyup="checkAssignQtyKarigor('<?php echo $c; ?>');" style="text-align:center;font-weight:bold;color:blue" type="text" class="form-control" id="kassign_qty<?php echo $c; ?>"/>
					</td>
					<td>
						<input style="text-align:right;font-weight:bold" type="text" class="form-control" id="kdesign_tk<?php echo $c; ?>"/>
					</td>
					</tr>
					<?php 
				}
			}
		?>
		<input type="hidden" value="<?php echo $c; ?>" id="kpending_total"/>
		<?php 
	}
	

	
	if(isset($_REQUEST['rearrangeReceivePendingList'])){
		$com_id=$_SESSION['COM_ID'];
		$cutting_pending=$conn->query("SELECT ord.*,(ord.receive_qty-ord.delivery_qty) item_qtys,(select product_name from product where id=ord.item_id limit 0,1) item_name,(select cus_name from dsms where id=ord.dsms_id limit 0,1) cus_name,(select cus_mobile from dsms where id=ord.dsms_id limit 0,1) cus_mobile FROM `order_record` ord WHERE ord.is_active=1 and ord.delivery_qty!=ord.`receive_qty` and com_id=$com_id");
		mysqli_close($conn);	
		
			$sl2=1;$order_tk2=0;$c=0;
			if(mysqli_num_rows($cutting_pending)>0){
				while($row=mysqli_fetch_array($cutting_pending)){
					$c=$sl2++;
					?>
					<tr id="rleft_row<?php echo $c; ?>">
					<td style="text-align:center"><?php echo $c; ?></td>
					<td style="text-align:center;font-weight:bold"><?php echo $row['order_number']; ?></td>
					<td>
						<?php echo $row['cus_name']; ?>
					</td>
					<td style="text-align:center">
						<?php echo $row['item_name']; ?>
					</td>
					<td style="text-align:center;font-weight:bold">
						<?php echo $row['item_qtys']; ?>
						<input type="hidden" id="rcus_name<?php echo $c; ?>" value="<?php echo $row['cus_name']; ?>"/>
						<input type="hidden" id="rcus_mobile<?php echo $c; ?>" value="<?php echo $row['cus_mobile']; ?>"/>
						<input type="hidden" id="ritem_name<?php echo $c; ?>" value="<?php echo $row['item_name']; ?>"/>
						<input type="hidden" id="ritem_qty<?php echo $c; ?>" value="<?php echo $row['item_qtys']; ?>"/>
						<input type="hidden" id="rorder_num<?php echo $c; ?>" value="<?php echo $row['order_number']; ?>"/>
						<input type="hidden" id="rorder_tbl_id<?php echo $c; ?>" value="<?php echo $row['id']; ?>"/>
						<input type="hidden" id="ritem_id<?php echo $c; ?>" value="<?php echo $row['item_id']; ?>"/>
						<input type="hidden" id="rall_ok<?php echo $c; ?>"/>
					</td>
					
					<td>
						<input onkeyup="checkAssignQtyReceive('<?php echo $c; ?>');" style="text-align:center;font-weight:bold" type="text" class="form-control" id="rassign_qty<?php echo $c; ?>"/>
					</td>
					</tr>
					<?php 
				}
			}
		?>
		<input type="hidden" value="<?php echo $c; ?>" id="rpending_total"/>
		<?php 
	}
	
	if(isset($_REQUEST['getBarcode'])){
		$barcode_all=explode("\n",$_REQUEST['barcode_all']);
		for($i=0; $i<count($barcode_all); $i++){
			?>
			<div style="text-align: center;font-weight: bold;display: block; page-break-before: always;">
				<img src='barcode.php?codetype=Code128&size=30&text=<?php echo $barcode_all[$i];?>' width='180px'
                     height='30px'><br/>
					 <span><?php echo $barcode_all[$i]; ?></span>
			</div>
		<?php 
		}
	}
	
	if(isset($_REQUEST['getReceivedItem'])){
		date_default_timezone_set("Asia/Dhaka");
		$date=date("d/m/Y");
		$com_id=$_SESSION['COM_ID'];
		$cutting_pending=$conn->query("SELECT ord.*,(select product_name from product where id=ord.item_id limit 0,1) item_name,(select cus_name from dsms where id=ord.dsms_id limit 0,1) cus_name,(select cus_mobile from dsms where id=ord.dsms_id limit 0,1) cus_mobile FROM `order_record` ord WHERE ord.is_active=1 and ord.delivery_qty!=0 and com_id=$com_id order by ord.id desc limit 100");
		mysqli_close($conn);	
		
			$sl2=1;$order_tk2=0;$c=0;
			if(mysqli_num_rows($cutting_pending)>0){
				while($row=mysqli_fetch_array($cutting_pending)){
					$c=$sl2++;
					?>
					<tr id="row_received<?php echo $row['id']; ?>">
						<td style="text-align:center">
							<?php if($row['delivery_date']==$date){ ?>
							<button onclick="delDeliveryItem('<?php echo $row['id']; ?>','<?php echo $row['delivery_qty']; ?>');" name='btn' id='delbtns_receive<?php echo $row['id']; ?>' class="btn btn-danger form-control"><?php echo $c; ?></button>
							<?php }else{
								echo $c;
							} ?>
						</td>
						<td style="text-align:center;font-weight:bold">
							<?php echo $row['order_number']; ?>
						</td>
						<td style="text-align:center">
							<?php echo $row['delivery_date']; ?><br/>
							<i style="color:blue"><?php echo $row['cus_name']; ?></i>
						</td>
						<td style="text-align:center">
							<?php echo $row['item_name']; ?>
						</td>
						<td style="text-align:center">
							<?php echo $row['delivery_qty']; ?>
						</td>
						
					</tr>
					<?php 
				}
			}
		
	}
	
	if(isset($_REQUEST['masterSearchingBtn'])){
		
		$com_id=$_SESSION['COM_ID'];
		$mstart_dates=explode("/",$_REQUEST['mstart_date']);
		$mend_dates=explode("/",$_REQUEST['mend_date']);
		if($_REQUEST['mstart_date']!=""){
			@$mstart_date=$mstart_dates[2].'-'.$mstart_dates[1].'-'.$mstart_dates[0];
		}
		if($mend_dates!=""){
			@$mend_date=$mend_dates[2].'-'.$mend_dates[1].'-'.$mend_dates[0];
		}
		$emp_type=trim($_REQUEST['emp_type']);
		$msearch_order=trim($_REQUEST['msearch_order']);
		$msearching_type=trim($_REQUEST['msearching_type']);
		$master_id=trim($_REQUEST['master_id']);
		if($msearching_type==1){ // item wise
			$con="";
			if($master_id!=""){
				if($msearch_order!=""){
					$con.="and wd.order_num='$msearch_order' ";
				}
				if(@$mstart_date!="" && @$mend_date!=""){
					$con.="and date(wd.insert_date) between '$mstart_date' and '$mend_date' ";
				}
				
				if($master_id=="all"){
					$master_sql=$conn->query("SELECT wd.*,(select user_name from user where id=wd.emp_id limit 0,1) emp_name FROM `wages_details` wd WHERE wd.`is_active`=1 and wd.`status`=0 and wd.`emp_type`=1 $con order by id desc limit 0,500");
				}else{
					$master_sql=$conn->query("SELECT wd.*,(select user_name from user where id=wd.emp_id limit 0,1) emp_name FROM `wages_details` wd WHERE wd.`is_active`=1 and wd.`status`=0 and wd.`emp_type`=1 and `emp_id`='$master_id' $con order by id desc limit 0,500");
				}
				mysqli_close($conn);
				if(mysqli_num_rows($master_sql)>0){
					
					$c=0;$sl2=0;
						while($rows=mysqli_fetch_array($master_sql)){
							$c=++$sl2;
						?>
						<tr id="row_master<?php echo $rows['id']; ?>">
							<td style="text-align:center">
								<button onclick="delItemPayment('<?php echo $rows['id']; ?>','<?php echo $rows['emp_type']; ?>','<?php echo $rows['taka']; ?>','<?php echo $rows['emp_id']; ?>','<?php echo $rows['status']; ?>','<?php echo $rows['ord_record_tblid']; ?>');" name='btn' id='delbtns<?php echo $rows['id']; ?>' class="btn btn-danger form-control"><?php echo $c; ?></button>
							</td>
							<td style="text-align:center;font-weight:bold">
								<?php echo $rows['order_num']; ?>
							</td>
							<td style="text-align:center">
								<?php echo $rows['insert_date']; ?><br/>
								<i style="color:blue"><?php echo $rows['emp_name']; ?></i>
							</td>
							<td style="">
								<?php echo $rows['item_name']; ?>
							</td>
							<td style="text-align:center">
								<?php echo $rows['item_qty']; ?>
							</td>
							<td style="text-align:right;font-weight:bold">
								<?php echo $rows['taka']; ?>
							</td>
							
						</tr>
							<?php 
						}
				
				}else{
					echo "";
				}
			}else{
				echo "";
			}
		}else if($msearching_type==2){ //vouchar wise
			$con="";
			if($master_id!=""){
				
				if(@$mstart_date!="" && @$mend_date!=""){
					$con.="and date(mo.insert_date) between '$mstart_date' and '$mend_date' ";
				}
				
				if($master_id=="all"){
					$master_sql=$conn->query("SELECT mo.*,(select user_name from user where id=mo.emp_id limit 0,1) emp_name,(select sum(item_qty) from wages_details where memo_id=mo.id and is_active=1) item_quantity,(select sum(taka) from wages_details where memo_id=mo.id and is_active=1) total_tk FROM `wages_memo` mo WHERE mo.`is_active`=1 and mo.`emp_type`=1 $con order by id desc limit 0,200");
				}else{
					$master_sql=$conn->query("SELECT mo.*,(select user_name from user where id=mo.emp_id limit 0,1) emp_name,(select sum(item_qty) from wages_details where memo_id=mo.id and is_active=1) item_quantity,(select sum(taka) from wages_details where memo_id=mo.id and is_active=1) total_tk FROM `wages_memo` mo WHERE mo.`is_active`=1 and mo.`emp_type`=1 and mo.`emp_id`='$master_id' $con order by id desc limit 0,200");
				}
				mysqli_close($conn);
				if(mysqli_num_rows($master_sql)>0){
					
					$c=0;$sl2=0;
						while($rows=mysqli_fetch_array($master_sql)){
							$c=++$sl2;
						?>
						<tr style="color:<?php echo ($rows['total_tk']=="")? '#8080808f;' : ''; ?>" id="row_master<?php echo $rows['id']; ?>">
							<td style="text-align:center">
								<?php
									if($rows['total_tk']!=""){								
								?>
								<button id='mmemo_view<?php echo $rows['id']; ?>' class="btn btn-success form-control" data-toggle="modal" data-target="#myModal" onclick="showMasterMemo('1','<?php echo @$rows['id']; ?>','<?php echo @$rows['emp_name']; ?>','<?php echo @$rows['insert_date']; ?>')"><?php echo $rows['id']; ?></button>
									<?php }else{
										echo $rows['id'];
									} ?>
							</td>
							<td style="text-align:center;font-weight:bold">
								
							</td>
							<td style="text-align:center">
								<?php echo $rows['insert_date']; ?><br/>
								<i style="color:blue"><?php echo $rows['emp_name']; ?></i>
							</td>
							<td style="">
								
							</td>
							<td style="text-align:center">
								<?php echo $rows['item_quantity']; ?>
							</td>
							<td style="text-align:right;font-weight:bold">
								<?php echo $rows['total_tk']; ?>
							</td>
							
						</tr>
							<?php 
						}
				
				}else{
					echo "";
				}
			}else{
				echo "";
			}
		}else{ // Day wise
			$con="";
			$mstart_dates=$_REQUEST['mstart_date'];
			$mend_dates=$_REQUEST['mend_date'];
			if($master_id!=""){
				
				if(@$mstart_date!="" && @$mend_date!=""){
					$con.="and date(insert_date) between '$mstart_date' and '$mend_date' ";
				}
				
				if($master_id=="all"){
					$master_sql=$conn->query("SELECT sum(`taka`) total_tk,sum(`item_qty`) item_quantity,(select user_name from user where id=wages_details.emp_id limit 0,1) emp_name,(select mobile from user where id=wages_details.emp_id limit 0,1) emp_mobile,wages_details.`emp_id` FROM `wages_details` WHERE `is_active`=1 and `status`=0 and `emp_type`=1 $con GROUP by wages_details.`emp_id`");
				}else{
					$master_sql=$conn->query("SELECT sum(`taka`) total_tk,sum(`item_qty`) item_quantity,(select user_name from user where id=wages_details.emp_id limit 0,1) emp_name,(select mobile from user where id=wages_details.emp_id limit 0,1) emp_mobile,wages_details.`emp_id` FROM `wages_details` WHERE `is_active`=1 and `status`=0 and `emp_type`=1 and `emp_id`='$master_id' $con GROUP by wages_details.`emp_id`");
				}
				mysqli_close($conn);
				if(mysqli_num_rows($master_sql)>0){
					
					$c=0;$sl2=0;
						while($rows=mysqli_fetch_array($master_sql)){
							$c=++$sl2;
						?>
						<tr style="color:<?php echo ($rows['total_tk']=="")? '#8080808f;' : ''; ?>" id="row_master<?php //echo $rows['id']; ?>">
							<td style="text-align:center">
								
								<button id='mmemo_view<?php //echo $rows['id']; ?>' class="btn btn-success form-control" onclick="showMasterDayWise('1','<?php echo @$rows['emp_id']; ?>','<?php echo @$rows['emp_mobile']; ?>','<?php echo @$rows['emp_name']; ?>','<?php echo @$mstart_date; ?>','<?php echo @$mend_date; ?>')"><?php echo $c; ?></button>
								
							</td>
							<td style="text-align:center;font-weight:bold">
								
							</td>
							<td style="text-align:center">
								<?php echo $mstart_dates; ?><br/>
								<?php echo $mend_dates; ?><br/>
								<i style="color:blue"><?php echo $rows['emp_name']; ?></i>
							</td>
							<td style="">
								
							</td>
							<td style="text-align:center">
								<?php echo $rows['item_quantity']; ?>
							</td>
							<td style="text-align:right;font-weight:bold">
								<?php echo $rows['total_tk']; ?>
							</td>
							
						</tr>
							<?php 
						}
				
				}else{
					echo "";
				}
			}else{
				echo "";
			}
		}
	}
	
	
	if(isset($_REQUEST['karigorSearchingBtn'])){
		
		$com_id=$_SESSION['COM_ID'];
		$mstart_dates=explode("/",$_REQUEST['mstart_date']);
		$mend_dates=explode("/",$_REQUEST['mend_date']);
		if($_REQUEST['mstart_date']!=""){
			@$mstart_date=$mstart_dates[2].'-'.$mstart_dates[1].'-'.$mstart_dates[0];
		}
		if($mend_dates!=""){
			@$mend_date=$mend_dates[2].'-'.$mend_dates[1].'-'.$mend_dates[0];
		}
		$emp_type=trim($_REQUEST['emp_type']);
		$msearch_order=trim($_REQUEST['msearch_order']);
		$msearching_type=trim($_REQUEST['msearching_type']);
		$master_id=trim($_REQUEST['master_id']);
		if($msearching_type==1){ // item wise
			$con="";
			if($master_id!=""){
				if($msearch_order!=""){
					$con.="and wd.order_num='$msearch_order' ";
				}
				if(@$mstart_date!="" && @$mend_date!=""){
					$con.="and date(wd.insert_date) between '$mstart_date' and '$mend_date' ";
				}
				
				if($master_id=="all"){
					$master_sql=$conn->query("SELECT wd.*,(select user_name from user where id=wd.emp_id limit 0,1) emp_name FROM `wages_details` wd WHERE wd.`is_active`=1 and wd.`status`=0 and wd.`emp_type`=2 $con order by id desc limit 0,500");
				}else{
					$master_sql=$conn->query("SELECT wd.*,(select user_name from user where id=wd.emp_id limit 0,1) emp_name FROM `wages_details` wd WHERE wd.`is_active`=1 and wd.`status`=0 and wd.`emp_type`=2 and `emp_id`='$master_id' $con order by id desc limit 0,500");
				}
				mysqli_close($conn);
				if(mysqli_num_rows($master_sql)>0){
					
					$c=0;$sl2=0;
						while($rows=mysqli_fetch_array($master_sql)){
							$c=++$sl2;
						?>
						<tr id="row_karigor<?php echo $rows['id']; ?>">
							<td style="text-align:center">
								<button onclick="delItemPayment('<?php echo $rows['id']; ?>','<?php echo $rows['emp_type']; ?>','<?php echo $rows['taka']; ?>','<?php echo $rows['emp_id']; ?>','<?php echo $rows['status']; ?>','<?php echo $rows['ord_record_tblid']; ?>');" name='btn' id='delbtnskarigor<?php echo $rows['id']; ?>' class="btn btn-danger form-control"><?php echo $c; ?></button>
							</td>
							<td style="text-align:center;font-weight:bold">
								<?php echo $rows['order_num']; ?>
							</td>
							<td style="text-align:center">
								<?php echo $rows['insert_date']; ?><br/>
								<i style="color:blue"><?php echo $rows['emp_name']; ?></i>
							</td>
							<td style="">
								<?php echo $rows['item_name']; ?>
							</td>
							<td style="text-align:center">
								<?php echo $rows['item_qty']; ?>
							</td>
							<td style="text-align:right;font-weight:bold">
								<?php echo $rows['taka']; ?>
							</td>
							
						</tr>
							<?php 
						}
				
				}else{
					echo "";
				}
			}else{
				echo "";
			}
		}else if($msearching_type==2){ //vouchar wise
			$con="";
			if($master_id!=""){
				
				if(@$mstart_date!="" && @$mend_date!=""){
					$con.="and date(mo.insert_date) between '$mstart_date' and '$mend_date' ";
				}
				
				if($master_id=="all"){
					$master_sql=$conn->query("SELECT mo.*,(select user_name from user where id=mo.emp_id limit 0,1) emp_name,(select sum(item_qty) from wages_details where memo_id=mo.id and is_active=1) item_quantity,(select sum(taka) from wages_details where memo_id=mo.id and is_active=1) total_tk FROM `wages_memo` mo WHERE mo.`is_active`=1 and mo.`emp_type`=2 $con order by id desc limit 0,200");
				}else{
					$master_sql=$conn->query("SELECT mo.*,(select user_name from user where id=mo.emp_id limit 0,1) emp_name,(select sum(item_qty) from wages_details where memo_id=mo.id and is_active=1) item_quantity,(select sum(taka) from wages_details where memo_id=mo.id and is_active=1) total_tk FROM `wages_memo` mo WHERE mo.`is_active`=1 and mo.`emp_type`=2 and mo.`emp_id`='$master_id' $con order by id desc limit 0,200");
				}
				mysqli_close($conn);
				if(mysqli_num_rows($master_sql)>0){
					
					$c=0;$sl2=0;
						while($rows=mysqli_fetch_array($master_sql)){
							$c=++$sl2;
						?>
						<tr style="color:<?php echo ($rows['total_tk']=="")? '#8080808f;' : ''; ?>" id="row_master<?php echo $rows['id']; ?>">
							<td style="text-align:center">
								<?php
									if($rows['total_tk']!=""){								
								?>
								<button id='mmemo_view<?php echo $rows['id']; ?>' class="btn btn-success form-control" data-toggle="modal" data-target="#myModal" onclick="showMasterMemo('2','<?php echo @$rows['id']; ?>','<?php echo @$rows['emp_name']; ?>','<?php echo @$rows['insert_date']; ?>')"><?php echo $rows['id']; ?></button>
									<?php }else{
										echo $rows['id'];
									} ?>
							</td>
							<td style="text-align:center;font-weight:bold">
								
							</td>
							<td style="text-align:center">
								<?php echo $rows['insert_date']; ?><br/>
								<i style="color:blue"><?php echo $rows['emp_name']; ?></i>
							</td>
							<td style="">
								
							</td>
							<td style="text-align:center">
								<?php echo $rows['item_quantity']; ?>
							</td>
							<td style="text-align:right;font-weight:bold">
								<?php echo $rows['total_tk']; ?>
							</td>
							
						</tr>
							<?php 
						}
				
				}else{
					echo "";
				}
			}else{
				echo "";
			}
		}else{ //Day wise
			$mstart_dates=$_REQUEST['mstart_date'];
			$mend_dates=$_REQUEST['mend_date'];
			$con="";
			if($master_id!=""){
				
				if(@$mstart_date!="" && @$mend_date!=""){
					$con.="and date(insert_date) between '$mstart_date' and '$mend_date' ";
				}
				
				if($master_id=="all"){
					$master_sql=$conn->query("SELECT sum(`taka`) total_tk,sum(`item_qty`) item_quantity,(select user_name from user where id=wages_details.emp_id limit 0,1) emp_name,(select mobile from user where id=wages_details.emp_id limit 0,1) emp_mobile,wages_details.`emp_id` FROM `wages_details` WHERE `is_active`=1 and `status`=0 and `emp_type`=2 $con GROUP by wages_details.`emp_id`");
				}else{
					$master_sql=$conn->query("SELECT sum(`taka`) total_tk,sum(`item_qty`) item_quantity,(select user_name from user where id=wages_details.emp_id limit 0,1) emp_name,(select mobile from user where id=wages_details.emp_id limit 0,1) emp_mobile,wages_details.`emp_id` FROM `wages_details` WHERE `is_active`=1 and `status`=0 and `emp_type`=2 and `emp_id`='$master_id' $con GROUP by wages_details.`emp_id`");
				}
				mysqli_close($conn);
				if(mysqli_num_rows($master_sql)>0){
					
					$c=0;$sl2=0;
						while($rows=mysqli_fetch_array($master_sql)){
							$c=++$sl2;
						?>
						<tr style="color:<?php echo ($rows['total_tk']=="")? '#8080808f;' : ''; ?>" id="row_master<?php //echo $rows['id']; ?>">
							<td style="text-align:center">
								
								<button id='mmemo_view<?php //echo $rows['id']; ?>' class="btn btn-success form-control" onclick="showKarigorDayWise('2','<?php echo @$rows['emp_id']; ?>','<?php echo @$rows['emp_mobile']; ?>','<?php echo @$rows['emp_name']; ?>','<?php echo @$mstart_date; ?>','<?php echo @$mend_date; ?>')"><?php echo $c; ?></button>
								
							</td>
							<td style="text-align:center;font-weight:bold">
								
							</td>
							<td style="text-align:center">
								<?php echo $mstart_dates; ?><br/>
								<?php echo $mend_dates; ?><br/>
								<i style="color:blue"><?php echo $rows['emp_name']; ?></i>
							</td>
							<td style="">
								
							</td>
							<td style="text-align:center">
								<?php echo $rows['item_quantity']; ?>
							</td>
							<td style="text-align:right;font-weight:bold">
								<?php echo $rows['total_tk']; ?>
							</td>
							
						</tr>
							<?php 
						}
				
				}else{
					echo "";
				}
			}else{
				echo "";
			}
		}
	}
	
	if(isset($_REQUEST['receiveSearchingBtn'])){
		date_default_timezone_set("Asia/Dhaka");
		$date=date("d/m/Y");
		$com_id=$_SESSION['COM_ID'];
		$mstart_date=$_REQUEST['mstart_date'];
		$mend_date=$_REQUEST['mend_date'];
		
		$msearch_order=trim($_REQUEST['msearch_order']);
		
			$con="";
			if($msearch_order!=""){
				$con.="and ord.order_number='$msearch_order' ";
			}
			if(@$mstart_date!="" && @$mend_date!=""){
				$con.="and ord.delivery_date between '$mstart_date' and '$mend_date' and ord.delivery_date is not null ";
			}
			
		$cutting_pending=$conn->query("SELECT ord.*,(select product_name from product where id=ord.item_id limit 0,1) item_name,(select cus_name from dsms where id=ord.dsms_id limit 0,1) cus_name,(select cus_mobile from dsms where id=ord.dsms_id limit 0,1) cus_mobile FROM `order_record` ord WHERE ord.is_active=1 and ord.delivery_qty!=0 and com_id=$com_id $con order by ord.id desc limit 100");
		mysqli_close($conn);	
		
			$sl2=1;$order_tk2=0;$c=0;
			if(mysqli_num_rows($cutting_pending)>0){
				while($row=mysqli_fetch_array($cutting_pending)){
					$c=$sl2++;
					?>
					<tr id="row_received<?php echo $row['id']; ?>">
						<td style="text-align:center">
							<?php if($row['delivery_date']==$date){ ?>
							<button onclick="delDeliveryItem('<?php echo $row['id']; ?>','<?php echo $row['delivery_qty']; ?>');" name='btn' id='delbtns_receive<?php echo $row['id']; ?>' class="btn btn-danger form-control"><?php echo $c; ?></button>
							<?php }else{
								echo $c;
							} ?>
						</td>
						<td style="text-align:center;font-weight:bold">
							<?php echo $row['order_number']; ?>
						</td>
						<td style="text-align:center">
							<?php echo $row['delivery_date']; ?><br/>
							<i style="color:blue"><?php echo $row['cus_name']; ?></i>
						</td>
						<td style="text-align:center">
							<?php echo $row['item_name']; ?>
						</td>
						<td style="text-align:center">
							<?php echo $row['delivery_qty']; ?>
						</td>
						
					</tr>
					<?php 
					}
				}else{
					echo "";
				}
	}
	
		if(isset($_REQUEST['getOrderDetails'])){
		
		?>
		
	  <div class="panel-body">
			<div class="row" id="ord_details_panel">
				<div class="col-xs-12 col-sm-12">
					<div id="src_result">
					</div>
					<input type="hidden" id="last_id_hide" value="3"/>
					
				</div>
				<div class="col-xs-12 col-sm-4">
					<span id="previous_due_tab">
					<!--<p for="comment" style="text-align:right">Previous Total Due:</p>-->
						<input type="hidden" style="font-weight: bold;font-size:18px;font-style: italic;text-align:right" name="previous_due" id="previous_due" class="form-control">
					</span>
				</div>
			</div>
			<button style="" onclick="closeArea();" name="btn" id="morebtn" class="btn btn-danger">Clear</button><span id="load_img"></span>
	  </div>
	
		<?php 
				
	}
	
if(isset($_REQUEST['moneyReceitPrint'])){
		?>
		  <div class="panel-body">
			<button onclick="printOrder();" name="btn" id="printBtns" value="sub" class="btn btn-info">Print</button>
			
				<div class="row">
					<span id="summery_report2"></span>
				</div>
				<button style="" onclick="closeArea();" name="btn" id="morebtn" class="btn btn-danger">Clear</button><span id="load_img"></span>
		  </div>
	<?php 
				
	}

if(isset($_REQUEST['viewEditArea'])){
	@$ord_num=$_REQUEST['ord_num'];
		?>
		  <div class="panel-body">
			 <div class="row">
				<div class="col-xs-12 col-sm-6" style="">
					<button onclick="updateMeasurement();" style="margin-top: 12px;" name="btn" value="sub" id="updatebtn" class="btn btn-warning">Update</button>
					<input type="hidden" id="new_measurement_parameter" />
					<input type="hidden" id="edit_ord_number" value="<?php echo $ord_num; ?>"/>
				<span id="uload"></span>
				</div>
				<div class="col-xs-12 col-sm-6" style="">
					<span id="item_area"></span>
			 
				</div>
			</div>
			 <div class="row">
				 <div class="col-xs-12 col-sm-12" style="">
					<div id="head_measurement"  style="color: black;box-shadow: inset 0 0 1em gray;padding: 15px;margin-top: 10px;"></div>
					<div id="edit_measurement"  style="color: black;box-shadow: inset 0 0 1em gray;padding: 15px;margin-top: 10px;"></div>
				</div>
			</div>
				<button style="float:right" onclick="closeArea();" name="btn" id="morebtn" class="btn btn-success">Close</button><span id="load_img"></span>
		</div>
	<?php 
				
}

if(isset($_REQUEST['getExpenseList'])){
	
		
	$mstart_dates=explode("/",$_REQUEST['kstart_date']);
	$mend_dates=explode("/",$_REQUEST['kend_date']);
	if($_REQUEST['kstart_date']!=""){
		@$mstart_date=$mstart_dates[2].'-'.$mstart_dates[1].'-'.$mstart_dates[0];
	}
	if($_REQUEST['kend_date']!=""){
		@$mend_date=$mend_dates[2].'-'.$mend_dates[1].'-'.$mend_dates[0];
	}
	
		$con="";
		
			if($_REQUEST['searching_status']!=""){
				$searching_status=explode("#sep#",$_REQUEST['searching_status']);
				$etype=$searching_status[0];
				$con.="and ex.expense_type=$etype ";
			}
		
		if(@$mstart_date!="" && @$mend_date!=""){
			$con.="and  date(ex.insert_date) between '$mstart_date' and '$mend_date' ";
		}
		
			$expense_detail=$conn->query("select ex.id,ex.insert_date,ex.expense_type,ex.expense,ex.remarks,(select expense from expense_type where id=ex.expense_type) ex_title from expenses ex where ex.is_active=1 $con order by date(ex.insert_date) desc limit 0,400");
		mysqli_close($conn);	
		?>
		<table id="dynamic-table" class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th style="width: 16%;">ক্রমিক নং</th>
					<th style="text-align:center;width: 20%;">তারিখ</th>
					<th style="">ব্যয়ের ধরণ</th>
					<th style="">মন্তব্য</th>
					<th style="text-align:right">টাকা</th>
				</tr>
			</thead>
		
			<tbody id="searching_tbl">
		<?php 
		
			$sl=0;$i=1;$tot=0;
			if(mysqli_num_rows($expense_detail)>0){
				while($row=mysqli_fetch_array($expense_detail)){
					$sl=$i++;
					$tbl_id=$row['id'];
					$tot+=$row['expense'];
					?>
					<tr id="delrow<?php echo $tbl_id; ?>">
					<td>
					<button onclick="delExpense('<?php echo $tbl_id; ?>','<?php echo $sl; ?>')" class="btn btn-danger form-control" id="delExbtn<?php echo $sl; ?>"><?php echo $sl; ?></button>
					</td>
					<td style="text-align:center"><?php echo $row['insert_date']; ?></td>
					<td><?php echo $row['ex_title']; ?></td>
					<td><?php echo $row['remarks']; ?></td>
					<td style="text-align:right"><?php echo $row['expense'] ?></td>
					</tr>
					<?php 
				}
			}
		?>
			<tr style="font-weight: bold;">
				<td colspan="4" style="text-align:right">Total</td>
				<td style="text-align:right"><?php echo $tot; ?></td>
			</tr>
		</tbody>
		<input type="hidden" id="ex_last_id" value="<?php echo $sl; ?>"/>

	</table>
	<div id="expense_not_found"></div>
	<?php 
		
}

if(isset($_REQUEST['getCustomerFabricsOrderList'])){
		date_default_timezone_set("Asia/Dhaka");
		$date=date("Y-m-d");
		$com_id=$_SESSION['COM_ID'];
		$search_ord_num=trim($_REQUEST['search_ord_num']);
		$cus_name_mobile=trim($_REQUEST['cus_name_mobile']);
		
		$mstart_dates=explode("/",$_REQUEST['kstart_date']);
		$mend_dates=explode("/",$_REQUEST['kend_date']);
		if($_REQUEST['kstart_date']!=""){
			@$mstart_date=$mstart_dates[2].'-'.$mstart_dates[1].'-'.$mstart_dates[0];
		}
		if($_REQUEST['kend_date']!=""){
			@$mend_date=$mend_dates[2].'-'.$mend_dates[1].'-'.$mend_dates[0];
		}
		$con="";
		if(@$mstart_date!="" && @$mend_date!=""){
			$con.="and date(insert_date) between '$mstart_date' and '$mend_date' ";
		}
		
		
		
			
			if($search_ord_num!=""){
				$con.="and id like '%$search_ord_num%' ";
			}
			if($cus_name_mobile!=""){
				$con.="and (cus_mobile like '%$cus_name_mobile%') ";
			}
		if(@$mstart_date=="" && @$mend_date=="" && $search_ord_num=="" && $cus_name_mobile==""){
			$con.="and date(insert_date)='$date' ";
		}
		$sales_details=$conn->query("SELECT id,cus_mobile,insert_date,f_total,others_tk,discount_tk,total_receive,(select cus_name from customer where cus_mobile=direct_sale_head.cus_mobile limit 0,1) cus_name,(select id from customer where cus_mobile=direct_sale_head.cus_mobile limit 0,1) cus_id,(select order_number from direct_sale where dstid=direct_sale_head.id and is_active=1 limit 0,1) ord_num FROM `direct_sale_head` WHERE com_id=$com_id and is_active!=0 and in_out_status=0 and is_order=0 $con order by id desc limit 0,200");
		mysqli_close($conn);	
		
			$sl2=1;$order_tk2=0;$c=0;
		if(mysqli_num_rows($sales_details)>0){
		?>
			<button onclick="printOrder();" style="margin-right:15px" name="btn" id="printBtns" value="sub" class="btn btn-info">Print</button>
			<span id="clear_action" onclick="closeArea();" style="color:red;font-weight:bold;cursor:pointer">Clear</span>
			<table id="example" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th style="text-align:center">Fabrics Order</th>
						<th style="">Customer</th>
						<th style="text-align:center">Mobile</th>
						<th>Sales Date</th>
						<th style="text-align:right">Net Total</th>
						<th style="text-align:right">discount(Tk)</th>
						<th style="text-align:right">Total(Tk)</th>
						<th style="text-align:right">Advance</th>
						<th style="text-align:right">Due</th>
						
						<th style="text-align:center">Action</th>
					</tr>
				</thead>
				<tbody id="tbl_two2">
					<?php 
						$i=1;$ttk=0;$others=0;$total=0;$gtotal=0;
						while($row=mysqli_fetch_array($sales_details)){
							$total_receive=$row['total_receive'];
							$ttk=$row['f_total'];
							$others=$row['others_tk'];
							$discount=$row['discount_tk'];
							$total=($ttk+$others)-$discount;
							$due=$total-$total_receive;
							$gtotal+=$total;
							?>
								<tr id="frow<?php echo $row['id']; ?>">
									<td style="text-align:center">
										<?php echo $row['id']; ?>
									</td>
									<th style=""><?php echo $row['cus_name']; ?></th>
									<th style="text-align:center;width: 12%;" id="cus_mobile_row<?php echo $row['id']; ?>"><span style="text-decoration: underline dashed red;cursor: pointer;" onclick="updateAnyColumn('<?php echo $row['id']; ?>','<?php echo $row['cus_mobile']; ?>','<?php echo $row['cus_id']; ?>');"><?php echo $row['cus_mobile']; ?></span></th>
									<th><?php echo $row['insert_date']; ?></th>
									<th style="text-align:right" id="netpay<?php echo $row['id']; ?>"><?php echo $ttk; ?></th>
									<th style="text-align:right" id="tbl_discount_tk<?php echo $row['id']; ?>"><?php echo $discount; ?></th>
									<th style="text-align:right" id="tbl_total_tk<?php echo $row['id']; ?>"><?php echo $total; ?></th>
									<th style="text-align:right"><?php echo $total_receive; ?></th>
									<th style="text-align:right"><?php echo $due; ?></th>
									<th style="text-align:center;"><?php 
										if($row['ord_num']=="" || $row['ord_num']=="0"){
											?>
											<span style="cursor: pointer;color:#ff0000c7;" onclick="showDetailSales('<?php echo $row['id']; ?>');"><i>Edit</i></span> | 
											<span style="cursor: pointer;color:#0000ffd1;" onclick="dateWisePrint('<?php echo $row['id']; ?>','10');"><i>View</i></span>
											<?php 
										}
										?>
									</th>
								</tr>
							<?php 
						}
					
					?>
					<tr>
						<th colspan="7" style="text-align:right">Total: </th>
						<th style="text-align:right"><?php echo $gtotal; ?></th>
					</tr>
					
				</tbody>
			</table>
		<?php 
		}else{
			echo 2;
		}
			
	}
	
if(isset($_REQUEST['getCustomerList'])){
		$com_id=$_SESSION['COM_ID'];
		$search_ord_num=trim($_REQUEST['search_ord_num']);
		$cus_name_mobile=trim($_REQUEST['cus_name_mobile']);
		$searching_status=$_REQUEST['searching_status'];
		
		$mstart_dates=explode("/",$_REQUEST['kstart_date']);
		$mend_dates=explode("/",$_REQUEST['kend_date']);
		if($_REQUEST['kstart_date']!=""){
			@$mstart_date=$mstart_dates[2].'-'.$mstart_dates[1].'-'.$mstart_dates[0];
		}
		if($_REQUEST['kend_date']!=""){
			@$mend_date=$mend_dates[2].'-'.$mend_dates[1].'-'.$mend_dates[0];
		}
		
		
		
			$con="";
			if($search_ord_num!=""){
				$con.="and ord.phy_ord_num like '%$search_ord_num%' ";
			}
			if($cus_name_mobile!=""){
				$con.="and (ord.cus_name like '%$cus_name_mobile%' or ord.cus_mobile like '%$cus_name_mobile%') ";
			}
			
			if($searching_status!=""){
				if(@$mstart_date!="" && @$mend_date!=""){
					if($searching_status==1){ //order date
						$con.="and date(ord.insert_date) between '$mstart_date' and '$mend_date' ";
					}else if($searching_status==2){ //delivery date
						$con.="and ord.dv_date is not null and date(ord.dv_date) between '$mstart_date' and '$mend_date' ";
					}else if($searching_status==3){ //is received 
						$con.="and ord.factory_receive_date is not null and date(ord.factory_receive_date) between '$mstart_date' and '$mend_date' ";
					}else if($searching_status==4){ //is not received 
						$con.="and ord.factory_receive_date is null ";
					}else if($searching_status==5){ //is delivered
						$con.="and ord.phy_dv_date is not null and date(ord.phy_dv_date) between '$mstart_date' and '$mend_date' ";
					}else if($searching_status==6){ //is not delivered
						$con.="and ord.phy_dv_date is null ";
					}if($searching_status==7 || $searching_status==8 || $searching_status==9){ //is paid
						$con.="and date(ord.insert_date) between '$mstart_date' and '$mend_date' ";
					}
					
				}else{
					if($searching_status==2){ //delivery date
						$con.="and ord.dv_date is not null ";
					}else if($searching_status==3){ //is received 
						$con.="and ord.factory_receive_date is not null ";
					}else if($searching_status==4){ //is not received 
						$con.="and ord.factory_receive_date is null ";
					}else if($searching_status==5){ //is delivered
						$con.="and ord.phy_dv_date is not null ";
					}else if($searching_status==6){ //is not delivered
						$con.="and ord.phy_dv_date is null ";
					}
				}
				
			}
	
		$pending_order=$conn->query("SELECT ord.*,date(ord.insert_date) insert_date,date(ord.insert_date) insert_date,(select sum(amount) from accounting where dsms_id=ord.id and is_active=1 and pay_status in(1,0)) tpay FROM `dsms` ord WHERE ord.is_active=1 and com_id=$com_id $con order by id desc limit 0,300");
		mysqli_close($conn);	
		
			$sl2=1;$order_tk2=0;$c=0;
			if(mysqli_num_rows($pending_order)>0){
				while($row=mysqli_fetch_array($pending_order)){
					$c=$sl2++;
					@$factory_receive_date=$row['factory_receive_date'];
					if($row['tpay']=="" || $row['tpay']==0){
						$color="red";
					}
					if($row['tpay']==$row['amount']){
						$color="#177617;";
					}
					if($row['tpay']>0 && $row['tpay']<$row['amount']){
						$color="#8a6d3b;";
					}
					if($searching_status==7){
						if($row['tpay']==$row['amount']){
							$color="#177617;";
						?>
						<tr id="cleft_row<?php echo $row['id']; ?>" style="color:<?php echo @$color; ?>">
						<td style="text-align:center"><?php echo $c; ?></td>
						<td style="text-align:center;font-weight:bold">
							<span style='color:#180cac;cursor: pointer;' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$row['phy_ord_num']; ?>')"><b><?php echo $row['phy_ord_num']; ?></b></span>
						</td>
						<td>
							<?php echo $row['cus_name']; ?>
						</td>
						<td style="text-align:center">
							<?php echo $row['cus_mobile']; ?>
						</td>
						
						<td style="text-align:center">
							<?php echo date_format(date_create($row['insert_date']),"d/m/Y"); ?>
						</td>
						<!--<td style="text-align:center;color:#a01546;">
							<?php echo (@$row['factory_receive_date']!="")? date_format(date_create($row['factory_receive_date']),"d/m/Y") : ''; ?>
						</td>-->
						<td style="text-align:center;color:blue">
							<?php echo date_format(date_create($row['dv_date']),"d/m/Y"); ?>
						</td>
						<td style="text-align:right;font-weight:bold">
							<?php echo ($row['amount']+$row['discount']); ?>
						</td>
						<td style="text-align:right;font-weight:bold">
							<?php echo $row['discount']; ?>
						</td>
						<td style="text-align:right;font-weight:bold">
							<?php echo $row['tpay']; ?>
						</td>
						<td style="text-align:right;font-weight:bold">
							<?php echo ($row['amount']-$row['tpay']); ?>
						</td>
						<td style="text-align:center;cursor:pointer">
							<?php 
							if(isset($row['phy_dv_date'])){
								@$phy_dv_date=date_format(date_create($row['phy_dv_date']),"d/m/Y");
								echo "<span style='font-weight: bold;' title='Physical Delivery Date: $phy_dv_date'>Delivered</span>";
							}else if(isset($factory_receive_date)){
								@$factory_receive_date=date_format(date_create($factory_receive_date),"d/m/Y");
								echo "<span style='font-weight: bold;' title='Physical Delivery Date: $factory_receive_date'>Received</span>";
							}else{
								echo "<span style=''><i>Pending</i></span>";
							}
							
							?>
						</td>
						<td style="text-align:center;cursor: pointer;">
							<span onclick="viewEditArea('<?php echo @$row['phy_ord_num']; ?>');"><i>Edit</i></span> | 
							<span onclick="getOrderDetails('<?php echo @$row['phy_ord_num']; ?>');">View</span> | 
							<span style="color: blue;" onclick="moneyReceitPrint('<?php echo @$row['phy_ord_num']; ?>');">Print</span>
						</td>
						</tr>
						<?php 
						}
					}else if($searching_status==8){
						if($row['tpay']=="" || $row['tpay']==0){
							$color="red";
						?>
						<tr id="cleft_row<?php echo $row['id']; ?>" style="color:<?php echo $color; ?>">
						<td style="text-align:center"><?php echo $c; ?></td>
						<td style="text-align:center;font-weight:bold">
							<span style='color:#180cac;cursor: pointer;' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$row['phy_ord_num']; ?>')"><b><?php echo $row['phy_ord_num']; ?></b></span>
						</td>
						<td>
							<?php echo $row['cus_name']; ?>
						</td>
						<td style="text-align:center">
							<?php echo $row['cus_mobile']; ?>
						</td>
						
						<td style="text-align:center">
							<?php echo date_format(date_create($row['insert_date']),"d/m/Y"); ?>
						</td>
						<!--<td style="text-align:center;color:#a01546;">
							<?php echo (@$row['factory_receive_date']!="")? date_format(date_create($row['factory_receive_date']),"d/m/Y") : ''; ?>
						</td>-->
						<td style="text-align:center;color:blue">
							<?php echo date_format(date_create($row['dv_date']),"d/m/Y"); ?>
						</td>
						<td style="text-align:right;font-weight:bold">
							<?php echo ($row['amount']+$row['discount']); ?>
						</td>
						<td style="text-align:right;font-weight:bold">
							<?php echo $row['discount']; ?>
						</td>
						<td style="text-align:right;font-weight:bold">
							<?php echo $row['tpay']; ?>
						</td>
						<td style="text-align:right;font-weight:bold">
							<?php echo ($row['amount']-$row['tpay']); ?>
						</td>
						<td style="text-align:center;cursor:pointer">
							<?php 
							if(isset($row['phy_dv_date'])){
								@$phy_dv_date=date_format(date_create($row['phy_dv_date']),"d/m/Y");
								echo "<span style='font-weight: bold;' title='Physical Delivery Date: $phy_dv_date'>Delivered</span>";
							}else if(isset($factory_receive_date)){
								@$factory_receive_date=date_format(date_create($factory_receive_date),"d/m/Y");
								echo "<span style='font-weight: bold;' title='Physical Delivery Date: $factory_receive_date'>Received</span>";
							}else{
								echo "<span style=''><i>Pending</i></span>";
							}
							
							?>
						</td>
						<td style="text-align:center;cursor: pointer;">
							<span onclick="viewEditArea('<?php echo @$row['phy_ord_num']; ?>');"><i>Edit</i></span> | 
							<span onclick="getOrderDetails('<?php echo @$row['phy_ord_num']; ?>');">View</span> | 
							<span style="color: blue;" onclick="moneyReceitPrint('<?php echo @$row['phy_ord_num']; ?>');">Print</span>
						</td>
						</tr>
						<?php 
						}
					}else if($searching_status==9){
						if($row['tpay']>0 && $row['tpay']<$row['amount']){
							$color="#8a6d3b;";
						?>
						<tr id="cleft_row<?php echo $row['id']; ?>" style="color:<?php echo $color; ?>">
						<td style="text-align:center"><?php echo $c; ?></td>
						<td style="text-align:center;font-weight:bold">
							<span style='color:#180cac;cursor: pointer;' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$row['phy_ord_num']; ?>')"><b><?php echo $row['phy_ord_num']; ?></b></span>
						</td>
						<td>
							<?php echo $row['cus_name']; ?>
						</td>
						<td style="text-align:center">
							<?php echo $row['cus_mobile']; ?>
						</td>
						
						<td style="text-align:center">
							<?php echo date_format(date_create($row['insert_date']),"d/m/Y"); ?>
						</td>
						<!--<td style="text-align:center;color:#a01546;">
							<?php echo (@$row['factory_receive_date']!="")? date_format(date_create($row['factory_receive_date']),"d/m/Y") : ''; ?>
						</td>-->
						<td style="text-align:center;color:blue">
							<?php echo date_format(date_create($row['dv_date']),"d/m/Y"); ?>
						</td>
						<td style="text-align:right;font-weight:bold">
							<?php echo ($row['amount']+$row['discount']); ?>
						</td>
						<td style="text-align:right;font-weight:bold">
							<?php echo $row['discount']; ?>
						</td>
						<td style="text-align:right;font-weight:bold">
							<?php echo $row['tpay']; ?>
						</td>
						<td style="text-align:right;font-weight:bold">
							<?php echo ($row['amount']-$row['tpay']); ?>
						</td>
						<td style="text-align:center;cursor:pointer">
							<?php 
							if(isset($row['phy_dv_date'])){
								@$phy_dv_date=date_format(date_create($row['phy_dv_date']),"d/m/Y");
								echo "<span style='font-weight: bold;' title='Physical Delivery Date: $phy_dv_date'>Delivered</span>";
							}else if(isset($factory_receive_date)){
								@$factory_receive_date=date_format(date_create($factory_receive_date),"d/m/Y");
								echo "<span style='font-weight: bold;' title='Physical Delivery Date: $factory_receive_date'>Received</span>";
							}else{
								echo "<span style=''><i>Pending</i></span>";
							}
							
							?>
						</td>
						<td style="text-align:center;cursor: pointer;">
							<span onclick="viewEditArea('<?php echo @$row['phy_ord_num']; ?>');"><i>Edit</i></span> | 
							<span onclick="getOrderDetails('<?php echo @$row['phy_ord_num']; ?>');">View</span> | 
							<span style="color: blue;" onclick="moneyReceitPrint('<?php echo @$row['phy_ord_num']; ?>');">Print</span>
						</td>
						</tr>
						<?php 
						}
					}else{
						?>
						<tr id="cleft_row<?php echo $row['id']; ?>" style="color:<?php echo @$color; ?>">
						<td style="text-align:center"><?php echo $c; ?></td>
						<td style="text-align:center;font-weight:bold">
							<span style='color:#180cac;cursor: pointer;' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$row['phy_ord_num']; ?>')"><b><?php echo $row['phy_ord_num']; ?></b></span>
						</td>
						<td>
							<?php echo $row['cus_name']; ?>
						</td>
						<td style="text-align:center">
							<?php echo $row['cus_mobile']; ?>
						</td>
						
						<td style="text-align:center">
							<?php echo date_format(date_create($row['insert_date']),"d/m/Y"); ?>
						</td>
						<!--<td style="text-align:center;color:#a01546;">
							<?php echo (@$row['factory_receive_date']!="")? date_format(date_create($row['factory_receive_date']),"d/m/Y") : ''; ?>
						</td>-->
						<td style="text-align:center;color:blue">
							<?php echo date_format(date_create($row['dv_date']),"d/m/Y"); ?>
						</td>
						<td style="text-align:right;font-weight:bold">
							<?php echo ($row['amount']+$row['discount']); ?>
						</td>
						<td style="text-align:right;font-weight:bold">
							<?php echo $row['discount']; ?>
						</td>
						<td style="text-align:right;font-weight:bold">
							<?php echo $row['tpay']; ?>
						</td>
						<td style="text-align:right;font-weight:bold">
							<?php echo ($row['amount']-$row['tpay']); ?>
						</td>
						<td style="text-align:center;cursor:pointer">
							<?php 
							if(isset($row['phy_dv_date'])){
								@$phy_dv_date=date_format(date_create($row['phy_dv_date']),"d/m/Y");
								echo "<span style='font-weight: bold;' title='Physical Delivery Date: $phy_dv_date'>Delivered</span>";
							}else if(isset($factory_receive_date)){
								@$factory_receive_date=date_format(date_create($factory_receive_date),"d/m/Y");
								echo "<span style='font-weight: bold;' title='Physical Delivery Date: $factory_receive_date'>Received</span>";
							}else{
								echo "<span style=''><i>Pending</i></span>";
							}
							
							?>
						</td>
						<td style="text-align:center;cursor: pointer;">
							<span onclick="viewEditArea('<?php echo @$row['phy_ord_num']; ?>');"><i>Edit</i></span> | 
							<span onclick="getOrderDetails('<?php echo @$row['phy_ord_num']; ?>');">View</span> | 
							<span style="color: blue;" onclick="moneyReceitPrint('<?php echo @$row['phy_ord_num']; ?>');">Print</span>
						</td>
						</tr>
						<?php 
					}
					}
				}else{
					echo "";
				}
			
	}
	

	
	if(isset($_REQUEST['delDetailSales'])){
		$com_id=$_SESSION['COM_ID'];
		$user_id=$_SESSION['USER_ID'];
		$headid=$_REQUEST['headid'];
		$item_id=$_REQUEST['item_id'];
		$item_qty=$_REQUEST['item_qty'];
		$deltblid=$_REQUEST['deltblid'];
		$price=$_REQUEST['price'];
		@$ord_num=$_REQUEST['ord_num'];
		$head_tbl=$conn->query("select sh.f_total,sh.discount,sh.discount_tk,sh.total_receive,(select id from customer where cus_mobile=sh.cus_mobile and is_active=1) customer_id from direct_sale_head sh where sh.is_active!=0 and sh.com_id=$com_id and sh.id=$headid");
		$row=mysqli_fetch_array($head_tbl);
		$f_total=floatval($row['f_total']);
		$discount=floatval($row['discount']);
		$discount_tk=floatval($row['discount_tk']);
		$total_receive=floatval($row['total_receive']);
		$customer_id=$row['customer_id'];
		$ofprice=$adtdk=round($f_total-($f_total*$discount)/100);
		$query=$conn->query("update direct_sale set is_active=0,update_by='$user_id' where com_id=$com_id and id='$deltblid'");
		if($query){
			$after_deduction=($adtdk-$price);
			$f_total=round((($after_deduction*100)/(100-$discount)),2);
			 $receive_deduction=round(($f_total-$total_receive),2);
			/* if($total_receive>=0){
				$receive_deduct=$receive_deduction;
				
			}else{
				$receive_deduct=0;
			}  */
			//$receive_deduct=$receive_deduction; ,total_receive='$f_total'
			$conn->query("update direct_sale_head set f_total='$f_total' where com_id=$com_id and id='$headid'");
			
			
			if($ord_num!='0' && is_numeric($ord_num)==1){
				$conn->query("update dsms m set m.amount=(m.amount-$price) where m.com_id=$com_id and m.phy_ord_num='$ord_num'");
				$dsmsid=$conn->query("SELECT * FROM `dsms` mh WHERE mh.is_active=1 and mh.phy_ord_num='$ord_num'"); // and mh.com_id=$com_id
				$dsmsid_row=mysqli_fetch_array($dsmsid);
				$headid=$dsmsid_row['id'];
			}
			
				$transaction_tbl=$conn->query("select * from transaction where accounting_id='$headid'");
				while($rows=mysqli_fetch_array($transaction_tbl)){
					$com_id=$rows['com_id'];
					$cus_id=$rows['cus_id'];
					$amount=$rows['amount'];
					$remarks=$rows['remarks']." | আইটেম টি কাস্টমার মেকিং করে নেয় নি |";
					$insert_by=$rows['insert_by'];
					$transaction_type=$rows['transaction_type'];
					$accounting_id=$rows['accounting_id'];
					$method_name=$rows['method_name'];
					$status=$rows['status'];
					
					if($status==1){
						$receiveamount=$rows['amount'];
					}else{ //0=due 
						$dueamount=$rows['amount']-$price;
					}
				}
				//$conn->query("update transaction set is_active=0 where accounting_id='$dsms_id' and is_active=1");
				$conn->query("update transaction set amount='$dueamount',remarks='$remarks' where accounting_id='$headid' and is_active=1 and status=0");
				if($dueamount<=$receiveamount){
					$receiveamount=$dueamount;
				}
				
				$conn->query("update transaction set amount='$receiveamount',remarks='$remarks' where accounting_id='$headid' and is_active=1 and status=1");
				
				
			$transaction_last_id=$conn->query("SELECT * FROM `update_due` mh WHERE mh.is_active=1 and mh.cus_id='$customer_id' order by mh.id desc limit 0,1"); // and mh.com_id=$com_id
					$transaction_last_id_row=mysqli_fetch_array($transaction_last_id);
					$last_due=$transaction_last_id_row['last_due'];
					$id=$transaction_last_id_row['id'];
					if($price>$last_due){
						$conn->query("update update_due set last_due='0' where id=$id and is_active=1");
					}else{
						$last_due=$last_due-$price;
						$conn->query("update update_due set last_due='$last_due' where id=$id and is_active=1");
					}
			
			//dueTblUpdate($row['customer_id'],0,1,"ফ্যাব্রিক্স After sales return $total_receive tk.",'0');
			if($_SESSION['IS_STOCK']==1){ // maintain stock
				$product_tbl=$conn->query("select stock_qty,total_price,avg_price from product where id=$item_id");
				if($product_tbl){
					$rows=mysqli_fetch_array($product_tbl);
					$previous_item_qty=$rows['stock_qty'];
					$previous_avg_price=$rows['avg_price'];
					$present_qty=($previous_item_qty+$item_qty);
					$present_tot_price=round(($present_qty*$previous_avg_price),2);
					$conn->query("update product set stock_qty='$present_qty',total_price='$present_tot_price',avg_price='$previous_avg_price' where id='$item_id'");
				}
			}
			echo 1;
			
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['updateFabQty'])){
		$com_id=$_SESSION['COM_ID'];
		$user_id=$_SESSION['USER_ID'];
		
				
		$headid=$_REQUEST['sales_head_id'];
		$item_id=$_REQUEST['item_id'];
		$item_qty=$_REQUEST['item_qty'];
		$deltblid=$_REQUEST['sales_tbl_id'];
		$item_per_price=$_REQUEST['item_per_price'];
		
		$edit_fab_qty=$_REQUEST['edit_fab_qty'];
		if($edit_fab_qty>$item_qty){ //added new qty 
			$added_qty=($edit_fab_qty-$item_qty);
			$price=($added_qty*$item_per_price); //have to add tk from previous tk 
			
			//$price=$_REQUEST['price'];
			@$ord_num=$_REQUEST['ord_num'];
			$head_tbl=$conn->query("select sh.f_total,sh.discount,sh.discount_tk,sh.total_receive,(select id from customer where cus_mobile=sh.cus_mobile and is_active=1 limit 0,1) customer_id from direct_sale_head sh where sh.is_active!=0 and sh.com_id=$com_id and sh.id=$headid");
			$row=mysqli_fetch_array($head_tbl);
			$f_total=floatval($row['f_total']);
			$discount=floatval($row['discount']);
			$discount_tk=floatval($row['discount_tk']);
			$total_receive=floatval($row['total_receive']);
			$customer_id=$row['customer_id'];
			//$ofprice=$adtdk=round($f_total-($f_total*$discount)/100);
			$query=$conn->query("update direct_sale set item_qty='$edit_fab_qty',update_by='$user_id' where com_id=$com_id and id='$deltblid'");
			if($query){
				$f_total=($f_total+$price);
				//$f_total=round((($after_deduction*100)/(100-$discount)),2);
				//$receive_deduction=round(($f_total-$total_receive),2);
				
				//$receive_deduct=$receive_deduction; ,total_receive='$f_total'
				$conn->query("update direct_sale_head set f_total='$f_total' where com_id=$com_id and id='$headid'");
				
				
				if($ord_num!='0' && is_numeric($ord_num)==1){
					$conn->query("update dsms m set m.amount=(m.amount+$price) where m.com_id=$com_id and m.phy_ord_num='$ord_num'");
					$dsmsid=$conn->query("SELECT * FROM `dsms` mh WHERE mh.is_active=1 and mh.phy_ord_num='$ord_num'"); // and mh.com_id=$com_id
					$dsmsid_row=mysqli_fetch_array($dsmsid);
					$headid=$dsmsid_row['id'];
				}
				
					$transaction_tbl=$conn->query("select * from transaction where accounting_id='$headid'");
					while($rows=mysqli_fetch_array($transaction_tbl)){
						$com_id=$rows['com_id'];
						$cus_id=$rows['cus_id'];
						$amount=$rows['amount'];
						$remarks=$rows['remarks']." | আইটেম টি কাস্টমার মেকিং করে নেয় নি |";
						$insert_by=$rows['insert_by'];
						$transaction_type=$rows['transaction_type'];
						$accounting_id=$rows['accounting_id'];
						$method_name=$rows['method_name'];
						$status=$rows['status'];
						
						if($status==1){
							$receiveamount=$rows['amount'];
						}else{ //0=due 
							$dueamount=$rows['amount']+$price;
						}
					}
					//$conn->query("update transaction set is_active=0 where accounting_id='$dsms_id' and is_active=1");
					$conn->query("update transaction set amount='$dueamount',remarks='$remarks' where accounting_id='$headid' and is_active=1 and status=0");
					if($dueamount<=$receiveamount){
						$receiveamount=$dueamount;
					}
					
					$conn->query("update transaction set amount='$receiveamount',remarks='$remarks' where accounting_id='$headid' and is_active=1 and status=1");
					
					
				$transaction_last_id=$conn->query("SELECT * FROM `update_due` mh WHERE mh.is_active=1 and mh.cus_id='$customer_id' order by mh.id desc limit 0,1"); // and mh.com_id=$com_id
						$transaction_last_id_row=mysqli_fetch_array($transaction_last_id);
						$last_due=$transaction_last_id_row['last_due'];
						$id=$transaction_last_id_row['id'];
						if($price>$last_due){
							$conn->query("update update_due set last_due='0' where id=$id and is_active=1");
						}else{
							$last_due=$last_due+$price;
							$conn->query("update update_due set last_due='$last_due' where id=$id and is_active=1");
						}
				
				//dueTblUpdate($row['customer_id'],0,1,"ফ্যাব্রিক্স After sales return $total_receive tk.",'0');
				if($_SESSION['IS_STOCK']==1){ // maintain stock
					$product_tbl=$conn->query("select stock_qty,total_price,avg_price from product where id=$item_id");
					if($product_tbl){
						$rows=mysqli_fetch_array($product_tbl);
						$previous_item_qty=$rows['stock_qty'];
						$previous_avg_price=$rows['avg_price'];
						$present_qty=($previous_item_qty-$added_qty);
						$present_tot_price=round(($present_qty*$previous_avg_price),2);
						$conn->query("update product set stock_qty='$present_qty',total_price='$present_tot_price',avg_price='$previous_avg_price' where id='$item_id'");
					}
				}
				echo 1;
				
			}else{
				echo 2;
			}
		}else{ // deducted item qty
			$deducted_qty=($item_qty-$edit_fab_qty);
			$price=($deducted_qty*$item_per_price); //have to deduct tk from previous tk
			
			//$price=$_REQUEST['price'];
			@$ord_num=$_REQUEST['ord_num'];
			$head_tbl=$conn->query("select sh.f_total,sh.discount,sh.discount_tk,sh.total_receive,(select id from customer where cus_mobile=sh.cus_mobile and is_active=1 limit 0,1) customer_id from direct_sale_head sh where sh.is_active!=0 and sh.com_id=$com_id and sh.id=$headid");
			$row=mysqli_fetch_array($head_tbl);
			$f_total=floatval($row['f_total']);
			$discount=floatval($row['discount']);
			$discount_tk=floatval($row['discount_tk']);
			$total_receive=floatval($row['total_receive']);
			$customer_id=$row['customer_id'];
			$ofprice=$adtdk=round($f_total-($f_total*$discount)/100);
			$query=$conn->query("update direct_sale set item_qty='$edit_fab_qty',update_by='$user_id' where com_id=$com_id and id='$deltblid'");
			if($query){
				$after_deduction=($adtdk-$price);
				$f_total=round((($after_deduction*100)/(100-$discount)),2);
				$receive_deduction=round(($f_total-$total_receive),2);
				
				//$receive_deduct=$receive_deduction; ,total_receive='$f_total'
				$conn->query("update direct_sale_head set f_total='$f_total' where com_id=$com_id and id='$headid'");
				
				
				if($ord_num!='0' && is_numeric($ord_num)==1){
					$conn->query("update dsms m set m.amount=(m.amount-$price) where m.com_id=$com_id and m.phy_ord_num='$ord_num'");
					$dsmsid=$conn->query("SELECT * FROM `dsms` mh WHERE mh.is_active=1 and mh.phy_ord_num='$ord_num'"); // and mh.com_id=$com_id
					$dsmsid_row=mysqli_fetch_array($dsmsid);
					$headid=$dsmsid_row['id'];
				}
				
					$transaction_tbl=$conn->query("select * from transaction where accounting_id='$headid'");
					while($rows=mysqli_fetch_array($transaction_tbl)){
						$com_id=$rows['com_id'];
						$cus_id=$rows['cus_id'];
						$amount=$rows['amount'];
						$remarks=$rows['remarks']." | আইটেম টি কাস্টমার মেকিং করে নেয় নি |";
						$insert_by=$rows['insert_by'];
						$transaction_type=$rows['transaction_type'];
						$accounting_id=$rows['accounting_id'];
						$method_name=$rows['method_name'];
						$status=$rows['status'];
						
						if($status==1){
							$receiveamount=$rows['amount'];
						}else{ //0=due 
							$dueamount=$rows['amount']-$price;
						}
					}
					//$conn->query("update transaction set is_active=0 where accounting_id='$dsms_id' and is_active=1");
					$conn->query("update transaction set amount='$dueamount',remarks='$remarks' where accounting_id='$headid' and is_active=1 and status=0");
					if($dueamount<=$receiveamount){
						$receiveamount=$dueamount;
					}
					
					$conn->query("update transaction set amount='$receiveamount',remarks='$remarks' where accounting_id='$headid' and is_active=1 and status=1");
					
					
				$transaction_last_id=$conn->query("SELECT * FROM `update_due` mh WHERE mh.is_active=1 and mh.cus_id='$customer_id' order by mh.id desc limit 0,1"); // and mh.com_id=$com_id
						$transaction_last_id_row=mysqli_fetch_array($transaction_last_id);
						$last_due=$transaction_last_id_row['last_due'];
						$id=$transaction_last_id_row['id'];
						if($price>$last_due){
							$conn->query("update update_due set last_due='0' where id=$id and is_active=1");
						}else{
							$last_due=$last_due-$price;
							$conn->query("update update_due set last_due='$last_due' where id=$id and is_active=1");
						}
				
				//dueTblUpdate($row['customer_id'],0,1,"ফ্যাব্রিক্স After sales return $total_receive tk.",'0');
				if($_SESSION['IS_STOCK']==1){ // maintain stock
					$product_tbl=$conn->query("select stock_qty,total_price,avg_price from product where id=$item_id");
					if($product_tbl){
						$rows=mysqli_fetch_array($product_tbl);
						$previous_item_qty=$rows['stock_qty'];
						$previous_avg_price=$rows['avg_price'];
						$present_qty=($previous_item_qty+$deducted_qty);
						$present_tot_price=round(($present_qty*$previous_avg_price),2);
						$conn->query("update product set stock_qty='$present_qty',total_price='$present_tot_price',avg_price='$previous_avg_price' where id='$item_id'");
					}
				}
				echo 1;
				
			}else{
				echo 2;
			}
		}
		
		
	}
	
	if(isset($_REQUEST['liveCheckStockQty'])){
		$com_id=($_SESSION['COM_ID']);
				
		$item_id=$_REQUEST['item_id'];
		$edit_fab_qty=$_REQUEST['edit_fab_qty'];
		if($_SESSION['IS_STOCK']==1){
			$query=$conn->query("select stock_qty from product where id=$item_id");
			if($query){
				$row=mysqli_fetch_array($query);
				$stock_qty=$row['stock_qty'];
				if($edit_fab_qty>$stock_qty){
					echo 3;
				}else{
					echo 1;
				}
			}else{
				echo 2;
			}
		}else{
			echo 1;
		}
	}
	
	if(isset($_REQUEST['rentPayment'])){
		$com_id=($_SESSION['COM_ID']);
		$pdate=date('Y-m-d');	
		$tbl_id=$_REQUEST['tbl_id'];
		$pay_amount=trim($_REQUEST['pay_amount']);
		$query=$conn->query("update direct_sale_head set payment_date='$pdate',payment_status='Paid',due_tk='$pay_amount' where id=$tbl_id");
		if($query){
			echo 1;
		}else{
			echo 2;
		}
	
	}
	
	if(isset($_REQUEST['AfterOrderDeleteItem'])){
		$com_id=$_SESSION['COM_ID'];
		$user_id=$_SESSION['USER_ID'];
		$ord_tbl_id=$_REQUEST['ord_tbl_id'];
		$item_id=$_REQUEST['item_id'];
		$design_cost=$_REQUEST['design_cost'];
		@$amount_cost=$_REQUEST['amount_cost'];
		@$dsms_id=$_REQUEST['dsms_id'];
		@$item_name=$_REQUEST['item_name'];
		$head_tbl=$conn->query("select amount,design_cost,previous_total_due,(select id from customer where cus_mobile=ds.cus_mobile and is_active=1 limit 0,1) customer_id from dsms ds where ds.id=$dsms_id");
		$row=mysqli_fetch_array($head_tbl);
		$customer_id=$row['customer_id'];
		$query=$conn->query("update order_record set is_active=2 where id=$ord_tbl_id");
		if($query){
			
			$transaction_tbl=$conn->query("select * from transaction where accounting_id='$dsms_id'");
				while($rows=mysqli_fetch_array($transaction_tbl)){
					$com_id=$rows['com_id'];
					$cus_id=$rows['cus_id'];
					$amount=$rows['amount'];
					$remarks=$rows['remarks']." | আইটেম টি কাস্টমার মেকিং করে নেয় নি |";
					$insert_by=$rows['insert_by'];
					$transaction_type=$rows['transaction_type'];
					$accounting_id=$rows['accounting_id'];
					$method_name=$rows['method_name'];
					$status=$rows['status'];
					
					if($status==1){
						$receiveamount=$rows['amount'];
					}else{ //0=due 
						$dueamount=$rows['amount']-$amount_cost;
					}
				}
				//$conn->query("update transaction set is_active=0 where accounting_id='$dsms_id' and is_active=1");
				$conn->query("update transaction set amount='$dueamount',remarks='$remarks' where accounting_id='$dsms_id' and is_active=1 and status=0");
				if($dueamount<=$receiveamount){
					$receiveamount=$dueamount;
				}
				
				$conn->query("update transaction set amount='$receiveamount',remarks='$remarks' where accounting_id='$dsms_id' and is_active=1 and status=1");
				
				
			$transaction_last_id=$conn->query("SELECT * FROM `update_due` mh WHERE mh.is_active=1 and mh.cus_id='$customer_id' order by mh.id desc limit 0,1"); // and mh.com_id=$com_id
					$transaction_last_id_row=mysqli_fetch_array($transaction_last_id);
					$last_due=$transaction_last_id_row['last_due'];
					$id=$transaction_last_id_row['id'];
					if($amount_cost>$last_due){
						$conn->query("update update_due set last_due='0' where id=$id and is_active=1");
					}else{
						$last_due=$last_due-$amount_cost;
						$conn->query("update update_due set last_due='$last_due' where id=$id and is_active=1");
					}
			
			$ord_num=$conn->query("update dsms m set m.amount=(m.amount-$amount_cost),m.design_cost=(m.design_cost-$design_cost),m.tai_and_fab_tk=(m.tai_and_fab_tk-$amount_cost) where m.com_id=$com_id and m.id='$dsms_id'");
			if($ord_num){
				echo 1;
			}
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['changeUser'])){
		$com_id=($_SESSION['COM_ID']);
		$ord_num_id=$_REQUEST['ord_num_id'];
		$old_userid=$_REQUEST['old_userid'];
		$new_useri_id=$_REQUEST['new_useri_id'];
		$query=$conn->query("update emp_salary set user_id=$new_useri_id where com_id=$com_id and order_number='$ord_num_id' and user_id=$old_userid");
		$query2=$conn->query("update order_record set karigor_id=$new_useri_id where com_id=$com_id and id='$ord_num_id' and karigor_id=$old_userid");
		if($query2){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['updateReferenceAmount'])){
		$com_id=($_SESSION['COM_ID']);
		$reference_amount=$_REQUEST['reference_amount'];
		$_SESSION['REFERENCE_AMOUNT']=$reference_amount;
		$query=$conn->query("update company set reference_amount='$reference_amount' where id=$com_id");
		if($query){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['getOrdList'])){
		$date=$_REQUEST['date']; // date or master or karigor id
		@$etype=$_REQUEST['etype'];
		@$month_year=$_REQUEST['month_year'];
		$dvtype=$_REQUEST['dvtype'];
		$com_id=($_SESSION['COM_ID']);
		if($dvtype==2){ // and old_order_status!=0
			$order=$conn->query("select phy_ord_num from dsms where is_active=1 and com_id=$com_id and phy_dv_date is not null and phy_dv_date='$date' order by phy_dv_date asc");
		}else if($dvtype==1){
		$order=$conn->query("select phy_ord_num from dsms where is_active=1 and com_id=$com_id and date(insert_date)='$date' order by date(insert_date) asc");
		}else if($dvtype==3){
			$ex=explode("#sep#",$month_year);
			$month=$ex[0];
			$year=$ex[1];
			if($etype==1){
				$con=" and master_id";
				$col="(p.master_price*od.item_qty) salary,p.master_price per_item_cost";
			}else{
				$con=" and karigor_id";
				$col="(p.artisan_price*od.item_qty) salary,p.artisan_price per_item_cost";
			}
			$order=$conn->query("SELECT od.item_qty,od.`order_number`,p.product_name item,$col FROM `order_record` od,product p WHERE od.item_id=p.id and od.is_active=1 $con=$date and od.com_id=$com_id and month(od.insert_date)=$month and year(od.insert_date)=$year");
		}
		if($dvtype==1 || $dvtype==2){
		?>
		<label>Order List</label>
		<table id="dynamic-table" class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>Sl</th>
					<th style="width: 40%;">Order No.</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$sl2=1;$order_tk2=0;
					if(mysqli_num_rows($order)>0){
						while($row=mysqli_fetch_array($order)){
							$order_tk2=$sl2++;
							?>
							<tr>
							<td><?php echo $order_tk2; ?></td>
							<td>
							<span style='cursor: pointer;' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('<?php echo $order_tk2; ?>','<?php echo @$row['phy_ord_num']; ?>')">
								<?php echo $row['phy_ord_num']; ?>
							</span>
							</td>
							</tr>
							<?php 
						}
					}
				?>
			</tbody>
			<tr>
				<th colspan="1"  style="text-align:right">Total Order</th>
				<th style="width:40%;"><?php echo $order_tk2; ?></th>
			</tr>
		</table>
								
		<?php 
		}else{
			?>
		<label>Details List</label>
		<table id="dynamic-table" class="table table-striped table-bordered table-hover">
			<thead>
				<thead>
				<tr>
					<th>Sl</th>
					<th style="width: 15%;">Order No.</th>
					<th style="width: 25%;">Item</th>
					<th style="width: 15%;">Item Qty</th>
					<th style="width: 30%;">Per Item Making(Tk)</th>
					<th style="width: 15%;">Sub Taka</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$sl2=1;$order_tk2=0;
					if(mysqli_num_rows($order)>0){
						while($row=mysqli_fetch_array($order)){
							$order_tk2+=$row['salary'];
							?>
							<tr>
							<td><?php echo $sl2++; ?></td>
							<td><?php echo $row['order_number']; ?></td>
							<td>
								<?php echo $row['item']; ?>
							</td>
							<td>
								<?php echo $row['item_qty']; ?>
							</td>
							<td>
								<?php echo $row['per_item_cost']; ?>
							</td>
							<td>
								<?php echo $row['salary']; ?>
							</td>
							</tr>
							<?php 
						}
					}
				?>
			</tbody>
			<tr>
				<th colspan="5"  style="text-align:right">Total Tk.</th>
				<th style="width:40%;"><?php echo $order_tk2; ?></th>
			</tr>
		</table>
								
		<?php
		}
	}
	
	if(isset($_REQUEST['getDetails'])){
		$item_id=$_REQUEST['item_id'];
		if($conn->query("insert into sale_count(item_id) values('$item_id')")){
			@$top_id = $conn->insert_id;
			echo trim($top_id);
		}
	}
	
	if(isset($_REQUEST['changeUser2'])){
		$com_id=($_SESSION['COM_ID']);
		$ord_num_id=$_REQUEST['ord_num_id'];
		$old_userid=$_REQUEST['old_userid'];
		$new_useri_id=$_REQUEST['new_useri_id'];
		$query=$conn->query("update emp_salary set user_id=$new_useri_id where com_id=$com_id and order_number='$ord_num_id' and user_id=$old_userid");
		$query2=$conn->query("update order_record set master_id=$new_useri_id where com_id=$com_id and id='$ord_num_id' and master_id=$old_userid");
		if($query2){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['delbtn'])){
		
		$id=$_REQUEST['id'];
		$com_id=$_SESSION['COM_ID'];
		$user_id=($_SESSION['USER_ID']);
		$psmsquery=$conn->query("update product set is_active=0 where id=$id and com_id=$com_id");
		mysqli_close($conn);
		if($psmsquery){
			echo 1;
		}else{
			echo 2;
		}
		
	}
	
	if(isset($_REQUEST['delInStockItem'])){
		
		$id=$_REQUEST['tbl_id'];
		$sl=$_REQUEST['sl'];
		$purchase_qty=$_REQUEST['purchase_qty'];
		$total_price=$_REQUEST['total_price'];
		$item_id=$_REQUEST['item_id'];
		$com_id=$_SESSION['COM_ID'];
		$user_id=($_SESSION['USER_ID']);
		$psmsquery=$conn->query("update direct_sale_head set is_active=0 where id=$id and com_id=$com_id");
		$psmsquery=$conn->query("update direct_sale set is_active=0 where dstid=$id and com_id=$com_id");
		$product_tbl=$conn->query("select * from product where id=$item_id and com_id=$com_id");
		if(mysqli_num_rows($product_tbl)>0){
			$row=mysqli_fetch_array($product_tbl);
			$previous_stock_qty=($row['stock_qty']>=$purchase_qty)? $row['stock_qty'] : 0;
			$previous_total_price=($row['total_price']>=$total_price)? $row['total_price'] : 0;
			$avg_price=$row['avg_price'];
			if($row['stock_qty']<$purchase_qty){
				$purchase_qty=0;
				$total_price=0;
			}
			$status=2; // Stock out and item qty and price delete 
			$return_data=updateStockTbl($item_id,$purchase_qty,$avg_price,$previous_stock_qty,'',$status);
		}
		mysqli_close($conn);
		if($return_data){
			echo 1;
		}else{
			echo 2;
		}
		
	}
	
	if(isset($_REQUEST['delItemPayment'])){
		date_default_timezone_set("Asia/Dhaka");
		$last_update_date=date("d-m-Y h:i:s");
		$job_type=$_REQUEST['job_type']; // 0=assign 1=advance
		$id=$_REQUEST['tbl_id'];
		$order_rec_tblid=$_REQUEST['order_rec_tblid'];
		$sl_no=$_REQUEST['sl_no'];
		$taka=$_REQUEST['taka'];
		$emp_id=$_REQUEST['emp_id'];
		$status=$_REQUEST['status'];
		$get_emp_type=$_REQUEST['get_emp_type'];
		$com_id=$_SESSION['COM_ID'];
		$user_id=($_SESSION['USER_ID']);
		$head_tbl=$conn->query("select taka from wages_head where emp_id=$emp_id and com_id=$com_id");
		if(mysqli_num_rows($head_tbl)>0){
			$row=mysqli_fetch_array($head_tbl);
			if($status==1){ // payment status
				$ubalance=($row['taka']>=0)? ($row['taka']+$taka) : ($row['taka']+$taka);
			}else{ // job assign status=0
				$ubalance=($row['taka']-$taka);
			}
			$update_head=$conn->query("update wages_head set taka='$ubalance' where emp_id=$emp_id and com_id=$com_id");
			if($update_head){
				$update_details=$conn->query("update wages_details set is_active=0,update_by=$user_id,update_date='$last_update_date' where id=$id");
				$order_record_tbl=$conn->query("SELECT master_cutting_qty,receive_qty,(select item_qty from wages_details where wages_details.ord_record_tblid=order_record.id and wages_details.id=$id) del_item_qty FROM `order_record` WHERE `id`=$order_rec_tblid");
				
				if($get_emp_type==1){ // master 
					$row=mysqli_fetch_array($order_record_tbl);
					$master_cutting_qty=$row['master_cutting_qty'];
					$del_item_qty=$row['del_item_qty'];
					$result=($master_cutting_qty-$del_item_qty);
					if($result>0){
						$conn->query("update order_record set master_cutting_qty=$result where id=$order_rec_tblid");
					}else{
						$conn->query("update order_record set master_cutting_qty=0,master_assign_date='',master_emp_id=0 where id=$order_rec_tblid");
					}
				}else{
					$row=mysqli_fetch_array($order_record_tbl);
					$receive_qty=$row['receive_qty'];
					$del_item_qty=$row['del_item_qty'];
					$result=($receive_qty-$del_item_qty);
					if($result>0){
						$conn->query("update order_record set receive_qty=$result where id=$order_rec_tblid");
					}else{
						$conn->query("update order_record set receive_qty=0,assign_date='',maker=0,emp_type=0 where id=$order_rec_tblid");
					}
					
				}
			}
		}
		mysqli_close($conn);
		if($update_details){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['delDeliveryItem'])){
		date_default_timezone_set("Asia/Dhaka");
		$last_update_date=date("d-m-Y h:i:s");
		$order_tbl_id=$_REQUEST['order_tbl_id']; // 0=assign 1=advance
		$delivery_qty=$_REQUEST['delivery_qty'];
		
		$del_received_item=$conn->query("update order_record set delivery_qty=0,delivery_date='' where id=$order_tbl_id");
		
		mysqli_close($conn);
		if($del_received_item){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['get_by_mobile_num'])){
		$com_id=$_SESSION['COM_ID'];
		$searchable_mobile_num=trim($_REQUEST['searchable_mobile_num']);
		$item_sql=$conn->query("SELECT `phy_ord_num` from dsms where (`cus_mobile`='$searchable_mobile_num' or phy_ord_num='$searchable_mobile_num') and `is_active`=1 and com_id=$com_id order by id desc");
		if(mysqli_num_rows($item_sql)>0){
			while($row=mysqli_fetch_array($item_sql)){
				?>
				<a href="javascript:void(0)" id="active_btn<?php echo $row['phy_ord_num']; ?>" onclick="srchByOrdNum('<?php echo $row['phy_ord_num']; ?>');"><?php echo $row['phy_ord_num']; ?> | </a>
				<?php 
			}
		}
	}
	
	if(isset($_REQUEST['getPendingTask'])){
		$com_id=$_SESSION['COM_ID'];
		$emp_type=trim($_REQUEST['emp_type']);
		$emp_id=trim($_REQUEST['get_value']);
		if($emp_id=="" || $emp_id==0){
			echo 0; 
			exit;
		}
		if($emp_type==1){ // master id=1
		$item_sql=$conn->query("SELECT sum(item_qty) tot_iqty,sum(master_cutting_qty) tot_cqty from order_record where is_active=1 and master_id=$emp_id");
		}else{ //karigor id=2
			$item_sql=$conn->query("SELECT sum(item_qty) tot_iqty,sum(receive_qty) tot_cqty  from order_record where is_active=1 and karigor_id=$emp_id");
		}
		if(mysqli_num_rows($item_sql)>0){
			$row=mysqli_fetch_array($item_sql);
			echo ((int)$row['tot_iqty']-(int)$row['tot_cqty']);
		}else{
			echo 0;
		}
	}
	
	if(isset($_REQUEST['getDetailsPending'])){
		$com_id=$_SESSION['COM_ID'];
		$emp_type=trim($_REQUEST['user_type']);
		$emp_id=trim($_REQUEST['user_id']);
		if($emp_id=="" || $emp_id==0){
			echo 0; 
			exit;
		}
		if($emp_type==1){ // master id=1
		$item_sql=$conn->query("SELECT (select product_name from product where id=dd.item_id) item_name,dd.item_id,sum(dd.item_qty)-sum(dd.`master_cutting_qty`) pending_qty from order_record dd where dd.item_qty!=dd.master_cutting_qty and dd.is_active=1 and dd.master_id=$emp_id group by dd.item_id");
		}else{ //karigor id=2
			$item_sql=$conn->query("SELECT (select product_name from product where id=dd.item_id) item_name,dd.item_id,sum(dd.item_qty)-sum(dd.`receive_qty`) pending_qty from order_record dd where dd.item_qty!=dd.receive_qty and dd.is_active=1 and dd.karigor_id=$emp_id group by dd.item_id");
		}
		if(mysqli_num_rows($item_sql)>0){
			?>
			<label>Item List</label>
			<table id="dynamic-table" class="table table-striped table-bordered table-hover">
				<thead>
					<tr>
						<th style="width:5%;text-align: center;">Sl</th>
						<th style="width:80%;">Item Name</th>
						<th style="width:6%;">Item Qty</th>
					</tr>
				</thead>
			<tbody>
			<?php 
				$sl=1;$tot_qty=0;
				while($rows=mysqli_fetch_array($item_sql)){
				$c=$sl++;
				$item_id=$rows['item_id'];
				?>
				<tr>
				<td style="text-align: center;"><?php echo $c; ?></td>
				<td>
				<span id="show_all_order<?php echo $item_id; ?>" style='color:black;cursor: pointer;' onclick="getDetailsPendingOrder('<?php echo $item_id; ?>','<?php echo $emp_type; ?>','<?php echo $emp_id; ?>')"><b><?php echo @$rows['item_name']; ?></b></span>
				<span id="loading_icode<?php echo $item_id; ?>"></span>
				</td>
				<td style="text-align: center;">
				<span style='color:black;cursor: pointer;' onclick="getDetailsPendingOrder('<?php echo $item_id; ?>','<?php echo $emp_type; ?>','<?php echo $emp_id; ?>')"><b><?php echo @$rows['pending_qty']; ?></b></span>
				</td>
				</tr>
				<?php 
			}
				?>
			</tbody>
			
			</table>
			<?php 
		}else{
			echo '';
		}
	}
	
	
	if(isset($_REQUEST['getDetailsPendingOrder'])){
		$com_id=$_SESSION['COM_ID'];
		$item_id=trim($_REQUEST['item_id']);
		$emp_type=trim($_REQUEST['user_type']);
		$emp_id=trim($_REQUEST['user_id']);
		if($emp_id=="" || $emp_id==0){
			echo 0; 
			exit;
		}
		if($emp_type==1){ // master id=1
		$item_sql=$conn->query("SELECT dd.id,dd.item_id,(dd.item_qty-dd.`master_cutting_qty`) pending_qty,`order_number` from order_record dd where dd.item_qty!=dd.master_cutting_qty and dd.is_active=1 and dd.master_id=$emp_id and dd.item_id=$item_id");
		}else{ //karigor id=2
			$item_sql=$conn->query("SELECT dd.id,dd.item_id,(dd.item_qty-dd.`receive_qty`) pending_qty,`order_number` from order_record dd where dd.item_qty!=dd.receive_qty and dd.is_active=1 and dd.karigor_id=$emp_id and dd.item_id=$item_id");
		}
		if(mysqli_num_rows($item_sql)>0){
			$sl=1;$tot_qty=0;
			while($rows=mysqli_fetch_array($item_sql)){
			$c=$sl++;
			$item_code=$rows['id'];
			$pending_qty=$rows['pending_qty'];
			$order_number=$rows['order_number'];
			?>
				<span style='color:black;cursor: pointer;color:blue' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$order_number; ?>')"><b><?php echo @$item_code; ?><span style="color:black">(<?php echo @$pending_qty; ?>)</span></b></span> |
			<?php 
			}
			
		}else{
			echo '';
		}
	}
	
	
	if(isset($_REQUEST['get_edit_item'])){
		$com_id=$_SESSION['COM_ID'];
		$edit_ord_number=trim($_REQUEST['edit_ord_number']);
		$item_sql=$conn->query("SELECT ord.master_id,ord.karigor_id,ord.id,ord.item_qty,ord.group_id,ord.ptype,ord.item_id,ord.dsms_id,ord.design_cost,ord.amount_cost,(select product_name from product where id=ord.item_id) item_name,(SELECT CONCAT(`amount`,'_',`discount`, '_',`design_cost`,'_',`cus_mobile`,'_',id) from dsms where id=ord.dsms_id) orderinfo FROM `order_record` ord WHERE ord.is_active=1 and com_id=$com_id and ord.`order_number`='$edit_ord_number'");
		if(mysqli_num_rows($item_sql)>0){
			echo "<ol>";
			?>
			<ul><a style="font-weight: bold;color: #0d6464;" href="javascript:void(0)" onclick="showFabricsDetails('<?php echo $edit_ord_number; ?>')">Fabrics</a></ul>
			<?php 
			$c=1;
			while($row=mysqli_fetch_array($item_sql)){
				$j=$c++;
				?>
				<li><a href="javascript:void(0)" id="eitem<?php echo $j; ?>" onclick="showEditDetails('<?php echo $row['master_id']; ?>','<?php echo $row['karigor_id']; ?>','<?php echo $row['id']; ?>','<?php echo $row['group_id']; ?>','<?php echo $row['ptype']; ?>','<?php echo $row['item_id']; ?>','<?php echo $row['item_name']; ?>','<?php echo $j; ?>','<?php echo $row['orderinfo']; ?>','<?php echo $row['design_cost']; ?>','<?php echo $row['amount_cost']; ?>','<?php echo $row['item_qty']; ?>');"><?php echo $row['item_name']; ?>[<?php echo $row['id']; ?>] (<span id="org_item_qty<?php echo $j; ?>"><?php echo $row['item_qty']; ?></span>)</a>
					<span style="cursor:pointer" onclick="AfterOrderDeleteItem('<?php echo $row['id']; ?>','<?php echo $row['item_id']; ?>','<?php echo $row['design_cost']; ?>','<?php echo $row['amount_cost']; ?>','<?php echo $row['dsms_id']; ?>','<?php echo $row['item_name']; ?>','<?php echo $j; ?>')" id="itemDel<?php echo $j; ?>"><img src="img/cross.png"/></span>
				</li>
				<?php 
			}
			?>
			</ol>
			<?php 
			echo "<input type='hidden' id='eitem_chk' value='0'/>";
			
		}
	}
	
	if(isset($_REQUEST['showFabricsDetails'])){
		$com_id=$_SESSION['COM_ID'];
		$order_number=trim($_REQUEST['order_num']);
		
		$item_details=$conn->query("select id,price,item_id,(select cus_mobile from direct_sale_head where direct_sale_head.id=direct_sale.dstid) cus_mobile,(select product_name from product where id=direct_sale.item_id) item_name,item_qty,dstid from direct_sale where order_number='$order_number' and is_active=1");
	?>
		
			<label style="font-weight: bold;text-decoration: underline;">ফ্যাব্রিক্স আইটেম:</label>
				<table id="dynamic-table" class="table table-striped table-bordered table-hover">
					<thead>
						<thead>
						<tr>
							<th style="text-align:center;width: 5%;">Sl</th>
							<th style="">Item</th>
							<th style="text-align:center">Item Qty (গজ)</th>
							<th style="text-align:right">Taka</th>
							</tr>
					</thead>
					<tbody>
						<?php 
							$sl2=1; $total=0;
							if(mysqli_num_rows($item_details)>0){
								while($rows=mysqli_fetch_array($item_details)){
									$total+=($rows['price']*$rows['item_qty']);
									$dstid=$rows['dstid'];
									$cus_mobile=$rows['cus_mobile'];
								?>
									<tr id="row_fabrics<?php echo $rows['id']; ?>">
									<td style="text-align:center">
									<?php echo $sl2++; ?>
									</td>
									<td>
										<?php echo $rows['item_name']; ?>
									</td>
									<td style="text-align:center">
										<?php echo $rows['item_qty']; ?>
									</td>
									<td style="text-align:right">
										<?php echo ($rows['price']*$rows['item_qty']); ?>
									</td>
									
									</tr>
									<?php 
								}
							}
						?>
						<tr>
						<td colspan="3" style="text-align:right"><b>Total: </b></td>
						<td style="text-align:right">
							<b><?php echo $total; ?></b>
						</td>
						
						</tr>
					</tbody>
					
				</table>
				<?php 
	}
	
	if(isset($_REQUEST['updateItemQty'])){
		$com_id=$_SESSION['COM_ID'];
		$oldqty=$_REQUEST['oldqty'];
		$update_status=$_REQUEST['update_status'];
		$edit_ord_number=$_REQUEST['edit_ord_number'];
		$ex=explode("#sep#",$oldqty);
		$item_id=$ex[0];
		$item_qty=$ex[1];
		$edititemqty=$_REQUEST['edititemqty'];
		$item_price=$conn->query("select cus_price from product where id=$item_id and is_active=1 and com_id=$com_id");
		if($item_price){
			$row=mysqli_fetch_array($item_price);
			$cus_price=$row['cus_price'];
			$utot_price=(intval($cus_price)*intval($edititemqty));
			$tot_price=$conn->query("select amount from dsms where phy_ord_num='$edit_ord_number' and is_active=1 and com_id=$com_id");
			$totrow=mysqli_fetch_array($tot_price);
			$amount=$totrow['amount'];
			if($update_status==1){
			$updated_amount=(intval($amount)+$utot_price);
			$updated_qty=(intval($item_qty)+intval($edititemqty));
			}else{
				$updated_amount=(intval($amount)-$utot_price);
				$updated_qty=(intval($item_qty)-intval($edititemqty));
			}
			$conn->query("update dsms set amount='$updated_amount' where phy_ord_num='$edit_ord_number' and is_active=1 and com_id=$com_id");
			$update_item_qty=$conn->query("update order_record set item_qty='$updated_qty' where order_number='$edit_ord_number' and item_id=$item_id and is_active=1 and com_id=$com_id");
			if($update_item_qty){
				echo $item_id."#sep#".$updated_qty;
			}else{
				echo 2;
			}
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['delbtn2'])){
		
		$id=$_REQUEST['id'];
		$com_id=$_SESSION['COM_ID'];
		$user_id=($_SESSION['USER_ID']);
		$psmsquery=$conn->query("update measurement_head set is_active=0 where id=$id and is_active=1");
		mysqli_close($conn);
		if($psmsquery){
			echo 1;
		}else{
			echo 2;
		}
		
	}
	
	if(isset($_REQUEST['edit_order'])){
		$com_id=($_SESSION['COM_ID']);
		$update_by=($_SESSION['USER_ID']);
		$all_sizeida=explode("#sep#",$_REQUEST['all_sizeida']);
		$all_sizea=explode("#sep#",$_REQUEST['all_sizea']);
		$all_properticetitlea=explode("#sep#",$_REQUEST['all_properticetitlea']);
		$all_properticea=explode("#sep#",$_REQUEST['all_properticea']);
		if($_REQUEST['all_exproperticea']!=0){
		$all_exproperticea=explode("#sep#",$_REQUEST['all_exproperticea']);
		}
		$ord_tbl_id=$_REQUEST['ord_tbl_id'];
		$edit_ord_number=$_REQUEST['edit_ord_number'];
		$txtareaid=$_REQUEST['txtareaid'];
		
		$previous_amount_cost=$_REQUEST['previous_amount_cost'];
		$previous_design_cost=$_REQUEST['previous_design_cost'];
		$previous_group_name=$_REQUEST['previous_group_name'];
		$item_amounte=$_REQUEST['item_amounte'];
		$item_qtye=$_REQUEST['item_qtye'];
		$item_ratee=$_REQUEST['item_ratee'];
		$item_otherse=$_REQUEST['item_otherse']; //present design cost
		$group_namee=$_REQUEST['group_namee'];
		$master_ide=($_REQUEST['master_ide']=="")? 0 : $_REQUEST['master_ide'];
		$karigor_ide=($_REQUEST['karigor_ide']=="")? 0 : $_REQUEST['karigor_ide'];
		$previous_orderinfo=explode("_",$_REQUEST['previous_orderinfo']);
		$total_amount=$previous_orderinfo[0];
		$main_design_cost=$previous_orderinfo[2];
		$customer_mobile=$previous_orderinfo[3];
		$dsms_tbl_id=$previous_orderinfo[4];
		/*if($previous_orderinfo[1]>0){ //discount
			$after_discount_pay=$previous_amount_cost-(($previous_amount_cost*$previous_orderinfo[1])/100); //pay=1
			$after_discount_due=$item_amounte-(($item_amounte*$previous_orderinfo[1])/100); //due=0
			$actual_total_amount=($total_amount-($after_discount_pay)+($after_discount_due));*/
		//}else{
			$after_discount_pay=$previous_amount_cost; //pay=1
			$after_discount_due=$item_amounte; //due=0
			$actual_total_amount=($total_amount-$previous_amount_cost+$item_amounte);
		//}
		
		$design_cost=$main_design_cost-$previous_design_cost+$item_otherse;
		
		
		$extra_remarks=trim(str_replace("'", "",$_REQUEST['extra_remarks']));
		
			@$update_od=$conn->query("update order_details set is_active=2 where order_number='$ord_tbl_id' and is_active=1"); //is active=0 pending,1= active ,2= deleted
			if($update_od){
				if($previous_amount_cost!=$item_amounte){
					@$customer_sql=$conn->query("select * from customer where cus_mobile='$customer_mobile' and is_active=1"); 
					$rows=mysqli_fetch_array($customer_sql);
					$customer_id=$rows['id'];
					$conn->query("update order_record set item_qty=$item_qtye,design_cost='$item_otherse',amount_cost='$item_amounte',group_name='$group_namee',master_id='$master_ide',karigor_id='$karigor_ide' where id='$ord_tbl_id' and is_active=1");
					$conn->query("update dsms set amount='$actual_total_amount',design_cost='$design_cost' where id='$dsms_tbl_id' and is_active=1");
					$remarks1="ফ্যাব্রিক্স ডিজাইন অথবা মেকিং সংখ্যা এডিট($edit_ord_number)";
					$remarks2="ফ্যাব্রিক্স ডিজাইন অথবা মেকিং সংখ্যা এডিট এর পর payable($edit_ord_number)";
					$editable_due_pay=($item_amounte-$previous_amount_cost);
					dueTblUpdate($customer_id,$editable_due_pay,0,$remarks1,'0');
					//dueTblUpdate($customer_id,$after_discount_pay,1,$remarks2);
					
				}
				
				//only for group name update
				$conn->query("update order_record set group_name='$group_namee',master_id=$master_ide,karigor_id=$karigor_ide where id='$ord_tbl_id' and is_active=1");
				for($i=0;$i<count($all_sizeida);$i++){
					$measure_id=$all_sizeida[$i];
					$measurement=$all_sizea[$i];
					$new_ord=$conn->query("insert into order_details(com_id,order_number,mtype,measure_id,measurement,is_active,update_by) values('$com_id','$ord_tbl_id',1,$measure_id,'$measurement',1,$update_by)");
				}
				for($i=0;$i<count($all_properticetitlea);$i++){
					if($all_properticea[$i]!=0){
					$measure_id=$all_properticetitlea[$i];
					$measurement=$all_properticea[$i];
					$conn->query("insert into order_details(com_id,order_number,mtype,measure_id,measurement,is_active,update_by) values('$com_id','$ord_tbl_id',2,$measure_id,'$measurement',1,$update_by)");
					}
				}
				if($_REQUEST['all_exproperticea']!=0){
					for($i=0;$i<count($all_exproperticea);$i++){
						$measure_id=$all_exproperticea[$i];
						$conn->query("insert into order_details(com_id,order_number,mtype,measure_id,measurement,is_active,update_by) values('$com_id','$ord_tbl_id',3,$measure_id,'',1,$update_by)");
					
					}
				}
				if($txtareaid!=0){
					$conn->query("insert into order_details(com_id,order_number,mtype,measure_id,measurement,is_active,update_by) values('$com_id','$ord_tbl_id',4,$txtareaid,'$extra_remarks',1,$update_by)");
				}
				if($new_ord){
					echo 1;
				}
			}else{
				echo 2;
			}
		
	}
	
	if(isset($_REQUEST['updateItemPrice'])){
		$tbl_id=$_REQUEST['tbl_id'];
		$cus_price=$_REQUEST['cus_price'];
		$updatetype=$_REQUEST['updatetype'];
		$com_id=$_SESSION['COM_ID'];
		$user_id=($_SESSION['USER_ID']);
		if($updatetype==1){
			$psmsquery=$conn->query("update product set cus_price='$cus_price' where com_id=$com_id and id=$tbl_id");
		}else if($updatetype==2){
			$psmsquery=$conn->query("update product set master_price='$cus_price' where com_id=$com_id and id=$tbl_id");
		}else if($updatetype==3){
			$psmsquery=$conn->query("update product set artisan_price='$cus_price' where com_id=$com_id and id=$tbl_id");
		}else if($updatetype==4){
			$psmsquery=$conn->query("update product set steps='$cus_price' where com_id=$com_id and id=$tbl_id");
		}else if($updatetype==5){
			$psmsquery=$conn->query("update product set product_name='$cus_price' where com_id=$com_id and id=$tbl_id");
		}else if($updatetype==6){
			$checkCode=$conn->query("select * from product where com_id=$com_id and item_code='$cus_price' and is_active=2");
			if(mysqli_num_rows($checkCode)>0){
				echo 2;
				exit;
			}else{
				$psmsquery=$conn->query("update product set item_code='$cus_price' where com_id=$com_id and id=$tbl_id");
			}
		}else if($updatetype==7){
			$psmsquery=$conn->query("update product set selling_price='$cus_price' where com_id=$com_id and id=$tbl_id");
		}else if($updatetype==8){
			$psmsquery=$conn->query("update product set purchase_price='$cus_price' where com_id=$com_id and id=$tbl_id");
		}
		mysqli_close($conn);
		if($psmsquery){
			echo 1;
		}else{
			echo 2;
		}
		
	}
	
	if(isset($_REQUEST['delbtn3'])){
		
		$id=$_REQUEST['id'];
		$com_id=$_SESSION['COM_ID'];
		$user_id=($_SESSION['USER_ID']);
		$psmsquery=$conn->query("update select_detail set is_active=0 where id=$id and is_active=1");
		mysqli_close($conn);
		if($psmsquery){
			echo 1;
		}else{
			echo 2;
		}
		
	}
	
	if(isset($_REQUEST['setOrder'])){
		
		$id=$_REQUEST['tblid'];
		$mheadorder=$_REQUEST['mheadorder'];
		$com_id=$_SESSION['COM_ID'];
		$user_id=($_SESSION['USER_ID']);
		if($_REQUEST['chk_head']=="head"){
			if($_REQUEST['updatetype']==1){
				$psmsquery=$conn->query("update measurement_head set title='$mheadorder' where id=$id and is_active=1");
			}else if($_REQUEST['updatetype']==2){
				$psmsquery=$conn->query("update measurement_head set steps=$mheadorder where id=$id and is_active=1");
			}else if($_REQUEST['updatetype']==3){
				$psmsquery=$conn->query("update measurement_head set amount=$mheadorder where id=$id and is_active=1");
			}
		}else{
			if($_REQUEST['updatetype']==1){
				$psmsquery=$conn->query("update select_detail set title='$mheadorder' where id=$id and is_active=1");
			}else if($_REQUEST['updatetype']==2){
				$psmsquery=$conn->query("update select_detail set steps=$mheadorder where id=$id and is_active=1");
			}
		}
		mysqli_close($conn);
		if($psmsquery){
			echo 1;
		}else{
			echo 2;
		}
		
	}
	
	
	if(isset($_REQUEST['saveItem'])){
		$com_id=($_SESSION['COM_ID']);
		$item_type=$_REQUEST['item_type'];
		$item_name=trim(str_replace("'", "",$_REQUEST['item_name']));
		$group_id=$_REQUEST['group_id'];
		$cus_price=trim($_REQUEST['cus_price']);
		$master_price=trim($_REQUEST['master_price']);
		$karigor_price=trim($_REQUEST['karigor_price']);
		$ilast_id=intval($_REQUEST['ilast_id'])+1;
		$query=$conn->query("insert into product(product_name,cus_price,com_id,master_price,artisan_price,group_id,ptype,steps) values('$item_name',$cus_price,$com_id,$master_price,$karigor_price,$group_id,$item_type,100)");
		@$top_id = $conn->insert_id;
		$param1="'".$ilast_id."',"."'".$top_id."','1'";
		$param2="'".$ilast_id."',"."'".$top_id."','2'";
		$param3="'".$ilast_id."',"."'".$top_id."','3'";
		$param4="'".$ilast_id."',"."'".$top_id."','4'";
		$param5="'".$ilast_id."',"."'".$top_id."','5'";
		$tr="<tr><td>
		<button onclick='delItem($top_id,$ilast_id);' name='btn' id='delbtn$ilast_id' class='btn btn-danger form-control'>$ilast_id</button>
		</td><td>".'<input type="text" class="form-control" onkeyup="setCusPrice('.$param5.')" value="'.$item_name.'" id="product_name'.$ilast_id.'"/></td>
		<td><input type="text" class="form-control" onkeyup="setCusPrice('.$param1.')" value="'.$cus_price.'" id="cus_price'.$ilast_id.'"/></td>
		<td><input type="text" class="form-control" onkeyup="setCusPrice('.$param2.');" value="'.$master_price.'" id="mas_price'.$ilast_id.'"/></td>
		<td><input type="text" class="form-control" onkeyup="setCusPrice('.$param3.');" value="'.$karigor_price.'" id="kar_price'.$ilast_id.'"/></td>
		<td><input type="text" class="form-control" onkeyup="setCusPrice('.$param4.');" value="100" id="order'.$ilast_id.'"/></td>'."</tr>";
		
		if($query){
			echo $tr;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['saveUserInfo'])){
		$user_type=$_REQUEST['user_type'];
		@$user_name=trim(str_replace("'", "",$_REQUEST['user_name']));
		@$user_mobile=$_REQUEST['user_mobile'];
		@$login_user=trim($_REQUEST['login_user']);
		@$login_password=trim($_REQUEST['login_password']);
		
		$com_id=($_SESSION['COM_ID']);
		$query2=$conn->query("select * from user where com_id=$com_id and log_user='$login_user' and pass='$login_password'");
		if(mysqli_num_rows($query2)<1){
			if($user_type==2){
				$query=$conn->query("insert into user(com_id,user_name,mobile,log_user,pass,user_type) values($com_id,'$user_name','$user_mobile','$login_user','$login_password',$user_type)");
			}else{
				$query=$conn->query("insert into user(com_id,user_name,mobile,log_user,pass) values($com_id,'$user_name','$user_mobile','$login_user','$login_password')");
			}
			
			$ilast_id=intval($_REQUEST['ilast_id'])+1;
			@$top_id = $conn->insert_id;
			$param1="'".$ilast_id."',"."'".$top_id."','1'";
			$param2="'".$ilast_id."',"."'".$top_id."','2'";
			$param3="'".$ilast_id."',"."'".$top_id."','3'";
			$param5="'".$ilast_id."',"."'".$top_id."','5'";
			$tr="<tr><td>
			<button onclick='delEmployee($top_id,$ilast_id);' name='btn' id='delbtn$ilast_id' class='btn btn-danger form-control'>$ilast_id</button>
			</td><td>".'<input readonly type="text" class="form-control" onkeyup="setCusPrice('.$param5.')" value="'.$user_name.'" id="user_name'.$ilast_id.'"/></td>
			<td><input readonly type="text" class="form-control" onkeyup="setCusPrice('.$param1.')" value="'.$user_mobile.'" id="mobile'.$ilast_id.'"/></td>
			<td><input readonly type="text" class="form-control" onkeyup="setCusPrice('.$param2.');" value="'.$login_user.'" id="log_user'.$ilast_id.'"/></td>
			<td><input readonly type="text" class="form-control" onkeyup="setCusPrice('.$param3.');" value="'.$login_password.'" id="pass'.$ilast_id.'"/></td><td>"'.getUserWiseSale($top_id,0)."<br/><b>".getUserWiseSale($top_id,1).'"</b></td>'."</tr>";
			
			if($query){
				echo $tr;
			}else{
				echo 2;
			}
		}else{
			echo 3;
		}
	}
	
	if(isset($_REQUEST['checkItemCode'])){
		@$item_code=$_REQUEST['item_code'];
		$com_id=($_SESSION['COM_ID']);
		$query2=$conn->query("select * from product where com_id=$com_id and item_code='$item_code' and is_active=2");
		if(mysqli_num_rows($query2)>0){
			echo 1; 
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['saveFabrics'])){
		$com_id=($_SESSION['COM_ID']);
		$item_type=$_REQUEST['item_type'];
		$purchase_price=$_REQUEST['purchase_price'];
		$selling_price=$_REQUEST['selling_price'];
			
		$item_name=trim(str_replace("'", "",$_REQUEST['item_name']));
		$item_code=($_REQUEST['item_code']!="")? trim(str_replace("'", "",$_REQUEST['item_code'])) : "";
		$item_unit=($_REQUEST['item_unit']!="")? trim(str_replace("'", "",$_REQUEST['item_unit'])) : "";
		$ilast_id=intval($_REQUEST['ilast_id'])+1;
		$query=$conn->query("insert into product(product_name,com_id,ptype,steps,is_active,uom,item_code,purchase_price,selling_price) values('$item_name',$com_id,$item_type,1,2,'$item_unit','$item_code','$purchase_price','$selling_price')");
		@$top_id = $conn->insert_id;
		//$param1="'".$ilast_id."',"."'".$top_id."','2'";
		$param1="'".$ilast_id."',"."'".$top_id."','5'";
		$param2="'".$ilast_id."',"."'".$top_id."','6'"; // item code 
		$param3="'".$ilast_id."',"."'".$top_id."','7'"; // item code 
		$param4="'".$ilast_id."',"."'".$top_id."','8'"; // item code 
		if($_SESSION['IS_STOCK']==1){ // 1=means maintain stock
			
			
			$tr="<tr><td>
			<button onclick='delItem($top_id,$ilast_id);' name='btn' id='delbtn$ilast_id' class='btn btn-danger form-control'>$ilast_id</button>
			</td><td>".'<input type="text" class="form-control" onkeyup="setCusPrice('.$param1.')" value="'.$item_name.'" id="product_name'.$ilast_id.'"/></td><td><input type="text" style="text-align:center" class="form-control" onblur="setCusPrice('.$param2.')" value="'.$item_code.'" id="product_code'.$ilast_id.'"/></td><td style="text-align:center"><span style="color:red">0</span> <p style="font-size:8px;color:blue">'.$item_unit.'</p></td><td style="text-align:right"><input type="text" style="text-align:right;color:red" class="form-control" onkeyup="setCusPrice('.$param4.')" value="'.$purchase_price.'" id="purchase_price'.$ilast_id.'"/></td><td><input type="text" style="text-align:right;color:red" class="form-control" onkeyup="setCusPrice('.$param3.')" value="'.$selling_price.'" id="selling_price'.$ilast_id.'"/></td>'."</tr>";
		}else{
			$tr="<tr><td>
			<button onclick='delItem($top_id,$ilast_id);' name='btn' id='delbtn$ilast_id' class='btn btn-danger form-control'>$ilast_id</button>
			</td><td>".'<input type="text" class="form-control" onkeyup="setCusPrice('.$param1.')" value="'.$item_name.'" id="product_name'.$ilast_id.'"/></td>'."</tr>";
		}
		if($query){
			echo $tr;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['saveFabricsInStock'])){
		$com_id=($_SESSION['COM_ID']);
		$user_id=$_SESSION['USER_ID'];
		$item_id=$_REQUEST['item_id'];
		$item_name=$_REQUEST['item_name'];
		@$item_unit=$_REQUEST['item_unit'];
		@$item_code=$_REQUEST['item_code'];
		$purchase_qty=$_REQUEST['purchase_qty'];
		$purchase_price=$_REQUEST['purchase_price'];
		$total_price=$_REQUEST['total_price'];
		
		$previous_stock_qty=$_REQUEST['previous_stock_qty'];
		$previous_total_price=$_REQUEST['previous_total_price'];
		$previous_avg_price=$_REQUEST['previous_avg_price'];
		$supplier_mobile=$_REQUEST['supplier_mobile'];
		//$item_code=($_REQUEST['item_code']!="")? trim(str_replace("'", "",$_REQUEST['item_code'])) : "";
		//$item_unit=($_REQUEST['item_unit']!="")? trim(str_replace("'", "",$_REQUEST['item_unit'])) : "";
		$ilast_id=intval($_REQUEST['ilast_id'])+1;
		$head_query=$conn->query("insert into direct_sale_head(com_id,f_total,cus_mobile,insert_by,is_order,in_out_status) values($com_id,'$total_price','$supplier_mobile','$user_id',3,1)");
		if($head_query){
			@$top_id = $conn->insert_id;
			$description_query=$conn->query("insert into direct_sale(item_id,item_qty,price,com_id,insert_by,dstid,in_out_status) values($item_id,'$purchase_qty','$purchase_price',$com_id,'$user_id','$top_id',1)");
			if($description_query){
				$status=1; // Stock in 
				$return_data=updateStockTbl($item_id,$purchase_qty,$total_price,$previous_stock_qty,$previous_total_price,$status);
			}
		}
		//$param1="'".$ilast_id."',"."'".$top_id."','2'";
		$func="delInStockItem("."'".$top_id."','".$ilast_id."','".$purchase_qty."','".$total_price."','".$item_id."'".");";
		$param2="'".$ilast_id."',"."'".$top_id."','6'"; // item code 
			$tr="<tr><td>
			<button onclick=$func name='btn' id='delbtn$ilast_id' class='btn btn-danger form-control'>$ilast_id</button>
			</td><td>$item_name <p style='font-size:9px;color:blue'>$item_code</p></td><td style='text-align:center'>$purchase_qty <p style='font-size:8px;color:blue'>$item_unit</p></td><td style='text-align:right'>$purchase_price</td><td style='text-align:right'>$total_price</td><td style='text-align:center'>$supplier_mobile</td></tr>";
		
		if($return_data==1){ // success 
			echo $tr;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['saveStockAdjustment'])){
		$com_id=($_SESSION['COM_ID']);
		$user_id=$_SESSION['USER_ID'];
		$item_id=$_REQUEST['item_id'];
		$item_name=$_REQUEST['item_name'];
		@$item_unit=$_REQUEST['item_unit'];
		@$item_code=$_REQUEST['item_code'];
		$purchase_qty=$_REQUEST['purchase_qty'];
		$adjustment_qty=$_REQUEST['adjustment_qty'];
		$total_price=$_REQUEST['total_price'];
		$remarks="";
		
		$previous_avg_price=$_REQUEST['previous_avg_price'];
		
		//$item_code=($_REQUEST['item_code']!="")? trim(str_replace("'", "",$_REQUEST['item_code'])) : "";
		//$item_unit=($_REQUEST['item_unit']!="")? trim(str_replace("'", "",$_REQUEST['item_unit'])) : "";
		$ilast_id=intval($_REQUEST['ilast_id'])+1;
		
		$description_query=$conn->query("insert into stock_adjustment(item_id,adjustment_qty,remarks,insert_by) values($item_id,'$adjustment_qty','$remarks','$user_id')");
		@$top_id = $conn->insert_id;
		if($description_query){
			$total_price=round(($previous_avg_price*$purchase_qty),2);
			$return_data=$conn->query("update product set stock_qty='$purchase_qty',total_price='$total_price',avg_price='$previous_avg_price' where id=$item_id and is_active=2");
		}
		//"<button onclick='delItem($top_id,$ilast_id);' name='btn' id='delbtn$ilast_id' class='btn btn-danger form-control'>$ilast_id</button>";
		$tr="<tr><td style='text-align:center'>
			$ilast_id
			</td><td>$item_name <p style='font-size:9px;color:blue'>$item_code</p></td><td style='text-align:center'>$adjustment_qty <p style='font-size:8px;color:blue'>$item_unit</p></td><td style='text-align:center'>$remarks</td><td style='text-align:center'></td></tr>";
		
		if($return_data){ // success 
			echo $tr;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['savePropertices'])){
		$com_id=($_SESSION['COM_ID']);
		$item_type=$_REQUEST['item_type'];
		$ex_data=explode("#sep#",$_REQUEST['item_id']);
		$group_id=$ex_data[1];
		$item_name=$ex_data[0];
		$measurement_type=$_REQUEST['measurement_type'];
		$propertice_title=trim(str_replace("'", "",$_REQUEST['propertice_title']));
		$ilast_id=intval($_REQUEST['ilast_id'])+1;
		$query=$conn->query("insert into measurement_head(group_id,title,mtype,ptype,steps) values($group_id,'$propertice_title',$measurement_type,$item_type,100)");
		
		@$top_id = $conn->insert_id;
		$head="head";
		$param1="'".$ilast_id."',"."'".$top_id."',"."'".$head."','1'";
		$param2="'".$ilast_id."',"."'".$top_id."',"."'".$head."','2'";
		$tr="<tr><td>
		<button onclick='delItemTwo($top_id,$ilast_id);' name='btn' id='delbtnTwo$ilast_id' class='btn btn-danger form-control'>$ilast_id</button>
		</td><td>".'<input type="text" class="form-control" value="'.$propertice_title.'" id="mheadordertitle'.$ilast_id.'" onkeyup="setOrder('.$param1.')"/></td><td><input type="text" class="form-control" value="100" id="mheadorder'.$ilast_id.'" onkeyup="setOrder('.$param2.')"/></td>' ."</tr>";
		if($query){
			echo $tr;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['saveProperticesExtra'])){
		$com_id=($_SESSION['COM_ID']);
		$item_type=$_REQUEST['item_type'];
		$ex_data=explode("#sep#",$_REQUEST['item_id']);
		$group_id=$ex_data[1];
		$item_name=$ex_data[0];
		$measurement_type=$_REQUEST['measurement_type'];
		$propertice_title=trim(str_replace("'", "",$_REQUEST['propertice_title']));
		$ilast_id=intval($_REQUEST['ilast_id'])+1;
			$query=$conn->query("insert into select_detail(group_id,select_type,title,ptype,steps) values($group_id,'$measurement_type','$propertice_title',$item_type,100)");
		
		@$top_id = $conn->insert_id;
		$head="detail";
		$param1="'".$ilast_id."',"."'".$top_id."',"."'".$head."','1'";
		$param2="'".$ilast_id."',"."'".$top_id."',"."'".$head."','2'";
		$tr="<tr><td>
		<button onclick='delItemThree($top_id,$ilast_id);' name='btn' id='delbtnThree$ilast_id' class='btn btn-danger form-control'>$ilast_id</button>
		</td><td>".'<input type="text" class="form-control" value="'.$propertice_title.'" id="mheadordertitle'.$ilast_id.'" onkeyup="setOrder('.$param1.')"/></td><td><input type="text" class="form-control" value="100" id="mheadorder'.$ilast_id.'" onkeyup="setOrder('.$param2.')"/></td>'."</tr>";
		if($query){
			echo $tr;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['set_btn'])){
		$txt_sms=trim(str_replace("'", "", $_REQUEST['txt_sms']));
		$com_id=($_SESSION['COM_ID']);
			@$text=$conn->query("insert into set_text(sms_text,com_id) values('$txt_sms','$com_id')");
			if($text){
				@$top_id = $conn->insert_id;
				
				$conn->query("update set_text set is_active=0 where com_id=$com_id and id!=$top_id");
				@$textsql=$conn->query("select * from set_text where com_id=$com_id order by id desc limit 0,15");
				mysqli_close($conn);
				$m=1;
				while($row=mysqli_fetch_array($textsql)){
					if($row['is_active']==1){
					?>
					<div class="panel panel-success">
					  <div class="panel-heading"><?php echo $m++; ?></div>
					  <div class="panel-body"><?php echo $row['sms_text']; ?></div>
					  <a href="javascript:void(0)" style="margin:15px" class="btn btn-success">Active</a>
					</div>
					<?php 
					}else{
						?>
						<div class="panel panel-warning">
						  <div class="panel-heading"><?php echo $m++; ?></div>
						  <div class="panel-body"><?php echo $row['sms_text']; ?></div>
						  <a href="javascript:void(0)" onclick="activeInactive('<?php echo $row['id']; ?>','1')" style="margin:15px" class="btn btn-warning">In Active</a>
						</div>
					<?php 
					}
				}
			}else{
				echo 20000000;
			}
		
	}
	
	if(isset($_REQUEST['chkMonthlyBill'])){
		$com_id=($_SESSION['COM_ID']);
		echo chkMonthlyBill($com_id);
	}
	
	
	if(isset($_REQUEST['add_order'])){
		date_default_timezone_set("Asia/Dhaka");
		$bmonth=date("m"); 
		$byear=date("Y"); 
		$com_id=($_SESSION['COM_ID']);
		$user_id=($_SESSION['USER_ID']);
		$phy_ord_num=$_REQUEST['phy_ord_num'];
		$tbl_ord_num=$_REQUEST['tbl_ord_num'];
	$item_id_a=explode("#head#",$_REQUEST['item_id']);
	$group_name_a=explode("#head#",$_REQUEST['group_name']);
	$item_type_a=explode("#head#",$_REQUEST['item_type']);
	$ex_master=explode("#head#",$_REQUEST['master_id']);
	$ex_karigor=explode("#head#",$_REQUEST['karigor_id']);
	
	$item_qty_a=explode("#sep#",$_REQUEST['item_qty']);
	$design_cost_a=explode("#head#",$_REQUEST['design_cost']);
	$amount_cost_a=explode("#head#",$_REQUEST['amount_cost']);
	
	$all_sizeida_a=explode("#head#",$_REQUEST['all_sizeida']);
	$all_sizea_a=explode("#head#",$_REQUEST['all_sizea']);
	$all_properticetitlea_a=explode("#head#",$_REQUEST['all_properticetitlea']);
	$all_properticea_a=explode("#head#",$_REQUEST['all_properticea']);
	$all_exproperticea_a=explode("#head#",$_REQUEST['all_exproperticea']);
	$extra_remarks_a=explode("#head#",$_REQUEST['extra_remarks']);
	$txtareaid_a=explode("#head#",$_REQUEST['txtareaid']);
	
	for($hid=0;$hid<count($item_id_a);$hid++){
		
		$group_name=$group_name_a[$hid];
		$item_type=$item_type_a[$hid];
		$master_id=$ex_master[$hid];
		$karigor_id=$ex_karigor[$hid];
		$design_cost=$design_cost_a[$hid];
		$amount_cost=$amount_cost_a[$hid];
		$item_qty=$item_qty_a[$hid];
		$ex_item_id=explode("#sep#",$item_id_a[$hid]);
		$item_id=$ex_item_id[0];
		$group_id=$ex_item_id[1];
		$ord_type=$_SESSION['SVERSION']; //0=computer generated order, 1=physical book order, 2=merge order
		//if(chkMonthlyBill($com_id)==1){ // monthly bill is ok
			if($ord_type==0 || $ord_type==1 || $ord_type==2){
				$is_active=0;
			}
			
			$all_sizeida=explode("#sep#",$all_sizeida_a[$hid]);
			$all_sizea=explode("#sep#",$all_sizea_a[$hid]);
			$all_properticetitlea=explode("#sep#",$all_properticetitlea_a[$hid]);
			$all_properticea=explode("#sep#",$all_properticea_a[$hid]);
			if($all_exproperticea_a[$hid]!=0){
			$all_exproperticea=explode("#sep#",$all_exproperticea_a[$hid]);
			}
			
			
			
			//@$item_type=$_REQUEST['item_type'];
			@$extra_remarks=trim(str_replace("'", "",$extra_remarks_a[$hid]));
			$extra_remarks=explode("\n",$extra_remarks);
			$extra_remarks=implode("<br/>-&nbsp;",$extra_remarks);
			@$txtareaid=$txtareaid_a[$hid];
			
			
			@$bill_data=$conn->query("insert into billing(com_id,billing_month,billing_year) values('$com_id','$bmonth','$byear')");
			
			
			@$order_record=$conn->query("insert into order_record(
			com_id,
			item_id,
			order_number,
			master_id,
			karigor_id,
			insert_by,
			item_qty,
			group_id,ptype,is_active,design_cost,amount_cost,group_name) values('$com_id','$item_id','$phy_ord_num',$master_id,$karigor_id,$user_id,$item_qty,$group_id,$item_type,$is_active,'$design_cost','$amount_cost','$group_name')");
			
			if($order_record){
				@$top_id = $conn->insert_id;
				@$get_salary=$conn->query("select * from product where com_id=$com_id and is_active=1 and id=$item_id");
				if($get_salary){
					$row=mysqli_fetch_array($get_salary);
					@$master_sal=$row['master_price'];
					@$artisan_sal=$row['artisan_price'];
				$conn->query("insert into emp_salary(com_id,item_id,order_number,user_id,salary,is_active) values('$com_id','$item_id','$top_id',$master_id,$master_sal,$is_active)");
				$conn->query("insert into emp_salary(com_id,item_id,order_number,user_id,salary,is_active) values('$com_id','$item_id','$top_id',$karigor_id,$artisan_sal,$is_active)");
				}
				
				for($i=0;$i<count($all_sizeida);$i++){
					$measure_id=$all_sizeida[$i];
					$measurement=$all_sizea[$i];
					$new_ord=$conn->query("insert into order_details(com_id,order_number,mtype,measure_id,measurement,is_active) values('$com_id','$top_id',1,$measure_id,'$measurement',$is_active)");
					
				}
				for($i=0;$i<count($all_properticetitlea);$i++){
					if($all_properticea[$i]!=0){
					$measure_id=$all_properticetitlea[$i];
					$measurement=$all_properticea[$i];
					$conn->query("insert into order_details(com_id,order_number,mtype,measure_id,measurement,is_active) values('$com_id','$top_id',2,$measure_id,'$measurement',$is_active)");
					}
				}
				if($all_exproperticea_a[$hid]!=0){
					for($i=0;$i<count($all_exproperticea);$i++){
						$measure_id=$all_exproperticea[$i];
						$conn->query("insert into order_details(com_id,order_number,mtype,measure_id,measurement,is_active) values('$com_id','$top_id',3,$measure_id,'',$is_active)");
					
					}
				}
				if($txtareaid!=0){
					$conn->query("insert into order_details(com_id,order_number,mtype,measure_id,measurement,is_active) values('$com_id','$top_id',4,$txtareaid,'$extra_remarks',$is_active)");
				}
				//if($ord_type==2){
				//$conn->query("update order_record set dsms_id='$dsms_id' where com_id=$com_id and is_active=1 and order_number='$phy_ord_num'");
				//}
			
				//$taginc=intval($tbl_ord_num)+1;
				//$new_ord=$conn->query("update order_num set order_number=$taginc where com_id=$com_id");
				//mysqli_close($conn);
			}
		}
			if($new_ord){
				echo 1;
			}
		//}else{
			//echo 6; // Monthly bill pending
		//}
		
	}
	
	if(isset($_REQUEST['sendSMS'])){
		if(check_internet_connection()==1){
			$date=date("Y-m-d");
			$com_id=($_SESSION['COM_ID']);
			$insert_by=($_SESSION['USER_ID']);
			$mobile=$_REQUEST['mobile'];
			$phy_ord_num=$_REQUEST['hidden_phy_ord_num'];
			
			$response = file_get_contents($_SESSION['API']."api/data.php?mobile=$mobile&phy_ord_num=$phy_ord_num&com_id=$com_id&chk=14"); //chk=1 means order
			$json = json_decode($response, true);
			if(@$json['auth']==1){
				echo 456;
			}else if($json['auth']==2){
				echo 20000000; //online save not success
			}else if($json['auth']==3){
				echo 30000000; //Not enough sms
			}else if($json['auth']==4){
				echo 30000000; //Not enough sms
			}
		}else{
			echo 40000000; //action in connection failure
		}
		
	}
	
	if(isset($_REQUEST['sendToServerOrder'])){
		if(check_internet_connection()==1){
			$date=date("Y-m-d");
			$com_id=($_SESSION['COM_ID']);
			$insert_by=($_SESSION['USER_ID']);
			@$ordersql=$conn->query("select id,cus_mobile,dv_date from dsms where com_id=$com_id and dv_date>='$date' and is_active=1 and online_status=0 limit 0,30");
			$local_dsmsid=array();
			$local_dsmscus_mobile=array();
			$local_dsmsdv_date=array();
			while($row=mysqli_fetch_array($ordersql)){
				$local_dsmsid[]=$row['id'];
				$local_dsmscus_mobile[]=$row['cus_mobile'];
				$local_dsmsdv_date[]=$row['dv_date'];
			}
			$mo=implode("_",$local_dsmscus_mobile);
			$dv_date=implode("_",$local_dsmsdv_date);
			$response = file_get_contents($_SESSION['API']."api/data.php?mobile=$mo&dv_date=$dv_date&user=$insert_by&com_id=$com_id&chk=1"); //chk=1 means order
			$json = json_decode($response, true);
			if(@$json['auth']==1){
				for($i=0;$i<count($local_dsmsid);$i++){
					$id=$local_dsmsid[$i];
					$update_onlidestatus=$conn->query("update dsms set online_status=1,sms_status=1 where id=$id and com_id=$com_id");
				}
				mysqli_close($conn);
				if($update_onlidestatus){
					echo 10000000; //success
				}
			}else if($json['auth']==2){
				echo 20000000; //online save not success
			}else if($json['auth']==3){
				echo 30000000; //Not enough sms
			}else if($json['auth']==4){
				echo 30000000; //Not enough sms
			}
		}else{
			echo 40000000; //action in connection failure
		}
		
	}
	
	
	
	if(isset($_REQUEST['getSmsDetails'])){
		if(check_internet_connection()==1){
			$com_id=($_SESSION['COM_ID']);
			$response = file_get_contents($_SESSION['API']."api/data.php?com_id=$com_id&chk=3"); //chk=3 means sms details
			$json = json_decode($response, true);
			if(@$json['tbl']!="notok"){
				mysqli_close($conn);
				echo $json['tbl'];
			}else{
				echo 20000000;
			}
		}else{
			echo 40000000; //action in connection failure
		}
	}
	
	
	
	if(isset($_REQUEST['getOrder_Number'])){
			$com_id=($_SESSION['COM_ID']);
			@$ordnum=$conn->query("select id,phy_ord_num from dsms where is_active=1 and com_id=$com_id and is_print=0 order by id desc limit 0,1");
			if(mysqli_num_rows($ordnum)>0){
				$row=mysqli_fetch_array($ordnum);
				echo trim($row['phy_ord_num']);
			}else{
				echo 2;
			}
	}
	
	if(isset($_REQUEST['printStatusUpdate'])){
			$ord_number=trim($_REQUEST['ord_number']);
			$com_id=($_SESSION['COM_ID']);
			@$ordnum=$conn->query("update dsms set is_print=1 where is_active=1 and com_id=$com_id and phy_ord_num='$ord_number'");
			if($ordnum){
				echo 1;
			}else{
				echo 2;
			}
	}
	
	if(isset($_REQUEST['barcodeScan'])){
			$barcode=trim($_REQUEST['ds_item_id']);
			$com_id=($_SESSION['COM_ID']);
			$product_fabrics=$conn->query("select * from product where is_active=2 and item_code='$barcode' and stock_qty>0 limit 0,1");
			if(mysqli_num_rows($product_fabrics)>0){
				$rows=mysqli_fetch_array($product_fabrics);
				echo $rows['id']."#sep#".$rows['product_name']."#sep#".$rows['uom']."#sep#".$rows['selling_price']."#sep#".$rows['stock_qty']."#sep#".$rows['avg_price']."#sep#".$rows['item_code'];
			}else{
				echo 2;
			}
			
	}
	
	if(isset($_REQUEST['barcodeScanStockIn'])){
			$item_name=trim($_REQUEST['ds_item_id']);
			$com_id=($_SESSION['COM_ID']);
			$search_item=$conn->query("select pn.id,pn.product_name,pn.item_code,pn.avg_price,pn.selling_price,pn.uom,pn.stock_qty,pn.total_price from product pn where pn.com_id=$com_id and pn.product_name like '%$item_name%' or pn.item_code like '%$item_name%' and pn.is_active=2");
			mysqli_close($conn);
			$i=1;
			if(mysqli_num_rows($search_item)>0){
				$rows=mysqli_fetch_array($search_item);
				$item_code=($rows['item_code']=="")? '0' : $rows['item_code'];
				echo trim($rows['id']).'#sep#'.$rows['product_name'].'#sep#'.$item_code.'#sep#'.$rows['uom'].'#sep#'.$rows['selling_price'].'#sep#'.$rows['stock_qty'].'#sep#'.$rows['total_price'].'#sep#'.$rows['avg_price'].'#sep#2';
			}else{
				echo 2;
			}
			
	}
	
	if(isset($_REQUEST['setAddress'])){
			$cus_address=$_REQUEST['cus_address'];
			$tbl_id=$_REQUEST['tbl_id'];
			$status=$_REQUEST['status'];
			$com_id=$_SESSION['COM_ID'];
			if($status==1){
				@$setaddress=$conn->query("update customer set cus_name='$cus_address' where id=$tbl_id and com_id=$com_id");
				$conn->query("update dsms set cus_name='$cus_address' where cus_mobile=TRIM((select cc.cus_mobile from customer cc where cc.id=$tbl_id))");
			}else{
				@$setaddress=$conn->query("update customer set cus_address='$cus_address' where id=$tbl_id and com_id=$com_id");
			}
			if($setaddress){
				echo 1;
			}else{
				echo 2;
			}
	}
	
	if(isset($_REQUEST['saveCustomer'])){
		$customer_name=$_REQUEST['customer_name'];
		$customer_mobile=$_REQUEST['customer_mobile'];
		$customer_address=$_REQUEST['customer_address'];
		$com_id=$_SESSION['COM_ID'];
		$chk_mobile=$conn->query("select id from customer where cus_mobile='$customer_mobile' and is_active=1 and com_id='$com_id'");
		if(mysqli_num_rows($chk_mobile)>0){
			echo 3;
		}else{
			@$savesql=$conn->query("insert into customer(cus_name,cus_mobile,cus_address,com_id) values('$customer_name','$customer_mobile','$customer_address','$com_id')");
			@$chkAuthUserid = $conn->insert_id;
			$conn->query("insert into update_due(cus_id,com_id,last_due) values($chkAuthUserid,$com_id,0)");
			if($savesql){
				echo 1;
			}else{
				echo 2;
			}
		}
		
	}
	
	if(isset($_REQUEST['sendMonthlyBill'])){
		if(check_internet_connection()=='1'){
			date_default_timezone_set("Asia/Dhaka");
			$date=date("F-Y", strtotime("-1 months")); 
			$mnt=date("m", strtotime("-1 months")); 
			$ex=explode("-",$date);
			$year=$ex[1];
			$com_id=($_SESSION['COM_ID']);
			$insert_by=($_SESSION['USER_ID']);
			$sender_number=trim($_REQUEST['sender_number']);
			$bill_tk=trim($_REQUEST['bill_tk']);
			$security_code=trim($_REQUEST['security_code']);
			for($j=0;$j<strlen($security_code);$j++){
				if(ord($security_code[$j])>47 && ord($security_code[$j])<58){
					@$security_codes.=$security_code[$j];
				}
			}
			
			$response = file_get_contents($_SESSION['API']."api/data.php?com_id=$com_id&insert_by=$insert_by&sender_number=$sender_number&bill_tk=$bill_tk&security_no=$security_codes&month=$mnt&year=$year&chk=6"); //chk=6 means monthly bill pay details
			$json = json_decode($response, true);
			if($json['auth']==1){
				echo 10000000; //online save success
			}else if($json['auth']==2){
				echo 20000000; //online save not success
			}else if($json['auth']==3){
				echo 30000000; //Security code not match
			}
		}else{
			echo 40000000; //action in connection failure
		}
	}
	
	if(isset($_REQUEST['sendToServerReceivedOrder'])){
		if(check_internet_connection()==1){
			$com_id=($_SESSION['COM_ID']);
			$insert_by=($_SESSION['USER_ID']);
			
			$factory_mobile=explode("#sep#",$_REQUEST['factory_mobile']);
			$id=$factory_mobile[0];
			$mo=$factory_mobile[1];
			$dv_date=$factory_mobile[2];
			$local_factory_receive_date=$factory_mobile[3];
			$response = file_get_contents($_SESSION['API']."api/data.php?mobile=$mo&dv_date=$dv_date&factory_receive_date=$local_factory_receive_date&com_id=$com_id&chk=4"); //chk=4 production received order
			$json = json_decode($response, true);
			if(@$json['auth']==1){
				$update_onlidestatus=$conn->query("update dsms set factory_status=2 where id=$id and com_id=$com_id");
				mysqli_close($conn);
				if($update_onlidestatus){
					echo 10000000; //success
				}
			}else if($json['auth']==2){
				echo 20000000; //online save not success
			}
		}else{
			echo 40000000; //action in connection failure
		}
		
	}
	
	if(isset($_REQUEST['verification'])){
		date_default_timezone_set("Asia/Dhaka");
		$dates=date("d-m-Y");
		$com_id=($_SESSION['COM_ID']);
		$insert_by=($_SESSION['USER_ID']);
		$pin1=md5(trim($_REQUEST['pina']));
		$pin2=md5(trim($_REQUEST['pinb']));
		$bill_save=trim($_REQUEST['bill_save']);
		$month_year=explode("_",$_REQUEST['month_year']);
		$mnt=$month_year[0];
		$year=$month_year[1];
		$security_save=trim($_REQUEST['security_save']);
		$chk_security=$conn->query("select * from security where is_active=0 and pin1='$pin1' and pin2='$pin2'");
		if(mysqli_num_rows($chk_security)>0){
			$security_array=mysqli_fetch_array($chk_security);
			$sec_id=$security_array['id'];
			$billing=$conn->query("update billing set is_active=1,bill='$bill_save',encodedata='$security_save',insert_by=$insert_by,bill_pay_date='$dates',sec_id=$sec_id where billing_month='$mnt' and billing_year='$year' and is_active=0 and com_id=$com_id");
			if($billing){
				$security=$conn->query("update security set is_active=1 where pin1='$pin1' and pin2='$pin2'");
				if($security){
					echo 20000000;
				}else{
					echo 30000000;
				}
			}else{
				echo 30000000;
			}
			
		}else{
			echo 10000000;
		}
	}
	
	if(isset($_REQUEST['delOrderFnc'])){
		$ord_num=$_REQUEST['ord_num'];
		$com_id=($_SESSION['COM_ID']);
		$del_ord=$conn->query("update order_record set is_active=2 where id='$ord_num' and com_id=$com_id");
		$conn->query("update emp_salary set is_active=2 where order_number='$ord_num' and com_id=$com_id");
		$conn->query("update order_details set is_active=2 where order_number='$ord_num' and com_id=$com_id");
		mysqli_close($conn);
		if($del_ord){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['activeOrderFnc'])){
		$ord_num=$_REQUEST['ord_num'];
		$com_id=($_SESSION['COM_ID']);
		$del_ord=$conn->query("update order_record set is_active=0 where id='$ord_num' and com_id=$com_id");
		$conn->query("update emp_salary set is_active=0 where order_number='$ord_num' and com_id=$com_id");
		$conn->query("update order_details set is_active=0 where order_number='$ord_num' and com_id=$com_id");
		mysqli_close($conn);
		if($del_ord){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['saveMasterKarigor'])){
		$com_id=($_SESSION['COM_ID']);
		$emp_type=$_REQUEST['emp_type'];
		$emp_name=$_REQUEST['emp_name'];
		$emp_mobile=$_REQUEST['emp_mobile'];
		$salary_type=$_REQUEST['salary_type'];
		$emp_address=$_REQUEST['emp_address'];
		$emp_salary=trim($_REQUEST['emp_salary']);
		$tbl_last_id=intval($_REQUEST['tbl_last_id']);
		$insert=$conn->query("insert into user(com_id,user_name,mobile,emp_type,emp_address,salary_type,salary) values($com_id,'$emp_name','$emp_mobile',$emp_type,'$emp_address','$salary_type','$emp_salary')");
		if($insert){
			@$top_id = $conn->insert_id;
			?>
			<tr style="color:<?php 
								if($emp_type==1){
									echo "blue";
								}else if($emp_type==3){
									echo "#b60bc1;";
								}
								?>">
				<td><button onclick="delEmployee('<?php echo $top_id; ?>','<?php echo $tbl_last_id; ?>')" class="btn btn-danger form-control" id=""><?php echo $tbl_last_id; ?></button></td>
				<td><?php echo $emp_name; ?></td>
				<td><?php echo $emp_mobile; ?></td>
				<td><?php if($emp_type==1){ echo "Master"; }else if($emp_type==2){ echo "Karigor"; }else{ echo "Staff";} ?></td>
				<td><?php if($salary_type==1){ echo "Item Wise"; }else if($salary_type==2){ echo "Daily Basis (".$emp_salary."/=)"; }else{ echo "Monthly Basis (".$emp_salary."/=)";} ?></td>
				<td></td>
			</tr>
			<?php 
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['getAllEmployeeList'])){
		$com_id=($_SESSION['COM_ID']);
		$attendance_date=explode("/",$_REQUEST['attendance_date']);
		$attendance_date=$attendance_date[2].'-'.$attendance_date[1].'-'.$attendance_date[0];
		
		$all_emp_list=$conn->query("select user.*,(select id from daily_attendance where emp_id=user.id and attendence_date='$attendance_date' and is_active=1) chk_attandence from user where is_active=1 and com_id=$com_id and emp_type in(1,2,3) order by emp_type asc");

		mysqli_close($conn);
		if(mysqli_num_rows($all_emp_list)>0){
			$c=0;$m=1;
			while($array=mysqli_fetch_array($all_emp_list)){
				$c=$m++;
				if($array['chk_attandence']==""){
			?>
			<tr style="color:<?php 
								if($array['emp_type']==1){
									echo "blue";
								}else if($array['emp_type']==3){
									echo "#b60bc1;";
								}
								?>">
				<td style="text-align:center"><?php echo $c; ?></td>
				<td>
				<?php echo $array['user_name']; ?><br/>
				<?php echo $array['mobile']; ?>
				</td>
				<td style="text-align:center"><?php if($array['emp_type']==1){ echo "Master"; }else if($array['emp_type']==2){ echo "Karigor"; }else{ echo "Staff";} ?></td>
				<td style="text-align:center"><?php if($array['salary_type']==1){ echo "Item Wise"; }else if($array['salary_type']==2){ echo "Daily Basis"; }else{ echo "Monthly Basis";} ?></td>
				<td style="text-align:center">
				<button style="" onclick="setEmpStatus('present','<?php echo $array['id']; ?>','<?php echo $array['emp_type']; ?>','<?php echo $array['salary_type']; ?>','<?php echo $array['user_name']; ?>','<?php echo $array['mobile']; ?>','<?php echo $attendance_date; ?>','<?php echo $array['salary']; ?>');" name="btn" value="sub" id="r_searching_btn" class="btn btn-success">Present</button>
				<button style="" onclick="setEmpStatus('absent','<?php echo $array['id']; ?>','<?php echo $array['emp_type']; ?>','<?php echo $array['salary_type']; ?>','<?php echo $array['user_name']; ?>','<?php echo $array['mobile']; ?>','<?php echo $attendance_date; ?>','<?php echo $array['salary']; ?>');" name="btn" value="sub" id="r_searching_btn" class="btn btn-warning">Absent</button>
				</td>
			</tr>
			<?php 
				}
		}
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['setAttendanceTable'])){
		$com_id=($_SESSION['COM_ID']);
		$attendance_date=explode("/",$_REQUEST['attendance_date']);
		$attendance_date=$attendance_date[2].'-'.$attendance_date[1].'-'.$attendance_date[0];
		
		$all_emp_list=$conn->query("select daily_attendance.*,(select user_name from user where id=daily_attendance.emp_id and is_active=1) user_name,(select mobile from user where id=daily_attendance.emp_id and is_active=1) mobile,(select salary from user where id=daily_attendance.emp_id and is_active=1) salary from daily_attendance where is_active=1 and attendence_date='$attendance_date' order by emp_type asc");

		mysqli_close($conn);
		if(mysqli_num_rows($all_emp_list)>0){
			$c=0;$m=1;
			while($array=mysqli_fetch_array($all_emp_list)){
				$c=$m++;
				
			?>
			
											
			<tr style="color:<?php 
								if($array['emp_type']==1){
									echo "blue";
								}else if($array['emp_type']==3){
									echo "#b60bc1;";
								}
								?>">
				<td style="text-align:center">
				<?php if($array['sprocess_status']!='processed'){ ?>
					<button onclick="delPresentStatus('<?php echo $array['id']; ?>')" class="btn btn-danger form-control" id=""><?php echo $c; ?></button>
				<?php }else{ echo $c;} ?>
				</td>
				<td>
				<?php echo $array['user_name']; ?><br/>
				<?php echo $array['mobile']; ?><br/>
				Date: <?php echo date_format(date_create($array['attendence_date']),"d/m/Y"); ?><br/>
				<i style="font-weight: bold;color:<?php echo ($array['pastatus']=='present')? 'green' : 'red'; ?>"><?php echo $array['pastatus']; ?></i>
				</td>
				<td style="text-align:center">
					<?php if($array['emp_type']==1){ echo "Master"; }else if($array['emp_type']==2){ echo "Karigor"; }else{ echo "Staff";} ?><br/>
					<i style="color:red"><?php if($array['salary_type']==1){ echo "Item Wise"; }else if($array['salary_type']==2){ echo "Daily Basis"; }else{ echo "Monthly";} ?></i>
				</td>
				<td style="text-align:right;font-weight:bold">
					<?php 
					if($array['salary_type']!=1){
					?>
					<?php echo $array['original_salary']; ?>
					<?php }else{
						echo "";
					} ?>
				</td>
				<td style="text-align:right;font-weight:bold">
					<?php 
					if($array['pastatus']=='present'){
						if($array['sprocess_status']!="processed"){
							if($array['salary_type']!=1){
							
							?>
							<input type="text" style="text-align: right;" onkeyup="updateAnyColumn('deduction_salary','<?php echo $array['id']; ?>','daily_attendance');" placeholder="Deduction" value="<?php echo $array['deduction_salary']; ?>" id="deduction_salary<?php echo $array['id']; ?>" class="form-control" />	
							<?php }else{
								echo "";
							}
						}
					}	
					?>
				</td>
				<td style="text-align:right;font-weight:bold">
					<input type="text" style="" placeholder="Remarks" value="<?php echo @$array['remarks']; ?>" onkeyup="updateAnyColumn('remarks','<?php echo $array['id']; ?>','daily_attendance');" id="remarks<?php echo $array['id']; ?>" class="form-control" />	
				</td>
				<td style="text-align:center">
				<?php 
					if($array['pastatus']=='present'){
						if($array['sprocess_status']!="processed"){
							if($array['salary_type']==2){
							?>
							<button style="" onclick="salaryProcessedBtn('<?php echo $array['id']; ?>','<?php echo $array['emp_id']; ?>','<?php echo $array['emp_type']; ?>','<?php echo $array['salary_type']; ?>','<?php echo $array['emp_name']; ?>','<?php echo $array['emp_mobile']; ?>','<?php echo $array['attendence_date']; ?>','<?php echo $array['original_salary']; ?>');" name="btn" value="sub" id="salary_process<?php echo $array['id']; ?>" class="btn btn-success">Process</button>
							<?php }else{
								echo "";
							} 
						}
					}?>
				</td>
			</tr>
			<?php 
			
		}
		}else{
			echo 2;
		}
	}
	
	
	if(isset($_REQUEST['setEmpStatus'])){
	$com_id=($_SESSION['COM_ID']);
		$user_id=$_SESSION['USER_ID'];
		$asstatus=$_REQUEST['asstatus'];
		$emp_id=$_REQUEST['emp_id'];
		$emp_type=$_REQUEST['emp_type'];
		$salary_type=$_REQUEST['salary_type'];
		$user_name=$_REQUEST['user_name'];
		$mobile=$_REQUEST['mobile'];
		if($salary_type==3){ //monthly
			$salary=round(($_REQUEST['salary']/30),2);
		}else{
			$salary=$_REQUEST['salary'];
		}
		$attendance_date=$_REQUEST['attendance_date'];
		
		$all_emp_list=$conn->query("insert into daily_attendance(emp_id,
		emp_type,
		salary_type,
		emp_name,
		emp_mobile,
		attendence_date,
		pastatus,
		original_salary,
		insert_by) values('$emp_id',
		'$emp_type',
		'$salary_type',
		'$user_name',
		'$mobile',
		'$attendance_date',
		'$asstatus',
		'$salary',
		'$user_id')");

		mysqli_close($conn);
		if($all_emp_list){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['updateAnyColumn'])){
		$tbl_id=$_REQUEST['tbl_id'];
		@$field_name=$_REQUEST['field_name'];
		@$field_value=$_REQUEST['field_value'];
		@$tbl_name=$_REQUEST['tbl_name'];
		$ucol="";
		if($field_name=="remarks"){
			$ucol="remarks='$field_value'";
		}
		if($field_name=="deduction_salary"){
			$ucol="deduction_salary='$field_value'";
		}
		
		$sql=$conn->query("update $tbl_name set $ucol where id=$tbl_id");
		if($sql){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['dateWiseStaffPrint'])){
		date_default_timezone_set("Asia/Dhaka");
		$com_id=($_SESSION['COM_ID']);
		$date1=explode("/",$_REQUEST['date1']);
			$date2=explode("/",$_REQUEST['date2']);
			$status=$_REQUEST['extra_item'];
			$emp_list=$_REQUEST['karigor_list'];
			$con="";
			if($emp_list!=""){
				$con.=" and emp_id=$emp_list ";
			}
			$total=0;
			$c=0;$sl=0;
			//$d1=$date1[2]."-".$date1[1]."-".$date1[0];
			$d1="";
			$d2=$date2[2]."-".$date2[1]."-".$date2[0];
			if(@$_REQUEST['date1']!=""){
				$d1=$date1[2]."-".$date1[1]."-".$date1[0];
				$con.=" and date(insert_date) between '$d1' and '$d2'";
			}else{
				$con.=" and date(insert_date)<='$d2'";
			}
			if($status=='earning'){
				$statuss=0;
				$monthly_report_sql=$conn->query("SELECT (select user_name from user where user.id=salary_transaction.emp_id) emp_name,(select emp_type from user where user.id=salary_transaction.emp_id) emp_type,(select mobile from user where user.id=salary_transaction.emp_id) emp_mobile, sum(`actual_salary`) emp_tk,emp_id FROM `salary_transaction` WHERE `is_active`=1 and status=$statuss $con group by emp_id order by emp_tk desc");
			}else if($status=="payable"){
				$statuss=1;
				$monthly_report_sql=$conn->query("SELECT (select user_name from user where user.id=salary_transaction.emp_id) emp_name,(select emp_type from user where user.id=salary_transaction.emp_id) emp_type,(select mobile from user where user.id=salary_transaction.emp_id) emp_mobile, sum(`actual_salary`) emp_tk,emp_id FROM `salary_transaction` WHERE `is_active`=1 and status=$statuss $con group by emp_id order by emp_tk desc");
			}
			
		?>
			<div class="row" style="background:white">
			<div class="col-xs-12 col-sm-12">
						
						<?php 
					$tprofit=0;
					if(mysqli_num_rows($monthly_report_sql)>0){
						?>
						<label>Staff Earning/Payable Report </label>
						<table id="dynamic-table" class="table table-striped table-bordered table-hover">
							<thead>
								<tr>
									<th style="width:5%;text-align: center;">Sl</th>
									<th style="width:30%;">Employee Name</th>
									<th style="width:30%;text-align:center">Employee Type</th>
									<th style="width:10%;text-align:right"><?php echo $status; ?> (Tk.)</th>
								</tr>
							</thead>
							<tbody>
								<?php 
									$sl=1;$tot_qty=0;
									while($rows=mysqli_fetch_array($monthly_report_sql)){
											$emp_ids=$rows['emp_id'];
											$tot_qty+=$rows['emp_tk'];
											$c=$sl++;
											?>
											<tr style="color: <?php 
											if($rows['emp_type']==1){
												echo "blue";
											}else if($rows['emp_type']==3){
												echo "#b60bc1;";
											}
											?>">
											<td style="text-align: center;"><?php echo $c; ?></td>
											<td>
												<span style='cursor: pointer;' data-toggle="modal" data-target="#myModal" onclick="showEmployeesStaffDetails('<?php echo $d1; ?>','<?php echo $d2; ?>','<?php echo $status; ?>','<?php echo $emp_ids; ?>','<?php echo $rows['emp_name'].'('.$rows['emp_mobile'].')'; ?>')">
													<?php echo $rows['emp_name'].'('.$rows['emp_mobile'].')'; ?>
												</span>
											</td>
											<td style="text-align: center;">
												<?php if($rows['emp_type']==1){ echo "Master"; }else if($rows['emp_type']==2){ echo "Karigor"; }else{ echo "Staff";} ?>
											</td>
											<td style="text-align: right;"><?php echo @$rows['emp_tk']; ?>/=</td>
											</tr>
											<?php 
										}
								?>
								<tr>
								<td colspan="3" style="text-align: right;font-weight:bold">
									Total: 
								</td>
								<td style="text-align: right;font-weight:bold"><?php echo @$tot_qty; ?>/=</td>
								</tr>
							</tbody>
							
						</table>
						<?php 
					}
					?>	

			</div>
					
			</div>
		
			<?php 
			
	}
	
		if(isset($_REQUEST['searchStockItem'])){
		@$item_name=$_REQUEST['item_name'];
		@$item_code=trim($_REQUEST['item_code']);
		if($item_code!=""){
			@$item=$item_code;
		}
		if($item_name!=""){
			@$item=$item_name;
		}
		
		$com_id=($_SESSION['COM_ID']);
		
		@$product=$conn->query("select * from product where is_active=2 and com_id=$com_id and ptype in(1,2) and item_code='$item'");
		
		if(mysqli_num_rows($product)>0){
		$i=1;$tqty=0;$ttaka=0;
			while($rows=mysqli_fetch_array($product)){
				$j=$i++;
				$tqty+=$rows['stock_qty'];
				$ttaka+=round(($rows['stock_qty']*$rows['purchase_price']),2);
		?>
				<tr>
					<td style="text-align:center">
						<?php 
							echo $j;
						?>
					</td>
					<td style="padding-left:4px">
					<?php echo $rows['product_name']; ?>
					</td>
					
					<td style="text-align:center">
					<?php echo $rows['item_code']; ?>
					</td>
					<td style="text-align:center">
					<?php echo ($rows['stock_qty']<$_SESSION['SAFETY_STOCK'])? "<span style='color:red'>".$rows['stock_qty']."</sapn>" : $rows['stock_qty']; ?><p style="font-size:8px;color:blue"><?php echo $rows['uom']; ?></p>
					</td>
					<td style="text-align:right;padding-right:4px"><?php echo $rows['purchase_price']; ?></td>
					<td style="text-align:right;padding-right:4px">
					 <span style="<?php echo ($rows['purchase_price']>=$rows['selling_price'])? 'color:red': ''; ?>"><?php echo $rows['selling_price']; ?></span>
					</td>
					
				</tr>
			<?php 
				}
				?>
				<tr>
					<td colspan="3" style="text-align: right;font-weight: bold;">
						Total Stock Qty & Price: 
					</td>
					<td style="text-align: center;font-weight: bold;">
						<?php echo $tqty; ?>
					</td>
					<td style="text-align: right;font-weight: bold;padding-right: 4px;">
						<?php echo $ttaka; ?>
					</td>
				</tr>
			
				<?php 
			
			}else{
				echo "No result found.";
			}
	}
	
	if(isset($_REQUEST['getEmpAttendance'])){
		date_default_timezone_set("Asia/Dhaka");
		$date=date("Y-m-d");
		$com_id=($_SESSION['COM_ID']);
		$attendance_emp_id=$_REQUEST['attendance_emp_id'];
		
		$sdate=explode("/",$_REQUEST['sdate']);
		$sdate=$sdate[2].'-'.$sdate[1].'-'.$sdate[0];
		
		@$edate=explode("/",$_REQUEST['edate']);
		$edate=@$edate[2].'-'.@$edate[1].'-'.@$edate[0];
		
		
		if($attendance_emp_id=="all"){
			$all_emp_list=$conn->query("select daily_attendance.*,date(daily_attendance.insert_date) insert_date,(select user_name from user where id=daily_attendance.emp_id and is_active=1) user_name,(select mobile from user where id=daily_attendance.emp_id and is_active=1) mobile,(select salary from user where id=daily_attendance.emp_id and is_active=1) salary from daily_attendance where is_active=1 and attendence_date between '$sdate' and '$edate' order by emp_type asc");
		}else{
			$all_emp_list=$conn->query("select daily_attendance.*,date(daily_attendance.insert_date) insert_date,(select user_name from user where id=daily_attendance.emp_id and is_active=1) user_name,(select mobile from user where id=daily_attendance.emp_id and is_active=1) mobile,(select salary from user where id=daily_attendance.emp_id and is_active=1) salary from daily_attendance where is_active=1 and emp_id='$attendance_emp_id' and attendence_date between '$sdate' and '$edate' order by emp_type asc");
		
		}
		
		
		mysqli_close($conn);
		if(mysqli_num_rows($all_emp_list)>0){
			$c=0;$m=1;
			while($array=mysqli_fetch_array($all_emp_list)){
				$c=$m++;
				
			?>
										
			<tr style="color:<?php 
								if($array['emp_type']==1){
									echo "blue";
								}else if($array['emp_type']==3){
									echo "#b60bc1;";
								}
								?>">
				<td style="text-align:center">
				<?php
				if($array['sprocess_status']!='processed' && $date==$array['insert_date']){
				?>
					<button onclick="delPresentStatus('<?php echo $array['id']; ?>')" class="btn btn-danger form-control" id=""><?php echo $c; ?></button>
				<?php }else{ echo $c;} ?>
				</td>
				<td>
				<?php echo $array['user_name']; ?><br/>
				<?php echo $array['mobile']; ?><br/>
				Date: <?php echo date_format(date_create($array['attendence_date']),"d/m/Y"); ?><br/>
				<i style="font-weight: bold;color:<?php echo ($array['pastatus']=='present')? 'green' : 'red'; ?>"><?php echo $array['pastatus']; ?></i>
				</td>
				<td style="text-align:center">
					<?php if($array['emp_type']==1){ echo "Master"; }else if($array['emp_type']==2){ echo "Karigor"; }else{ echo "Staff";} ?><br/>
					<i style="color:red"><?php if($array['salary_type']==1){ echo "Item Wise"; }else if($array['salary_type']==2){ echo "Daily Basis"; }else{ echo "Monthly";} ?></i>
				</td>
				<td style="text-align:right;font-weight:bold">
					<?php 
					if($array['salary_type']!=1){
					?>
					<?php echo $array['original_salary']; ?>
					<?php }else{
						echo "";
					} ?>
				</td>
				<td style="text-align:right;font-weight:bold">
					<?php 
					if($array['pastatus']=='present'){
						if($array['sprocess_status']!="processed"){
							if($array['salary_type']!=1){
							?>
							<input type="text" style="text-align: right;" onkeyup="updateAnyColumn('deduction_salary','<?php echo $array['id']; ?>','daily_attendance');" placeholder="Deduction" value="<?php echo $array['deduction_salary']; ?>" id="deduction_salary<?php echo $array['id']; ?>" class="form-control" />	
							<?php }else{
								echo "";
							} 
						}
					}
					?>
				</td>
				<td style="text-align:right;font-weight:bold">
					<input type="text" style="" placeholder="Remarks" value="<?php echo @$array['remarks']; ?>" onkeyup="updateAnyColumn('remarks','<?php echo $array['id']; ?>','daily_attendance');" id="remarks<?php echo $array['id']; ?>" class="form-control" />	
				</td>
				<td style="text-align:center">
				<?php 
					if($array['pastatus']=='present'){
						if($array['sprocess_status']!="processed"){
							if($array['salary_type']==2){
							?>
							<button style="" onclick="salaryProcessedBtn('<?php echo $array['id']; ?>','<?php echo $array['emp_id']; ?>','<?php echo $array['emp_type']; ?>','<?php echo $array['salary_type']; ?>','<?php echo $array['emp_name']; ?>','<?php echo $array['emp_mobile']; ?>','<?php echo $array['attendence_date']; ?>','<?php echo $array['original_salary']; ?>');" name="btn" value="sub" id="salary_process<?php echo $array['id']; ?>" class="btn btn-success">Process</button>
							<?php }else{
								echo "";
							} 
						}
					}?>
				</td>
			</tr>
			<?php 
			
		}
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['delPresentStatus'])){
		$tbl_id=$_REQUEST['tbl_id'];
		$sql=$conn->query("update daily_attendance set is_active=0 where id=$tbl_id");
		if($sql){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['delEmployee'])){
		$tbl_id=$_REQUEST['tbl_id'];
		$sql=$conn->query("update user set is_active=0 where id=$tbl_id");
		if($sql){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['delCustomer'])){
		$tbl_id=$_REQUEST['tbl_id'];
		$sql=$conn->query("update customer set is_active=0 where id=$tbl_id");
		if($sql){
			echo 1;
		}else{
			echo 2;
		}
	}
	

	
	if(isset($_REQUEST['delExpense'])){
		$tbl_id=$_REQUEST['tbl_id'];
		$sql=$conn->query("update expenses set is_active=0 where id=$tbl_id");
		if($sql){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['activeInactive'])){
		$text_id=$_REQUEST['text_id'];
		$acinac=$_REQUEST['acinac'];
		$com_id=($_SESSION['COM_ID']);
			if($acinac==1){
			$conn->query("update set_text set is_active=$acinac where com_id=$com_id and id=$text_id");
			$conn->query("update set_text set is_active=0 where com_id=$com_id and id!=$text_id");
			}else{
				//$conn->query("update set_text set is_active=$acinac where com_id=$com_id and id=$text_id");
			}
				@$textsql=$conn->query("select * from set_text where com_id=$com_id order by id desc limit 0,15");
				mysqli_close($conn);
				if($textsql){
				$m=1;
				while($row=mysqli_fetch_array($textsql)){
					if($row['is_active']==1){
					?>
					<div class="panel panel-success">
					  <div class="panel-heading"><?php echo $m++; ?></div>
					  <div class="panel-body"><?php echo $row['sms_text']; ?></div>
					  <a href="javascript:void(0)" style="margin:15px" class="btn btn-success">Active</a>
					</div>
					<?php 
					}else{
						?>
						<div class="panel panel-warning">
						  <div class="panel-heading"><?php echo $m++; ?></div>
						  <div class="panel-body"><?php echo $row['sms_text']; ?></div>
						  <a href="javascript:void(0)" onclick="activeInactive('<?php echo $row['id']; ?>','1')" style="margin:15px" class="btn btn-warning">In Active</a>
						</div>
					<?php 
					}
				}
			}else{
				echo 20000000;
			}
		
	}
	
	if(isset($_REQUEST['editAllformation'])){
		$tbl_id=$_REQUEST['tbl_id'];
		$tbl_name=$_REQUEST['tbl_name'];
		$extra_tbl=$_REQUEST['extra_tbl'];
		$customer_id=$_REQUEST['customer_id'];
		if($_REQUEST['field_name']=="mobile"){
			$edit_cus_name=trim($_REQUEST['edit_cus_name']);
			if($tbl_name=='dsms'){
				$conn->query("update $tbl_name set cus_mobile='$edit_cus_name' where phy_ord_num='$tbl_id'");
			}else{
				$conn->query("update $tbl_name set cus_mobile='$edit_cus_name' where id='$tbl_id'");
			}
			$info=$conn->query("update $extra_tbl set cus_name='$edit_cus_name' where id='$customer_id'");
		}
		
		if($_REQUEST['field_name']=="cus_name"){
			$edit_cus_name=trim($_REQUEST['edit_cus_name']);
			if($tbl_name=='dsms'){
				$conn->query("update $tbl_name set cus_name='$edit_cus_name' where phy_ord_num='$tbl_id'");
			}
			$info=$conn->query("update $extra_tbl set cus_name='$edit_cus_name' where id='$customer_id'");
		}
		
		if($_REQUEST['field_name']=="date1"){
			$edit_cus_name=trim($_REQUEST['edit_cus_name']);
				$ex=explode("/",$edit_cus_name);
				$date1=$ex[2]."-".$ex[1]."-".$ex[0];
			$info=$conn->query("update dsms set dv_date='$date1' where phy_ord_num='$tbl_id'");
		}
		
		if($info){
		echo 1;
	}
			
	}
	
	
	if(isset($_REQUEST['search_btn'])){
		$mobile=trim($_REQUEST['mobile']);
		$com_id=($_SESSION['COM_ID']);
		$product_fabrics=$conn->query("select * from product where is_active=2 order by id asc");
		$fabricsoption="";
		while($rows=mysqli_fetch_array($product_fabrics)){
				$fab_id=$rows['id'];
				$fab_title=$rows['product_name'];
				$fabricsoption.="<option value='$fab_id'>$fab_title</option>";
			 } 
		$chk_com=$conn->query("select DISTINCT(ds.id),date(ds.insert_date) order_date,ds.sms_status,ds.order_type,ds.dv_date,ds.sent_time,ds.tagnum,ds.phy_dv_date,ds.phy_ord_num,ds.amount,ds.cus_name,(select id from customer where cus_mobile=ds.cus_mobile and is_active=1 limit 0,1) customer_id,ds.cus_mobile,ds.discount,ds.factory_status,ds.factory_receive_date,ds.box_number from dsms ds,order_record ord where ds.id=ord.dsms_id and ds.is_active=1 and ds.occasion=0 and ord.com_id=$com_id and (ord.order_number='$mobile' or ds.cus_mobile='$mobile' or ds.phy_ord_num='$mobile') and ord.is_active=1 order by ds.id desc limit 0,3");
		if(mysqli_num_rows($chk_com)>0){
			$si=1;
			while($rrow=mysqli_fetch_array($chk_com)){
			$s=$si++;
			$sid=$rrow['id'];
			$customer_id=$rrow['customer_id'];
			$total_tk=$rrow['amount'];
			$discount=$rrow['discount'];
			$box_number=$rrow['box_number'];
			$phy_ord_num=$rrow['phy_ord_num'];
			if($discount>0){
				$total_tk=round($total_tk+$discount);
			}
			$total_tk1=intval($total_tk-$discount);
			$chk_com_p=$conn->query("SELECT (select product_name from product where id=sd.item_id) pname,sd.master_assign_date,sd.assign_date,sd.item_qty pqty,sd.order_number,sd.id ord_id,sd.receive_qty,sd.delivery_qty,sd.master_cutting_qty,(select user_name from user where id=sd.maker) maker_name,(select user_name from user where id=sd.karigor_id) fmaker_name FROM `order_record` sd WHERE sd.com_id=$com_id and sd.is_active=1 and sd.dsms_id=$sid");
			$payment_detail=$conn->query("SELECT accounting.*,date(accounting.insert_date) indate FROM `accounting` WHERE `com_id`=$com_id and is_active=1 and `dsms_id`=$sid");
			$fab_taka_sql=$conn->query("SELECT f_total,total_receive FROM direct_sale_head dsh,`direct_sale` ds WHERE dsh.id=ds.`dstid` and ds.`order_number`='$phy_ord_num'");
			if(mysqli_num_rows($fab_taka_sql)>0){
			$fab_taka_row=mysqli_fetch_array($fab_taka_sql);
			$f_total_taka=$fab_taka_row['f_total'];
			}else{
				$f_total_taka=0;
			}
			echo "<div class='row'><div class='col-xs-12 col-sm-12'>";
			$ptbl='<table id="example" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>SL</th>
						<th>Dress/Order Number</th>
						<th>Qty</th>
					</tr>
				</thead>
				<tbody>';
				$ptbl2="";	
				$i=1;
				//$all_measurement=array();
				while($rrows=mysqli_fetch_array($chk_com_p)){
					$j=$i++;
					$code_no=$rrows['ord_id'];
					$pname=$rrows['pname'];
					@$maker_name=$rrows['maker_name'];
					@$master_assign_date=$rrows['master_assign_date'];
					@$assign_date=$rrows['assign_date'];
					$pqty=$rrows['pqty'];
					$receive_qty=$rrows['receive_qty'];
					$maker_name=($rrows['maker_name']=="")? $rrows['fmaker_name'] : $rrows['maker_name'];
					$delivery_qty=$rrows['delivery_qty'];
					$master_cutting_qty=$rrows['master_cutting_qty'];
					$order_number=$rrows['order_number']."#sep#".$rrows['ord_id']."#sep#".$s;
					
					if($master_cutting_qty<$pqty){
						$cutting="<input type='number' style='width:45px;text-align:center' id='cdressQtys$j$s'/>
							<input type='hidden' value='$order_number' id='chidebtn$j$s'/>
							<button style='background: #0000ff42;color: #000000c4;' onclick='recCuttingBtn($j$s);' name='btn' id='dressCuttingBtn$j$s' value='sub'>Cutting Done</button>
							<span style='color:#0000ff' id='cqty$j$s'>($master_cutting_qty)</span>";
					}else{
						$cutting="<span style='color:#0000ff' id='cqty$j$s'>($master_cutting_qty)</span>";
					}
					
					if($receive_qty<$pqty){
						$rd="<input type='number' style='width:45px;text-align:center' id='dressQtys$j$s'/>
							<input type='hidden' value='$order_number' id='hidebtn$j$s'/>
							<button style='background: #0e9a8421;color: #000000bd;' onclick='recDressBtn($j$s);' name='btn' id='dressReceiveBtn$j$s' value='sub'>Making Done</button>
							<span style='color:#0e9a84' id='dqty$j$s'>($receive_qty)</span>";
					}else{
						$rd="<span style='color:#0e9a84' id='dqty$j$s'>($receive_qty)</span>";
					}
					
					if($delivery_qty<$pqty){
						$pdelivery="<input type='hidden' value='$order_number' id='pdelivery$j$s'/>
							<input type='number' style='width:45px;text-align:center' id='pdeliveryQtys$j$s'/>
							<button style='background: #c041f559;color: #000000c2;' onclick='pdeliveryBtn($j$s);' name='btn' id='pdeliveryBtn$j$s' value='sub'>Delivery</button>
							<span style='color:#c041f5' id='ddqty$j$s'>($delivery_qty)</span>";
					}else{
						$pdelivery="<span style='color:#c041f5' id='ddqty$j$s'>($delivery_qty)</span>";
					}
					
					$ptbl2.="<tr>
						<td>
							<b>$j</b>
						</td>
						<td><b>
							<span style='cursor:pointer;font-size: 12px;' title='Cutting: $master_assign_date, Making: $assign_date'>[$code_no] $pname</span> $cutting | $rd | $pdelivery
						</b>
						</td>
						<td><b>
							$pqty
						</b>
						</td>
					
					</tr>";
				}
				
				$ptbl3="<input type='hidden' id='totid$s' value='$j'/></tbody>
				</table>";
			$ptblf=$ptbl.$ptbl2.$ptbl3;
			
			$payspan="<span id='payment_tbl$s'>";
			$paytbl='<table id="example" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>Description</th>
						<th style="text-align:right;width: 32%;">Taka</th>
					</tr>
				</thead>
				<tbody id="payable">';
				@$paytblhead.="<tr>
						<td>
							<b>Total</b>
						</td>
						<td><b>
							<input style='text-align:right;border: 1px solid #F9F9F9;background: #F9F9F9;width: 100%;' type='text' readonly value='$total_tk'/>
						</b>
						</td>
						</tr><tr><td>
							<b>Discount(Tk)</b>
						</td><td style='text-align:right'>$discount</td></tr>";
				$paytbl2="";	
				$i=1;$sum=0;
				date_default_timezone_set("Asia/Dhaka");
				$date=date("Y-m-d");$del_info="";
				while($payrows=mysqli_fetch_array($payment_detail)){
					$due_tk=$payrows['amount'];
					$accounting_tbl_id=$payrows['id'];
					$payment_type=$payrows['payment_type'];
					$sum+=intval($due_tk);
					if(isset($rrow['phy_dv_date'])){
						if($date==$payrows['indate']){
						$del="(<a href='javascript:void(0)' onclick='delPay($accounting_tbl_id,$s);'>Del</a>)";
						}else{
							$del="";
						}
						$paid="(<span style='color:blue'>Paid</span>)";
					}else{
						if($date==$payrows['indate']){
						$del="(<a href='javascript:void(0)' onclick='delPay($accounting_tbl_id,$s);'>Del</a>)";
						}else{
							$del="";
						}
						$paid="";
					}
					if($payrows['pay_status']==1){
						$paytbl2.="<tr>
						<td>
							Advance($payment_type) $del
						</td>
						<td style='text-align:right'>
							$due_tk
						</td>
						</tr>";
					}else{
						$paytbl2.="<tr>
						<td>
							Pay ($payment_type) $del
						</td>
						<td style='text-align:right;'>
							$due_tk
						</td>
						</tr>";
					}
				
				}
				$due=intval($total_tk1)-$sum;
				@$paytbldue.="<input type='hidden' value='$due' id='hide_due$s'/><tr>
						<td>
							<b>Due $paid</b>
						</td>
						<td style='text-align:right'><b>
							$due
						</b>
						</td>
						</tr>";
				if($due!=0){
					if(isset($rrow['phy_dv_date'])){
						@$paytblpay.="<input type='hidden' value='$sid' id='dsms_ids$s'/>
						<input type='hidden' value='$total_tk' id='total_tk$s'/>
						<span id='stksms$s'></span>
						<tr>
						<td style='color:red'>
							Discount <span style='color:black;cursor:pointer' onclick='setDiscountTk($s)' id='discount_tks$s'></span>
						</td>
						<td>
						<input style='text-align: right;width: 100%;background: #61c5cf87;' type='text' id='exdiscount$s'/>
						</td>
						</tr>
						<tr>
						<tr>
						
						<td>
							<button onclick='payTk($s);' name='btn' id='paybtns$s' value='sub' class='btn btn-success'>Pay</button>
							<select style='height: 30px;' id='payment_type$s'>
								<option value='Cash'>Cash</option>
								<option value='Bkash'>Bkash</option>
								<option value='Rocket'>Rocket</option>
								<option value='Nagad'>Nagad</option>
								<option value='Upay'>Upay</option>
								<option value='Sure Cash'>Sure Cash</option>
								<option value='Tap'>Tap</option>
								<option value='POS Machine'>POS Machine</option>
								<option value='Bank'>Bank</option>
							</select>
						</td>
						<td>
						<input style='text-align:right;width: 100%;' type='text' onkeyup='showLiveDiscount($s)' onclick='clickToSelect(paytxt$s)' id='paytxt$s'/>
						</td>
						</tr>";
					}else{
				@$paytblpay.="<tr>
					<td style='color:red'>
							Discount <span style='color:black;cursor:pointer' onclick='setDiscountTk($s)' id='discount_tks$s'></span>
						</td>
						<td>
						<input style='text-align: right;width: 100%;background: #61c5cf87;' type='text' id='exdiscount$s'/>
						</td>
				</tr><tr>
						<td>
							<button onclick='payTk($s);' name='btn' id='paybtns$s' value='sub' class='btn btn-success'>Pay</button>
							<select style='height: 30px;' id='payment_type$s'>
								<option value='Cash'>Cash</option>
								<option value='Bkash'>Bkash</option>
								<option value='Rocket'>Rocket</option>
								<option value='Nagad'>Nagad</option>
								<option value='Upay'>Upay</option>
								<option value='Sure Cash'>Sure Cash</option>
								<option value='Tap'>Tap</option>
								<option value='POS Machine'>POS Machine</option>
								<option value='Bank'>Bank</option>
							</select>
						</td>
						<td>
						<input style='text-align:right;width: 100%;' onkeyup='showLiveDiscount($s)' onclick='clickToSelect(paytxt$s)' type='text' id='paytxt$s'/>
						<input type='hidden' value='$sid' id='dsms_ids$s'/>
						<input type='hidden' value='$total_tk' id='total_tk$s'/>
						<span id='stksms$s'></span>
						</td>
						</tr>";
					}
				}else{
					$paytblpay="<input type='hidden' value='$total_tk' id='total_tk$s'/><input type='hidden' value='$sid' id='dsms_ids$s'/>";
				}
					
				$paytbl3='</tbody>
					</table>';
				$payspan_end="</span>";
			$paytblf=$payspan.$paytbl.$paytblhead.$paytbl2.$paytbldue.$paytblpay.$paytbl3.$payspan_end;
			
			if(isset($rrow['phy_dv_date'])){
				$phy_dv_date=date('d/m/Y',strtotime($rrow['phy_dv_date']));
			}else{
				$phy_dv_date=360;
			}
			?>
			<div class='row'>	
				
				<div class="col-xs-12 col-sm-8">
					<div style="overflow: hidden;">
					<p style="float:left" for="">Serial: <b><input type="text" onclick="copyOrderNumber('<?php echo $s; ?>');" style="width: 70px;color:red;cursor: pointer;" id="copying<?php echo $s; ?>" value="<?php echo @$rrow['phy_ord_num']; ?>"/></b></p>
					<p style="float:right" for="">SL: <span  id="tag_num"><?php echo $s; ?></span></p>
					<input type="hidden" id="customer_id" value="<?php echo $customer_id; ?>"/>
					</div>
					<p for="">Customer Name: <b><span style="color:green" id="tag_num">
					<input type="text" class="form-control" onkeyup="editCustomerInformation('<?php echo $rrow['phy_ord_num']; ?>','<?php echo $customer_id; ?>','cus_name','dsms','customer');" value="<?php echo @$rrow['cus_name']; ?>" onkeydown="enterEventSelection('cus_name','date1')" autocomplete="off" maxlength="30" style="font-weight: bold;font-size:18px;font-style: italic;width: 40%;" name="cus_name" id="cus_name" />
					</span></b></p>
					<p for="">Mobile: <b><span style="color:green" id="tag_num">
					<input type="text" onkeyup="editCustomerInformation('<?php echo $rrow['phy_ord_num']; ?>','<?php echo $customer_id; ?>','mobile','dsms','customer');" value="<?php echo $rrow['cus_mobile']; ?>" onkeydown="enterEventSelection('mobile','cus_name')" class="form-control" maxlength="11" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;width: 40%;" name="mobile" id="mobile" />
				
					</span></b></p>
					<p for="">Order Date: <b><span id="ord_date"><?php echo date('d/m/Y',strtotime($rrow['order_date'])); ?></span></b></p>
					<p for="">Production Receive: <b><?php echo ($rrow['factory_status']==1 || $rrow['factory_status']==2)? "Yes" : "No"; ?></b></p>
					<p for="">Production Receive Date: <b><?php if(@$rrow['factory_receive_date']!="") echo date('d/m/Y',strtotime(@$rrow['factory_receive_date'])); ?></b></p>
					<p for="">Delivery Date: <b><span id="dv_date<?php echo $s; ?>">
					<?php echo date('d/m/Y',strtotime($rrow['dv_date'])); ?>
					<input type="text" style="width: 40%;" autocomplete="off" name="date1" onkeydown="enterEventSelection('date1','ds_item_id')" onkeyup="editCustomerInformation('<?php echo $rrow['phy_ord_num']; ?>','<?php echo $customer_id; ?>','date1','dsms','customer');" id="date1" value="<?php echo date('d/m/Y',strtotime($rrow['dv_date'])); ?>" class="form-control"><!-- data-select="date"--->
				
					</span></b></p>
					<p for="">Physical Delivery Date: <b><span id="phy_dv_date<?php echo $s; ?>"><?php echo ($phy_dv_date==360)? "N/A" : $phy_dv_date; ?></span></b></p>
					<p for="">Order Type: <b><span id="ord_type"><?php echo ($rrow['order_type']==0)? "Normal": "Urgent"; ?></span></b></p>
					<p for="">Sms: <b><span id="chksms"><?php echo ($rrow['sms_status']==0)? "Pending": "Sent" ?></span></b></p>
					
				<div class="row">	
					<div class="col-xs-12 col-sm-12">
						<div class="row">
							<div class="col-xs-12 col-sm-9">
							<label for="comment" class="txt_color">Box Number: </label><br/>
							<input style="width: 80%;height: 30px;text-align:center;font-weight:bold;color:red" type="text" id="box_number<?php echo $s; ?>" value="<?php echo @$box_number; ?>"/> 
							<button style="" onclick="onlyBoxUpdateBtn('<?php echo $s; ?>','<?php echo @$rrow['phy_ord_num']; ?>');" name="btn" id="only_boxupdate<?php echo $s; ?>" value="sub" class="btn btn-info">Update</button>&nbsp;&nbsp;<br/>
							<span id="box_update_sms<?php echo $s; ?>"></span>
							</div>
						</div>
						<input type="hidden" value="<?php echo $f_total_taka; ?>" id="fab_total_tk<?php echo $s; ?>"/>
					</div>
				</div>	
						<span for="">Dress Details:(<span style='color:#ec68d0;cursor: pointer;' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('<?php echo $s; ?>','<?php echo @$rrow['phy_ord_num']; ?>')"><b>Measurement</b></span>)</span>
						<span id="pdetail">
						 <?php echo $ptblf; ?>
						</span>
				</div>
				<div class="col-xs-12 col-sm-4">
					<!--<?php if($phy_dv_date==360){ ?>				
					<div>
					<select style="width:30%;font-weight: bold;font-size: 15px;height: 31px;font-style: italic;" id="ds_item_id<?php echo $s; ?>">
						<option value="">Select Item</option>
						<?php echo $fabricsoption; ?>
					</select>
					<select style="width:18%;font-weight: bold;font-size: 15px;height: 31px;font-style: italic;" id="itemqty<?php echo $s; ?>">
						<option value="">Item Qty</option>
						<option value="1">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
						<option value="5">5</option>
						<option value="6">6</option>
					</select>
					
					<input style="width:20%;
					height: 31px;
					text-align: center;
					font-weight: bold;
					margin-left: 5px;
					font-size: 15px;
					margin-right: 5px;" type="text" autocomplete="off" placeholder="Fabrics Price" id="editfabricprice<?php echo $s; ?>"/>
					<a href="javascript:void(0)"  onclick="updateFabricsPrice('<?php echo $s; ?>','1');" >
					<img style="height: 25px;width: 25px;" src="img/plus.PNG"/></a>
					</div>	
					<?php } ?>	-->			
					<span for="">Payment Details:</span>
					<span id="paydetail">
						<?php echo $paytblf; ?>
					</span>
					<p></p>	
				<?php if($phy_dv_date==360){ ?>
				
				<button onclick="orderDeliveryBtn(<?php echo $s; ?>);" name="btn" id="order_delivery<?php echo $s; ?>" value="sub" class="btn btn-warning">Delivery</button>&nbsp;&nbsp;
				<span id="order_delivery_sms<?php echo $s; ?>"></span>
				<!--<button onclick="orderDenyBtn(<?php echo $s; ?>);" name="btn" id="order_deny<?php echo $s; ?>" value="sub" class="btn btn-info">Cancel</button>&nbsp;&nbsp;-->
				<input type="hidden" id="hide_sms_id<?php echo $s; ?>" value="<?php echo $rrow['id']; ?>" />
				<span id="order_deny_sms<?php echo $s; ?>"></span>
				
				<div class="row" style="margin-top: 15px;">
					<div class="col-xs-12 col-sm-6">	
						Date(calendar)
						<input type="text" readonly id="date3<?php echo $s; ?>" style="font-weight:bold" value="<?php echo date("m/d/Y"); ?>" class="form-control" name="bday">
						<input type="hidden" id="hide_sms_ids<?php echo $s; ?>" value="<?php echo $rrow['id']; ?>" />
						<input type="hidden" id="mobile3<?php echo $s; ?>" value="<?php echo $rrow['cus_mobile']; ?>" />
						<input type="hidden" style="" name="date1" id="date_org3<?php echo $s; ?>" value="<?php echo date('d/m/Y',strtotime($rrow['dv_date'])); ?>" />
					</div>
					<div class="col-xs-12 col-sm-6">
						<button style="margin-top: 19px;" onclick="onlyDateUpdateBtn(<?php echo $s; ?>);" name="btn" id="only_dateupdate<?php echo $s; ?>" value="sub" class="btn btn-success">Send SMS</button>&nbsp;&nbsp;<br/>
						<span id="only_date_update_sms<?php echo $s; ?>"></span>
					</div>
				</div>
				</div>
				
			</div>
				<?php } ?>
			<input type="hidden" id="mobile3<?php echo $s; ?>" value="<?php echo $rrow['cus_mobile']; ?>" />
			<?php 
			echo "<input type='hidden' id='discount$s' value='$discount' />
				<input type='hidden' id='discount_tot$s' value='$total_tk1' /></div></div><hr/>";
			$paytblf=$payspan=$paytbl=$paytblhead=$paytbl2=$paytbldue=$paytblpay=$paytbl3=$payspan_end="";
			$ptblf=$ptbl=$ptbl2=$ptbl3="";
			}
			
			
		}else{
			echo 1;
		}
	}
	
		if(isset($_REQUEST['updateFabricsPrice'])){
		$editfabricprice=$_REQUEST['editfabricprice'];
		$ds_item_id=$_REQUEST['ds_item_id'];
		$itemqty=$_REQUEST['itemqty'];
		$total_tk=$_REQUEST['total_tk'];
		$dsms_ids=$_REQUEST['dsms_ids'];
		$update_status=$_REQUEST['update_status'];
		$com_id=($_SESSION['COM_ID']);
		$user_id=$_SESSION['USER_ID'];
		$discount_tot=$_REQUEST['discount_tot'];
		$discount=$_REQUEST['discount'];
		$div_id=$_REQUEST['div_id'];
		if($update_status=='1'){
			$total_tk+=$editfabricprice;
		}else{
			$total_tk=($total_tk-$editfabricprice);
		}
		
	$chk_ord_num=$conn->query("select dstid from direct_sale mm where mm.com_id='$com_id' and mm.order_number=(select phy_ord_num from dsms where id=$dsms_ids) order by mm.id desc limit 0,1");	
	if(mysqli_num_rows($chk_ord_num)>0){
		$updatetk=$conn->query("update dsms set amount='$total_tk' where id='$dsms_ids' and com_id=$com_id");
		if($updatetk){
			$phy_ord_num=$conn->query("insert into direct_sale(item_id,item_qty,price,com_id,insert_by,is_active,dstid,order_number) values ($ds_item_id,'$itemqty','$editfabricprice',$com_id,$user_id,3,(select dstid from direct_sale d where d.com_id='$com_id' and d.order_number=(select phy_ord_num from dsms where id=$dsms_ids) and d.is_active=3 order by d.id desc limit 0,1),(select phy_ord_num from dsms where id=$dsms_ids))");
			if($phy_ord_num){
					$conn->query("update direct_sale_head set f_total=f_total+$editfabricprice
									where com_id=$com_id and id=(select dstid from direct_sale mm where mm.com_id='$com_id' and mm.order_number=(select phy_ord_num from dsms where id=$dsms_ids) order by mm.id desc limit 0,1)");
				
			}
			$payment_detail=$conn->query("SELECT * FROM `accounting` WHERE `com_id`=$com_id and is_active=1 and `dsms_id`=$dsms_ids");
			mysqli_close($conn);
		$payspan="<span id='payment_tbl$div_id'>";
		$paytbl='<table id="example" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>Description</th>
						<th style="text-align:right">Taka</th>
					</tr>
				</thead>
				<tbody id="payable">';
				@$paytblhead.="<tr>
						<td>
							<b>Total</b>
						</td>
						<td style='text-align:right'><b>
							<input style='text-align:right;border: 1px solid #F9F9F9;background: #F9F9F9;' type='text' id='' readonly value='$total_tk'/>
						</b>
						</td>
						</tr><tr><td>
							<b>Discount(%)</b>
						</td><td style='text-align:right'>$discount</td></tr>";
				$paytbl2="";	
				$i=1;$sum=0;
				while($payrows=mysqli_fetch_array($payment_detail)){
					$due_tk=$payrows['amount'];
					$accounting_tbl_id=$payrows['id'];
					$sum+=intval($due_tk);
					
					if($payrows['pay_status']==1){
						$paytbl2.="<tr>
						<td>
							Advance(<a href='javascript:void(0)' onclick='delPay($accounting_tbl_id,$div_id);'>Del</a>)
						</td>
						<td style='text-align:right'>
							$due_tk
						</td>
						</tr>";
					}else{
						$paytbl2.="<tr>
						<td>
							Pay(<a href='javascript:void(0)' onclick='delPay($accounting_tbl_id,$div_id);'>Del</a>)
						</td>
						<td style='text-align:right'>
							$due_tk
						</td>
						</tr>";
					}
				
				}
				$due=intval($total_tk)-((intval($total_tk)*intval($discount))/100)-$sum;
				@$paytbldue.="<input type='hidden' value='$due' id='hide_due$div_id'/><tr>
						<td>
							<b>Due</b>
						</td>
						<td style='text-align:right'><b>
							$due
						</b>
						</td>
						</tr>";
				if($due!=0){
				@$paytblpay.="<tr>
						<td>
							<button onclick='payTk($div_id);' name='btn' id='paybtns$div_id' value='sub' class='btn btn-success'>Pay</button>
						</td>
						<td>
						<input style='text-align:right;width:100%' type='text' id='paytxt$div_id'/>
						<input type='hidden' value='$dsms_ids' id='dsms_ids$div_id'/>
						<input type='hidden' value='$total_tk' id='total_tk$div_id'/>
						<span id='stksms$div_id'></span>
						</td>
						</tr>";
				}else{
					$paytblpay="";
				}
					
				$paytbl3="<input type='hidden' id='discount$div_id' value='$discount' />
				<input type='hidden' id='discount_tot$div_id' value='$total_tk'/></tbody>
					</table>";
				$payspan_end="</span>";// id='payment_tbl'>";
			$paytblf=$payspan.$paytbl.$paytblhead.$paytbl2.$paytbldue.$paytblpay.$paytbl3.$payspan_end;
		if($updatetk){
			echo $paytblf;
		}else{
			echo 2;
		}
		}
	}else{
		echo 2;
	}
	}
	
	if(isset($_REQUEST['show_advertise'])){
		if(check_internet_connection()==1){
			$response = file_get_contents($_SESSION['API']."api/data.php?chk=8"); //chk=8 showing advertisement
			$json = json_decode($response, true);
			if(@$json['auth']!=2){
				echo $json['auth'];
			}else{
				echo 2;
			}
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['cuttingDressBtn'])){
		$com_id=($_SESSION['COM_ID']);
		$hidebtn=$_REQUEST['hidebtn'];
		$ex=explode("#sep#",$hidebtn);
		$ord_num=$ex[0];
		$ord_rec_tblid=$ex[1];
		$dressQtys=intval($_REQUEST['dressQtys']);
		$ord_tbl=$conn->query("SELECT item_qty,master_cutting_qty FROM `order_record` WHERE `com_id`=$com_id and is_active=1 and id=$ord_rec_tblid");
		$ord_tbla=mysqli_fetch_array($ord_tbl);
			$item_qty=intval($ord_tbla['item_qty']);
			$receive_qty=$ord_tbla['master_cutting_qty'];
			if((intval($receive_qty)+$dressQtys)>$item_qty){
				echo 10000000; // item qty more than main qty
				exit();
			}else{
				$update_qty=intval($receive_qty)+$dressQtys;
				@$ord_tbl_update=$conn->query("update order_record set master_cutting_qty=$update_qty where com_id=$com_id and id=$ord_rec_tblid");
				if($ord_tbl_update){
				$ord_tbl_select=$conn->query("SELECT CASE WHEN sum(item_qty)=sum(master_cutting_qty) THEN 1 ELSE 0 END receive_test FROM `order_record` WHERE `com_id`=$com_id and is_active=1 and order_number='$ord_num'");
					$ord_tbl_selecta=mysqli_fetch_array($ord_tbl_select);
					echo $ord_tbl_selecta['receive_test']."#sep#".$update_qty;
				}
			}
	}
	
	if(isset($_REQUEST['recDressBtn'])){
		$com_id=($_SESSION['COM_ID']);
		$hidebtn=$_REQUEST['hidebtn'];
		$ex=explode("#sep#",$hidebtn);
		$ord_num=$ex[0];
		$ord_rec_tblid=$ex[1];
		$dressQtys=intval($_REQUEST['dressQtys']);
		$ord_tbl=$conn->query("SELECT item_qty,receive_qty FROM `order_record` WHERE `com_id`=$com_id and is_active=1 and id=$ord_rec_tblid");
		$ord_tbla=mysqli_fetch_array($ord_tbl);
			$item_qty=intval($ord_tbla['item_qty']);
			$receive_qty=$ord_tbla['receive_qty'];
			if((intval($receive_qty)+$dressQtys)>$item_qty){
				echo 10000000; // item qty more than main qty
				exit();
			}else{
				$update_qty=intval($receive_qty)+$dressQtys;
				@$ord_tbl_update=$conn->query("update order_record set receive_qty=$update_qty where com_id=$com_id and id=$ord_rec_tblid");
				if($ord_tbl_update){
				$ord_tbl_select=$conn->query("SELECT CASE WHEN sum(item_qty)=sum(receive_qty) THEN 1 ELSE 0 END receive_test FROM `order_record` WHERE `com_id`=$com_id and is_active=1 and order_number='$ord_num'");
					$ord_tbl_selecta=mysqli_fetch_array($ord_tbl_select);
					echo $ord_tbl_selecta['receive_test']."#sep#".$update_qty;
				}
			}
	}
	
	if(isset($_REQUEST['pdeliveryBtn'])){
		date_default_timezone_set("Asia/Dhaka");
		$dv_date=date("d/m/Y");
		$com_id=($_SESSION['COM_ID']);
		$hidebtn=$_REQUEST['hidebtn'];
		$ex=explode("#sep#",$hidebtn);
		$ord_num=$ex[0];
		$ord_rec_tblid=$ex[1];
		$dressQtys=intval($_REQUEST['dressQtys']);
		$ord_tbl=$conn->query("SELECT item_qty,delivery_qty FROM `order_record` WHERE `com_id`=$com_id and is_active=1 and id=$ord_rec_tblid");
		$ord_tbla=mysqli_fetch_array($ord_tbl);
			$item_qty=intval($ord_tbla['item_qty']);
			$receive_qty=$ord_tbla['delivery_qty'];
			if((intval($receive_qty)+$dressQtys)>$item_qty){
				echo 10000000; // item qty more than main qty
				exit();
			}else{
				$update_qty=intval($receive_qty)+$dressQtys;
				@$ord_tbl_update=$conn->query("update order_record set delivery_qty=$update_qty,delivery_date='$dv_date' where com_id=$com_id and id=$ord_rec_tblid");
				if($ord_tbl_update){
				$ord_tbl_select=$conn->query("SELECT CASE WHEN sum(item_qty)=sum(delivery_qty) THEN 1 ELSE 0 END receive_test FROM `order_record` WHERE `com_id`=$com_id and is_active=1 and order_number='$ord_num'");
					$ord_tbl_selecta=mysqli_fetch_array($ord_tbl_select);
					echo $ord_tbl_selecta['receive_test']."#sep#".$update_qty;
				}
			}
	}
	
	if(isset($_REQUEST['factoryReceiveItem'])){
		date_default_timezone_set("Asia/Dhaka");
		$dv_date=date("d/m/Y");
		$com_id=($_SESSION['COM_ID']);
		
		$cus_namea=explode("#sep#",$_REQUEST['cus_name']);
		$cus_mobilea=explode("#sep#",$_REQUEST['cus_mobile']);
		$citem_namea=explode("#sep#",$_REQUEST['citem_namea']);
		$cassign_qtya=explode("#sep#",$_REQUEST['cassign_qtya']);
		$corder_numa=explode("#sep#",$_REQUEST['corder_numa']);
		$corder_tbl_ida=explode("#sep#",$_REQUEST['corder_tbl_ida']);
		$citem_ida=explode("#sep#",$_REQUEST['citem_ida']);
		for($i=0; $i<count($citem_namea);$i++){
			@$cus_name=$cus_namea[$i];
			@$cus_mobile=$cus_mobilea[$i];
			@$ord_num=$corder_numa[$i];
			@$item_name=$citem_namea[$i];
			@$item_id=$citem_ida[$i];
			@$ord_rec_tblid=$corder_tbl_ida[$i];
			@$dressQtys=$cassign_qtya[$i];
			
		
		$ord_tbl=$conn->query("SELECT dsms_id,item_qty,delivery_qty FROM `order_record` WHERE `com_id`=$com_id and is_active=1 and id=$ord_rec_tblid");
		$ord_tbla=mysqli_fetch_array($ord_tbl);
			$hide_sms_id=$ord_tbla['dsms_id'];
			$item_qty=intval($ord_tbla['item_qty']);
			$receive_qty=$ord_tbla['delivery_qty'];
			
				$update_qty=intval($receive_qty)+$dressQtys;
				@$ord_tbl_update=$conn->query("update order_record set delivery_qty=$update_qty,delivery_date='$dv_date' where com_id=$com_id and id=$ord_rec_tblid");
				if($ord_tbl_update){
					$date=date("Y-m-d");
						$ord_tbl_select=$conn->query("SELECT CASE WHEN sum(item_qty)=sum(delivery_qty) THEN 1 ELSE 0 END receive_test FROM `order_record` WHERE `com_id`=$com_id and is_active=1 and order_number='$ord_num'");
						$ord_tbl_selecta=mysqli_fetch_array($ord_tbl_select);
						if($ord_tbl_selecta['receive_test']==1){ // Order wise all item received =1
							$chk_com=$conn->query("update dsms set factory_status=1,factory_receive_date='$date' where id=$hide_sms_id and com_id=$com_id");
							if($from_factory_recive_live_sms==1){ // 1=means active order live smsm 	
								if(check_internet_connection()==1){
									$response = file_get_contents($_SESSION['API']."api/data.php?com_id=$com_id&cus_mobile=$cus_mobile&order_no=$ord_no&chk=11"); //chk=2 means check sms
									$json = json_decode($response, true);
								}
							}
						}
				}
			
			
			?>
			<!--<tr id="row_received<?php echo $ord_rec_tblid; ?>">
				<td style="text-align:center">
					<button onclick="delItemPayment('<?php echo $ord_rec_tblid; ?>','<?php echo $dressQtys; ?>');" name='btn' id='delbtns_receive<?php echo $ord_rec_tblid; ?>' class="btn btn-danger form-control">***</button>
				</td>
				<td style="text-align:center;font-weight:bold">
					<?php echo $ord_num; ?>
				</td>
				<td style="text-align:center">
					<?php echo date('Y-m-d h:i:s'); ?><br/>
					<i style="color:blue"><?php echo $cus_name; ?></i>
				</td>
				<td style="">
					<?php echo $item_name; ?>
				</td>
				<td style="text-align:center">
					<?php echo $dressQtys; ?>
				</td>
				
			</tr>-->
				<?php 
		}
		mysqli_close($conn);
	}
	
	if(isset($_REQUEST['showOrderNumberItemWise'])){
		
		$com_id=$_SESSION['COM_ID'];
		$search_type=$_REQUEST['search_type'];
		$item_id=$_REQUEST['item_id'];
		$d1=$_REQUEST['start_date'];
		$d2=$_REQUEST['end_date'];
		if($search_type=='order'){
			$psmsquery=$conn->query("SELECT `item_id`,order_number FROM `order_record` WHERE `is_active`=1 and item_id=$item_id and `com_id`=$com_id and date(insert_date) between '$d1' and '$d2'");
		}else if($search_type=="receive"){
			$psmsquery=$conn->query("SELECT `item_id`,order_number FROM `order_record` WHERE `receive_qty`>0 and item_id=$item_id and `is_active`=1 and `com_id`=$com_id and assign_date between '$d1' and '$d2'");
		}else if($search_type=="factory_delivery"){
			$psmsquery=$conn->query("SELECT `item_id`,order_number FROM `order_record` WHERE `is_active`=1 and item_id=$item_id and `com_id`=$com_id and delivery_date between '$d1' and '$d2'");
		}else if($search_type=="only_delivery"){
			$psmsquery=$conn->query("SELECT `item_id`,order_number FROM `order_record` WHERE `is_active`=1 and item_id=$item_id and `com_id`=$com_id and dsms_id in (select id from dsms where is_active=1 and dv_date between '$d1' and '$d2' and phy_dv_date is null)");
		}else if($search_type=="delivery"){
			$psmsquery=$conn->query("SELECT `item_id`,order_number FROM `order_record` WHERE `is_active`=1 and item_id=$item_id and `com_id`=$com_id and dsms_id in (select id from dsms where is_active=1 and phy_dv_date between '$d1' and '$d2')");
		}
				$order_number="";
				while($row=mysqli_fetch_array($psmsquery)){
					$order_numbers=$row['order_number'];
					$num=1;
					$param1="'".$num."'";
					$param2="'".$order_numbers."'";
					$method='onclick="showMeasurement('.$param1.','.$param2.')"';
					$order_number.="<span style='cursor: pointer;' data-toggle='modal' $method data-target='#myModal'>".$row['order_number']."</span> | ";
				}
		echo "(".$order_number.")";
	}
	

	
	
	if(isset($_REQUEST['delPay'])){
		$accounting_tbl_id=trim($_REQUEST['accounting_tbl_id']);
		$dsms_ids=trim($_REQUEST['dsms_ids']);
		$total_tk=trim($_REQUEST['total_tk']);
		$div_id=trim($_REQUEST['div_id']);
		$discount=trim($_REQUEST['discount']);
		$discount_tot=trim($_REQUEST['discount_tot']);
		$customer_id=$_REQUEST['customer_id'];
		$ord_no=$_REQUEST['ord_no'];
		$com_id=($_SESSION['COM_ID']);
		$user_id=($_SESSION['USER_ID']);
		@$text=$conn->query("update accounting set is_active=0,update_by=$user_id where id=$accounting_tbl_id");
		@$del_amount=$conn->query("SELECT amount FROM `accounting` WHERE id=$accounting_tbl_id");
		$row=mysqli_fetch_array($del_amount);
		dueTblUpdate($customer_id,$row['amount'],0,"মেকিং Due ফেরত",'0');
		$conn->query("update transaction set is_active=0 where accounting_id=$accounting_tbl_id");
		$payment_detail=$conn->query("SELECT accounting.*,date(accounting.insert_date) indate FROM `accounting` WHERE `com_id`=$com_id and is_active=1 and `dsms_id`=$dsms_ids");
		mysqli_close($conn);
		$payspan="<span id='payment_tbl$div_id'>";
		$paytbl='<table id="example" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>Description</th>
						<th style="text-align:right">Taka</th>
					</tr>
				</thead>
				<tbody id="payable">';
				@$paytblhead.="<tr>
						<td>
							<b>Total</b>
						</td>
						<td style='text-align:right'><b>
							<input style='text-align:right;border: 1px solid #F9F9F9;background: #F9F9F9;' type='text' readonly value='$total_tk'/>
						</b>
						</td>
						</tr><tr><td>
							<b>Discount(%)</b>
						</td><td style='text-align:right'>$discount</td></tr>";
				$paytbl2="";	
				$i=1;$sum=0;
				date_default_timezone_set("Asia/Dhaka");
				$date=date("Y-m-d");$advance_tk_del="";
				while($payrows=mysqli_fetch_array($payment_detail)){
					$due_tk=$payrows['amount'];
					$accounting_tbl_id=$payrows['id'];
					$payment_type=$payrows['payment_type'];
					$sum+=intval($due_tk);
					if($date==$payrows['indate']){
						$advance_tk_del="(<a href='javascript:void(0)' onclick='delPay($accounting_tbl_id,$div_id);'>Del</a>)";
					}else{
						$advance_tk_del="";
					}
					if($payrows['pay_status']==1){
						
						$paytbl2.="<tr>
						<td>
							Advance($payment_type) $advance_tk_del
						</td>
						<td style='text-align:right'>
							$due_tk
						</td>
						</tr>";
					}else{
						$paytbl2.="<tr>
						<td>
							Pay($payment_type) $advance_tk_del
						</td>
						<td style='text-align:right'>
							$due_tk
						</td>
						</tr>";
					}
				
				}
				$due=intval($discount_tot)-$sum;
				@$paytbldue.="<input type='hidden' value='$due' id='hide_due$div_id'/><tr>
						<td>
							<b>Due</b>
						</td>
						<td style='text-align:right'><b>
							$due
						</b>
						</td>
						</tr>";
				if($due!=0){
				@$paytblpay.="<tr>
						<td style='color:red'>
							Discount <span style='color:black;cursor:pointer' onclick='setDiscountTk($div_id)' id='discount_tks$div_id'></span>
						</td>
						<td>
						<input style='text-align: right;width: 100%;background: #61c5cf87;' type='text' id='exdiscount$div_id'/>
						</td>
						</tr>
						<tr>
						<td>
							<button onclick='payTk($div_id);' name='btn' id='paybtns$div_id' value='sub' class='btn btn-success'>Pay</button>
							<select style='height: 30px;' id='payment_type$div_id'>
								<option value='Cash'>Cash</option>
								<option value='Bkash'>Bkash</option>
								<option value='Rocket'>Rocket</option>
								<option value='Nagad'>Nagad</option>
								<option value='Upay'>Upay</option>
								<option value='Sure Cash'>Sure Cash</option>
								<option value='Tap'>Tap</option>
								<option value='POS Machine'>POS Machine</option>
								<option value='Bank'>Bank</option>
							</select>
						</td>
						<td>
						<input style='text-align:right;width:100%' onkeyup='showLiveDiscount($div_id)' onclick='clickToSelect(paytxt$div_id)' type='text' id='paytxt$div_id'/>
						<input type='hidden' value='$dsms_ids' id='dsms_ids$div_id'/>
						<input type='hidden' value='$total_tk' id='total_tk$div_id'/>
						<span id='stksms$div_id'></span>
						</td>
						</tr>";
				}else{
					$paytblpay="";
				}
					
				$paytbl3='</tbody>
					</table>';
				$payspan_end="</span>";// id='payment_tbl'>";
			$paytblf=$payspan.$paytbl.$paytblhead.$paytbl2.$paytbldue.$paytblpay.$paytbl3.$payspan_end;
		if($text){
			echo $paytblf;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['orderDenyBtn'])){
		$hide_sms_id=trim($_REQUEST['hide_sms_id']);
		$div_id=trim($_REQUEST['div_id']);
		$com_id=($_SESSION['COM_ID']);
		$chk_com=$conn->query("update dsms set is_active=0 where id=$hide_sms_id and com_id=$com_id");
		mysqli_close($conn);
		if($chk_com){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['delCustomerDue'])){
		$cus_id=$_REQUEST['cus_id'];
		$tbl_id=$_REQUEST['tbl_id'];
		$paytxt=$_REQUEST['amount'];
		$pstatus=$_REQUEST['pstatus'];
		$com_id=($_SESSION['COM_ID']);
			//$conn->query("insert into transaction(cus_id,com_id,amount,status,remarks,insert_by,transaction_type) values($customer_id,$com_id,'$paytxt',$status,'$remarks',$user_id,'$transaction_type')");
			$conn->query("update transaction set is_active=3 where id=$tbl_id");
			$duetbl=$conn->query("select ud.last_due from update_due ud where ud.com_id=$com_id and ud.cus_id=$cus_id and ud.is_active=1 order by ud.id desc limit 0,1");
			if(mysqli_num_rows($duetbl)>0){
				$row=mysqli_fetch_array($duetbl);
				if($pstatus==0){ //baki prodan delete adjustment 
					$paytxt=$row['last_due']-$paytxt;
				}else{
					$paytxt+=$row['last_due'];
				}
			}else{
				$paytxt+=0;
			}
			$chk_com=$conn->query("insert into update_due(cus_id,com_id,last_due) values($cus_id,$com_id,'$paytxt')");
			mysqli_close($conn);
		if($chk_com){
			echo 1;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['set_print_val'])){
		$set_print_val=trim($_REQUEST['set_print_val']);
		$com_id=($_SESSION['COM_ID']);
		$chk_com=$conn->query("update company set order_copy=$set_print_val where id=$com_id");
		$_SESSION['ORDER_COPY']=$set_print_val;
		mysqli_close($conn);
		if($chk_com){
			echo 1;
		}else{
			echo 0;
		}
	}
	
	if(isset($_REQUEST['productionReceiveBtn'])){
		
		if($_SESSION['SOFT_TYPE']==1){ // for online
			$hide_sms_id=trim($_REQUEST['hide_sms_id']);
			$div_id=trim($_REQUEST['div_id']);
			$date=date("Y-m-d");
			$com_id=($_SESSION['COM_ID']);
			$chk_com=$conn->query("update dsms set factory_status=1,factory_receive_date='$date',dv_date='$date' where id=$hide_sms_id and com_id=$com_id");
			mysqli_close($conn);
			if($chk_com){
				echo 1;
			}else{
				echo 2;
			}
		}
		
		if($_SESSION['SOFT_TYPE']==2){ // for offline
			$hide_sms_id=trim($_REQUEST['hide_sms_id']);
			$div_id=trim($_REQUEST['div_id']);
			$mobile=trim($_REQUEST['mobile']);
			$ord_no=trim($_REQUEST['ord_no']);
			$sms_status=trim($_REQUEST['sms_status']);
			$date=date("Y-m-d");
			$com_id=($_SESSION['COM_ID']);
			$chk_com=$conn->query("update dsms set factory_status=1,factory_receive_date='$date' where id=$hide_sms_id and com_id=$com_id");
			mysqli_close($conn);
				if($sms_status==0){
					if($from_factory_recive_live_sms==1){ // 1=means active order live smsm 
						if(check_internet_connection()==1){
							$response = file_get_contents($_SESSION['API']."api/data.php?com_id=$com_id&cus_mobile=$mobile&order_no=$ord_no&chk=11"); //chk=2 means check sms
							$json = json_decode($response, true);
						}
					}
				}
			if($chk_com){
				echo 1;
			}else{
				echo 2;
			}
		}
		
	}
	
	if(isset($_REQUEST['payTk'])){
		$previous_due=trim($_REQUEST['previous_due']);
		$mobile=$_REQUEST['mobile'];
		$paytxt=($_REQUEST['paytxt']=="")? 0 : trim($_REQUEST['paytxt']);
		@$exdiscount=trim($_REQUEST['exdiscount']);
		@$order_number=trim($_REQUEST['order_number']);
		$payment_type=$_REQUEST['payment_type'];
		$dsms_ids=trim($_REQUEST['dsms_ids']);
		$total_tk=trim($_REQUEST['total_tk']);
		$hide_due=trim($_REQUEST['hide_due']);
		$ord_number=trim($_REQUEST['ord_number']);
		$div_id=trim($_REQUEST['div_id']);
		$discount=trim($_REQUEST['discount']);
		$customer_id=$_REQUEST['customer_id'];
		$discount_tot=trim($_REQUEST['discount_tot']);
		$fab_total_tk=trim($_REQUEST['fab_total_tk']);
		//$total_tk1=intval($total_tk)-((intval($total_tk)*intval($discount))/100);
		$com_id=($_SESSION['COM_ID']);
		$user_id=($_SESSION['USER_ID']);
		
		$pay_taka=($total_tk-$hide_due);
		if($pay_taka<$fab_total_tk){
			if(($pay_taka+$paytxt)<=$fab_total_tk){
				$only_fab_tk=$paytxt;
			}else{
				$only_fab_tk=($fab_total_tk-$pay_taka);
			}
			$conn->query("insert into only_febrics_tk(ord_number,taka)values('$order_number','$only_fab_tk')");
		}
		
		if($paytxt!=""){
			$tdue=0;
			if($exdiscount>0){
				$update_total_tk=$total_tk-$discount-$exdiscount;
				$discount=($discount+$exdiscount);
				$discount_tot-=$exdiscount;
				$conn->query("update dsms set amount='$update_total_tk',discount='$discount' where id='$dsms_ids'");
			}
		@$text=$conn->query("insert into accounting(dsms_id,com_id,amount,insert_by,payment_type) values($dsms_ids,$com_id,$paytxt,$user_id,'$payment_type')");
		}
		dueTblUpdate($customer_id,$paytxt,1,"মেকিং Due আদায়($ord_number)-$payment_type",2); //payable status, 2=due receive from tailor item
		$last_transaction_id=$conn->query("SELECT max(id) id FROM `transaction`");
		$t_row=mysqli_fetch_array($last_transaction_id);
		$t_id=$t_row['id'];
		$conn->query("update transaction set accounting_id=(select id from accounting where pay_status=0 and is_active=1 order by id desc limit 0,1) where id=$t_id");
		$payment_detail=$conn->query("SELECT accounting.*,date(accounting.insert_date) indate FROM `accounting` WHERE `com_id`=$com_id and is_active=1 and `dsms_id`=$dsms_ids");
		mysqli_close($conn);
		$payspan="<span id='payment_tbl$div_id'>";
		$paytbl='<table id="example" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th style="width: 68%;">Description</th>
						<th style="text-align:right;width: 32%;">Taka</th>
					</tr>
				</thead>
				<tbody id="payable">';
				@$paytblhead.="<tr>
						<td>
							<b>Total</b>
						</td>
						<td style='text-align:right;'><b>
							<input style='text-align:right;border: 1px solid #F9F9F9;background: #F9F9F9;' type='text' readonly value='$total_tk'/>
						</b>
						</td>
						</tr><tr><td>
							<b>Discount(%)</b>
						</td><td style='text-align:right'>$discount</td></tr>";
				$paytbl2="";	
				$i=1;$sum=0;
				date_default_timezone_set("Asia/Dhaka");
				$date=date("Y-m-d");$del_info="";
				while($payrows=mysqli_fetch_array($payment_detail)){
					$due_tk=$payrows['amount'];
					$accounting_tbl_id=$payrows['id'];
					$payment_type=$payrows['payment_type'];
					$sum+=intval($due_tk);
					$del_info=($date==$payrows['indate'])? "(<a href='javascript:void(0)' onclick='delPay($accounting_tbl_id,$div_id);'>Del</a>)" : '';
					if($payrows['pay_status']==1){
						$paytbl2.="<tr>
						<td>
							Advance($payment_type) $del_info
						</td>
						<td style='text-align:right'>
							$due_tk
						</td>
						</tr>";
					}else{
						$paytbl2.="<tr>
						<td>
							Pay($payment_type) $del_info
						</td>
						<td style='text-align:right'>
							$due_tk
						</td>
						</tr>";
					}
				
				}
				$due=intval($discount_tot)-$sum;
				@$paytbldue.="<input type='hidden' value='$due' id='hide_due$div_id'/><tr>
						<td>
							<b>Due</b>
						</td>
						<td style='text-align:right'><b>
							$due
						</b>
						<input type='hidden' value='$dsms_ids' id='dsms_ids$div_id'/>
						<input type='hidden' value='$total_tk' id='total_tk$div_id'/>
						</td>
						</tr>";
				if($due!=0){
				@$paytblpay.="<tr>
						<td style='color:red'>
							Discount <span style='color:black;cursor:pointer' onclick='setDiscountTk($div_id)' id='discount_tks$div_id'></span>
						</td>
						<td>
						<input style='text-align: right;width: 100%;background: #61c5cf87;' type='text' id='exdiscount$div_id'/>
						</td>
						</tr>
						<tr>
						<td>
							<button onclick='payTk($div_id);' name='btn' id='paybtns$div_id' value='sub' class='btn btn-success'>Pay</button>
							<select style='height: 30px;' id='payment_type$div_id'>
								<option value='Cash'>Cash</option>
								<option value='Bkash'>Bkash</option>
								<option value='Rocket'>Rocket</option>
								<option value='Nagad'>Nagad</option>
								<option value='Upay'>Upay</option>
								<option value='Sure Cash'>Sure Cash</option>
								<option value='Tap'>Tap</option>
								<option value='POS Machine'>POS Machine</option>
								<option value='Bank'>Bank</option>
							</select>
						</td>
						<td>
						<input style='text-align:right;width:100%' onkeyup='showLiveDiscount($div_id)' onclick='clickToSelect(paytxt$div_id)' type='text' id='paytxt$div_id'/>
						
						<span id='stksms$div_id'></span>
						</td>
						</tr>";
				}else{
					$paytblpay="";
				}
					
				$paytbl3="<input type='hidden' id='discount$div_id' value='$discount' />
				<input type='hidden' id='discount_tot$div_id' value='$discount_tot'/></tbody>
					</table>";
				$payspan_end="</span>";// id='payment_tbl'>";
			$paytblf=$payspan.$paytbl.$paytblhead.$paytbl2.$paytbldue.$paytblpay.$paytbl3.$payspan_end;
		
			
		
		if($text){
			echo $paytblf;
		}else{
			echo 2;
		}
	}
	
	if(isset($_REQUEST['orderDeliveryBtn'])){
		$hide_sms_id=trim($_REQUEST['hide_sms_id']);
		@$customer_id=$_REQUEST['customer_id'];
		@$paytxt=($_REQUEST['paytxt']=="")? 0 : trim($_REQUEST['paytxt']);
		@$exdiscount=trim($_REQUEST['exdiscount']);
		@$payment_type=$_REQUEST['payment_type'];
		@$hide_due=trim($_REQUEST['hide_due']);
		@$total_tk=trim($_REQUEST['total_tk']);
		@$div_id=trim($_REQUEST['div_id']);
		@$discount=trim($_REQUEST['discount']);
		@$order_number=trim($_REQUEST['order_number']);
		@$discount_tot=trim($_REQUEST['discount_tot']);
		@$fab_total_tk=trim($_REQUEST['fab_total_tk']);
		
		$pay_taka=($total_tk-$hide_due);
		if($pay_taka<$fab_total_tk){
			if(($pay_taka+$paytxt)<=$fab_total_tk){
				$only_fab_tk=$paytxt;
			}else{
				$only_fab_tk=($fab_total_tk-$pay_taka);
			}
			$conn->query("insert into only_febrics_tk(ord_number,taka)values('$order_number','$only_fab_tk')");
		}
		
		$com_id=($_SESSION['COM_ID']);
		$user_id=($_SESSION['USER_ID']);
		$phy_dv_date=date("Y-m-d");
		if($paytxt!=""){
			if($exdiscount>0){
				$update_total_tk=$total_tk-$discount-$exdiscount;
				$discount=($discount+$exdiscount);
				$discount_tot-=$exdiscount;
				$conn->query("update dsms set amount='$update_total_tk',discount='$discount' where id='$hide_sms_id'");
			}
		$conn->query("insert into accounting(dsms_id,com_id,amount,insert_by,delivery_status,payment_type) values($hide_sms_id,$com_id,'$paytxt',$user_id,'1','$payment_type')");
		}
		$chk_com=$conn->query("update dsms set phy_dv_date='$phy_dv_date' where id=$hide_sms_id and com_id=$com_id");
		dueTblUpdate($customer_id,$paytxt,1,"মেকিং Due পরিশোধ এবং ডেলিভারি-$payment_type",'0');
		$last_transaction_id=$conn->query("SELECT max(id) id FROM `transaction`");
		$t_row=mysqli_fetch_array($last_transaction_id);
		$t_id=$t_row['id'];
		$conn->query("update transaction set accounting_id=(select id from accounting where pay_status=0 and is_active=1 order by id desc limit 0,1) where id=$t_id");
		
		$payment_detail=$conn->query("SELECT accounting.*,date(accounting.insert_date) indate FROM `accounting` WHERE `com_id`=$com_id and is_active=1 and `dsms_id`=$hide_sms_id");
		$order_detail=$conn->query("SELECT * FROM `order_record` WHERE `com_id`=$com_id and is_active=1 and `dsms_id`=$hide_sms_id");
		
		$order_dv_date=date("d/m/Y");
		while($delivery_rows=mysqli_fetch_array($order_detail)){
			$order_tbl_id=$delivery_rows['id'];
			$order_item_in_qty=$delivery_rows['item_qty'];
			$delivery_date_for_checking=$delivery_rows['delivery_date'];
			if($delivery_date_for_checking==""){
				$conn->query("update order_record set delivery_date='$order_dv_date',delivery_qty=$order_item_in_qty where id=$order_tbl_id");
			}else{
				$conn->query("update order_record set delivery_qty=$order_item_in_qty where id=$order_tbl_id");
			}
			
		}
		mysqli_close($conn);
		$payspan="<span id='payment_tbl$div_id'>";
		$paytbl='<table id="example" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>Description</th>
						<th style="text-align:right;width: 32%;">Taka</th>
					</tr>
				</thead>
				<tbody id="payable">';
				@$paytblhead.="<tr>
						<td>
							<b>Total</b>
						</td>
						<td style='text-align:right'><b>
							<input style='text-align:right;border: 1px solid #F9F9F9;background: #F9F9F9;' type='text' readonly value='$total_tk'/>
						</b>
						</td>
						</tr><tr><td>
							<b>Discount(%)</b>
						</td><td style='text-align:right'>$discount</td></tr>";
				$paytbl2="";	
				$i=1;$sum=0;
				date_default_timezone_set("Asia/Dhaka");
				$date=date("Y-m-d");$del_info="";
				while($payrows=mysqli_fetch_array($payment_detail)){
					$due_tk=$payrows['amount'];
					$accounting_tbl_id=$payrows['id'];
					$payment_type=$payrows['payment_type'];
					$sum+=intval($due_tk);
					$del_info=($date==$payrows['indate'])? "(<a href='javascript:void(0)' onclick='delPay($accounting_tbl_id,$div_id);'>Del</a>)" : '';
					if($payrows['pay_status']==1){
						$paytbl2.="<tr>
						<td>
							Advance($payment_type) $del_info
						</td>
						<td style='text-align:right'>
							$due_tk
						</td>
						</tr>";
					}else{
						$paytbl2.="<tr>
						<td>
							Pay($payment_type) $del_info
						</td>
						<td style='text-align:right'>
							$due_tk
						</td>
						</tr>";
					}
				
				}
				$due=intval($discount_tot)-$sum;
				@$paytbldue.="<input type='hidden' value='$due' id='hide_due$div_id'/><tr>
						<td>
							<b>Due</b>
						</td>
						<td style='text-align:right'><b>
							$due
						</b>
						<input type='hidden' value='$hide_sms_id' id='dsms_ids$div_id'/>
						<input type='hidden' value='$total_tk' id='total_tk$div_id'/>
						</td>
						</tr>";
				if($due!=0){
				@$paytblpay.="<tr>
						<td style='color:red'>
							Discount
						</td>
						<td>
						<input style='text-align: right;width: 100%;background: #61c5cf87;' type='text' id='exdiscount$div_id'/>
						</td>
						</tr>
						<tr>
						<td>
							<button onclick='payTk($div_id);' name='btn' id='paybtns$div_id' value='sub' class='btn btn-success'>Pay</button>
							<select style='height: 30px;' id='payment_type$div_id'>
								<option value='Cash'>Cash</option>
								<option value='Bkash'>Bkash</option>
								<option value='Rocket'>Rocket</option>
								<option value='Nagad'>Nagad</option>
								<option value='Upay'>Upay</option>
								<option value='Sure Cash'>Sure Cash</option>
								<option value='Tap'>Tap</option>
								<option value='POS Machine'>POS Machine</option>
								<option value='Bank'>Bank</option>
							</select>
						</td>
						<td>
						<input style='text-align:right;width:100%' type='text' id='paytxt$div_id'/>
						
						<span id='stksms$div_id'></span>
						</td>
						</tr>";
				}else{
					$paytblpay="";
				}
					
				$paytbl3='</tbody>
					</table>';
				$payspan_end="</span>";// id='payment_tbl'>";
			$paytblf=$payspan.$paytbl.$paytblhead.$paytbl2.$paytbldue.$paytblpay.$paytbl3.$payspan_end;
		
		if($chk_com){
			echo date('d/m/Y',strtotime($phy_dv_date))."#sep#".$paytblf;
		}else{
			echo 2;
		}
	}
	
	
	if(isset($_REQUEST['urgentbtn'])){
		
		$com_id=$_SESSION['COM_ID'];
		$psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,dm.umobile,ds.phy_ord_num from dsms ds,dsms_mobile dm where ds.id=dm.sms_id and ds.is_active=1 and ds.sms_status=0 and ds.occasion=0 and ds.order_type=1 and ds.com_id='$com_id' and ds.phy_dv_date IS NULL order by ds.id asc");
		mysqli_close($conn);
		if(mysqli_num_rows($psmsquery)>0){
		?>
		<div class="panel-group">
 
   <?php 
			$i=1;
			$date=date("Y-m-d");
			
				while($row=mysqli_fetch_array($psmsquery)){
					$j=$i++;
					$sms_id=$row['id'];
					$sms_status=$row['sms_status'];
					$dv_date=explode("-",$row['dv_date']);
					$dv_date=$dv_date[2]."/".$dv_date[1]."/".$dv_date[0];
					@$txt_sms=$row['txt_sms'];
					@$tagnum=$row['tagnum'];
					@$order_type=$row['order_type'];
					
					@$umobile=$row['umobile']; 
					
				
				
			?>
	
   <div class='panel panel-info'>
      <div class="panel-heading"><?php  echo $j.". (".date('d/m/Y',strtotime($row['indate'])).")"; if($sms_status==0) echo " pending "; else echo " sent "; ?></div>
	 
      <div class="panel-body">
			<div class="input-group">
			<label for="comment">Order No.: <span style="color:green"><?php echo $row['phy_ord_num']; ?></span></label>
			
				<input type="hidden" name="tagnum" id="tagnum<?php echo $j; ?>" value="<?php echo $tagnum; ?>" >
						
			</div>
			<div class="form-group">
			  <label for="comment">Mobile Number: <span ><?php echo $umobile; ?></span></label>
			</div>
			<div class="input-group">
			<label for="comment">Delivery Date:</label>
						<input type="text" name="date1" id="date1<?php echo $j; ?>" value="<?php echo $dv_date; ?>" class="form-control" data-select="date">
						
			</div>
			<input type="hidden"  name="txt_sms" id="txt_sms<?php echo $j; ?>" />
			<input type="hidden"  name="sms_id" id="sms_id<?php echo $j; ?>" value="<?php echo $sms_id; ?>" />
			<input type="hidden"  name="order_type" id="order_type<?php echo $j; ?>" value="<?php echo $order_type; ?>" />
			<div class="form-group">
			  <input type="hidden" name="mobile" id="mobile<?php echo $j; ?>" value="<?php echo $umobile; ?>" />
			</div>
			<button onclick="sendUrgent('<?php echo $j; ?>');" name="btn" value="sub" class="btn btn-success">Update</button>
			<span id="urgsms<?php echo $j; ?>"></span>
			
			
	  </div>
	 
    </div>
	
 <?php } ?>
 </div>
	<script type="text/javascript" src="cal/js/apiajax.js"></script>
	<script type="text/javascript" src="cal/js/mousewheel.js"></script>
	<script type="text/javascript" src="cal/js/jquery.dateselect.js"></script> 
  
		<?php
		
		}else{
			echo 1;
		}
	}
	
	
	if(isset($_REQUEST['nddbtn'])){
		
		$com_id=$_SESSION['COM_ID'];
		@$dv_date =date('d/m/Y', strtotime(date('Y-m-d'). ' + 2 days'));
		$psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,ds.cus_mobile umobile,ds.phy_ord_num,ds.cus_name,ds.factory_status,ds.factory_receive_date,ds.fddate from dsms ds where ds.is_active=1 and ds.occasion=0 and ds.com_id='$com_id' and ds.factory_status not in(1,2) and ds.fddate='$dv_date' and ds.phy_dv_date IS NULL order by ds.id asc limit 0,10");
		
		if(mysqli_num_rows($psmsquery)>0){
		?>
		<div id="n3d_display">
		<div class="panel-group">
 
   <?php 
			$i=1;
			$date=date("Y-m-d");
			
				while($row=mysqli_fetch_array($psmsquery)){
					$j=$i++;
					$sms_id=$row['id'];
					$sms_status=$row['sms_status'];
					$dv_date=explode("-",$row['dv_date']);
					$dv_date=$dv_date[2]."/".$dv_date[1]."/".$dv_date[0];
					$dv_date=$row['fddate'];
					@$txt_sms=$row['txt_sms'];
					@$tagnum=$row['tagnum'];
					@$phy_ord_num=$row['phy_ord_num'];
					
					@$umobile=$row['umobile'];
					
				$chk_com_p=$conn->query("SELECT (select product_name from product where id=sd.item_id) pname,sd.item_qty pqty,sd.receive_qty,sd.order_number FROM `order_record` sd WHERE sd.com_id=$com_id and sd.is_active=1 and sd.dsms_id=$sms_id");
				
			?>
	
   <div class='panel panel-info'>
      <div class="panel-heading"><?php  echo $j.". (".date('d/m/Y',strtotime($row['indate'])).")"; if($sms_status==0) echo " pending "; else echo " sent "; ?></div>
	 
      <div class="panel-body">
			
			<div class="row">
			<div class="col-xs-12 col-sm-6">
				<p for="comment">Serial: <span style='cursor: pointer;color:red;font-weight:bold' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$row['phy_ord_num']; ?>')">
					<?php echo $row['phy_ord_num']; ?>
				</span></p>
				<p for="comment">Customer Name: <b><?php echo $row['cus_name']; ?></b></p>
				<p for="comment">Mobile Number: <b><?php echo $umobile; ?></b></p>
				<p for="comment" style="color:blue">Production Receive: <b><?php echo ($row['factory_status']==1 || $row['factory_status']==2)? "Yes" : "No"; ?></b></p>
				<p for="comment">Factory Delivery Date: <b><?php echo $dv_date; ?></b></p>
			</div>
			<div class="col-xs-12 col-sm-6">
			<span for="">Dress Details:</span>
			<table id="example" class="table table-striped table-bordered">
			
				<thead>
					<tr>
						<th>SL</th>
						<th>Dress/Order Number</th>
						<th>Qty</th>
					</tr>
				</thead>
				<tbody>
				<?php 
				$jj=1;
				while($rrows=mysqli_fetch_array($chk_com_p)){
					$pname=$rrows['pname'];
					$pqty=$rrows['pqty'];
					$order_number=$rrows['order_number'];
					$receive_qty=$rrows['receive_qty'];
					if($receive_qty<$pqty){
						$rd="<span id='dqty'>($receive_qty)</span>";
					}else{
						$rd="<span style='color:blue' id='dqty'>($receive_qty)</span>";
					}
					?>
					<tr>
						<td>
							<b><?php echo $jj++; ?></b>
						</td>
						<td><b>
							<?php echo $pname." ".$rd; ?>
						</b>
						</td>
						<td><b>
							<?php echo $pqty; ?>
						</b>
						</td>
					
					</tr>
					<?php  
				}
				
				?>
				</tbody>
			</table>
			</div>
		</div>
			
	  </div>
	 
    </div>
	
 <?php } ?>
 </div>
 </div>
  <?php 
	if(mysqli_num_rows($psmsquery)>9){
	 ?>
	 <div class="form-group" style="margin-top:15px">
	  <button onclick="seaMoreN3d();" name="btn" id="moreN3dtbtn" class="btn btn-danger">More+</button><span id="load_img_n3d"></span>
	  </div>
		<?php } ?>

  
		<?php 
		mysqli_close($conn);
		}else{
			echo 1;
		}
	}
	
	
		if(isset($_REQUEST['tomorrowDelivery'])){
		
		$com_id=$_SESSION['COM_ID'];
		@$dv_date =date('d/m/Y', strtotime(date('Y-m-d'). ' + 1 days'));
		$psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,ds.cus_mobile umobile,ds.phy_ord_num,ds.cus_name,ds.factory_status,ds.fddate from dsms ds where ds.is_active=1 and ds.occasion=0 and ds.factory_status not in(1,2) and ds.com_id='$com_id' and ds.fddate='$dv_date' and ds.phy_dv_date IS NULL order by ds.id asc limit 0,10");
		
		if(mysqli_num_rows($psmsquery)>0){
		?>
		<div id="romorrow_display">
		<div class="panel-group">
 
   <?php 
			$i=1;
			
				while($row=mysqli_fetch_array($psmsquery)){
					$j=$i++;
					$sms_id=$row['id'];
					$sms_status=$row['sms_status'];
					$dv_date=explode("-",$row['dv_date']);
					$dv_date=$dv_date[2]."/".$dv_date[1]."/".$dv_date[0];
					$dv_date=$row['fddate'];
					@$txt_sms=$row['txt_sms'];
					@$tagnum=$row['tagnum'];
					@$phy_ord_num=$row['phy_ord_num'];
					
					@$umobile=$row['umobile'];
					$chk_com_p=$conn->query("SELECT (select product_name from product where id=sd.item_id) pname,sd.item_qty pqty,sd.order_number,sd.id ord_id,sd.receive_qty FROM `order_record` sd WHERE sd.com_id=$com_id and sd.is_active=1 and sd.dsms_id=$sms_id");
				
				
				
			?>
	
   <div class='panel panel-info'>
      <div class="panel-heading"><?php  echo $j.". (".date('d/m/Y',strtotime($row['indate'])).")"; if($sms_status==0) echo " pending "; else echo " sent "; ?></div>
	 
      <div class="panel-body">
			
			<div class="row">
			<div class="col-xs-12 col-sm-6">
				<p for="comment">Serial: <span style='cursor: pointer;color:red;font-weight:bold' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$row['phy_ord_num']; ?>')">
					<?php echo $row['phy_ord_num']; ?>
				</span></p>
				<p for="comment">Customer Name: <b><?php echo $row['cus_name']; ?></b></p>
				<p for="comment">Mobile Number: <b><?php echo $umobile; ?></b></p>
				<p for="comment" style="color:blue">Production Receive: <b><?php echo ($row['factory_status']==1 || $row['factory_status']==2)? "Yes" : "No"; ?></b></p>
				<p for="comment">Factory Delivery Date: <span > <b><?php echo $dv_date; ?></b></span></p>
				<input type="hidden" style="font-weight: bold;font-size:18px;font-style: italic;" name="date1" id="date2<?php echo $j; ?>" value="<?php echo $dv_date; ?>" class="form-control" data-select="date">
				<input type="hidden" style="" name="date1" id="date_org<?php echo $j; ?>" value="<?php echo @$dv_date; ?>" />
				<input type="hidden" style="" name="mobile" id="mobilet<?php echo $j; ?>" value="<?php echo @$umobile; ?>" />
				
			</div>
			<div class="col-xs-12 col-sm-6">
			<span for="">Dress Details:</span>
			<table id="example" class="table table-striped table-bordered">
			
				<thead>
					<tr>
						<th>SL</th>
						<th>Dress/Order Number</th>
						<th>Qty</th>
					</tr>
				</thead>
				<tbody>
				<?php 
				$jj=1;
				while($rrows=mysqli_fetch_array($chk_com_p)){
					$m=$jj++;
					$pname=$rrows['pname'];
					$pqty=$rrows['pqty'];
					$order_number=$rrows['order_number']."#sep#".$rrows['ord_id']."#sep#".$j;
					$receive_qty=$rrows['receive_qty'];
					if($receive_qty<$pqty){
						$rd="<span id='dqty$m$j'>($receive_qty)</span>";
					}else{
						$rd="<span style='color:blue' id='dqty$m$j'>($receive_qty)</span>";
					}
					?>
					<tr>
						<td>
							<b><?php echo $m; ?></b>
						</td>
						<td><b>
							<?php echo $pname." ".$rd;  ?>
						</b>
						</td>
						<td><b>
							<?php echo $pqty; ?>
						</b>
						</td>
					
					</tr>
					<?php  
				}
				
				?>
				</tbody>
			</table>
			<!--<?php 
			if($row['factory_status']==0){
				?>
				<button onclick="productionReceiveBtn('<?php echo $j; ?>');" name="btn" id="order_receive<?php echo $j; ?>" value="sub" class="btn btn-info">Receive</button>
				<input type="hidden" id="hide_sms_id<?php echo $j; ?>" value="<?php echo $sms_id; ?>" />
				<span id="order_deny_sms<?php echo $j; ?>"></span>
				<?php } ?>-->
			<!--<button onclick="onlyDateUpdateBtn('<?php echo $j; ?>');" name="btn" id="only_dateupdate<?php echo $j; ?>" value="sub" class="btn btn-success">Update</button>&nbsp;&nbsp;-->
				<span id="only_date_update_sms<?php echo $j; ?>"></span>
				<input type="hidden" id="hide_sms_ids<?php echo $j; ?>" value="<?php echo $sms_id; ?>" />
			</div>
		</div>
	  </div>
	 
    </div>
	
 <?php } ?>
 </div>
</div>
 <script type="text/javascript" src="cal/js/apiajax.js"></script>
	<script type="text/javascript" src="cal/js/mousewheel.js"></script>
	<script type="text/javascript" src="cal/js/jquery.dateselect.js"></script>
  <?php 
	if(mysqli_num_rows($psmsquery)>9){
	 ?>
	 <div class="form-group" style="margin-top:15px">
	  <button onclick="seaMoreTomorrow();" name="btn" id="moreTomorrowtbtn" class="btn btn-danger">More+</button><span id="load_img_tomorrow"></span>
	  </div>
	  
		<?php } 
		mysqli_close($conn);
		}else{
			echo 1;
		}
	}
	
		if(isset($_REQUEST['pendingDelivery'])){
		
		$com_id=$_SESSION['COM_ID'];
		@$dv_date =date('d/m/Y');
		//$psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,ds.cus_mobile umobile,ds.phy_ord_num,ds.cus_name,ds.factory_status,ds.fddate from dsms ds where ds.is_active=1 and ds.occasion=0 and ds.com_id='$com_id' and ds.dv_date<'$dv_date' and ds.factory_status not in(1,2) and ds.phy_dv_date IS NULL order by ds.id asc limit 0,10");
		$psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,ds.cus_mobile umobile,ds.phy_ord_num,ds.cus_name,ds.factory_status,ds.fddate from dsms ds where ds.is_active=1 and ds.occasion=0 and ds.com_id='$com_id' and str_to_date(ds.fddate,'%d/%m/%Y') <= str_to_date('$dv_date','%d/%m/%Y') and ds.factory_status not in(1,2) and ds.phy_dv_date IS NULL order by ds.id asc limit 0,10");
		
		if(mysqli_num_rows($psmsquery)>0){
		?>
		<div id="expired_display">
		<div class="panel-group">
 
   <?php 
			$i=1;
			
				while($row=mysqli_fetch_array($psmsquery)){
					$j=$i++;
					$sms_id=$row['id'];
					$sms_status=$row['sms_status'];
					$dv_date=explode("-",$row['dv_date']);
					$dv_date=$dv_date[2]."/".$dv_date[1]."/".$dv_date[0];
					@$txt_sms=$row['txt_sms'];
					@$tagnum=$row['tagnum'];
					@$phy_ord_num=$row['phy_ord_num'];
					
					@$umobile=$row['umobile'];
					$chk_com_p=$conn->query("SELECT (select product_name from product where id=sd.item_id) pname,sd.item_qty pqty,sd.order_number,sd.id ord_id,sd.receive_qty FROM `order_record` sd WHERE sd.com_id=$com_id and sd.is_active=1 and sd.dsms_id=$sms_id");
				if(mysqli_num_rows($chk_com_p)<=0){
					$conn->query("update dsms set is_active=0 where id=$sms_id");
				}
				
				
			?>
	
   <div class='panel panel-info'>
      <div class="panel-heading"><?php  echo $j.". (".date('d/m/Y',strtotime($row['indate'])).")"; if($sms_status==0) echo " pending "; else echo " sent "; ?></div>
	 
      <div class="panel-body">
			
			<div class="row">
			<div class="col-xs-12 col-sm-6">
				<p for="comment">Serial: <span style='cursor: pointer;color:red;font-weight:bold' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$row['phy_ord_num']; ?>')">
					<?php echo $row['phy_ord_num']; ?>
				</span></p>
				<p for="comment">Customer Name: <b><?php echo $row['cus_name']; ?></b></p>
				<p for="comment">Mobile Number: <b><?php echo $umobile; ?></b></p>
				<p for="comment" style="color:blue">Production Receive: <b><?php echo ($row['factory_status']==1 || $row['factory_status']==2)? "Yes" : "No"; ?></b></p>
				<p for="comment" style="">Factory Delivery Date: <b><?php echo $row['fddate']; ?></b></p>
				<p for="comment">Customer Delivery Date: <span > <b><?php echo $dv_date; ?></span></p>
				<input type="hidden" style="font-weight: bold;font-size:18px;font-style: italic;" name="date1" id="date2<?php echo $j; ?>" value="<?php echo $dv_date; ?>" class="form-control" data-select="date">
				<input type="hidden" style="" name="date1" id="date_org<?php echo $j; ?>" value="<?php echo @$dv_date; ?>" />
				<input type="hidden" style="" name="mobile" id="mobilet<?php echo $j; ?>" value="<?php echo @$umobile; ?>" />
				
			</div>
			<div class="col-xs-12 col-sm-6">
			<span for="">Dress Details:</span>
			<table id="example" class="table table-striped table-bordered">
			
				<thead>
					<tr>
						<th>SL</th>
						<th>Dress/Order Number</th>
						<th>Qty</th>
					</tr>
				</thead>
				<tbody>
				<?php 
				$jj=1;
				while($rrows=mysqli_fetch_array($chk_com_p)){
					$m=$jj++;
					$pname=$rrows['pname'];
					$pqty=$rrows['pqty'];
					$order_number=$rrows['order_number']."#sep#".$rrows['ord_id']."#sep#".$j;
					$receive_qty=$rrows['receive_qty'];
					if($receive_qty<$pqty){
						$rd="<span id='dqty$m$j'>($receive_qty)</span>";
					}else{
						$rd="<span style='color:blue' id='dqty$m$j'>($receive_qty)</span>";
					}
					?>
					<tr>
						<td>
							<b><?php echo $m; ?></b>
						</td>
						<td><b>
							<?php echo $pname." ".$rd;  ?>
						</b>
						</td>
						<td><b>
							<?php echo $pqty; ?>
						</b>
						</td>
					
					</tr>
					<?php  
				}
				
				?>
				</tbody>
			</table>
			<!--<?php 
			if($row['factory_status']==0){
				?>
				<button onclick="productionReceiveBtn('<?php echo $j; ?>');" name="btn" id="order_receive<?php echo $j; ?>" value="sub" class="btn btn-info">Receive</button>
				<input type="hidden" id="hide_sms_id<?php echo $j; ?>" value="<?php echo $sms_id; ?>" />
				<span id="order_deny_sms<?php echo $j; ?>"></span>
				<?php } ?>-->
			<!--<button onclick="onlyDateUpdateBtn('<?php echo $j; ?>');" name="btn" id="only_dateupdate<?php echo $j; ?>" value="sub" class="btn btn-success">Update</button>-->&nbsp;&nbsp;
				<span id="only_date_update_sms<?php echo $j; ?>"></span>
				<input type="hidden" id="hide_sms_ids<?php echo $j; ?>" value="<?php echo $sms_id; ?>" />
			</div>
		</div>
	  </div>
	 
    </div>
	
 <?php } ?>
 </div>
</div>
 <script type="text/javascript" src="cal/js/apiajax.js"></script>
	<script type="text/javascript" src="cal/js/mousewheel.js"></script>
	<script type="text/javascript" src="cal/js/jquery.dateselect.js"></script>
  <?php 
	if(mysqli_num_rows($psmsquery)>9){
	 ?>
	 <div class="form-group" style="margin-top:15px">
	  <button onclick="seaMoreExpiredDelivery();" name="btn" id="moreExpiredtbtn" class="btn btn-danger">More+</button><span id="load_img_expired"></span>
	  </div>
	  
		<?php } 
		mysqli_close($conn);
		}else{
			echo 1;
		}
	}
	
	
		if(isset($_REQUEST['todays_delivery'])){
		
		$com_id=$_SESSION['COM_ID'];
		@$dv_date =date('Y-m-d'); // and ds.sms_status=0
		@$dv_date =date('d/m/Y'); // and ds.sms_status=0
		$psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,ds.cus_mobile umobile,ds.phy_dv_date,ds.phy_ord_num,ds.amount,ds.cus_name,ds.discount,ds.factory_status,ds.fddate from dsms ds where ds.is_active=1 and ds.factory_status not in(1,2) and ds.occasion=0 and ds.com_id='$com_id' and ds.fddate='$dv_date' and ds.phy_dv_date IS NULL order by ds.id asc limit 0,10");
		
		if(mysqli_num_rows($psmsquery)>0){
		?>
		<div id="todays_delivery_ord">
		<div class="panel-group">
 
   <?php 
			$i=1;
			$date=date("Y-m-d");
			
				while($row=mysqli_fetch_array($psmsquery)){
					$j=$i++;
					$sms_id=$row['id'];
					$sms_status=$row['sms_status'];
					$dv_date=explode("-",$row['dv_date']);
					$dv_date=$dv_date[2]."/".$dv_date[1]."/".$dv_date[0];
					$dv_date=$row['fddate'];
					@$txt_sms=$row['txt_sms'];
					@$tagnum=$row['tagnum'];
					@$phy_ord_num=$row['phy_ord_num'];
					
					@$umobile=$row['umobile'];
					
				
				
			?>
	
   <div class='panel panel-info'>
      <div class="panel-heading"><?php  echo $j.". (".date('d/m/Y',strtotime($row['indate'])).")"; if($sms_status==0) echo " pending "; else echo " sent "; ?></div>
	 
      <div class="panel-body">
			
			<div class="row">
			<div class="col-xs-12 col-sm-6">
				<p for="comment">Serial:<span style='cursor: pointer;color:red;font-weight:bold' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$row['phy_ord_num']; ?>')">
					<?php echo $row['phy_ord_num']; ?>
				</span></p>
				<p for="comment">Customer Name: <b><?php echo $row['cus_name']; ?></b></p>
				<p for="comment">Mobile Number: <b><?php echo $umobile; ?></b></p>
				<p for="comment" style="color:blue">Production Receive: <b><?php echo ($row['factory_status']==1 || $row['factory_status']==2)? "Yes" : "No"; ?></b></p>
				<p for="comment">Factory Delivery Date: <b><?php echo $dv_date; ?></b></p>
				<input type="hidden" class="form-control" name="txt_sms" id="txt_sms<?php echo $j; ?>" />
				<input type="hidden" class="form-control" name="sms_id" id="sms_id<?php echo $j; ?>" value="<?php echo $sms_id; ?>" />
			
			
			
			<!----------------------------------------->
			<?php
			
			$total_tk=$row['amount'];
			$discount=$row['discount'];
			$total_tk1=intval($total_tk)-((intval($total_tk)*intval($row['discount']))/100);
			$chk_com_p=$conn->query("SELECT (select product_name from product where id=sd.item_id) pname,sd.item_qty pqty,sd.order_number,sd.id ord_id,sd.receive_qty FROM `order_record` sd WHERE sd.com_id=$com_id and sd.is_active=1 and sd.dsms_id=$sms_id");
			$payment_detail=$conn->query("SELECT * FROM `accounting` WHERE `com_id`=$com_id and is_active=1 and `dsms_id`=$sms_id");
			
					
			$ptbl='<table id="example" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>SL</th>
						<th>Dress/Order Number</th>
						<th>Qty</th>
					</tr>
				</thead>
				<tbody>';
				$ptbl2="";	
				$m=1;
				while($rrows=mysqli_fetch_array($chk_com_p)){
					$n=$m++;
					$pname=$rrows['pname'];
					$pqty=$rrows['pqty'];
					$order_number=$rrows['order_number'];
					$receive_qty=$rrows['receive_qty'];
					if($receive_qty<$pqty){
						$rd="<span id='dqty$m$j'>($receive_qty)</span>";
					}else{
						$rd="<span style='color:blue' id='dqty$m$j'>($receive_qty)</span>";
					}
					$ptbl2.="<tr>
						<td>
							<b>$n</b>
						</td>
						<td><b>
							$pname $rd
						</b>
						</td>
						<td><b>
							$pqty
						</b>
						</td>
					
					</tr>";
				}
				
					
				$ptbl3='</tbody>
				</table>';
			$ptblf=$ptbl.$ptbl2.$ptbl3;
			
			$payspan="<span id='payment_tbl$j'>";
			$paytbl='<table id="example" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>Description</th>
						<th style="text-align:right">Taka</th>
					</tr>
				</thead>
				<tbody id="payable">';
				@$paytblhead.="<tr>
						<td>
							<b>Total</b>
						</td>
						<td><b>
							<input style='text-align:right;border: 1px solid #F9F9F9;background: #F9F9F9;width:100%' type='text' readonly value='$total_tk'/>
						</b>
						</td>
						</tr><tr><td>
							<b>Discount(%)</b>
						</td><td style='text-align:right'>$discount</td></tr>";
				$paytbl2="";	
				$sum=0;
				while($payrows=mysqli_fetch_array($payment_detail)){
					$due_tk=$payrows['amount'];
					$accounting_tbl_id=$payrows['id'];
					$sum+=intval($due_tk);
					if(isset($row['phy_dv_date'])){
						$del="";
						$paid="(<span style='color:blue'>Paid</span>)";
					}else{
						$del="(<a href='javascript:void(0)' onclick='delPay($accounting_tbl_id,$j);'>Del</a>)";
						$paid="";
					}
					if($payrows['pay_status']==1){
						$paytbl2.="<tr>
						<td>
							Advance $del
						</td>
						<td style='text-align:right'>
							$due_tk
						</td>
						</tr>";
					}else{
						$paytbl2.="<tr>
						<td>
							Pay $del
						</td>
						<td style='text-align:right'>
							$due_tk
						</td>
						</tr>";
					}
				
				}
				$due=intval($total_tk1)-$sum;
				@$paytbldue.="<input type='hidden' value='$due' id='hide_due$j'/><tr>
						<td>
							<b>Due $paid</b>
						</td>
						<td style='text-align:right'><b>
							$due
						</b>
						</td>
						</tr>";
				if($due!=0){
					if(isset($row['phy_dv_date'])){
						@$paytblpay.="<input type='hidden' value='$sms_id' id='dsms_ids$j'/>
						<input type='hidden' value='$total_tk' id='total_tk$j'/>
						<span id='stksms$j'></span>";
					}else{ //<button onclick='payTk($j);' name='btn' id='paybtns$j' value='sub' class='btn btn-success'>Pay</button>
				@$paytblpay.="<tr>
						<td>
							---
						</td>
						<td>
						<input style='text-align:right;width:100%' type='text' id='paytxt$j'/>
						<input type='hidden' value='$sms_id' id='dsms_ids$j'/>
						<input type='hidden' value='$total_tk' id='total_tk$j'/>
						<span id='stksms$j'></span>
						</td>
						</tr>";
					}
				}else{
					$paytblpay="<input type='hidden' value='$total_tk' id='total_tk$j'/><input type='hidden' value='$sms_id' id='dsms_ids$j'/>";
				}
					
				$paytbl3='</tbody>
					</table>';
				$payspan_end="</span>";
				echo "<input type='hidden' id='discount$j' value='$discount' />
				<input type='hidden' id='discount_tot$j' value='$total_tk1' />";
			$paytblf=$payspan.$paytbl.$paytblhead.$paytbl2.$paytbldue.$paytblpay.$paytbl3.$payspan_end;
			
			?>
				
				
					<span for="">Dress Details:</span>
					<span id="pdetail">
					 <?php echo $ptblf; ?>
					</span>
				</div>
				<div class="col-xs-12 col-sm-6">
					
					<span for="">Payment Details:</span>
					<span id="paydetail">
						<?php echo $paytblf; ?>
					</span>
			
			<!----------------------------------------->
					<!--<button onclick="orderDeliveryBtn(<?php echo $j; ?>);" name="btn" id="order_delivery<?php echo $j; ?>" value="sub" class="btn btn-warning">Delivery</button>&nbsp;&nbsp;-->
					<span id="order_delivery_sms<?php echo $j; ?>"></span>
					<input type="hidden" id="hide_sms_id<?php echo $j; ?>" value="<?php echo $row['id']; ?>" />
				</div>
		</div>
	  </div>
	 
    </div>
	
 <?php 
 $paytblf=$payspan=$paytbl=$paytblhead=$paytbl2=$paytbldue=$paytblpay=$paytbl3=$payspan_end="";
			$ptblf=$ptbl=$ptbl2=$ptbl3="";
		echo "<hr/>";	
 }
 ?>
 </div>
 </div>
<?php 
	if(mysqli_num_rows($psmsquery)>9){
	 ?>
	 <div class="form-group" style="margin-top:15px">
	  <button onclick="seaMoreToday();" name="btn" id="moreTodaytbtn" class="btn btn-danger">More+</button><span id="load_img_today"></span>
	  </div>
		<?php } ?>
	
		<?php 
		}else{
			echo 1;
		}
	}
	
	
	if(isset($_REQUEST['only_date_update'])){
		$com_id=$_SESSION['COM_ID'];
		$date2=$date1=$_REQUEST['date1']; //chagned date
		$date_org=$_REQUEST['date_org']; // org date
		$hide_sms_id=$_REQUEST['hide_sms_id'];
		$update_dv_status=0;
		$mobile=explode(",",$_REQUEST['mobile']);
		if($_SESSION['SOFT_TYPE']==1){ //for online
			if($date1!=$date_org){
					$remsql=$conn->query("select rem_sms from rem_sms where com_id=$com_id");
					$rrow=mysqli_fetch_array($remsql);
					$rem_sms=$rrow['rem_sms'];
					if(($rem_sms-count($mobile))>=0){
					@$rem_sms=$rem_sms-count($mobile);
					$conn->query("update rem_sms set rem_sms=$rem_sms where com_id=$com_id");
					sendSms($_REQUEST['mobile'],$date1);
					}else{
						echo 10000000;
						exit();
					}
			}
		}
		if(isset($date1)){
			$ex=explode("/",$date1);
			$date_orgex=explode("/",$date_org);
			$date1=$ex[2]."-".$ex[1]."-".$ex[0];
			$date_org=$date_orgex[2]."-".$date_orgex[1]."-".$date_orgex[0];
		}
		if($_SESSION['SOFT_TYPE']==2){ //for offline
			if($date1!=$date_org){
				if(check_internet_connection()==1){
					$mobiles=$_REQUEST['mobile'];
					$response = file_get_contents($_SESSION['API']."api/data.php?com_id=$com_id&dv_date=$date1&org_date=$date_org&mobiles=$mobiles&chk=5"); //chk=5 means dv date update sms
					$json = json_decode($response, true);
					if(@$json['auth']==1){
						$update_dv_status=1;
					}else if($json['auth']==2){
						echo 20000000; //server busy
						exit();
					}else if($json['auth']==3){
						echo 10000000; //not enough sms
						exit();
					}
				}else{
					echo 40000000; //action in connection failure
					exit();
				}
			}
		}
		
		
		@$text=$conn->query("update dsms set dv_date='$date1',update_dv_status=$update_dv_status where id=$hide_sms_id");
		mysqli_close($conn);
		if($text){
			echo $date2;
		}else{
			echo 1;
		}
	}
	
	if(isset($_REQUEST['after_receive_only_date_update'])){
		$com_id=$_SESSION['COM_ID'];
		$date2=$date1=$_REQUEST['date1']; //chagned date
		$date_org=$_REQUEST['date_org']; // org date
		$hide_sms_id=$_REQUEST['hide_sms_id'];
		$update_dv_status=0;
	if(mysqli_num_rows($conn->query("select id from dsms where factory_status=1 and id=$hide_sms_id"))>0){
		$mobile=explode(",",$_REQUEST['mobile']);
		if($_SESSION['SOFT_TYPE']==1){ //for online
			if($date1!=$date_org){
					$remsql=$conn->query("select rem_sms from rem_sms where com_id=$com_id");
					$rrow=mysqli_fetch_array($remsql);
					$rem_sms=$rrow['rem_sms'];
					if(($rem_sms-count($mobile))>=0){
					@$rem_sms=$rem_sms-count($mobile);
					$conn->query("update rem_sms set rem_sms=$rem_sms where com_id=$com_id");
					sendSms($_REQUEST['mobile'],$date1);
					}else{
						echo 10000000;
						exit();
					}
			}
		}
		if(isset($date1)){
			$ex=explode("/",$date1);
			$date_orgex=explode("/",$date_org);
			$date1=$ex[2]."-".$ex[1]."-".$ex[0];
			$date_org=$date_orgex[2]."-".$date_orgex[1]."-".$date_orgex[0];
		}
		
		if($_SESSION['SOFT_TYPE']==2){ //for offline
			
				if(check_internet_connection()==1){
					$mobiles=$_REQUEST['mobile'];
					$response = file_get_contents($_SESSION['API']."api/data.php?com_id=$com_id&dv_date=$date1&org_date=$date_org&mobiles=$mobiles&chk=7"); //chk=5 means dv date update sms
					$json = json_decode($response, true);
					if(@$json['auth']==1){
						$update_dv_status=1;
					}else if($json['auth']==2){
						echo 20000000; //server busy
						exit();
					}else if($json['auth']==3 || $json['auth']==4){
						echo 10000000; //not enough sms
						exit();
					}
				}else{
					echo 40000000; //action in connection failure
					exit();
				}
			
		}
		
		
		@$text=$conn->query("update dsms set sms_status=1,update_dv_status=$update_dv_status where id=$hide_sms_id");
		mysqli_close($conn);
		
		if($text){
			echo $date2;
		}else{
			echo 1;
		}
	}else{
		echo 50000000;
	}
	}
	
	if(isset($_REQUEST['searchEmpDueStatus'])){
		$com_id=$_SESSION['COM_ID'];
		$emp_due_statuss=$_REQUEST['emp_due_statuss'];
		if($emp_due_statuss=="not_delivery"){
			$delivery_due=$conn->query("select distinct(dd.cus_mobile),dd.cus_name,dd.due_amount,dd.cus_address
from (SELECT cus_mobile,(SELECT customer.cus_name FROM `customer` WHERE customer.cus_mobile=dsms.cus_mobile limit 0,1) cus_name,
      (SELECT customer.id FROM `customer` WHERE customer.cus_mobile=dsms.cus_mobile limit 0,1) cus_ids,
      (SELECT customer.cus_address FROM `customer` WHERE customer.cus_mobile=dsms.cus_mobile limit 0,1) cus_address,
      (select last_due from update_due where cus_id=cus_ids and is_active=1 order by id desc limit 0,1) due_amount,
      (select sum(amount) from accounting where is_active=1 and dsms_id=dsms.id) tk,`amount` FROM `dsms` WHERE  is_active=1 and phy_dv_date is null HAVING amount>tk) dd");
		}else if($emp_due_statuss=="delivery"){
		/*	$delivery_due=$conn->query("select dd.cus_mobile,dd.cus_name,dd.due_amount,dd.cus_address
from (SELECT cus_mobile,(SELECT customer.cus_name FROM `customer` WHERE customer.cus_mobile=dsms.cus_mobile limit 0,1) cus_name,
      (SELECT customer.id FROM `customer` WHERE customer.cus_mobile=dsms.cus_mobile limit 0,1) cus_ids,
      (SELECT customer.cus_address FROM `customer` WHERE customer.cus_mobile=dsms.cus_mobile limit 0,1) cus_address,
      (select last_due from update_due where cus_id=cus_ids and is_active=1 order by id desc limit 0,1) due_amount,
      (select sum(amount) from accounting where is_active=1 and dsms_id=dsms.id) tk,`amount` FROM `dsms` WHERE  is_active=1 and phy_dv_date is not null HAVING amount>tk) dd where dd.due_amount!=0");*/
	  $delivery_due=$conn->query("select distinct(nn.cus_mobile) cus_mobile,nn.cus_name,nn.cus_ids,nn.due_amount due_amount,nn.cus_address from (select cus_mobile,
(SELECT customer.id FROM `customer` WHERE customer.cus_mobile=dd.cus_mobile limit 0,1) cus_ids,
(SELECT customer.cus_name FROM `customer` WHERE customer.cus_mobile=dd.cus_mobile limit 0,1) cus_name,
(SELECT customer.cus_address FROM `customer` WHERE customer.cus_mobile=dd.cus_mobile limit 0,1) cus_address,
(select last_due from update_due where cus_id=cus_ids and is_active=1 order by id desc limit 0,1) due_amount
FROM `dsms` dd WHERE  is_active=1 and cus_mobile not in(select cus_mobile FROM `dsms` mm WHERE  is_active=1 and mm.cus_mobile=dd.cus_mobile and mm.phy_dv_date is null)) nn where nn.due_amount>0");
		}else if($emp_due_statuss=="creditor"){
		$delivery_due=$conn->query("select dd.* from (SELECT c.id,c.cus_name,c.cus_mobile,c.cus_address,
		(select last_due from update_due where cus_id=c.id and is_active=1 order by id desc limit 0,1) due_amount 
		FROM `customer` c WHERE c.com_id=$com_id and c.is_active=1) dd where dd.due_amount<0");
			
		}
		mysqli_close($conn);
		if(mysqli_num_rows($delivery_due)>0){
						$i=1;
					$sum=0;	
				while($row=mysqli_fetch_array($delivery_due)){
					$j=$i++;
					$sum+=$row['due_amount'];
					?>
					<tr>
						<td style="width:15%">
							<b><?php echo $j; ?></b>
						</td>
						<td><b><?php 
							echo $row['cus_name'];
						?></b>
						</td>
						<td>
						<?php 
							echo $row['cus_mobile'];
						?>
						</td>
						<td>
						<?php 
							echo $row['cus_address'];
						?>
						</td>
					<td style="text-align: right;font-weight:bold">
						<?php 
							echo englishToBangla($row['due_amount']);
						?>/=
						</td>
					</tr>
						<?php 
						
				} 
				?>
				<tr>
					<td colspan="4" style="text-align:right">
							<b>Total: </b>
					</td>
					<td style="text-align:right">
							<b><?php  echo $sum; ?>/=</b>
					</td>
			<?php 
		}else{
			echo 1;
		}
	}
	
	if(isset($_REQUEST['getTodaysDelivery'])){
		$com_id=$_SESSION['COM_ID'];
		$branch_id=$_SESSION['BRANCH_ID'];
		if(isset($branch_id)){
			$ex=explode("_",$branch_id);
			$com_id=implode(",",$ex);
		}
		$date=date("Y-m-d");
		$todays=$conn->query("SELECT count(ord.order_number) torder,(select com_name from company where id=ds.com_id) com_name FROM `dsms` ds, order_record ord WHERE ds.id=ord.dsms_id and ds.`is_active`=1 and ord.is_active=1 and ds.`occasion`=0 and ds.`phy_dv_date` is not null and ds.`phy_dv_date`='$date' and ds.com_id in ($com_id) GROUP by ds.com_id");
		mysqli_close($conn);
		if(mysqli_num_rows($todays)>0){
			?>
			<div class="panel-group">
			<div class="panel panel-info">
			  <div class="panel-heading">Todays</div>
				<div class="panel-body">
				
				<table id="example" class="table table-striped table-bordered" style="width:100%">
				<thead>
					<tr>
						<th>SL</th>
						<th>Branch Name</th>
						<th>Order Qty</th>
					</tr>
				</thead>
				<tbody id="pbodytbl">
					<?php
						$i=1;
					$sum=0;	
				while($row=mysqli_fetch_array($todays)){
					$j=$i++;
					$sum+=$row['torder'];	
					?>
					<tr>
						<td style="width:15%">
							<b><?php echo $j; ?></b>
						</td>
						<td><b><?php 
							echo $row['com_name'];
						?></b>
						</td>
						<td><b><?php 
							echo $row['torder'];
						?></b>
						</td>
					
					</tr>
						<?php 
						
						} ?>
						<tr>
						<td colspan="2" style="text-align:right">Total Order</td>
						<td><b><?php echo $sum; ?></b></td>
						</tr>
					
				</tbody>
			</table>
					
				</div>
			</div>
		</div>
			<?php 
		}else{
			echo 1;
		}
	}
	
	
		if(isset($_REQUEST['getPreMonthDelivery'])){
		$com_id=$_SESSION['COM_ID'];
		$branch_id=$_SESSION['BRANCH_ID'];
		if(isset($branch_id)){
			$ex=explode("_",$branch_id);
			$com_id=implode(",",$ex);
		}

		$date=date("m-Y", strtotime("-1 months")); 
		$ex=explode("-",$date);
		$month=$ex[0];
		$year=$ex[1];
		$todays=$conn->query("SELECT count(ord.order_number) torder,(select com_name from company where id=ds.com_id) com_name FROM `dsms` ds, order_record ord WHERE ds.id=ord.dsms_id and ds.`is_active`=1 and ord.is_active=1 and ds.`occasion`=0 and ds.`phy_dv_date` is not null and month(ds.`phy_dv_date`)='$month' and year(ds.`phy_dv_date`)='$year' and ds.com_id in ($com_id) GROUP by ds.com_id");
		mysqli_close($conn);
		if(mysqli_num_rows($todays)>0){
			?>
			<div class="panel-group">
			<div class="panel panel-info">
			  <div class="panel-heading">Todays</div>
				<div class="panel-body">
				
				<table id="example" class="table table-striped table-bordered" style="width:100%">
				<thead>
					<tr>
						<th>SL</th>
						<th>Branch Name</th>
						<th>Order Qty</th>
					</tr>
				</thead>
				<tbody id="pbodytbl">
					<?php
						$i=1;
					$sum=0;	
				while($row=mysqli_fetch_array($todays)){
					$j=$i++;
					$sum+=$row['torder'];	
					?>
					<tr>
						<td style="width:15%">
							<b><?php echo $j; ?></b>
						</td>
						<td><b><?php 
							echo $row['com_name'];
						?></b>
						</td>
						<td><b><?php 
							echo $row['torder'];
						?></b>
						</td>
					
					</tr>
						<?php 
						
						} ?>
						<tr>
						<td colspan="2" style="text-align:right">Total Order</td>
						<td><b><?php echo $sum; ?></b></td>
						</tr>
					
				</tbody>
			</table>
					
				</div>
			</div>
		</div>
			<?php 
		}else{
			echo 1;
		}
	}
	
	
	if(isset($_REQUEST['getMonthlyDelivery'])){
		$com_id=$_SESSION['COM_ID'];
		$branch_id=$_SESSION['BRANCH_ID'];
		if(isset($branch_id)){
			$ex=explode("_",$branch_id);
			$com_id=implode(",",$ex);
		}
		$month=date("m");
		$year=date("Y");
		
		$todays=$conn->query("SELECT count(ord.order_number) torder,(select com_name from company where id=ds.com_id) com_name FROM `dsms` ds, order_record ord WHERE ds.id=ord.dsms_id and ds.`is_active`=1 and ord.is_active=1 and ds.`occasion`=0 and ds.`phy_dv_date` is not null and month(ds.`phy_dv_date`)='$month' and year(ds.`phy_dv_date`)='$year' and ds.com_id in ($com_id) GROUP by ds.com_id");
		mysqli_close($conn);
		if(mysqli_num_rows($todays)>0){
			?>
			<div class="panel-group">
			<div class="panel panel-info">
			  <div class="panel-heading">Todays</div>
				<div class="panel-body">
				
				<table id="example" class="table table-striped table-bordered" style="width:100%">
				<thead>
					<tr>
						<th>SL</th>
						<th>Branch Name</th>
						<th>Order Qty</th>
					</tr>
				</thead>
				<tbody id="pbodytbl">
					<?php
						$i=1;
					$sum=0;	
				while($row=mysqli_fetch_array($todays)){
					$j=$i++;
					$sum+=$row['torder'];	
					?>
					<tr>
						<td style="width:15%">
							<b><?php echo $j; ?></b>
						</td>
						<td><b><?php 
							echo $row['com_name'];
						?></b>
						</td>
						<td><b><?php 
							echo $row['torder'];
						?></b>
						</td>
					
					</tr>
						<?php 
						
						} ?>
						<tr>
						<td colspan="2" style="text-align:right">Total Order</td>
						<td><b><?php echo $sum; ?></b></td>
						</tr>
					
				</tbody>
			</table>
					
				</div>
			</div>
		</div>
			<?php 
		}else{
			echo 1;
		}
	}
	
	
		if(isset($_REQUEST['getDeliverySummary'])){
		
		$com_id=$_SESSION['COM_ID'];
		@$dv_date_start =date('Y-m-d');
		@$dv_date_end =date('Y-m-d', strtotime(date('Y-m-d'). ' + 30 days'));
		$psmsquery=$conn->query("select ds.dv_date,count(dv_date) nofdev from dsms ds where ds.is_active=1 and ds.occasion=0 and ds.com_id='$com_id' and ds.dv_date BETWEEN '$dv_date_start' and '$dv_date_end' and ds.phy_dv_date IS NULL GROUP by ds.dv_date");
		mysqli_close($conn);
		if(mysqli_num_rows($psmsquery)>0){
		?>
		<div class="panel-group">
 
   
   <div class='panel panel-info'>
      <div class="panel-heading" id="stdv"></div>
	 
      <div class="panel-body">
			
			<table id="example" class="table table-striped table-bordered" style="width:100%">
				<thead>
					<tr>
						<th>SL</th>
						<th>Delivery Date</th>
						<th>Qty</th>
					</tr>
				</thead>
				<tbody id="pbodytbl">
					<?php
						$i=1;
						$sum=0;
				while($row=mysqli_fetch_array($psmsquery)){
					$j=$i++;
					$dv_date=date('d/m/Y',strtotime($row['dv_date']));
					$no_of_order=$row['nofdev'];
					$sum+=$no_of_order;		
					?>
					<tr>
						<td style="width:15%">
							<b><?php echo $j; ?></b>
						</td>
						<td><b><?php 
							echo $dv_date;
						?></b>
						</td>
						<td><b><?php 
							echo $no_of_order;
						?></b>
						</td>
					
					</tr>
						<?php 
						
						} ?>
					
				</tbody>
			</table>
			<input type="hidden" id="tdev" value="<?php echo $sum; ?>"/>
	  </div>
	 
    </div>
	
 
 </div>

  
		<?php 
		}else{
			echo 1;
		}
	}
	
	
		if(isset($_REQUEST['arcbtn'])){
		
		$com_id=$_SESSION['COM_ID'];
		$year=$_REQUEST['year'];
		if($year=="all"){
			$psmsquery=$conn->query("select cus_mobile umobile from dsms where com_id=$com_id group by cus_mobile limit 0,5000");
		}else{
		$psmsquery=$conn->query("select cus_mobile umobile from dsms where com_id=$com_id and year=$year group by cus_mobile limit 0,5000");
		}
		$i=1;
		if(mysqli_num_rows($psmsquery)>0){
			$mobiles=array();
				while($row=mysqli_fetch_array($psmsquery)){
					$mobiles[]=$row['umobile'];
				
					@$umobile=implode(",",$mobiles);
					
				}
				$count_mobile=count($mobiles);
				mysqli_close($conn);
			?>
	<br/>
	
   <div class='panel panel-success'>
      <div class="panel-heading"><?php  echo "Total: ".$count_mobile." Numbers"; ?></div>
	 
      <div class="panel-body">
			
			
			<div class="form-group">
				<span id="sms_op">
				  <label for="comment">Message(English):</label>
				  <textarea class="form-control" maxlength="200" rows="5" name="otxt_sms" id="otxt_sms" required></textarea>
				</span>
				<span id="condition" style="font-size:11px;color:red">
				  <p>১. এসএমএস সার্ভিস পার্সোনাল ব্যবহার যেমন বান্ধবীকে ম্যাসেজ দিতে কিংবা যে কোনো ধরনের ভালোবাসা সম্পর্কিত, অ্যাডাল্ট, গালী, কিংবা হুমকি দেবার কাজে ব্যবহার করতে পারবেন না ।</p>
				  <p>২. যে কোনো ধরনের ব্যক্তিগত এসএমএস প্রেরন করা সম্পূর্ন নিষিদ্ধ ।</p>
				  <p>৩. বাংলা এসএমএস এ ৬৭ এবং ইংরেজি এসএমএস এ ১৬০ ক্যারেক্টারে সমান টাকা কাটা হয়  ।</p>
				  <p>৪. এসএমএস সম্পূর্ণ ইংলিশ এ লিখতে হবে।</p>
				  <!--<button onclick="txtbtn();" name="btn" id="txtbtn" value="sub" class="btn btn-warning">Text Here</button>-->
				 </span>
			</div>
			<div class="form-group">
			  <label for="comment">Mobile Number: <button onclick="copyFunction();" name="btn" id="txtbtn" value="sub" class="btn btn-success">Copy</button></label>
			  <textarea class="form-control" style="font-weight: bold;font-size:18px;font-style: italic;" rows="5" name="omobile" id="omobile" required><?php echo $umobile; ?></textarea>
			</div>
		<!--<button onclick="sendSmsOccasion();" name="btn" id="allockbtn" value="sub" class="btn btn-danger">Send</button>-->
		<a target="_blank" href="<?php echo $_SESSION['API']; ?>client_sms/login_code.php?code1=<?php echo $_SESSION['COM_ID']; ?>&&code2=<?php echo $_SESSION['LOG_USER']; ?>&&code3=<?php echo $_SESSION['LOG_PASS']; ?>" name="btn" value="sub" class="btn btn-danger">SMS</a>
		<span id="sms_save"></span>	
			
	  </div>
	 
    </div>
	
	
		<?php 
		}else{
			echo 1;
		}
	}
		
		
		if(isset($_REQUEST['sendOcasionbtn'])){
				
			$txt_sms=trim(str_replace("'", "",$_REQUEST['txt_sms']));

			if((strlen($txt_sms) != mb_strlen($txt_sms, 'utf-8')) || $txt_sms=="")
			{ 
				echo 50000000; //"Please enter English words only:(";
			}
			else {

			$com_id=($_SESSION['COM_ID']);
			$com_name=($_SESSION['COM']);
			$com_address=($_SESSION['COM_ADDRESS']);
			$user_id=$_SESSION['USER_ID'];
			$year=date("Y");
			$send="";
		if($_SESSION['SOFT_TYPE']==1){ //online status
			$chk_com=$conn->query("select * from company where is_active=1 and id=$com_id");
			if(mysqli_num_rows($chk_com)>0){
				
					$remsql=$conn->query("select rem_sms from rem_sms where com_id=$com_id");
					$rrow=mysqli_fetch_array($remsql);
					$rem_sms_hidden=$rrow['rem_sms'];
			
						$txt_sms=$txt_sms."\n".$com_name."\n".$com_address;
				
				if(strlen($txt_sms)<300){
				$mobile=explode(",",trim($_REQUEST['mobile']));
				$tmobile=count($mobile);
				$smscount=count($mobile);
				if(strlen($txt_sms)>157){
					$smscount=($smscount*2);
				}
				if(($rem_sms_hidden-$smscount)>=0){
					@$rem_sms=($rem_sms_hidden-$smscount); //rem sms
					
				
				$mod=$tmobile%250;
				
				$result=intval($tmobile/250);
				$m=0;
				if($mod==0){
				for($i=0;$i<$result;$i++){
					@$text=$conn->query("insert into dsms_occasion(txt_sms,com_id,insert_by,occasion) values('$txt_sms','$com_id',$user_id,1)");
					if($text){
						@$top_id = $conn->insert_id;
					}
					for($j=0;$j<250;$j++){
						$amobile=$mobile[$m++];
						$conn->query("insert into dsms_mobile_occasion(sms_id,umobile,com_id,year) values($top_id,'$amobile',$com_id,$year)");
					//echo $m++."<br/>";
					}
					//$m++;
				}
				$send=1;
				}else{
					if($tmobile<250){
						@$text=$conn->query("insert into dsms_occasion(txt_sms,com_id,insert_by,occasion) values('$txt_sms','$com_id',$user_id,1)");
						if($text){
							@$top_id = $conn->insert_id;
						}
						for($k=0;$k<$mod;$k++){
							$amobile=$mobile[$m++];
							$conn->query("insert into dsms_mobile_occasion(sms_id,umobile,com_id,year) values($top_id,'$amobile',$com_id,$year)");
							
						}
					}else{
						for($i=0;$i<$result;$i++){
							@$text=$conn->query("insert into dsms_occasion(txt_sms,com_id,insert_by,occasion) values('$txt_sms','$com_id',$user_id,1)");
							if($text){
								@$top_id = $conn->insert_id;
							}
								for($j=0;$j<250;$j++){
									$amobile=$mobile[$m++];
									$conn->query("insert into dsms_mobile_occasion(sms_id,umobile,com_id,year) values($top_id,'$amobile',$com_id,$year)");
								
								}
						
						}
					
						@$text=$conn->query("insert into dsms_occasion(txt_sms,com_id,insert_by,occasion) values('$txt_sms','$com_id',$user_id,1)");
						if($text){
							@$top_id = $conn->insert_id;
						}
						for($k=0;$k<$mod;$k++){
							$amobile=$mobile[$m++];
							$conn->query("insert into dsms_mobile_occasion(sms_id,umobile,com_id,year) values($top_id,'$amobile',$com_id,$year)");
							
						}
					}
					$send=1;
				}
				
					if($send==1){
						$conn->query("update rem_sms set rem_sms=$rem_sms where com_id=$com_id");
						mysqli_close($conn);
						echo 40000000; // send success
					}else{
						echo 20000000; //sms not sent
					}
				}else{
					echo 10000000; //not enough sms
				}
			}else{
				echo 60000000;
			}
			}else{
				echo 30000000; // invalid business id
			}
		}
			if($_SESSION['SOFT_TYPE']==2){ //offline status for occasion mobile num
				$connected = @fsockopen("www.google.com", 443); 
				if ($connected){
					/*$mobiles=$_REQUEST['mobile'];
					fclose($connected);
					$response = file_get_contents($_SESSION['API']."api/data.php?com_id=$com_id&dv_date=$date1&org_date=$date_org&mobiles=$mobiles&chk=5"); //chk=5 means dv date update sms
					$json = json_decode($response, true);
					if(@$json['auth']==1){
						$update_dv_status=1;
					}else if($json['auth']==2){
						echo 20000000; //server busy
						exit();
					}else if($json['auth']==3){
						echo 10000000; //not enough sms
						exit();
					}*/   // development pending
				}else{
					echo 70000000; //action in connection failure
				}
			}
		
		}
	}
	
	/*-------------------------------------------------------------------------------------------------------------*/
	
	if(isset($_REQUEST['saveOldOrder'])){
		$com_id=($_SESSION['COM_ID']);
		$oorder_numbers=trim($_REQUEST['oorder_numbers']);
		$omobile_num=trim($_REQUEST['omobile_num']);
		@$text=$conn->query("insert into extra_mobile(com_id,order_num,mobile_num) values('$com_id',$oorder_numbers,'$omobile_num')");
		if($text){
			$ex_mobile=$conn->query("select * from extra_mobile where is_active=1 and com_id=$com_id order by id desc limit 0,15");
			if(mysqli_num_rows($ex_mobile)>0){
						$i=1;
							while($rows=mysqli_fetch_array($ex_mobile)){
								$j=$i++;
						?>
							<tr>
								<td><?php echo $j; ?></td>
								<td><?php echo $rows['order_num']; ?></td>
								<td><?php echo $rows['mobile_num']; ?></td>
								
								<td><button onclick="delOldOrder(<?php echo $rows['id']; ?>);" style="" id="del_ord_btn<?php echo $rows['id']; ?>" name="btn" value="sub" class="btn btn-danger form-control">Delete</button></td>
							</tr>
						<?php 
							}
						
			
			}
		}
		
	}
	
	if(isset($_REQUEST['searchOldOrder'])){
		$com_id=($_SESSION['COM_ID']);
		$oorder_numberormobile=trim($_REQUEST['oorder_numberormobile']);
			$ex_mobile=$conn->query("select * from extra_mobile where is_active=1 and com_id=$com_id and (order_num='$oorder_numberormobile' or mobile_num='$oorder_numberormobile')");
			if(mysqli_num_rows($ex_mobile)>0){
						$i=1;
							while($rows=mysqli_fetch_array($ex_mobile)){
								$j=$i++;
						?>
							<tr>
								<td><?php echo $j; ?></td>
								<td><?php echo $rows['order_num']; ?></td>
								<td><?php echo $rows['mobile_num']; ?></td>
								<td><button onclick="delOldOrder(<?php echo $rows['id']; ?>);" style="" id="del_ord_btn<?php echo $rows['id']; ?>" name="btn" value="sub" class="btn btn-danger form-control">Delete</button></td>
							</tr>
						<?php 
							}
						
			
			}
	}
	
	if(isset($_REQUEST['delOldOrder'])){
		$id=trim($_REQUEST['id']);
		$com_id=($_SESSION['COM_ID']);
		$ex_mobile=$conn->query("update extra_mobile set is_active=0 where id=$id");
		if($ex_mobile){
			$ex_mobile=$conn->query("select * from extra_mobile where is_active=1 and com_id=$com_id order by id desc limit 0,15");
			if(mysqli_num_rows($ex_mobile)>0){
						$i=1;
							while($rows=mysqli_fetch_array($ex_mobile)){
								$j=$i++;
						?>
							<tr>
								<td><?php echo $j; ?></td>
								<td><?php echo $rows['order_num']; ?></td>
								<td><?php echo $rows['mobile_num']; ?></td>
								<td><button onclick="delOldOrder(<?php echo $rows['id']; ?>);" style="" id="del_ord_btn<?php echo $rows['id']; ?>" name="btn" value="sub" class="btn btn-danger form-control">Delete</button></td>
							</tr>
						<?php 
							}
						
			
			}
		}
	}
	
	if(isset($_REQUEST['meargeOrder'])){
		$com_id=($_SESSION['COM_ID']);
		if($_SESSION['SVERSION']==0){
			$_SESSION['SVERSION']=2;
			$ex_mobile=$conn->query("update company set sversion=2 where id=$com_id");
		}else if($_SESSION['SVERSION']==2){
			$_SESSION['SVERSION']=0;
			$ex_mobile=$conn->query("update company set sversion=0 where id=$com_id");
		}
		echo 1;
	}
	
	if(isset($_REQUEST['orderChangeOption'])){
		$order_change_option=trim($_REQUEST['order_change_option']);
		$chk_id=trim($_REQUEST['id']);
		$com_id=($_SESSION['COM_ID']);
		if($chk_id==1){
		$ex_mobile=$conn->query("update company set sversion=$order_change_option where id=$com_id");
		$_SESSION['SVERSION']=$order_change_option;
			if($order_change_option==1){
				$_SESSION['OLD_ORDER_STATUS']=0;
			}else{
				$_SESSION['OLD_ORDER_STATUS']=1;
			}
		}
		if($chk_id==2){
			$ex_mobile=$conn->query("update company set measure_type=$order_change_option where id=$com_id");
			$_SESSION['MEASURE_TYPE']=$order_change_option;
		}
		if($chk_id==3){
			$ex_mobile=$conn->query("update company set factory_delivery=$order_change_option where id=$com_id");
			$_SESSION['FAC_DELIVERY']=$order_change_option;
		}
		if($chk_id==4){
			$ex_mobile=$conn->query("update company set customer_delivery=$order_change_option where id=$com_id");
			$_SESSION['CUS_DELIVERY']=$order_change_option;
		}
		if($chk_id==5){
			$ex_mobile=$conn->query("update company set set_tax=$order_change_option where id=$com_id");
			$_SESSION['SET_TAX']=$order_change_option;
		}
		
		if($chk_id==6){
			$ex_mobile=$conn->query("update company set ord_settings=$order_change_option where id=$com_id");
			$_SESSION['ORD_SETTINGS']=$order_change_option;
		}
		
		if($chk_id==7){
			$ex_mobile=$conn->query("select order_qty from feg_order where com_id=$com_id and year='$order_change_option' order by id desc limit 0,1");
			$rows=mysqli_fetch_array($ex_mobile);
			
		}
		if($chk_id==9){
			$ex_mobile=$conn->query("update company set design_set=$order_change_option where id=$com_id");
			$_SESSION['SHOW_DESIGN']=$order_change_option;
		}
		if($chk_id==10){
			$ex_mobile=$conn->query("update company set active_reference=$order_change_option where id=$com_id");
			$_SESSION['ACTIVE_REFERENCE']=$order_change_option;
		}
		if($chk_id==11){
			$ex_mobile=$conn->query("update company set apply_selling_price=$order_change_option where id=$com_id");
			$_SESSION['APPLY_SELLING_PRICE']=$order_change_option;
		}
		if($chk_id==12){
			$ex_mobile=$conn->query("update company set sefty_stock=$order_change_option where id=$com_id");
			$_SESSION['SAFETY_STOCK']=$order_change_option;
		}
		if($chk_id==13){
			$ex_mobile=$conn->query("update company set order_sms=$order_change_option where id=$com_id");
			$_SESSION['order_sms']=$order_change_option;
		}
		if($chk_id==14){
			$ex_mobile=$conn->query("update company set item_receive_sms=$order_change_option where id=$com_id");
			$_SESSION['item_receive_sms']=$order_change_option;
		}
		if($chk_id==15){
			$ex_mobile=$conn->query("update company set emp_payment_sms=$order_change_option where id=$com_id");
			$_SESSION['emp_payment_sms']=$order_change_option;
		}
		if($chk_id==8){
			$_SESSION['ITEM_SETTINGS']=$order_change_option;
			echo 1;
			exit();
		}
		if($chk_id!=7){
			if($ex_mobile){
				echo 1;
			}
		}else{
			echo $rows['order_qty'];
		}
	}
	
	if(isset($_REQUEST['saveFegOrd'])){
		$com_id=($_SESSION['COM_ID']);
		$ord_qty=$_REQUEST['ord_qty'];
		$year=$_REQUEST['year'];
		$expense_info=$conn->query("insert into feg_order(com_id,year,order_qty)values($com_id,'$year','$ord_qty')");
		if($expense_info){
			echo 1;
		}
	}
	
	
	if(isset($_REQUEST['saveExpense'])){
		$com_id=($_SESSION['COM_ID']);
		$user_id=($_SESSION['USER_ID']);
		$expense_type=$_REQUEST['expense_type'];
		$ex=explode("#sep#",$expense_type);
		$expense_type=$ex[0];
		$expense_title=$ex[1];
		@$expense_tk=$_REQUEST['expense_tk'];
		@$ex_last_id=$_REQUEST['ex_last_id'];
		@$remarks=$_REQUEST['remarks'];
		$expense_info=$conn->query("insert into  expenses(com_id,expense_type,expense,remarks,insert_by)values($com_id,$expense_type,$expense_tk,'$remarks',$user_id)");
		if($expense_info){
			$tbl_id=$conn->insert_id;
			?>
			<tr>
				<td>
				<button onclick="delExpense('<?php echo $tbl_id; ?>','<?php echo ($ex_last_id+1); ?>')" class="btn btn-danger form-control" id="delExbtn<?php echo ($ex_last_id+1); ?>"><?php echo ($ex_last_id+1); ?></button>
				
				</td>
				<td><?php echo $expense_title; ?></td>
				<td><?php echo @$remarks; ?></td>
				<td style="text-align:right"><?php echo @$expense_tk; ?></td>
			</tr>
			<?php 
		}else{
			echo 2;
		}
	}
	
}
?>
 