<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/png" sizes="16x16" href="img/logo.png">
<title>Login</title>
<link rel="stylesheet" href="file/bootstrap.min.css">
<script src="file/jquery.min.js"></script>
<script src="file/bootstrap.min.js"></script>  
<style type="text/css">
	.login-form {
		width: 340px;
    	margin: 50px auto;
	}
    .login-form form {
    	margin-bottom: 15px;
        background: #f7f7f7;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 30px;
    }
    .login-form h2 {
        margin: 0 0 15px;
    }
    .form-control, .btn {
        min-height: 38px;
        border-radius: 2px;
    }
    .btn {        
        font-size: 15px;
        font-weight: bold;
    }
</style>
</head>
<body>
<?php 
	if(@$_REQUEST['id']==1){
		$page="login_code.php";
	}else{
		$page="activate.php";
	}
?>
<div class="login-form">
    <form action="<?php echo $page; ?>" method="post">
		<?php 
		if(@$_REQUEST['id']==1){
		?>
		<h4 class="text-center">Log in</h4>       
        <div class="form-group">
            <input type="text" name="username" value="" autocomplete="off" class="form-control" placeholder="Username" required="required">
        </div>
        <div class="form-group">
            <input type="password" name="pass" value="" autocomplete="off" class="form-control" placeholder="Password" required="required">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary btn-block">Log in</button>
			
        </div>
        <div class="clearfix">
            <label class="pull-left checkbox-inline" style="text-align:center;color:red"><?php 
				if(@$_REQUEST['chk']==2){
					echo "Wrong user or password";
				}else if(@$_REQUEST['chk']==1){
					echo "Invalid Org.!";
				}
			?></label>
            <!--<a href="#" class="pull-right">Forgot Password?</a>-->
        </div> 
		
		<?php 
		}else if(@$_REQUEST['id']==5){
	
			?>
		<h4 class="text-center">Security Info</h4>       
		<div class="form-group">
			<input type="text" name="scode" autocomplete="off" class="form-control" placeholder="Enter Security Number" required="required">
			<span style="color:blue;font-size: 10px;">Wait...you will get a SMS soon.</span>
		</div>
		
		<div class="form-group">
			<button type="submit" class="btn btn-primary btn-block">Activate</button>
		</div>
		
			<?php 
		}else{
		?>
        
		<?php 
			if(@$_REQUEST['load']==''){
			?>
			<script>
				$(document).ready(function(){
					$.ajax({
						type: 'post',
						url: 'activate.php',
						data: {
							chk_activate:1
						},
						success: function (response) {
							if(response==1){
								window.location.href = "index.php?id=1&load=1";
							}else if(response==3){
								window.location.href = "index.php?id=6&it=1&load=1";
							}else{
								window.location.href = "index.php?id=6&load=1";
							}
						 }
					});
				});
			</script>
			<?php } ?>
			 <h4 class="text-center" id="fhead">Software Activate Info</h4>       
			<div class="form-group">
				<input type="text" name="uname" autocomplete="off" class="form-control" placeholder="Enter Your name" required="required">
			</div>
			<div class="form-group">
				<input type="text" name="umobile" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="11" autocomplete="off" class="form-control" placeholder="Enter Your Mobile" required="required">
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-primary btn-block">Send</button>
			</div>
			 <div class="clearfix">
				<label class="pull-left checkbox-inline" style="text-align:center;color:red"><?php 
					if(@$_REQUEST['it']==1){
						echo "<b>No Internet Connection!</b>";
					}else if(@$_REQUEST['it']==2){
						echo "<b>Please try again!</b>";
					}
				?></label>
				<!--<a href="#" class="pull-right">Forgot Password?</a>-->
			</div> 
			<?php 
		} 
		 ?>	
		 <span style="font-size: 11px;font-weight: bold;">Version: 2.1</span>
    </form>
	<div style="overflow:hidden">
		<div style="float:left">
			<p>Help: <b>01311240085</b></p>
		</div>
		<div style="float:right;text-align:center;line-height: 4px;margin-top: 5px;">
			<p>EasyTech<span style="color:red">24</span></p>
			<p><small>Chondra,Gazipur<small></p>
		</div>
	</div>
	<div style="text-align:center;color:red">
		<p>নিরাপত্তার স্বার্থে Out এ ক্লিক করে Apps থেকে বের হন।</p>
	</div>
	<div style="text-align:center;color:#1f0ac7;">
		<p>Copyright © 2020 EasyTech24 -All Rights Reserved</p>
	</div>
      <div style="text-align:center;color:green">
       <a href="http://bmmsbd.com/">bmmsbd.com</a></p>
	</div> 
</div>

</body>
</html>                                		                            