<?php 
	include'library.php';
	$secret_num=getSecNum();
	$getpass=$_POST['getpass'];
	if(md5($getpass)==$secret_num){
		header("location:setup_details.php");
	}else{
		header("location:setup.php");
	}
?>


