<?php 

ini_set('max_execution_time', 600); //300 seconds = 5
	$order_live_sms=$_SESSION['order_sms']; //1=means order live sms, 0=not sms 
	$from_factory_recive_live_sms=$_SESSION['item_receive_sms']; //1=means order live sms, 0=not sms 
	$wages_sms=$_SESSION['emp_payment_sms']; //1=means order live sms, 0=not sms 
	/*--------------------------------------------------All Functions-----------------------------------------------------------------------*/
	
	function payToSms() // due pay to send sms status=1
	{
		return 1;
	}
	
	function getData($id){
		//return md5(exec('getmac'));
		ob_start();
		system('ipconfig /all');
		$mycom=ob_get_contents();
		ob_clean();
		$findme = "Physical";
		$pmac = strpos($mycom, $findme);
		$mac=substr($mycom,($pmac+36),17);
		if($id==1)
			return md5($mac);
		else
			return $mac;
	}
	
	function getSecNum(){
		return "189ffc4a1884ad1654a2c30101859214";
	}
	
	function db($uname,$umobile,$getData,$chk){
		include'db.php';
		if($chk==1){
			$ok=$conn->query("insert into activate_shop(uname,umobile,maca) values('$uname','$umobile','$getData')");
		}else if($chk==2){
			$ok=$conn->query("insert into device_security(dsecurity) values('$getData')");
		}else if($chk==3){
			$sql=$conn->query("select dsecurity from device_security where dsecurity='$getData' and is_active=1");
			if(mysqli_num_rows($sql)>0){
				$ok=1;
			}else{
				$ok=0;
			}
		}
		return $ok;
	}
	
	function check_internet_connection() 
	{
		$sCheckHost = 'www.google.com';
		return (bool) @fsockopen($sCheckHost, 80, $iErrno, $sErrStr, 5);
	}
	
	function chkMonthlyBill($com_id){
		include'db.php';
		date_default_timezone_set("Asia/Dhaka");
		$day=date("d"); 
		$bill_sql=$conn->query("select bill,sec_id,billing_month,billing_year,is_active,bill_pay_date from billing where com_id=$com_id order by id desc limit 1,1");
			if(mysqli_num_rows($bill_sql)>0){
				$bill_array=mysqli_fetch_array($bill_sql);
				if($bill_array['bill']==0 && $bill_array['sec_id']=="" && $day>5){
					return 0; // bill payment pending
				}else{
					return 1; // bill payment ok
				}
			}else{
				return 1; // newly started
			}
	}
	
	function getMonth($month){
		$dateObj   = DateTime::createFromFormat('!m', $month);
		return $dateObj->format('F');
	}
	
	function getSelectDetail_Sh($select_head,$group_id,$item_type){
		include'db.php';
		$com_id=($_SESSION['COM_ID']);
		$get_details=$conn->query("SELECT mh.title,mh.id FROM `select_detail` mh WHERE mh.group_id=$group_id and mh.is_active=1 and mh.ptype=$item_type and mh.select_type='$select_head' order by mh.steps asc");
		mysqli_close($conn);
		$option="";
		while($rows=mysqli_fetch_array($get_details)){
			$id=$rows['id'];
			$title=$rows['title'];
			$option.="<option value='$id'>$title</option>";
		}
		return $option;
	}
	
	function getUpdateDue($customer_id){
		include'db.php';
		$com_id=($_SESSION['COM_ID']);
		$cus_id_sql=$conn->query("select * from update_due where is_active=1 and com_id=$com_id and cus_id='$customer_id' order by id desc limit 0,1");
		if(mysqli_num_rows($cus_id_sql)>0){
			$rows=mysqli_fetch_array($cus_id_sql);
			$last_due=trim($rows['last_due']);
		}else{
			$last_due=0;
		}
		
		return $last_due;
	}
	
	function dueTblUpdate($customer_id,$paytxt,$status,$remarks,$transaction_type){
		include'db.php';
		$com_id=($_SESSION['COM_ID']);
		$user_id=$_SESSION['USER_ID'];
		$ex=explode("-",$remarks);
		$method_name="";
		if(count($ex)>0){
			@$method_name=$ex[1];
		}
		
		if($status==1){
			$conn->query("insert into transaction(cus_id,com_id,amount,status,remarks,insert_by,transaction_type,method_name) values($customer_id,$com_id,'$paytxt',$status,'$remarks',$user_id,'$transaction_type','$method_name')");
			$conn->query("insert into update_due(cus_id,com_id,last_due) values($customer_id,$com_id,(select ud.last_due-$paytxt from update_due ud where ud.com_id=$com_id and ud.cus_id=$customer_id and ud.is_active=1 order by ud.id desc limit 0,1))");
		}else{
			$conn->query("insert into transaction(cus_id,com_id,amount,status,remarks,insert_by,transaction_type,method_name) values($customer_id,$com_id,'$paytxt',$status,'$remarks',$user_id,'$transaction_type','$method_name')");
			$duetbl=$conn->query("select ud.last_due from update_due ud where ud.com_id=$com_id and ud.cus_id=$customer_id and ud.is_active=1 order by ud.id desc limit 0,1");
			if(mysqli_num_rows($duetbl)>0){
				$row=mysqli_fetch_array($duetbl);
				$paytxt+=$row['last_due'];
			}else{
				$paytxt+=0;
			}
			$conn->query("insert into update_due(cus_id,com_id,last_due) values($customer_id,$com_id,'$paytxt')");
		}
		return 1;
	}
	
	function updateStockTbl($item_id,$purchase_qty,$total_price,$previous_stock_qty,$previous_total_price,$status){
		include'db.php';
		date_default_timezone_set("Asia/Dhaka");
		$last_update_date=date("d-m-Y h:i:s");
		$com_id=($_SESSION['COM_ID']);
		$user_id=$_SESSION['USER_ID'];
		if($status==1){ // Stock in 
		$stock_qty=($previous_stock_qty+$purchase_qty);
		$total_price=round(($total_price+$previous_total_price), 2);
		$avg_price=round(($total_price/$stock_qty), 2);
			$conn->query("update product set last_update_by='$user_id',last_update_date='$last_update_date',stock_qty='$stock_qty',total_price='$total_price',avg_price='$avg_price' where id=$item_id and is_active=2");
		}else if($status==2){ // Stock out
			$stock_qty=($previous_stock_qty-$purchase_qty);
			$total_price=round(($stock_qty*$total_price), 2);
			if($stock_qty==0){
				$avg_price=0;
			}else{
				$avg_price=round(($total_price/$stock_qty), 2);
			}
			$conn->query("update product set stock_qty='$stock_qty',total_price='$total_price',avg_price='$avg_price' where id=$item_id and is_active=2");
			
		}
		return 1;
	}
	
	function getUserWiseSale($user_id,$status){
		include'db.php';
		date_default_timezone_set("Asia/Dhaka");
		$dates=date("Y-m-d");
		$com_id=($_SESSION['COM_ID']);
		$sql=$conn->query("select sum(amount) taka from transaction where insert_by=$user_id and com_id=$com_id and status=$status and is_active=1 and date(insert_date)='$dates'");
		mysqli_close($conn);
		if(mysqli_num_rows($sql)>0){
			$rows=mysqli_fetch_array($sql);
			return $rows['taka'];
		}else{
			return 0;
		}
	}
	
	function getCustomerId($mobile){
		include'db.php';
		$sql=$conn->query("select id from customer ordn where cus_mobile='$mobile'");
		mysqli_close($conn);
		if(mysqli_num_rows($sql)>0){
			$rows=mysqli_fetch_array($sql);
			return $rows['id'];
		}else{
			return "";
		}
	}
	
	function getGoupName($order_tbl_id){
		include'db.php';
		$sql=$conn->query("select ordn.group_name from order_record ordn where ordn.id=$order_tbl_id");
		mysqli_close($conn);
		if(mysqli_num_rows($sql)>0){
			$rows=mysqli_fetch_array($sql);
			return $rows['group_name'];
		}else{
			return "";
		}
	}
	
	function getEmpname($emp_type,$user_id){
		include'db.php';
		$com_id=($_SESSION['COM_ID']);
		$get_details=$conn->query("SELECT mh.user_name title,mh.id FROM `user` mh WHERE mh.com_id=$com_id and mh.is_active=1 and mh.emp_type='$emp_type'");
		mysqli_close($conn);
		$option="";
		while($rows=mysqli_fetch_array($get_details)){
			$id=$rows['id'];
			$selected=($id==$user_id)? 'selected' : '';
			$title=$rows['title'];
			$option.="<option $selected value='$id'>$title</option>";
		}
		return $option;
	}
	
	function getItemPrice($item_id){
		include'db.php';
		$com_id=($_SESSION['COM_ID']);
		$get_cus_price=$conn->query("SELECT mh.cus_price FROM `product` mh WHERE mh.com_id=$com_id and id=$item_id and mh.is_active=1");
		mysqli_close($conn);
		$rows=mysqli_fetch_array($get_cus_price);
		return $rows['cus_price'];
	}
	
	function getOrderNumber($com_id){
		include'db.php';
		if($_SESSION['SVERSION']==0){ //0=courrent copy,1=old copy
			$order_number=$conn->query("select order_number from order_num where com_id=$com_id");
			$row=mysqli_fetch_array($order_number);
			$new_number=$row['order_number'];
			if  ($new_number <= 0) { $new_number ="00001";}
			else if  ($new_number <= 9){ $new_number ="0000".$new_number;}
			else if  ($new_number <= 99){ $new_number ="000".$new_number;}
			else if  ($new_number <= 999){ $new_number ="00".$new_number;}
			else if  ($new_number <= 9999){ $new_number ="0".$new_number;}
			
			return $new_number."#sep#".$row['order_number'];
		}else{
			$order_number=$conn->query("select order_number from order_record where com_id=$com_id and is_active=0 and dsms_id IS NULL order by id desc limit 0,1");
			$row=mysqli_fetch_array($order_number);
			return $row['order_number'];
		}
	}
	
	function getMeasurement($order,$mtype){
		include'db.php';
		$com_id=($_SESSION['COM_ID']);
		if($mtype==1 || $mtype==3 || $mtype==4){
		$order_details=$conn->query("select (select group_id from measurement_head where id=ord.measure_id) group_id,(select steps from measurement_head where id=ord.measure_id) steps,(select title from measurement_head where id=ord.measure_id) product,ord.measure_id,ord.measurement from order_details ord where ord.is_active=0 and ord.com_id=$com_id and ord.mtype=$mtype and ord.order_number='$order'");
		}
		if($mtype==2){
			$order_details=$conn->query("select (select title from measurement_head where id=ord.measure_id) product,
			(select title from select_detail where id=ord.measurement) selected_title,
			ord.measure_id,ord.measurement from order_details ord where ord.is_active=0 and ord.com_id=$com_id and ord.mtype=$mtype and ord.order_number='$order'");
		}
		$measure="";
		$sm="";
		$sm1="";
		$sm2="";
		$sm3="";
		$sm4="";
		$sm5="";
		$sm6="";
		$sm7="";
		$sm8="";
		$op="";
		$ob="(";
		$cb=")";
		$chk1="";
		$chk2="";
		$po="<p style='line-height: 10px;'>";
		$pc="</p>";
		$tr1="<tr>";
		$tr2="</tr>";
		$tbl1="<table>";
		$tbl2="</table>";
		while($row=mysqli_fetch_array($order_details)){
			if($_SESSION['MEASURE_TYPE']==0){ //0=standard
				if($mtype==1){ //Gents
					$product=$row['product'];
					$measurement=$row['measurement'];
					$measure.="<div class='' style='float:left;padding-left:3px;padding-right:3px;margin-right: 5px;!important'>
					<p style='font-size: 10px;text-align: center; line-height: 0px;'>$product</p>
					<p style='border: 1px solid gray;text-align: center;font-weight: bold;padding-left:3px;padding-right:3px'>$measurement</p>
				</div>";
				}
			}
			if($_SESSION['MEASURE_TYPE']==1){ //1=normal
				if($mtype==1){ //Gents
					$measurement_a=explode(".",$row['measurement']);
					if(count($measurement_a)>1){
						$measurement=$measurement_a[0];
						$sup=$measurement_a[1];
						$measurement2="<sup>$sup</sup>";
					}else{
						$measurement=$row['measurement'];
						$measurement2="";
					}
					
					if($row['group_id']==1){ //shirt
						if($row['steps']==1 || $row['steps']==5){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==2){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==6){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==8){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'><span style='border:1px solid gray;padding: 3px;border-radius: 12px;'>".$measurement.$measurement2."</span></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==9){
							$sm2.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==3){
							$sm2.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==7){
							$sm2.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==10){
							$sm3.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==11){
							$sm4.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}else{
							$chk1=1;
						}
						if($row['steps']==14){
							$sm4.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}else{
							$chk2=1;
						}
						if($row['steps']==17){
							$sm8.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'><span style='font-size:12px;'>মাসুল-</span>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==12){
							$sm5.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==15){
							$sm5.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==13){
							$sm6.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==16){
							$sm6.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==4){
							$sm3.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td></td><td></td><td></td><td></td><td></td>";
						}
						//if($chk1==1 || $chk2==1){
							//$sm="<span style='font-size: 20px;'>".$tbl1.$tr1.$sm1.$tr2.$tr1.$sm2.$tr2.$tr1.$sm3.$tr2.$tr1."<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>".$sm8.$tr2.$tr1.$sm5.$tr2.$tr1.$sm6.$tr2.$tbl2."</span>";
						//}else{
						$sm="<span style='font-size: 20px;'>".$tbl1.$tr1.$sm1.$tr2.$tr1.$sm2.$tr2.$tr1.$sm3.$tr2.$tr1.$sm4.$sm8.$tr2.$tr1.$sm5.$tr2.$tr1.$sm6.$tr2.$tbl2."</span>";
						//}
					}
					if($row['group_id']==2){ //pant
						if($row['steps']==1 || $row['steps']==2 || $row['steps']==3){ // || $row['steps']==4
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>-</td>";
						}
						
						if($row['steps']==4){
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>-</td>";
						}
						
						if($row['steps']==6){
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>-</td>";
						}
						if($row['steps']==7){
							$sm3.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>F-</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==8){
							$sm4.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>B-</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==5){
							$sm2.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td>";
						}
						if($row['steps']==9){
							$sm5.=" <td style='font-size: 13px;'><span>বেল্ট সহ ফ্লাই:  </span><b>".$measurement.$measurement2."</b></td>";
						}
						
						$sm="<span style='font-size: 20px;'>".$tbl1.$tr1.$sm1.$tr2.$tr1.$sm2.$tr2.$tr1.$tbl2.$tbl1.$tr1.$sm3.$sm5.$tr2.$tr1.$sm4.$tr2.$tbl2."</span>";
					
					}
					
					if($row['group_id']==3){ //coat
					
						if($row['steps']==6){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==8){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==3){
							$sm2.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==1 || $row['steps']==5){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==2){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==4){
							$sm3.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==10){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'><span style='border:1px solid gray;padding: 3px;border-radius: 15px;'>".$measurement.$measurement2."</span></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==7){
							$sm2.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						
						if($row['steps']==9){
							$sm2.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						
						$sm="<span style='font-size: 20px;'>".$tbl1.$tr1.$sm1.$tr2.$tr1.$sm2.$tr2.$tr1.$sm3.$tr2.$tbl2."</span>";
					}
					
					if($row['group_id']==4){ //Panjabi
					
					if($row['steps']==1 || $row['steps']==5){
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>-</td>";
						}
						if($row['steps']==2){
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>-</td>";
						}
						if($row['steps']==6){
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>-</td>";
						}
						if($row['steps']==8){
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'><span style='border:1px solid gray;padding: 3px;border-radius: 12px;'>".$measurement.$measurement2."</span></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td>";
						}
						if($row['steps']==9){
							$sm2.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td>";
						}
						if($row['steps']==3){
							$sm2.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==7){
							$sm2.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==4){
							$sm3.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td><td></td><td></td><td></td>";
						}
						if($row['steps']==10){
							$sm3.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>";
						}
						if($row['steps']==10){
							$sm4.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'><span style='font-size: 15px;'>ঘের ".$measurement.$measurement2."</span></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>";
						}
						
						$sm="<span style='font-size: 20px;'>".$tbl1.$tr1.$sm1.$tr2.$tr1.$sm2.$tr2.$tr1.$sm3.$tr2.$tr1.$sm4.$tr2.$tbl2."</span>";
					}
				}
			}
			if($mtype==2){
				$product=$row['product'];
				$measurement=$row['selected_title'];
				if($_SESSION['MEASURE_TYPE']==0){
				$measure.="<p style='font-size: 11px;line-height:5px;'>$product -<b>$measurement</b></p>";
				}else{
					$measure.="<p style='font-size: 11px;line-height:5px;'>-<b>$measurement</b></p>";
				}
			}
			
			if($mtype==3){
				$product=$row['product'];
				$measure.="<p style='font-size: 11px;line-height:5px;'>-<b>$product</b></p>";
			}
			if($mtype==4){
				if(@$row['measurement']!=""){
					$measurement=$row['measurement'];
					$measure.="<p style='font-size: 13px;line-height:12px;'>-<b>$measurement</b></p>";
				}
			}
		}
		
		return $sm.$measure;
	}
	
	function getMeasurementDel($order,$mtype){
		include'db.php';
		$com_id=($_SESSION['COM_ID']);
		if($mtype==1 || $mtype==3 || $mtype==4){
		$order_details=$conn->query("select (select group_id from measurement_head where id=ord.measure_id) group_id,(select steps from measurement_head where id=ord.measure_id) steps,(select title from measurement_head where id=ord.measure_id) product,ord.measure_id,ord.measurement from order_details ord where ord.is_active=2 and ord.com_id=$com_id and ord.mtype=$mtype and ord.order_number='$order'");
		}
		if($mtype==2){
			$order_details=$conn->query("select (select title from measurement_head where id=ord.measure_id) product,
			(select title from select_detail where id=ord.measurement) selected_title,
			ord.measure_id,ord.measurement from order_details ord where ord.is_active=2 and ord.com_id=$com_id and ord.mtype=$mtype and ord.order_number='$order'");
		}
		$measure="";
		$sm="";
		$sm1="";
		$sm2="";
		$sm3="";
		$sm4="";
		$sm5="";
		$sm6="";
		$sm7="";
		$sm8="";
		$op="";
		$ob="(";
		$cb=")";
		$chk1="";
		$chk2="";
		$po="<p style='line-height: 10px;'>";
		$pc="</p>";
		$tr1="<tr>";
		$tr2="</tr>";
		$tbl1="<table>";
		$tbl2="</table>";
		while($row=mysqli_fetch_array($order_details)){
			if($_SESSION['MEASURE_TYPE']==0){ //0=standard
				if($mtype==1){ //Gents
					$product=$row['product'];
					$measurement=$row['measurement'];
					$measure.="<div class='' style='float:left;padding-left:3px;padding-right:3px;margin-right: 5px;!important'>
					<p style='font-size: 10px;text-align: center; line-height: 0px;'>$product</p>
					<p style='border: 1px solid gray;text-align: center;font-weight: bold;padding-left:3px;padding-right:3px'>$measurement</p>
				</div>";
				}
			}
			if($_SESSION['MEASURE_TYPE']==1){ //1=normal
				if($mtype==1){ //Gents
					$measurement_a=explode(".",$row['measurement']);
					if(count($measurement_a)>1){
						$measurement=$measurement_a[0];
						$sup=$measurement_a[1];
						$measurement2="<sup>$sup</sup>";
					}else{
						$measurement=$row['measurement'];
						$measurement2="";
					}
					
					if($row['group_id']==1){ //shirt
						if($row['steps']==1 || $row['steps']==5){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==2){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==6){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==8){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'><span style='border:1px solid gray;padding: 3px;border-radius: 12px;'>".$measurement.$measurement2."</span></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==9){
							$sm2.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==3){
							$sm2.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==7){
							$sm2.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==10){
							$sm3.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==11){
							$sm4.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}else{
							$chk1=1;
						}
						if($row['steps']==14){
							$sm4.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}else{
							$chk2=1;
						}
						if($row['steps']==17){
							$sm8.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'><span style='font-size:12px;'>মাসুল-</span>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==12){
							$sm5.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==15){
							$sm5.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==13){
							$sm6.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==16){
							$sm6.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==4){
							$sm3.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td></td><td></td><td></td><td></td><td></td>";
						}
						//if($chk1==1 || $chk2==1){
							//$sm="<span style='font-size: 20px;'>".$tbl1.$tr1.$sm1.$tr2.$tr1.$sm2.$tr2.$tr1.$sm3.$tr2.$tr1."<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>".$sm8.$tr2.$tr1.$sm5.$tr2.$tr1.$sm6.$tr2.$tbl2."</span>";
						//}else{
						$sm="<span style='font-size: 20px;'>".$tbl1.$tr1.$sm1.$tr2.$tr1.$sm2.$tr2.$tr1.$sm3.$tr2.$tr1.$sm4.$sm8.$tr2.$tr1.$sm5.$tr2.$tr1.$sm6.$tr2.$tbl2."</span>";
						//}
					}
					if($row['group_id']==2){ //pant
						if($row['steps']==1 || $row['steps']==2 || $row['steps']==3){ // || $row['steps']==4
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>-</td>";
						}
						
						if($row['steps']==4){
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>-</td>";
						}
						
						if($row['steps']==6){
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>-</td>";
						}
						if($row['steps']==7){
							$sm3.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>F-</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==8){
							$sm4.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>B-</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==5){
							$sm2.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td>";
						}
						if($row['steps']==9){
							$sm5.=" <td style='font-size: 13px;'><span>বেল্ট সহ ফ্লাই:  </span><b>".$measurement.$measurement2."</b></td>";
						}
						
						$sm="<span style='font-size: 20px;'>".$tbl1.$tr1.$sm1.$tr2.$tr1.$sm2.$tr2.$tr1.$tbl2.$tbl1.$tr1.$sm3.$sm5.$tr2.$tr1.$sm4.$tr2.$tbl2."</span>";
					
					}
					
					if($row['group_id']==3){ //coat
						if($row['steps']==6){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==8){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==3){
							$sm2.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==1 || $row['steps']==5){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==2){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==4){
							$sm3.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==10){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'><span style='border:1px solid gray;padding: 3px;border-radius: 15px;'>".$measurement.$measurement2."</span></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==7){
							$sm2.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						
						if($row['steps']==9){
							$sm2.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						
						$sm="<span style='font-size: 20px;'>".$tbl1.$tr1.$sm1.$tr2.$tr1.$sm2.$tr2.$tr1.$sm3.$tr2.$tbl2."</span>";
					}
					
					if($row['group_id']==4){ //Panjabi
					
					if($row['steps']==1 || $row['steps']==5){
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>-</td>";
						}
						if($row['steps']==2){
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>-</td>";
						}
						if($row['steps']==6){
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>-</td>";
						}
						if($row['steps']==8){
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'><span style='border:1px solid gray;padding: 3px;border-radius: 12px;'>".$measurement.$measurement2."</span></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td>";
						}
						if($row['steps']==9){
							$sm2.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td>";
						}
						if($row['steps']==3){
							$sm2.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==7){
							$sm2.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==4){
							$sm3.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td><td></td><td></td><td></td>";
						}
						if($row['steps']==10){
							$sm3.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>";
						}
						if($row['steps']==10){
							$sm4.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'><span style='font-size: 15px;'>ঘের ".$measurement.$measurement2."</span></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>";
						}
						
						$sm="<span style='font-size: 20px;'>".$tbl1.$tr1.$sm1.$tr2.$tr1.$sm2.$tr2.$tr1.$sm3.$tr2.$tr1.$sm4.$tr2.$tbl2."</span>";
					}
				}
			}
			if($mtype==2){
				$product=$row['product'];
				$measurement=$row['selected_title'];
				$measure.="<p style='font-size: 11px;line-height:5px;'>$product -<b>$measurement</b></p>";
			}
			
			if($mtype==3){
				$product=$row['product'];
				$measure.="<p style='font-size: 11px;line-height:5px;'>-<b>$product</b></p>";
			}
			if($mtype==4){
				if(@$row['measurement']!=""){
				$measurement=$row['measurement'];
				$measure.="<p style='font-size: 13px;line-height:12px;'>-<b>$measurement</b></p>";
				}
			}
		}
		
		return $sm.$measure;
	}
	
	function getMeasurement2($order,$mtype){
		include'db.php';
		$com_id=($_SESSION['COM_ID']);
		if($mtype==1 || $mtype==3 || $mtype==4){ // measurement and checkbox
		$order_details=$conn->query("select (select group_id from measurement_head where id=ord.measure_id) group_id,(select steps from measurement_head where id=ord.measure_id) steps,(select title from measurement_head where id=ord.measure_id) product,ord.measure_id,ord.measurement from order_details ord where ord.is_active=1 and ord.com_id=$com_id and ord.mtype=$mtype and ord.order_number='$order'");
		}
		if($mtype==2){ // only selectbox
			$order_details=$conn->query("select (select title from measurement_head where id=ord.measure_id) product,
			(select title from select_detail where id=ord.measurement) selected_title,
			ord.measure_id,ord.measurement from order_details ord where ord.is_active=1 and ord.com_id=$com_id and ord.mtype=$mtype and ord.order_number='$order'");
		}
		$measure="";
		$sm="";
		$sm1="";
		$sm2="";
		$sm3="";
		$sm4="";
		$sm5="";
		$sm6="";
		$sm7="";
		$sm8="";
		$op="";
		$ob="(";
		$cb=")";
		$chk1="";
		$chk2="";
		$po="<p style='line-height: 10px;'>";
		$pc="</p>";
		$tr1="<tr>";
		$tr2="</tr>";
		$tbl1="<table>";
		$tbl2="</table>";
		while($row=mysqli_fetch_array($order_details)){
			if($_SESSION['MEASURE_TYPE']==2 || $_SESSION['MEASURE_TYPE']==0){ //0=Standard
				if($mtype==1){ //Gents
					$product=$row['product'];
					$measurement=$row['measurement'];
					$measure.="<div class='' style='float:left;padding-left:3px;padding-right:3px;margin-right: 5px;!important'>
					<p style='font-size: 10px;text-align: center; line-height: 0px;'>$product</p>
					<p style='border: 1px solid gray;text-align: center;font-weight: bold;padding-left:3px;padding-right:3px'>$measurement</p>
				</div>";
				}
			}
			if($_SESSION['MEASURE_TYPE']==1){ //1=normal
				if($mtype==1){ //Gents
					$measurement_a=explode(".",$row['measurement']);
					if(count($measurement_a)>1){
						$measurement=$measurement_a[0];
						$sup=$measurement_a[1];
						$measurement2="<sup>$sup</sup>";
					}else{
						$measurement=$row['measurement'];
						$measurement2="";
					}
					
					if($row['group_id']==1){ //shirt
						if($row['steps']==1 || $row['steps']==5){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==2){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==6){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==8){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'><span style='border:1px solid gray;padding: 3px;border-radius: 12px;'>".$measurement.$measurement2."</span></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==9){
							$sm2.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==3){
							$sm2.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==7){
							$sm2.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==10){
							$sm3.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==11){
							$sm4.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}else{
							$chk1=1;
						}
						if($row['steps']==14){
							$sm4.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}else{
							$chk2=1;
						}
						if($row['steps']==17){
							$sm8.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'><span style='font-size:12px;'>মাসুল-</span>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==12){
							$sm5.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==15){
							$sm5.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==13){
							$sm6.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==16){
							$sm6.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==4){
							$sm3.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td></td><td></td><td></td><td></td><td></td>";
						}
						//if($chk1==1 || $chk2==1){
							//$sm="<span style='font-size: 20px;'>".$tbl1.$tr1.$sm1.$tr2.$tr1.$sm2.$tr2.$tr1.$sm3.$tr2.$tr1."<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>".$sm8.$tr2.$tr1.$sm5.$tr2.$tr1.$sm6.$tr2.$tbl2."</span>";
						//}else{
						$sm="<span style='font-size: 20px;'>".$tbl1.$tr1.$sm1.$tr2.$tr1.$sm2.$tr2.$tr1.$sm3.$tr2.$tr1.$sm4.$sm8.$tr2.$tr1.$sm5.$tr2.$tr1.$sm6.$tr2.$tbl2."</span>";
						//}
					}
					if($row['group_id']==2){ //pant
						if($row['steps']==1 || $row['steps']==2 || $row['steps']==3){ // || $row['steps']==4
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>-</td>";
						}
						
						if($row['steps']==4){
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>-</td>";
						}
						
						if($row['steps']==6){
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>-</td>";
						}
						if($row['steps']==7){
							$sm3.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>F-</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==8){
							$sm4.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>B-</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==5){
							$sm2.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td>";
						}
						if($row['steps']==9){
							$sm5.=" <td style='font-size: 13px;'><span>বেল্ট সহ ফ্লাই:  </span><b>".$measurement.$measurement2."</b></td>";
						}
						
						$sm="<span style='font-size: 20px;'>".$tbl1.$tr1.$sm1.$tr2.$tr1.$sm2.$tr2.$tr1.$tbl2.$tbl1.$tr1.$sm3.$sm5.$tr2.$tr1.$sm4.$tr2.$tbl2."</span>";
					
					}
					
					if($row['group_id']==3){ //coat
					
						if($row['steps']==6){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==8){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==3){
							$sm2.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==1 || $row['steps']==5){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==2){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>-</td>";
						}
						if($row['steps']==4){
							$sm3.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==10){
							$sm1.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'><span style='border:1px solid gray;padding: 3px;border-radius: 15px;'>".$measurement.$measurement2."</span></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						if($row['steps']==7){
							$sm2.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						
						if($row['steps']==9){
							$sm2.="<td style='padding-left: 15px;padding-right: 15px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 15px;padding-right: 15px;text-align: center;'></td>";
						}
						
						$sm="<span style='font-size: 20px;'>".$tbl1.$tr1.$sm1.$tr2.$tr1.$sm2.$tr2.$tr1.$sm3.$tr2.$tbl2."</span>";
					}
					
					if($row['group_id']==4){ //Panjabi
					
					if($row['steps']==1 || $row['steps']==5){
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>-</td>";
						}
						if($row['steps']==2){
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>-</td>";
						}
						if($row['steps']==6){
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>-</td>";
						}
						if($row['steps']==8){
							$sm1.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'><span style='border:1px solid gray;padding: 3px;border-radius: 12px;'>".$measurement.$measurement2."</span></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td>";
						}
						if($row['steps']==9){
							$sm2.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;;border-bottom:1px solid gray'>".$measurement.$measurement2."</td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td>";
						}
						if($row['steps']==3){
							$sm2.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;border-bottom:1px solid gray'>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==7){
							$sm2.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td>";
						}
						if($row['steps']==4){
							$sm3.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td><td></td><td></td><td></td>";
						}
						if($row['steps']==10){
							$sm3.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'>".$measurement.$measurement2."</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>";
						}
						if($row['steps']==10){
							$sm4.="<td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'></td><td style='padding-left: 10px;padding-right: 10px;text-align: center;'><span style='font-size: 15px;'>ঘের ".$measurement.$measurement2."</span></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>";
						}
						
						$sm="<span style='font-size: 20px;'>".$tbl1.$tr1.$sm1.$tr2.$tr1.$sm2.$tr2.$tr1.$sm3.$tr2.$tr1.$sm4.$tr2.$tbl2."</span>";
					}
				}
			}
			if($mtype==2){
				$product=$row['product'];
				$measurement=$row['selected_title'];
				if($_SESSION['MEASURE_TYPE']==0){
					$measure.="<p style='font-size: 11px;line-height:5px;'>$product -<b>$measurement</b></p>";
				}else{
					//$measure.="<p style='font-size: 11px;line-height:5px;'>-<b>$measurement=</b></p>";
					$measure.="<span style='font-size: 11px;line-height:5px;'>-<b>$measurement</b></span>&nbsp;&nbsp;";
				}
			}
			
			if($mtype==3){
				$product=$row['product'];
				$measure.="<span style='font-size: 11px;line-height:5px;'>-<b>$product</b></span>&nbsp;&nbsp;";
			}
			if($mtype==4){
				if(@$row['measurement']!=""){
				$measurement=$row['measurement'];
				$measure.="<span style='font-size: 13px;line-height:12px;'>-<b>$measurement</b></span>&nbsp;&nbsp;";
				}
			}
		
		}
		
		return $sm.$measure;
	}
	
	function englishToBangla($number){
		$val="";
		for($i=0;$i<strlen($number);$i++){
			$val.=convertingTo($number[$i]);
		}
		return $val;
	}
	
	function convertingTo($number){
		if($number==0){
			$val="০";
		}
		if($number==1){
			$val="১";
		}
		if($number==2){
			$val="২";
		}
		if($number==3){
			$val="৩";
		}
		if($number==4){
			$val="৪";
		}
		if($number==5){
			$val="৫";
		}
		if($number==6){
			$val="৬";
		}
		if($number==7){
			$val="৭";
		}
		if($number==8){
			$val="৮";
		}
		if($number==9){
			$val="৯";
		}
		if($number=="."){
			$val=".";
		}
		if($number=="-"){
			$val="-";
		}
		return @$val;
	}
	
	class Converter 
		{
			public static $bn = ["১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "০",".","-","+",":","/","শুক্রবার","শনিবার","রবিবার","সোমবার","মঙ্গলবার","বুধবার","বৃহস্পতিবার","শুক্রবার","শনিবার","রবিবার","সোমবার","মঙ্গলবার","বুধবার","বৃহস্পতিবার"];
			public static $en = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0",".","-","+",":","/","Friday","Saturday","Sunday","Monday","Tuesday","Wednesday","Thursday","Fri","Sat","Sun","Mon","Tue","Wed","Thu"];

			public static function bn2en($number)
			{
				return str_replace(self::$bn, self::$en, $number);
			}

			public static function en2bn($number)
			{
				return str_replace(self::$en, self::$bn, $number);
			}
		}
	
	function getCustomerRecept($tag,$date1,$cus_order_date,$get_mobile,$total_tk,$advance_tk,$cus_name,$all_itemqtya,$all_itema,$discount){
		$cus_ord="";
		$com_name=$_SESSION['COM'];
		$address=$_SESSION['COM_ADDRESS'];
		$total_tk1=intval($total_tk)-((intval($total_tk)*intval($discount))/100);
		@$balance=intval($total_tk1)-intval($advance_tk);
		if(isset($all_itemqtya)){
			$ex=explode("#sep#",$all_itemqtya);
			$ex2=explode("#sep#",$all_itema);
			$itemdes="";
			
		for($i=0;$i<count($ex);$i++){
			$itemdes.=$ex2[$i]."(".$ex[$i]."),";
		}
		@$item_details=substr($itemdes,0,-1);
			if(strlen($item_details)<46){
				@$idescription=$item_details;
			}else{
				@$idescription=substr($item_details,0,-(strlen($item_details)-45));
			}
		}else{
			@$idescription="";
		}
		//<span style='font-size: 16px;font-weight: bold; padding-left:250px;'>Order Copy</span>
		if($_SESSION['MEASURE_TYPE']==0){
		$cus_ord="<div id='print_area' style='overflow:hidden;margin-top:5px;margin-bottom: 6px;width:590px;height:210px;display: block; page-break-before: always;'>
							<span style='font-size:13px;overflow:hidden;float:left;width:253px'><b>Name: </b>$cus_name</span><span style='font-size: 16px;font-weight: bold;'>Order Copy</span>
						<div style=''>	
							<div style='float: left;border: 1px solid gray;height:167px; margin-right:5px;width:50px;'>
								<p style=' display:block;-webkit-transform: rotate(-90deg); -moz-transform: rotate(-90deg);margin-top:65px;'>Sample</p>
							</div>
							<div style='float:left;margin-right:15px;width:230px'>
								<table border='1' style='height:167px' width='100%'>
									<tr style='height: 32px;'>
										<td style='padding-left:5px;width: 110px;'>Total Taka</td><td style='padding-right:5px;text-align:right'><b>$total_tk/=</b></td>
									</tr>
									<tr style='height: 32px;'>
										<td style='padding-left:5px'>Discount(%)</td><td style='padding-right:5px;text-align:right'><b>$discount/=</b></td>
									</tr>
									<tr style='height: 32px;'>
										<td style='padding-left:5px'>Advance Taka</td><td style='padding-right:5px;text-align:right'><b>$advance_tk/=</b></td>
									</tr>
									<tr style='height: 32px;'>
										<td style='padding-left:5px'>Balance Taka</td><td style='padding-right:5px;text-align:right'><b>$balance/=</b></td>
									</tr>
								</table>
							</div>
							<div style='float: left;width:290px'>
								<table border='1' style='height:167px' width='100%'>
									<tr style='height: 32px;'>
										<td style='padding-left:5px;width: 110px;'>Serial No.</td><td style='padding-left:5px'><b>$tag</b></td>
									</tr>
									<tr style='height: 32px;'>
										<td style='padding-left:5px'>Order Date</td><td style='padding-left:5px'><b>$cus_order_date</b></td>
									</tr>
									<tr style='height: 32px;'>
										<td style='padding-left:5px'>Delivery Date</td><td style='padding-left:5px'><b>$date1</b></td>
									</tr>
									<tr style='height: 32px;'>
										<td style='padding-left:5px'>Description</td><td style='padding-left:5px;font-size: 10px;'><b>$idescription</b></td>
									</tr>
								</table>
								<span style='float: right;font-style: italic;font-size: 11px;padding-right: 5px;'>EasyTech24</span>
							</div>
							
						</div></div>";
		}else{
			$cus_ord="<div id='print_area' style='overflow:hidden;margin-left:70px; margin-bottom: 6px;width:590px;height:210px;display: block; page-break-before: always;'>
							<span style='font-size: 16px;font-weight: bold; padding-left:250px;'>Order Copy</span>
						<div style=''>	
							<div style='float: left;border: 1px solid gray;height:167px; margin-right:5px;width:50px;'>
								<p style=' display:block;-webkit-transform: rotate(-90deg); -moz-transform: rotate(-90deg);margin-top:65px;'>Sample</p>
							</div>
							<div style='float:left;margin-right:15px;width:220px'>
								<table border='1' style='height:167px' width='100%'>
									<tr style='height: 32px;'>
										<td style='padding-left:5px;width: 110px;'>Total Taka</td><td style='padding-right:5px;text-align:right'><b>$total_tk/=</b></td>
									</tr>
									<tr style='height: 32px;'>
										<td style='padding-left:5px'>Discount(%)</td><td style='padding-right:5px;text-align:right'><b>$discount/=</b></td>
									</tr>
									<tr style='height: 32px;'>
										<td style='padding-left:5px'>Advance Taka</td><td style='padding-right:5px;text-align:right'><b>$advance_tk/=</b></td>
									</tr>
									<tr style='height: 32px;'>
										<td style='padding-left:5px'>Balance Taka</td><td style='padding-right:5px;text-align:right'><b>$balance/=</b></td>
									</tr>
								</table>
							</div>
							<div style='float: left;width:285px'>
								<table border='1' style='height:167px' width='100%'>
									<tr style='height: 32px;'>
										<td style='padding-left:5px;width: 110px;'>Serial No.</td><td style='padding-left:5px'><b>$tag</b></td>
									</tr>
									<tr style='height: 32px;'>
										<td style='padding-left:5px'>Order Date</td><td style='padding-left:5px'><b>$cus_order_date</b></td>
									</tr>
									<tr style='height: 32px;'>
										<td style='padding-left:5px'>Delivery Date</td><td style='padding-left:5px'><b>$date1</b></td>
									</tr>
									<tr style='height: 32px;'>
										<td style='padding-left:5px'>Description</td><td style='padding-left:5px;font-size: 10px;'><b>$idescription</b></td>
									</tr>
								</table>
								<span style='float: right;font-style: italic;font-size: 11px;padding-right: 5px;margin-right: -4px;'>EasyTech24</span>
							</div>
							
						</div></div>";
		}
		return $cus_ord;
	}
	
	function getCustomerRecept2($param){
	include'db.php';
		$com_name=$_SESSION['COM'];
		$address=$_SESSION['COM_ADDRESS'];
		$com_id=$_SESSION['COM_ID'];
		$order_details=$conn->query("SELECT ds.id,ds.phy_ord_num,ds.cus_name,date(ds.insert_date) cus_order_date,ds.discount,
		ds.dv_date as date1,ds.amount,(select user_name from user where id=ds.insert_by) insert_by,
		(select sum(amount) advance_tk from accounting where dsms_id=ds.id and is_active=1) advance_tk,
		(select group_concat((select product_name from product where id=ord.item_id) separator '_') product_name from `order_record` ord where ord.dsms_id=ds.id) all_itema,
		(select group_concat(ord.item_qty separator '_') item_qty from `order_record` ord where ord.dsms_id=ds.id) all_itemqtya
		FROM dsms ds WHERE  ds.com_id=$com_id and (date(ds.insert_date)='$param' or ds.cus_mobile='$param' or ds.phy_ord_num='$param') and ds.is_active=1");
		$cus_ord="";
		if(mysqli_num_rows($order_details)>0){
		while($row=mysqli_fetch_array($order_details)){
				$total_tk=$row['amount'];
				$advance_tk=$row['advance_tk'];
				$all_itemqtya=$row['all_itemqtya'];
				$all_itema=$row['all_itema'];
				$phy_ord_num=$row['phy_ord_num'];
				$cus_name="<b>Name:</b>".$row['cus_name'];
				$cus_order_date=$row['cus_order_date'];
				$date1=$row['date1'];
				$discount=$row['discount'];
				$insert_by=$row['insert_by'];
				/*<span style='float: left;font-style: italic;font-size: 11px;'>Received By:$insert_by</span>*/
			$total_tk1=intval($total_tk)-((intval($total_tk)*intval($discount))/100);
			@$balance=intval($total_tk1)-intval($advance_tk);
			if(isset($all_itemqtya)){
				$ex=explode("_",$all_itemqtya);
				$ex2=explode("_",$all_itema);
				$itemdes="";
				
			for($i=0;$i<count($ex);$i++){
				$itemdes.=$ex2[$i]."(".$ex[$i]."),";
				}
			@$item_details=substr($itemdes,0,-1);
				if(strlen($item_details)<36){
					@$idescription=$item_details;
				}else{
					//$exx=explode(",",$idescription);
					
					@$idescription=substr($item_details,0,-(strlen($item_details)-35))."..";
				}
			}else{
				@$idescription="";
			}
			
				if($_SESSION['MEASURE_TYPE']==0){
				//290
				$cus_ord.="<div id='print_area' style='overflow:hidden;margin-top:5px;margin-bottom: 6px; width:590px;height:210px;display: block; page-break-before: always;'>
							<span style='font-size: 13px;overflow: hidden;float: left;width: 253px;'>$cus_name</span><span style='font-size: 16px;font-weight: bold; '>Order Copy</span>
							<div style=''>	
								<div style='float: left;border: 1px solid gray;height:167px; margin-right:5px;width:50px;'>
									<p style=' display:block;-webkit-transform: rotate(-90deg); -moz-transform: rotate(-90deg);margin-top:65px;'>Sample</p>
								</div>
								<div style='float:left;margin-right:15px;width:230px'>
									<table border='1' style='height:167px' width='100%'>
										<tr style='height: 32px;'>
											<td style='padding-left:5px;width: 110px;'>Total Taka</td><td style='padding-right:5px;text-align:right'><b>$total_tk/=</b></td>
										</tr>
										<tr style='height: 32px;'>
											<td style='padding-left:5px'>Discount(%)</td><td style='padding-right:5px;text-align:right'><b>$discount/=</b></td>
										</tr>
										<tr style='height: 32px;'>
											<td style='padding-left:5px'>Advance Taka</td><td style='padding-right:5px;text-align:right'><b>$advance_tk/=</b></td>
										</tr>
										<tr style='height: 32px;'>
											<td style='padding-left:5px'>Balance Taka</td><td style='padding-right:5px;text-align:right'><b>$balance/=</b></td>
										</tr>
									</table>
								</div>
								<div style='float: left;width:290px'>
									<table border='1' style='height:167px' width='100%'>
										<tr style='height: 32px;'>
											<td style='padding-left:5px;width: 110px;'>Serial No.</td><td style='padding-left:5px'><b>$phy_ord_num</b></td>
										</tr>
										<tr style='height: 32px;'>
											<td style='padding-left:5px'>Order Date</td><td style='padding-left:5px'><b>$cus_order_date</b></td>
										</tr>
										<tr style='height: 32px;'>
											<td style='padding-left:5px'>Delivery Date</td><td style='padding-left:5px'><b>$date1</b></td>
										</tr>
										<tr style='height: 32px;'>
											<td style='padding-left:5px'>Description</td><td style='padding-left:5px;font-size: 10px;'><b>$idescription</b></td>
										</tr>
									</table>
								</div>
								<span style='float: right;font-style: italic;font-size: 11px;'>Atompac Limited</span>
								
							</div></div>";
				}else{
					$cus_ord.="<div id='print_area' style='overflow:hidden;margin-bottom: 6px;margin-left:70px; width:590px;height:210px;display: block; page-break-before: always;'>
							<span style='font-size: 16px;font-weight: bold; padding-left:250px;'>Order Copy</span>
							<div style=''>	
								<div style='float: left;border: 1px solid gray;height:167px; margin-right:5px;width:50px;'>
									<p style=' display:block;-webkit-transform: rotate(-90deg); -moz-transform: rotate(-90deg);margin-top:65px;'>Sample</p>
								</div>
								<div style='float:left;margin-right:15px;width:220px'>
									<table border='1' style='height:167px' width='100%'>
										<tr style='height: 32px;'>
											<td style='padding-left:5px;width: 110px;'>Total Taka</td><td style='padding-right:5px;text-align:right'><b>$total_tk/=</b></td>
										</tr>
										<tr style='height: 32px;'>
											<td style='padding-left:5px'>Discount(%)</td><td style='padding-right:5px;text-align:right'><b>$discount/=</b></td>
										</tr>
										<tr style='height: 32px;'>
											<td style='padding-left:5px'>Advance Taka</td><td style='padding-right:5px;text-align:right'><b>$advance_tk/=</b></td>
										</tr>
										<tr style='height: 32px;'>
											<td style='padding-left:5px'>Balance Taka</td><td style='padding-right:5px;text-align:right'><b>$balance/=</b></td>
										</tr>
									</table>
								</div>
								<div style='float: left;width:285px'>
									<table border='1' style='height:167px' width='100%'>
										<tr style='height: 32px;'>
											<td style='padding-left:5px;width: 110px;'>Serial No.</td><td style='padding-left:5px'><b>$phy_ord_num</b></td>
										</tr>
										<tr style='height: 32px;'>
											<td style='padding-left:5px'>Order Date</td><td style='padding-left:5px'><b>$cus_order_date</b></td>
										</tr>
										<tr style='height: 32px;'>
											<td style='padding-left:5px'>Delivery Date</td><td style='padding-left:5px'><b>$date1</b></td>
										</tr>
										<tr style='height: 32px;'>
											<td style='padding-left:5px'>Description</td><td style='padding-left:5px;font-size: 10px;'><b>$idescription</b></td>
										</tr>
									</table>
								</div>
								<span style='float: right;font-style: italic;font-size: 11px;margin-right: 16px;'>Atompac Limited</span>
							</div></div>";
				}
			}
			return $cus_ord;
		}else{
			return 2;
		}
			
	}
	
	function getCustomerRecept3(){
			@$cus_ord="<div id='print_area' style='overflow:hidden;margin-top:5px;margin-bottom: 6px; width:590px;height:210px;display: block; page-break-before: always;'>
						<span style='font-size: 16px;font-weight: bold; padding-left:250px;'>Order Copy</span>
						<div style=''>	
							<div style='float: left;border: 1px solid gray;height:167px; margin-right:5px;width:50px;'>
								<p style=' display:block;-webkit-transform: rotate(-90deg); -moz-transform: rotate(-90deg);margin-top:65px;'>Sample</p>
							</div>
							<div style='float:left;margin-right:15px;width:230px'>
								<table border='1' style='height:167px' width='100%'>
									<tr style='height: 32px;'>
										<td style='padding-left:5px;width: 110px;'>Total Taka</td><td style='padding-right:5px;text-align:right'><b></b></td>
									</tr>
									<tr style='height: 32px;'>
										<td style='padding-left:5px'>Discount(%)</td><td style='padding-right:5px;text-align:right'><b></b></td>
									</tr>
									<tr style='height: 32px;'>
										<td style='padding-left:5px'>Advance Taka</td><td style='padding-right:5px;text-align:right'><b></b></td>
									</tr>
									<tr style='height: 32px;'>
										<td style='padding-left:5px'>Balance Taka</td><td style='padding-right:5px;text-align:right'><b></b></td>
									</tr>
								</table>
							</div>
							<div style='float: left;width:290px'>
								<table border='1' style='height:167px' width='100%'>
									<tr style='height: 32px;'>
										<td style='padding-left:5px;width: 110px;'>Serial No.</td><td style='padding-left:5px'><b></b></td>
									</tr>
									<tr style='height: 32px;'>
										<td style='padding-left:5px'>Order Date</td><td style='padding-left:5px'><b></b></td>
									</tr>
									<tr style='height: 32px;'>
										<td style='padding-left:5px'>Delivery Date</td><td style='padding-left:5px'><b></b></td>
									</tr>
									<tr style='height: 32px;'>
										<td style='padding-left:5px'>Description</td><td style='padding-left:5px;font-size: 10px;'><b></b></td>
									</tr>
								</table>
							</div>
							<span style='float: right;font-style: italic;font-size: 11px;'>EasyTech24</span>
						</div></div>";
		return $cus_ord;
	}
	
		function printOnlyFabricsMoneyReceipt($sl_no,$cus_name,$mobile,$fab_total,$discount,$discount_tk,$user_id,$payment_type,$others_tk,$advance_tk,$itema,$ex_all_fitemqtya,$ex_all_fitempricea,$total_due){
		date_default_timezone_set("Asia/Dhaka");
		$dates=date("Y-m-d h:i:s");
		$advance_tk=sprintf('%0.2f', $advance_tk);
		$total_due=sprintf('%0.2f', $total_due);
		$idetails="";$sl=0;$tprice=0;
		for($di=0;$di<count($itema); $di++){
			$item_name=$itema[$di];
			$item_qtys=$ex_all_fitemqtya[$di];
			$item_price=$ex_all_fitempricea[$di];
			
			if($discount_tk>0){
				$item_price=(($item_price*100)/(100-$discount));
			}
			$tprice=($item_qtys*$item_price);
			$sl=$di+1;
			$idetails.="<div style='float:left;width: 7%;'>	
				$sl.
			</div>
			<div style='float:left;width: 53%;;text-align:left'>	
				$item_name
			</div>
			<div style='float:left;width: 10%;'>	
				$item_qtys
			</div>
			<div style='float:left;width: 15%;text-align: right;'>	
				$item_price
			</div>
			<div style='float:left;width: 15%;text-align: right;padding-right: 5px;'>	
				$tprice
			</div>";
		}
		$sl=$sl+1;
		if($others_tk>0){
			$otaka=$others_tk;
			$fab_total+=$otaka;
			$otaka_title="Others ";
			$idetails.="<div style='float:left;width: 7%;'>	
				$sl.
			</div>
			<div style='float:left;width: 53%;text-align:left'>	
				Others
			</div>
			<div style='float:left;width: 10%;'>	
				---
			</div>
			<div style='float:left;width: 15%;text-align: right;'>	
				$otaka
			</div>
			<div style='float:left;width: 15%;text-align: right;padding-right: 5px;'>	
				$otaka
			</div>";
		}
		if($discount_tk>0){
			$fab_totald=($fab_total-$discount_tk);
			$remaining=($fab_totald-$advance_tk);
		}else{
			$remaining=($fab_total-$advance_tk);
		}
		$remaining=sprintf('%0.2f', $remaining);
		$dis="";
		if($discount>0){
			$dis="<div style='overflow:hidden;font-size: 10px;
				font-weight: bold;text-align:center;
				padding-top: 3px;
				padding-bottom: 3px;
				'>	
				<div style='float: left;text-align: right;width: 204px;'>	
					Discount($discount%): 
				</div>
				<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 5px;'>	
					$discount_tk
				</div>
			
			</div>";
		}
		$com=$_SESSION['COM'];
		@$address=$_SESSION['COM_ADDRESS'];
		@$email=$_SESSION['EMAIL'];
		@$com_mobile=$_SESSION['COM_MOBILE'];
	if($_SESSION['FAB_MONEY_RECEIPT_TYPE']==0){ //0=pos receipt 
	
		$receipt="<div id='print_area' style='overflow:hidden;margin-top:5px;margin-bottom: 6px; width:290px;display: block; page-break-before: always;'>
	<div style='overflow:hidden;padding-top:25px;'>	
		<div style='line-height: 5px;padding-top:15px;text-align:center;'>	
			<p style='font-size: 15px;font-weight: bold;padding-top:0px;'>$com</p>
			<p style='font-size: 12px; font-weight: bold;padding-top: 0px;'>$address</p>
			<p style='font-size: 11px; font-weight: bold;padding-top: 0px;'>$email</p>
			<p style='font-size: 11px; font-weight: bold;padding-top: 0px;'>$com_mobile</p>
		</div>
		
	</div>
	
	<div style='overflow:hidden;margin-top: 20px;'>	
		<div style='float:left; padding-left: 6px;'>	
			<p style='font-size: 10px;'><b>Order No:</b>$sl_no</span>
		</div>
		<div style='float:right; padding-right: 6px;'>	
			<p style='font-size: 10px;'>$dates</p>
		</div>
	</div>
	<div style='overflow:hidden;margin-top: 0px;'>	
		<div style='float:left; padding-left: 6px;width: 50%;'>	
			<p style='font-size: 10px;'><b>Customer:</b>$cus_name</span>
		</div>
		<div style='float:left; padding-right: 6px;width:50%;text-align:right;'>	
			<p style='font-size: 10px;'>$mobile</p>
		</div>
	</div>
	<div style='overflow:hidden;margin-top: -3px;margin-left: 6px;
			margin-right: 6px;'>	
	<div style='width: 100%;margin-bottom: -6px;'>	
			-----------------------------------------------------------
	</div>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;margin-bottom: -7px;'>	
			<div style='float:left;width: 7%;'>	
				Sl
			</div>
			<div style='float:left;width: 53%;text-align:left'>	
				Description
			</div>
			<div style='float:left;width: 10%;'>	
				Qty
			</div>
			<div style='float:left;width: 15%;text-align: right;'>	
				Rate
			</div>
			<div style='float:left;width: 15%;text-align: right;padding-right: 5px;'>	
				Taka
			</div>
		</div>
	<div style='width: 100%;margin-bottom: -6px;'>	
			-----------------------------------------------------------
	</div>

	<div style=''>
		<div style='overflow:hidden;font-size: 9px;
			font-weight: bold;text-align:center;
			padding-bottom: 15px;'>	
			$idetails
		</div>
	</div>
	<div style='width: 100%;margin-bottom: -6px;'>	
			-----------------------------------------------------------
	</div>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;
			
			padding-bottom: 3px;
			'>	
			<div style='float: left;text-align: right;width: 204px;'>	
				Total: 
			</div>
			<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 5px;'>	
				$fab_total
			</div>
			
		</div>
		$dis
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;
			padding-top: 3px;
			padding-bottom: 3px;'>	
			<div style='float: left;text-align: right;width: 204px;'>	
				Receive: 
			</div>
			<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 5px;'>	
				$advance_tk
			</div>
			
		</div>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;
			padding-top: 3px;
			padding-bottom: 3px;'>	
			<div style='float: left;text-align: right;width: 204px;'>	
				Present Due: 
			</div>
			<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 5px;'>	
				$remaining
			</div>
		</div>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;
			padding-top: 3px;
			padding-bottom: 3px;'>	
			<div style='float: left;text-align: right;width: 204px;'>	
				Total Due: 
			</div>
			<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 5px;'>	
				$total_due
			</div>
		</div>
	<div style='width: 100%;margin-bottom: -6px;'>	
			-----------------------------------------------------------
	</div>
	
	</div>
	
	<div style='width: 100%;text-align: center;padding-top: 65px;padding-bottom: 50px;'>	
			*** Thanks for your purchase ***
	</div>
	
</div>";
		
		
	}else{ //1= normal receipt 
		$receipt="<div id='print_area' style='overflow:hidden;margin-top:5px;margin-bottom: 6px;border: 1px solid gray; width:580px;height:600px;display: block; page-break-before: always;'>
	<div style='overflow:hidden;padding-top: 10px;'>	
		<div style='float:left; line-height: 3px;padding-left: 228px;'>	
			<p style='font-size: 10px;'>বিসমিল্লাহির রাহমানির রাহিম</p>
			<p style='font-size: 12px;font-weight: bold;padding-left: 28px;padding-top:0px;'>ক্যাশ মেমো</p>
			<p style='font-size: 14px; font-weight: bold;padding-left:6px;padding-top: 0px;'>MM Company Ltd.</p>
		</div>
		<div style='float:right;text-align: right;padding-right: 6px;line-height: 3px;'>	
			<p style='font-size: 10px;'>মুজিবর রহমান</p>
			<p style='font-size: 10px;'>প্রোপ্রাইটর</p>
			<p style='font-size: 10px;'>মোবা: ০১৭১৮৬৩৫৫৩৬</p>
		</div>
	</div>
	<div style='overflow:hidden; margin-top: -4px;'>	
		<div style='text-align:center'>	
			<p style='font-size: 10px;'>শিববাড়ি, জয়দেবপুর,গাজীপুর</span>
		</div>
	</div>
	<div style='overflow:hidden;margin-top: -3px;'>	
		<div style='float:left; padding-left: 6px;'>	
			<p style='font-size: 10px;'>ক্রমিক নং: $sl_no</span>
		</div>
		<div style='float:right; padding-right: 6px;'>	
			<p style='font-size: 10px;'>তারিখ: $dates</p>
		</div>
	</div>
	<div style='overflow:hidden;margin-top: -7px;'>	
		<div style='float:left; padding-left: 6px;width: 30%;'>	
			<p style='font-size: 10px;'>নাম: $cus_name</span>
		</div>
		<div style='float:left; padding-right: 6px;width: 40%;'>	
			<p style='font-size: 10px;'>ঠিকানা:............................</p>
		</div>
		<div style='float:left; padding-right: 6px;width: 30%;'>	
			<p style='font-size: 10px;'>মোবা:  $mobile</p>
		</div>
	</div>
	<div style='overflow:hidden;margin-top: -3px;margin-left: 6px;
			margin-right: 6px;border: 1px solid gray;'>	
	
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;background: lightgray;
			padding-top: 3px;
			padding-bottom: 3px;
			'>	
			<div style='float:left;width: 7%;'>	
				নং
			</div>
			<div style='float:left;width: 53%;'>	
				বিবরণ
			</div>
			<div style='float:left;width: 10%;'>	
				পরিমান
			</div>
			<div style='float:left;width: 15%;text-align: right;'>	
				দর
			</div>
			<div style='float:left;width: 15%;text-align: right;padding-right: 5px;'>	
				টাকা
			</div>
		</div>
	<div style='height:327px'>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;
			padding-top: 3px;
			padding-bottom: 3px;'>	
			$idetails
		</div>
	
		
	</div>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;
			
			padding-bottom: 3px;
			'>	
			<div style='float: left;width: 490px;text-align: right;'>	
				মোট: 
			</div>
			<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 5px;'>	
				$fab_total
			</div>
			
		</div>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;
			padding-top: 3px;
			padding-bottom: 3px;
			'>	
			<div style='float: left;width: 490px;text-align: right;'>	
				ছাড় ($discount%): 
			</div>
			<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 5px;'>	
				$discount_tk
			</div>
			
		</div>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;
			padding-top: 3px;
			padding-bottom: 3px;
			'>	
			<div style='float: left;width: 490px;text-align: right;'>	
				জমা: 
			</div>
			<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 5px;'>	
				$advance_tk
			</div>
			
		</div>
		<div style='overflow:hidden;font-size: 10px;
			font-weight: bold;text-align:center;
			padding-top: 3px;
			padding-bottom: 3px;
			'>	
			<div style='float: left;width: 490px;text-align: right;'>	
				বকেয়া: 
			</div>
			<div style='float:left;font-size:11px;width: 74px;text-align: right;padding-right: 5px;'>	
				$remaining
			</div>
			
		</div>
	
	</div>
	
	<div style='overflow:hidden;margin-top: 32px;'>	
	<div style='float:left; padding-left: 16px;font-size: 11px;'>	
		সাক্ষর
	</div>
	<div style='float: right;padding-right: 6px;font-size: 9px; padding-top: 14px;'>	
		EasyTech24
	</div>

	</div>
</div>";
	}
	return $receipt;
	}
	
	function printOnlyFabricsMoneyReceiptRent($direct_sale_head_top_id,$cus_name,$mobile,$fab_total,$discount_tk,$advance_tk,$itema,$ex_all_fitemqtya,$ex_all_fitempricea,$total_due,$submission_date){
		date_default_timezone_set("Asia/Dhaka");
		$dates=date("Y-m-d h:i:s");
		$advance_tk=sprintf('%0.2f', $advance_tk);
		$total_due=sprintf('%0.2f', $total_due);
		$idetails="";$sl=0;$tprice=0;
		for($di=0;$di<count($itema); $di++){
			$item_name=$itema[$di];
			$item_qtys=$ex_all_fitemqtya[$di];
			$item_price=$ex_all_fitempricea[$di];
			
			/* if($discount_tk>0){
				$item_price=(($item_price*100)/(100-$discount));
			} */
			$tprice=($item_qtys*$item_price);
			$sl=$di+1;
			$idetails.="<div style='float:left;width: 7%;'>	
				$sl.
			</div>
			<div style='float:left;width: 53%;;text-align:left'>	
				$item_name
			</div>
			<div style='float:left;width: 10%;'>	
				$item_qtys
			</div>
			<div style='float:left;width: 15%;text-align: right;'>	
				$item_price
			</div>
			<div style='float:left;width: 15%;text-align: right;padding-right: 5px;'>	
				$tprice
			</div>";
		}
		$sl=$sl+1;
		
		if($discount_tk>0){
			$fab_totald=($fab_total-$discount_tk);
			$remaining=($fab_totald-$advance_tk);
		}else{
			$remaining=($fab_total-$advance_tk);
		}
		$remaining=sprintf('%0.2f', $remaining);
		$dis="";
		if($discount_tk>0){
			$dis="<div style='overflow:hidden;font-size: 14px;
				font-weight: bold;text-align:center;
				padding-top: 3px;
				padding-bottom: 3px;
				'>	
				<div style='float: left;text-align: right;width: 250px;'>	
					Discount: 
				</div>
				<div style='float:left;font-size:14px;width: 74px;text-align: right;padding-right: 5px;'>	
					$discount_tk
				</div>
			
			</div>";
		}
		$com=$_SESSION['COM'];
		@$address=$_SESSION['COM_ADDRESS'];
		@$email=$_SESSION['EMAIL'];
		@$com_mobile=$_SESSION['COM_MOBILE'];
	
$receipt="<div id='print_area' style='overflow:hidden;margin-top:5px;margin-bottom: 6px;width:336px;max-width:336px;display: block; page-break-before: always;'>
	<div style='overflow:hidden;padding-top:25px;'>	
		<div style='line-height: 5px;padding-top:15px;text-align:center;'>	
			<p style='font-size: 17px;font-weight: bold;padding-top:0px;'>$com</p>
			<p style='font-size: 16px; font-weight: bold;padding-top: 0px;'>$address</p>
			<p style='font-size: 14px; font-weight: bold;padding-top: 0px;'>$email</p>
			<p style='font-size: 16px; font-weight: bold;padding-top: 0px;'>$com_mobile</p>
			<p style='font-size: 16px; font-weight: bold;padding-top: 10px;text-decoration:underline'>Money Receipt</p>
		</div>
		
	</div>
	
	<div style='overflow:hidden;margin-top: 20px;'>	
		<div style='float:left; padding-left: 6px;'>	
			<p style='font-size: 14px;'><b>Order No:$direct_sale_head_top_id</b></span>
		</div>
		<div style='float:right; padding-right: 6px;'>	
			<p style='font-size: 14px;font-weight:bold'>$dates</p>
		</div>
	</div>
	<div style='overflow:hidden;margin-top: 0px;'>	
		<div style='float:left; padding-left: 6px;width: 100%;'>	
			<p style='font-size: 14px;'><b>Customer:$cus_name</b></span>
		</div>
		
	</div>
	<div style='overflow:hidden;margin-top: 0px;'>	
		
		<div style='float:left; padding-left: 6px;width:100%;text-align:left;'>	
			<p style='font-size: 14px;font-weight:bold'>Mobile: $mobile</p>
		</div>
	</div>
	<div style='overflow:hidden;margin-top: 0px;'>	
		<div style='float:left; padding-left: 6px;width: 90%;'>	
			<p style='font-size: 14px;'><b>Return Date:$submission_date</b></span>
		</div>
		
	</div>
	<div style='overflow:hidden;margin-top: -3px;margin-left: 6px;
			margin-right: 6px;'>	
	<div style='width: 100%;margin-bottom: -6px;'>	
			---------------------------------------------------------------------
	</div>
		<div style='overflow:hidden;font-size: 15px;
			font-weight: bold;text-align:center;margin-bottom: -7px;'>	
			<div style='float:left;width: 7%;'>	
				Sl
			</div>
			<div style='float:left;width: 53%;text-align:left'>	
				Description
			</div>
			<div style='float:left;width: 10%;'>	
				Qty
			</div>
			<div style='float:left;width: 15%;text-align: right;'>	
				Rate
			</div>
			<div style='float:left;width: 15%;text-align: right;padding-right: 5px;'>	
				Taka
			</div>
		</div>
	<div style='width: 100%;margin-bottom: -6px;'>	
			---------------------------------------------------------------------
	</div>

	<div style=''>
		<div style='overflow:hidden;font-size: 14px;
			font-weight: bold;text-align:center;
			padding-bottom: 15px;'>	
			$idetails
		</div>
	</div>
	<div style='width: 100%;margin-bottom: -6px;'>	
			---------------------------------------------------------------------
	</div>
		<div style='overflow:hidden;font-size: 14px;
			font-weight: bold;text-align:center;
			
			padding-bottom: 3px;
			'>	
			<div style='float: left;text-align: right;width: 250px;'>	
				Total: 
			</div>
			<div style='float:left;font-size:14px;width: 74px;text-align: right;padding-right: 5px;'>	
				$fab_total
			</div>
			
		</div>
		$dis
		<div style='overflow:hidden;font-size: 14px;
			font-weight: bold;text-align:center;
			padding-top: 3px;
			padding-bottom: 3px;'>	
			<div style='float: left;text-align: right;width: 250px;'>	
				Receive: 
			</div>
			<div style='float:left;font-size:14px;width: 74px;text-align: right;padding-right: 5px;'>	
				$advance_tk
			</div>
			
		</div>
		<div style='overflow:hidden;font-size: 14px;
			font-weight: bold;text-align:center;
			padding-top: 3px;
			padding-bottom: 3px;'>	
			<div style='float: left;text-align: right;width: 250px;'>	
				Due: 
			</div>
			<div style='float:left;font-size:14px;width: 74px;text-align: right;padding-right: 5px;'>	
				$remaining
			</div>
		</div>
		
	<div style='width: 100%;margin-bottom: -6px;'>	
			---------------------------------------------------------------------
	</div>
	
	</div>
	
	<div style='width: 100%;text-align: center;padding-top: 65px;padding-bottom: 50px;font-size:16px'>	
			*** Thanks for your purchase ***
	</div>
	
</div>";
	
	return $receipt;
	}
	
	function getEditMeasurement($ord_tbl_id,$measurement_id,$mtype){
		include'db.php';
		if($mtype==1){
			$item_sql=$conn->query("SELECT `measurement` FROM `order_details` WHERE is_active=1 and mtype=$mtype and `measure_id`=$measurement_id and `order_number`='$ord_tbl_id'");
		}
		if($mtype==2){
			$item_sql=$conn->query("SELECT `measurement` FROM `order_details` WHERE is_active=1 and mtype=$mtype and `measurement`=$measurement_id and `order_number`='$ord_tbl_id'");
		}
		if($mtype==3){
			$item_sql=$conn->query("SELECT `measure_id` measurement FROM `order_details` WHERE is_active=1 and mtype=$mtype and `measure_id`=$measurement_id and `order_number`='$ord_tbl_id'");
		}
		if($mtype==4){
			$item_sql=$conn->query("SELECT `measurement` FROM `order_details` WHERE is_active=1 and mtype=$mtype and `measure_id`=$measurement_id and `order_number`='$ord_tbl_id'");
		}
		$row=mysqli_fetch_array($item_sql);
		return $row['measurement'];
	}
	
	function getSelectDetail_ShEdit($select_head,$group_id,$item_type,$ord_tbl_id){
		include'db.php';
		$com_id=($_SESSION['COM_ID']);
		$get_details=$conn->query("SELECT mh.title,mh.id FROM `select_detail` mh WHERE mh.group_id=$group_id and mh.is_active=1 and mh.ptype=$item_type and mh.select_type='$select_head' order by mh.steps asc");
		mysqli_close($conn);
		$option="";
		while($rows=mysqli_fetch_array($get_details)){
			$id=$rows['id'];
			$title=$rows['title'];
			$selectid=getEditMeasurement($ord_tbl_id,$id,2);
			if(isset($selectid)){
				$select="selected";
			}else{
				$select="";
			}
			$option.="<option $select value='$id'>$title</option>";
		}
		return $option;
	}
	
	function getSecurity($tk){
		$n="$tk";
		$s=0;
		for($i=0;$i<strlen($n); $i++){
			$s+=(($n[$i]*(strlen($n)-$i))+$n[$i]);
		}
		if(strlen($s)==1){
			$l=3;
		}else if(strlen($s)==2){
			$l=2;
		}else{
			$l=1;
		}
		$c="ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz";
		
		for($i=0;$i<$l; $i++){
			@$j.= $c[rand(0, strlen($c) - 1)];
		}
		$s="$s";
		 if(strlen($s)==2){
			 @$ss=$s[0].$j[0].$s[1].$j[1];
			 return $ss;
		 }else
		 if(strlen($s)==3){
			 @$ss=$s[0].$j[0].$s[1].$j[1].$s[2];
			 return $ss;
		 }else{
			 return $s.$j;
		 }
	}
	
	function generateMail($order_sql,$order_del,$receivable_list,$direct_sale,$expense,$com,$address,$mobile){
		include'db.php';
		$order_list=$conn->query($order_sql);
		$order_del=$conn->query($order_del);
		$receivable_list=$conn->query($receivable_list);
		$direct_sale=$conn->query($direct_sale);
		$expense=$conn->query($expense);
		$dis=0;
		/*
		<tr style='height: 25px;'>
		<th colspan='3' style='text-align:right' >Discount(-)</th>
		<th style='width:40%;text-align:right'>$dis/=</th>
		</tr>
		*/
		
		$sl=1;$order_tk=0;@$ord_list="";$c=0;
		if(mysqli_num_rows($order_list)>0){
			while($row=mysqli_fetch_array($order_list)){
				$order_tk+=$row['taka'];
				$phy_ord_num=$row['phy_ord_num'];
				$taka=$row['taka'];
				$c=$sl++;
				if($c%2!=0){
					$tr1="<tr style='height: 25px;text-align:center;background: #b9b3b338;'>";
				}else{
					$tr1="<tr style='height: 25px;text-align:center;'>";
				}
				
				$ord_list.=$tr1."<td>$c</td>
				<td>$phy_ord_num</td>
				<td style='width:40%;text-align:right'>$taka/=</td>
				</tr>";
				
			}
		}
		
		$sl=1;$receivable_tk=0;@$rcv_list="";$c=0;
		if(mysqli_num_rows($receivable_list)>0){
			while($row1=mysqli_fetch_array($receivable_list)){
				$receivable_tk+=$row1['taka'];
				$phy_ord_num=$row1['phy_ord_num'];
				$taka=row1['taka'];
				$c=$sl++;
				if($c%2!=0){
					$tr1="<tr style='height: 25px;text-align:center;background: #b9b3b338;'>";
				}else{
					$tr1="<tr style='height: 25px;text-align:center;'>";
				}
				$rcv_list.=$tr1."<td>$c</td>
				<td>$phy_ord_num</td>
				<td style='width:40%;text-align:right'>$taka/=</td>
				</tr>";
				
			}
		}
		
		$sl2=1;$order_tk2=0;@$order_list="";$c=0;
		if(mysqli_num_rows($order_del)>0){
			while($row2=mysqli_fetch_array($order_del)){
				$order_tk2+=$row2['taka'];
				$phy_ord_num=$row2['phy_ord_num'];
				$taka=$row2['taka'];
				$c=$sl2++;
				if($c%2!=0){
					$tr1="<tr style='height: 25px;text-align:center;background: #b9b3b338;'>";
				}else{
					$tr1="<tr style='height: 25px;text-align:center;'>";
				}
				$order_list.=$tr1."<td>$c</td>
				<td>$phy_ord_num</td>
				<td style='width:40%;text-align:right'>$taka/=</td>
				</tr>";
				
			}
		}
		
		$sl3=1;$order_tk3=0;$qty=0;$direct_sale_list="";$c=0;$f_total=0;
		if(mysqli_num_rows($direct_sale)>0){
			while($row3=mysqli_fetch_array($direct_sale)){
				$order_tk3+=($row3['price']*$row3['pic']);
				$qty+=$row3['pic'];
				$c=$sl3++;
				$items=$row3['items'];
				$pic=$row3['pic'];
				$price=$row3['price'];
				$tprice=($price*$pic);
				if($c%2!=0){
					$tr1="<tr style='height: 25px;text-align:center;background: #b9b3b338;'>";
				}else{
					$tr1="<tr style='height: 25px;text-align:center;'>";
				}
				$direct_sale_list.=$tr1."<td>$c</td>
				<td>$items</td>
				<td>$pic</td>
				<td style='width:35%;text-align:right'>$tprice/=</td>
				</tr>";
				
			}
			$f_total=$order_tk3;
		}
		
		$sl3=1;$order_tk4=0;$expense_list="";$c=0;
		if(mysqli_num_rows($expense)>0){
			while($row4=mysqli_fetch_array($expense)){
				$order_tk4+=$row4['expense'];
				$ex_type=$row4['ex_type'];
				$expense=$row4['expense'];
				$c=$sl3++;
				if($c%2!=0){
					$tr2="<tr style='height: 25px;text-align:center;background: #b9b3b338;'>";
				}else{
					$tr2="<tr style='height: 25px;text-align:center;'>";
				}
				$expense_list.=$tr2."<td>$c</td>
				<td>$ex_type</td>
				<td style='width:35%;text-align:right'>$expense/=</td>
				</tr>";
				
			}
		}
		
		date_default_timezone_set("Asia/Dhaka");
		$cdate=date('d/m/Y');
		$tdate=date('l');
		$ttk=($order_tk+$order_tk2+$f_total+$receivable_tk);
		$attk=(($order_tk+$order_tk2+$f_total+$receivable_tk)-$order_tk4);
		
		$mail_body="<div>
						<div style='overflow: hidden;'>
							<div style='float: left;width:392px;'>
								<p style=''>Date: <b>$cdate</b></p>
								<p style='line-height: 0px;'>Day: <b>$tdate</b></p>
							</div>
							<div style='float: left;margin-top: 11px;margin-bottom: 6px;'>
								<p style='text-align: center;line-height: 1px;margin-left: 37px;'><b>$com</b></p>
								<p style='text-align: center;line-height: 11px;margin-left: 37px;'>$mobile</p>
								<p style='text-align: center;line-height: 0px;margin-bottom: 16px;margin-left: 37px;'>$address</p>
								<span style='font-weight: bold;text-align: center;border: 1px solid gray; padding: 4px 6px 4px 6px; border-radius: 9px; margin-left: 48px;'>Daily Report</span>
							</div>
							<div style=''>
								
							</div>
						</div>
						<div style='overflow: hidden;'>
							<div style='float: left;width:500px;margin-right:15px'>
								<label>Order List</label>
								<table border='1' style='border-collapse:collapse;width:500px;margin-bottom:10px'>
									<thead>
										<tr style='height: 25px;background: #9491918f;'>
											<th>Sl</th>
											<th style='width:40%;'>Order No.</th>
											<th style='width:40%;text-align:right'>Taka</th>
										</tr>
									</thead>
									<tbody>$ord_list<tr style='height: 25px;'>
										<th colspan='2'  style='text-align:right'>Total</th>
										<th style='width:40%;text-align:right'>$order_tk/=</th>
									</tr></tbody>
								</table>
								
								<thead>Receivable List</thead>
								<table border='1' style='border-collapse:collapse;width:500px;margin-bottom:10px'>
									<thead>
										<tr style='height: 25px;background: #9491918f;'>
											<th>Sl</th>
											<th style='width:40%;'>Order No.</th>
											<th style='width:40%;text-align:right'>Taka</th>
										</tr>
									</thead>
									<tbody>$rcv_list
									<tr style='height: 25px;'>
										<th colspan='2'  style='text-align:right'>Total</th>
										<th style='width:40%;text-align:right'>$receivable_tk/=</th>
									</tr>
									</tbody>
								</table>
								
								
							</div><div style='float: left;width: 500px;margin-right:15px'>
								<label>Delivery List</label>
								<table border='1' style='border-collapse:collapse;width:500px;margin-bottom:10px'>
									<thead>
										<tr style='height: 25px;background: #9491918f;'>
											<th>Sl</th>
											<th style='width: 40%;'>Order No.</th>
											<th style='width:40%;text-align:right'>Taka</th>
										</tr>
									</thead>
									<tbody>$order_list
									<tr style='height: 25px;'>
										<th colspan='2'  style='text-align:right'>Total</th>
										<th style='width:40%;text-align:right'>$order_tk2/=</th>
									</tr>
									</tbody>
								</table>
								<label>Direct Sale List</label>
								<table border='1' style='border-collapse:collapse;width:500px;'>
									<thead>
										<tr style='height: 25px;background: #9491918f;'>
											<th>Sl</th>
											<th style='width:35%;'>Item Name</th>
											<th style='width:20%;'>Qty(piece)</th>
											<th style='width:35%;text-align:right'>Taka</th>
										</tr>
									</thead>
									<tbody>$direct_sale_list
									<tr style='height: 25px;'>
										<th colspan='2'  style='text-align:right'>Total</th>
										<th style=''>$qty Items</th>
										<th style='width:40%;text-align:right'>Total: $order_tk3/=</th>
									</tr>
									</tbody>
								</table>
								
							</div>
							
						</div>
						<div style='overflow: hidden;'>
							<div style='float: left;width: 500px;margin-right:15px'>
								<label>Expense List</label>
								<table border='1' style='border-collapse:collapse;width:500px;'>
									<thead>
										<tr style='height: 25px;background: #9491918f;'>
											<th>Sl</th>
											<th style='width:40%;'>Expense Type</th>
											<th style='width:40%;text-align:right'>Taka</th>
										</tr>
									</thead>
									<tbody>$expense_list
									<tr style='height: 25px;'>
										<th colspan='2'  style='text-align:right'>Total</th>
										<th style='width:40%;text-align:right'>$order_tk4/=</th>
									</tr>
									</tbody>
								</table>
							</div>
							<div style='float: left;width: 500px;margin-top:10px;background: #878b8e1a;'>
								<label style='font-size: 19px;font-weight: bold;'>Summary Report</label>
								<table border='1' style='border-collapse:collapse;width:500px;'>
										<thead>
											<tr style='height: 25px;'>
												<th style='text-align: right;'>Title</th>
												<th style='text-align:right'>Taka</th>
											</tr>
											<tr style='height: 25px;'>
												<th style='text-align: right;'>Order</th>
												<th style='text-align:right'>$order_tk/=</th>
											</tr>
											<tr style='height: 25px;'>
												<th style='text-align: right;'>Delivery</th>
												<th style='text-align:right'>$order_tk2/=</th>
											</tr>
											<tr style='height: 25px;'>
												<th style='text-align: right;'>Receivable</th>
												<th style='text-align:right'>$receivable_tk/=</th>
											</tr>
											<tr style='height: 25px;'>
												<th style='text-align: right;'>Direct Sale</th>
												<th style='text-align:right'>$f_total/=</th>
											</tr>
											<tr style='background:#F5F5F5;color: #b93333;height: 25px;'>
												<th style='text-align: right;'>Total Taka</th>
												<th style='text-align:right'>$ttk/=</th>
											</tr>
											<tr style='height: 25px;'>
												<th style='text-align: right;'>Expense(-)</th>
												<th style='text-align:right'>$order_tk4/=</th>
											</tr>
											<tr style='background:#F5F5F5;color: #b61ed2;height: 25px;'>
												<th style='text-align: right;'>Actual Total</th>
												<th style='text-align:right'>$attk/=</th>
											</tr>
										</thead>
										
									</table>
							</div>
						</div>
					</div>";
		return $mail_body;
	}
	
	
	
	/*----------------------------Email end---------------------------------------------------------------------------------------------*/
function getLeftPropertice($code,$max_chk){
		include'db.php';
		$max_order_details=$_SESSION['MAX_ORDER_DETAILS'];
		if($max_chk==1){
			$order_details_sql=$conn->query("SELECT (select title from select_detail where id=ods.measurement) title FROM order_details ods WHERE ods.id>$max_order_details and ods.is_active=1 and ods.mtype=2 and ods.order_number='$code'");
		}else{
			$order_details_sql=$conn->query("SELECT (select title from select_detail where id=ods.measurement) title FROM order_details ods WHERE ods.is_active=1 and ods.mtype=2 and ods.order_number='$code'");
		}
		
		$title="";
		if(mysqli_num_rows($order_details_sql)>0){
			while($detail_row=mysqli_fetch_array($order_details_sql)){
				$title.=$detail_row['title'].", ";
			}
		}
		return $title;
	}
	
	function getChkPropertice($code,$max_chk){
		include'db.php';
		$max_order_details=$_SESSION['MAX_ORDER_DETAILS'];
		if($max_chk==1){
			$order_details_sql=$conn->query("SELECT (select title from measurement_head where id=ods.measure_id) title FROM order_details ods WHERE ods.id>$max_order_details and ods.is_active=1 and ods.mtype=3 and ods.order_number='$code'");
		}else{
			$order_details_sql=$conn->query("SELECT (select title from measurement_head where id=ods.measure_id) title FROM order_details ods WHERE ods.is_active=1 and ods.mtype=3 and ods.order_number='$code'");
		}
		
		$title="";
		if(mysqli_num_rows($order_details_sql)>0){
			while($detail_row=mysqli_fetch_array($order_details_sql)){
				$title.=$detail_row['title'].", ";
			}
		}
		return $title;
	}
	
	function getTextPropertice($code,$max_chk){
		include'db.php';
		$max_order_details=$_SESSION['MAX_ORDER_DETAILS'];
		if($max_chk==1){
			$order_details_sql=$conn->query("SELECT measurement title FROM order_details ods WHERE ods.id>$max_order_details and ods.is_active=1 and ods.mtype=4 and ods.order_number='$code'");
		}else{
			$order_details_sql=$conn->query("SELECT measurement title FROM order_details ods WHERE ods.is_active=1 and ods.mtype=4 and ods.order_number='$code'");
		}
		
		$title="";
		if(mysqli_num_rows($order_details_sql)>0){
			$detail_row=mysqli_fetch_array($order_details_sql);
			$title.=$detail_row['title'].", ";
			
		}
		return $title;
	}
	
	function printMoneyReceiptNormal($cus_name,$get_mobile,$total_tk,$discount_tk,$design_charge,$others_tk,$tag,$date1,$advance_tk,$previous_due,$karigor_dv_date){
		include'db.php';
		date_default_timezone_set("Asia/Dhaka");
		$ord_date=date("d/m/Y");
		$time=date("h:i:s A");
		$font="font-size:12px;font-weight: bold;";
		$font2="font-size:10px;";
		$align_right="text-align:right;padding-right: 2px;";
		$td="width: 131px;";
		$padding="padding-left:4px;";
		
		$box2="";
		$box3="";
		$com_id=($_SESSION['COM_ID']);
		$max_dsms=$_SESSION['MAX_DSMS'];
		$max_order_record=$_SESSION['MAX_ORDER_RECORD'];
		$max_order_details=$_SESSION['MAX_ORDER_DETAILS'];
		$max_direct_sale=$_SESSION['MAX_DIRECT_SALE'];
		$user_name=$_SESSION['USER'];
		
	$order_record_sql=$conn->query("SELECT ord.id,(select product_name from product where id=ord.item_id) item_name,ord.item_qty FROM order_record ord WHERE ord.com_id=$com_id and ord.is_active=1 and ord.order_number='$tag'");
	$shirt="";$pant="";$panjabi="";$Safari="";
	while($iarray=mysqli_fetch_array($order_record_sql)){
		$item=$iarray['item_name'];
		if($item=="Shirt"){
			$shirt.=$iarray['item_name']."(".$iarray['item_qty'].") ";
		}
		if($item=="Coat"){
			$shirt.=$iarray['item_name']."(".$iarray['item_qty'].") ";
		}
		if($item=="Fatua"){
			$shirt.=$iarray['item_name']."(".$iarray['item_qty'].") ";
		}
		
		if($item=="Pant"){
			$pant.=$iarray['item_name']."(".$iarray['item_qty'].") ";
		}
		if($item=="Pajama"){
			$pant.=$iarray['item_name']."(".$iarray['item_qty'].") ";
		}
		
		if($item=="Safari"){
			$Safari.=$iarray['item_name']."(".$iarray['item_qty'].") ";
		}
		
		if($item=="Panjabi"){
			$panjabi.=$iarray['item_name']."(".$iarray['item_qty'].") ";
		}
	}
		
	
	$total_tk2=($total_tk-$others_tk-$design_charge+$discount_tk);
	$present_due=($total_tk-$advance_tk);
	$total_due=($previous_due+$present_due);
	$cus_name=substr($cus_name,0,20);
		$ex=explode("-",$date1);
		$date1=$ex[2]."/".$ex[1]."/".$ex[0];
		$day=date('l', strtotime($ex[2]."-".$ex[1]."-".$ex[0]));
		$making_item="";$making_item2="";$full_measurement="";
		$c=1;$mc=0;$total=0;
		
		//<img src='img/heading.JPG' style='height: 80px;'/>
		$receipt="<div style='overflow: hidden;margin-bottom: 5px;padding-bottom: 12px;width:700px;height:322px'>
		<div style='margin-left: 378px;'>
			<div style='height:22px;margin-bottom:3px;border:1px solid gray;padding-left: 5px;padding-top: 1px;'>
				$tag
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$ord_date $time
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$date1
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$cus_name
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$shirt
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$pant
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$panjabi
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$Safari
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$total_tk/=
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$advance_tk/=
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$present_due/=
			</div>
		</div>
		
	</div>";


//return $receipt.$receipt2;
return $receipt;
	}
	
	// create order to direct print option
	
	function printMoneyReceipt($cus_name,$get_mobile,$total_tk,$discount_tk,$design_charge,$others_tk,$tag,$date1,$advance_tk,$previous_due,$karigor_dv_date){
		include'db.php';
		date_default_timezone_set("Asia/Dhaka");
		$ord_date=date("d/m/Y");
		$time=date("h:i:s A");
		$font="font-size:12px;font-weight: bold;";
		$font2="font-size:10px;";
		$align_right="text-align:right;padding-right: 2px;";
		$td="width: 131px;";
		$padding="padding-left:4px;";
		
		$box2="";
		$box3="";
		$com_id=($_SESSION['COM_ID']);
		$max_dsms=$_SESSION['MAX_DSMS'];
		$max_order_record=$_SESSION['MAX_ORDER_RECORD'];
		$max_order_details=$_SESSION['MAX_ORDER_DETAILS'];
		$max_direct_sale=$_SESSION['MAX_DIRECT_SALE'];
		$user_name=$_SESSION['USER'];
		
		//$time
	$order_record_sql=$conn->query("SELECT ord.id,(select cus_price from product where id=ord.item_id) cus_price,(select product_name from product where id=ord.item_id) item_name,ord.item_qty,ord.group_name,(select user_name from user where id=ord.master_id) master_name,(select user_name from user where id=ord.karigor_id) karigor_name FROM order_record ord WHERE ord.id>$max_order_record and ord.com_id=$com_id and ord.is_active=1 and ord.order_number='$tag'");
	$direct_sale_sql=$conn->query("SELECT ds.item_qty,(select product_name from product where id=ds.item_id) item_name,ds.price FROM direct_sale ds WHERE ds.id>$max_direct_sale and ds.com_id=$com_id and ds.is_active=1 and ds.order_number='$tag'");
	
	$total_tk2=($total_tk-$others_tk-$design_charge+$discount_tk);
	$present_due=($total_tk-$advance_tk);
	$total_due=($previous_due+$present_due);
	$cus_name=substr($cus_name,0,40);
		$ex=explode("-",$date1);
		$date1=$ex[2]."/".$ex[1]."/".$ex[0];
		$day=date('l', strtotime($ex[2]."-".$ex[1]."-".$ex[0]));
		$making_item="";$making_item2="";$full_measurement="";
		$c=1;$mc=0;$total=0;
		while($row=mysqli_fetch_array($order_record_sql)){
			$mc=$c++;
			$code=$row['id'];
			if($row['group_name']!=""){
				$group_array=explode(",",$row['group_name']);
			}else{
				$group_array=array();
			}
			
			@$master_name=($row['master_name']=='0')? '' : $row['master_name'];
			@$karigor_name=($row['karigor_name']=='0')? '' : $row['karigor_name'];
			$name=$row['item_name'];
			$qty=$row['item_qty'];
			$cus_price=$row['cus_price'];
			$total=($qty*$cus_price);
			$making_item.="<tr>
				<td style='$font2 $padding'>
					$name
				</td>
				<td style='$font2 $padding'>
					$qty
				</td>
			</tr>";
			$making_item2.="<tr>
				<td style='$font2 $padding'>
					$mc
				</td>
				<td style='$font2 $padding'>
					$name
				</td>
				<td style='$font2 $padding'>
					$qty
				</td>
				<td style='$font2 $align_right'>
					$cus_price
				</td>
				<td style='$font2 $align_right'>
					$total
				</td>
				<td style='$font2 $padding'>
					Wages
				</td>
			</tr>";
			$box1="";$item_heading="";$get_propertice="";$tbl_head="";
			$order_details_sql=$conn->query("SELECT measurement,(select title from measurement_head where id=ods.measure_id) measure_title FROM order_details ods WHERE ods.id>$max_order_details and ods.is_active=1 and ods.mtype=1 and ods.order_number='$code'");
			while($detail_row=mysqli_fetch_array($order_details_sql)){
				$measurement=$detail_row['measurement'];
				$measure_title=$detail_row['measure_title'];
				$box1.="<div style='float:left;text-align: center;padding-left:5px;padding-right:5px;margin-right: 1px;'>
					<p style='font-size: 10px;padding-top: 8px;text-align: center; line-height: 0px;'>$measure_title</p>
					<span style='margin-top: -3px;padding-left:3px;padding-right:3px;font-size: 15px;'>$measurement</span>
				</div>";
			}
			$get_propertice=getLeftPropertice($code,1).getChkPropertice($code,1).getTextPropertice($code,1);
			$tbl_head="<div style='overflow: hidden;
				width: 716px;
				padding-top: 2px;
				padding-bottom: 2px;'>
				<div style='float: left;
				width: 155px;
				font-size: 15px;
				padding-left: 5px;'>
				<b>সিরিয়াল নং:</b> $tag
				</div>
				<div style='float: left;
				padding-left: 6px;
				font-size: 15px;
				padding-right: 10px;'>
				<b>ডেলিভারি :</b> $karigor_dv_date
				</div>
				<div style='float: left;
				padding-left: 10px;font-size: 15px;'>
				
				</div>
				<div style='float: left;
				padding-left: 10px;font-size: 15px;'>
				<b>মাস্টার:</b> $master_name 
				</div>
				<div style='float: left;
				padding-left: 10px;font-size: 15px;'>
				<b>কারিগর:</b> $karigor_name 
				</div>
			</div>";
			
			$item_heading.="<div style='margin-bottom:2px;'>
			    $tbl_head
				<table border='1' style='border-collapse: collapse;width:100%;'>
					<tr>
						<td style='$padding;width:18%;font-size:14px;'>
							কোড  নং: $code 
						</td>
						<td style='$padding;width:60%;font-size:14px;'>
							আইটেম: $name $qty পিছ
						</td>
						<td style='$font2 $padding;text-align: right;padding-right: 5px;'>
							
						</td>
					</tr>
					<tr>
						
						<td style='font-size:15px;padding-top: 2px;padding-left: 2px;padding-right: 2px;' colspan='3'>
							$get_propertice
						</td>
					</tr>
				</table>
			</div>";
			if($qty>0){
				$box3="";
				$qty=($qty>4)? 4 : $qty;
				for($j=0;$j<$qty;$j++){
					@$gnames=$group_array[0];
					$box3.="<div style='float: left;padding-top: 12px; height: 74px;border: 1px solid gray;margin-right:10px;margin-bottom: 10px;width: 186px; margin-top:2px;padding-left: 10px;'>
						<p style='line-height:5px;font-size:18px'>সিরিয়াল নং: $tag</p>
						<p style='line-height:5px'>কোড  নং: $code</p>
						<p style='line-height:5px'> $cus_name</p>
						<p style='line-height:5px'>গ্রুপ: $gnames</p>
					</div>";
				}
			}
			
			$full_measurement.="<div style='height: 340px;float:left;margin-top: 2px;width:796px;margin-right:5px;padding-bottom: 5px;margin-bottom: 15px;'><div style='width:792px;overflow: hidden;margin-left: 0px;'>
				$box3
				</div><div style='border: 1px solid black;height: 260px;'>
				$item_heading
				<div style='margin-bottom:2px;padding-left:2px'>
					$box1
				</div>
			</div></div>";
			
		}
		
		
		$sales_item="";$c=1;$mc=0;$total=0;
		while($row=mysqli_fetch_array($direct_sale_sql)){
			$mc=$c++;
			$name=$row['item_name'];
			$qty=$row['item_qty'];
			$price=$row['price'];
			$total=($price*$qty);
			$sales_item.="<tr>
				<td style='font-size:10px;width: 17px;$padding'>
					$mc
				</td>
				<td style='font-size:10px;width: 92px;$padding'>
					$name
				</td>
				<td style='font-size:10px;width: 26px;$padding'>
					$qty
				</td>
				<td style='font-size:10px;width: 33px;$align_right'>
					$price
				</td>
				<td style='font-size:10px;width: 51px;$align_right'>
					$total
				</td>
				<td style='font-size:10px;$padding'>
					গজ
				</td>
			</tr>";
		}
		if($_SESSION['ORDER_COPY']==1){
			$head="<tr>
				<th style='$font2 $align_right;width:154px'>
					পূর্বের বাকি
				</th>
				<td style='$font $align_right;width:72px'>
					$previous_due
				</td>
			</tr>";
			$tail="<tr>
				<th style='$font2 $align_right'>
					সর্বমোট বাকি
				</th>
				<td style='$font $align_right'>
					$total_due
				</td>
			</tr>";
		}else{
			$head="";
			$tail="";
		}
		//<img src='img/heading.JPG' style='height: 80px;'/>
		$receipt="<div style='overflow: hidden;margin-bottom: 30px;padding-bottom: 30px;border-bottom: 1px dotted gray;width:796px;'>
			<div style='width:796px;height:80px;margin-bottom:2px'>
				<img src='img/heading.JPG' style='height: 80px;width: 796px;'/>
			</div>
	<div style='float:left;width: 465px; margin-right: 5px;'>
		<table border='1' style='border-collapse: collapse;margin-right: 5px;width:100%'>
			<tr>
				<td style='$font $padding;width: 126px;'>
					সিরিয়াল নং:
				</td>
				<td style='$font $padding'>
					$tag
				</td>
				<td style='$font $padding'>
					বিক্রয়কারী :
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					অর্ডার তাং:
				</td>
				<td style='$font $padding'>
					$ord_date $time
				</td>
				<td style='$font $padding'>
					$user_name
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					সম্ভাব্য ডেলিভারি :
				</td>
				<td style='$font $padding'>
					$date1
				</td>
				<td style='$font $padding'>
					$day
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					নাম:
				</td>
				
				<td style='$font $padding'>
					$cus_name
				</td>
				<td style='$font $padding'>
					$get_mobile
				</td>
				
			</tr>
		</table>
		<div style='overflow:hidden'>
			<div style='float:left;width: 360px;height:115px;border: 1px solid gray;margin-top: 1px;margin-right:5px'>
				<img src='img/box.JPG' style='height: 113px; width: 357px;'/>
			</div>
			<div style='float: left;margin-top: 1px;'>
				<div style='width:100px;height: 50px;border: 1px solid gray;text-align: center;padding-top: 12px;'>
				নমুনা
				</div>
				<div style='width:100px;padding-top: 8px;text-align:center'>
				-------
				</div>
				<div style='width:100px;text-align:center;font-size: 10px;'>
				Authority<br/>Signature
				</div>
			</div>
			
		</div>
	</div>
	<div style='float:left;width: 200px;margin-right: 5px;'>
		<table border='1' style='border-collapse: collapse;width:100%'>
			<tr>
				<th style='$font $padding'>
					বিবরণ 
				</th>
				<th style='$font $padding'>
					সংখ্যা
				</th>
			</tr>
			$making_item
		</table>
	</div>
	<div style=''>
		<table border='1' style='border-collapse: collapse;width: 120px;'>
			$head 
			<tr>
				<th style='$font2 $align_right'>
					মোট টাকা
				</th>
				<td style='$font $align_right'>
					$total_tk2
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					স্টাইল
				</th>
				<td style='$font $align_right'>
					$design_charge
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					অন্যান্য খরচ
				</th>
				<td style='$font $align_right'>
					$others_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					ছাড় (%)			
				</th>
				<td style='$font.$align_right'>
					
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					ছাড় (টাকা)			
				</th>
				<td style='$font $align_right'>
					$discount_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					সর্বমোট টাকা		
				</th>
				<td style='$font $align_right'>
					$total_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					অগ্রিম
				</th>
				<td style='$font $align_right'>
					$advance_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					বর্তমান বাকি
				</th>
				<td style='$font $align_right'>
					$present_due
				</td>
			</tr>
			$tail 
		</table>
	</div>
</div>


<div style='overflow:hidden;width: 798px;'>
	$full_measurement
	
</div>";

return $receipt;
	}
	/*
	<div style='overflow:hidden;width: 796px;'>
	$box3
</div>
	*/
// page-break-before: always;

// Order number wise search and print

function printMoneyReceipt32($tag){
		include'db.php';
		date_default_timezone_set("Asia/Dhaka");
		$time=date("h:i:s A");
		$font="font-size:12px;font-weight: bold;";
		$font2="font-size:10px;";
		$align_right="text-align:right;padding-right: 2px;";
		$td="width: 131px;";
		$padding="padding-left:4px;";
		
		$box2="";
		$box3="";
		$com_id=($_SESSION['COM_ID']);
		$max_dsms=$_SESSION['MAX_DSMS'];
		$max_order_record=$_SESSION['MAX_ORDER_RECORD'];
		$max_order_details=$_SESSION['MAX_ORDER_DETAILS'];
		$max_direct_sale=$_SESSION['MAX_DIRECT_SALE'];
		
	$dsms_sql=$conn->query("SELECT date(ord.insert_date) ord_date,time(ord.insert_date) ord_time,ord.fddate,ord.dv_date,ord.amount,ord.cus_name,ord.cus_mobile,ord.discount,ord.design_cost,ord.others_tk,
	(SELECT sum(`amount`) FROM `accounting` WHERE `dsms_id`=ord.id and is_active=1 and `pay_status` in(0,1)) advance_tk,
	(select user_name from user where id=ord.insert_by) user_name,ord.previous_total_due
	from dsms ord WHERE ord.com_id=$com_id and ord.is_active=1 and ord.phy_ord_num='$tag'");
	if(mysqli_num_rows($dsms_sql)>0){
		$dsms_row=mysqli_fetch_array($dsms_sql);
		$date1=$dsms_row['dv_date'];
		$karigor_dv_date=$dsms_row['fddate'];
		$cus_name=$dsms_row['cus_name'];
		$ord_time=date('h:i A', strtotime($dsms_row['ord_time']));
		$get_mobile=$dsms_row['cus_mobile'];
		$ex2=explode("-",$dsms_row['ord_date']); // order date
		$total_tk=$dsms_row['amount'];
		$others_tk=intval($dsms_row['others_tk']);
		$design_charge=intval($dsms_row['design_cost']);
		$discount_tk=$dsms_row['discount'];
		$previous_due=$dsms_row['previous_total_due'];
		//$total_due=$dsms_row['present_due'];
		$advance_tk=$dsms_row['advance_tk'];
		$user_name=$dsms_row['user_name'];
		
	}else{
		return "Warning! Wrong Serial No.";
		exit;
	}
	$order_record_sql=$conn->query("SELECT ord.id,(select cus_price from product where id=ord.item_id) cus_price,(select product_name from product where id=ord.item_id) item_name,ord.item_qty,ord.group_name,ord.receive_qty,ord.master_cutting_qty,(select user_name from user where id=ord.karigor_id) karigor_name,(select user_name from user where id=ord.maker) karigor_names,(select user_name from user where id=ord.master_id) master_name,(select user_name from user where id=ord.master_emp_id) master_names FROM order_record ord WHERE ord.com_id=$com_id and ord.is_active=1 and ord.order_number='$tag'");

	//$order_record_sql=$conn->query("SELECT ord.id,(select cus_price from product where id=ord.item_id) cus_price,(select product_name from product where id=ord.item_id) item_name,ord.item_qty,ord.group_name FROM order_record ord WHERE ord.com_id=$com_id and ord.is_active=1 and ord.order_number='$tag'");
	$direct_sale_sql=$conn->query("SELECT ds.item_qty,(select product_name from product where id=ds.item_id) item_name,ds.price,(select item_code from product where id=ds.item_id) item_code FROM direct_sale ds WHERE ds.com_id=$com_id and ds.is_active=1 and ds.order_number='$tag'");
	
	$total_tk2=($total_tk-$others_tk-$design_charge+$discount_tk);
	$present_due=($total_tk-$advance_tk);
	$total_due=($present_due+$previous_due);
	$cus_name=substr($cus_name,0,80);
		$ex=explode("-",$date1);
		$date1=$ex[2]."/".$ex[1]."/".$ex[0];
		$day=date('l', strtotime($ex[2]."-".$ex[1]."-".$ex[0]));
		$ord_date=$ex2[2]."/".$ex2[1]."/".$ex2[0];
		$making_item="";$making_item2="";$full_measurement="";
		$c=1;$mc=0;$total=0;
		while($row=mysqli_fetch_array($order_record_sql)){
			$mc=$c++;
			$code=$row['id'];
			if($row['group_name']!=""){
				$group_array=explode(",",$row['group_name']);
			}else{
				$group_array=array();
			}
			
			$name=$row['item_name'];
			$qty=$row['item_qty'];
			$cus_price=$row['cus_price'];
			$receive_qty=$row['receive_qty'];
			$master_cutting_qty=$row['master_cutting_qty'];
			$karigor_name=$row['karigor_name'];
			$karigor_names=$row['karigor_names'];
			$karigor_name=($qty!=$receive_qty)? $karigor_name : $karigor_names;
			$master_name=($qty!=$master_cutting_qty)? $row['master_name'] : $row['master_names'];
	
			
			$total=($qty*$cus_price);
			$making_item.="<tr>
				<td style='$font2 $padding'>
					$name
				</td>
				<td style='$font2 $padding'>
					$qty
				</td>
			</tr>";
			$making_item2.="<tr>
				<td style='$font2 $padding'>
					$mc
				</td>
				<td style='$font2 $padding'>
					$name
				</td>
				<td style='$font2 $padding;width:32px'>
					$qty
				</td>
				<td style='$font2 $align_right'>
					$cus_price
				</td>
				<td style='$font2 $align_right'>
					$total
				</td>
				<td style='$font2 $padding'>
					Wages
				</td>
			</tr>";
			$box1="";$item_heading="";$get_propertice="";$tbl_head="";
			$order_details_sql=$conn->query("SELECT measurement,(select title from measurement_head where id=ods.measure_id) measure_title FROM order_details ods WHERE ods.is_active=1 and ods.mtype=1 and ods.order_number='$code'");
			while($detail_row=mysqli_fetch_array($order_details_sql)){
				$measurement=$detail_row['measurement'];
				$measure_title=$detail_row['measure_title'];
				$box1.="<div style='float:left;text-align: center;padding-left:5px;padding-right:5px;margin-right: 1px;'>
					<p style='font-size: 10px;padding-top: 8px;text-align: center; line-height: 0px;'>$measure_title</p>
					<span style='margin-top: -3px;padding-left:3px;padding-right:3px;font-size: 15px;'>$measurement</span>
				</div>";
			}
			
			$get_propertice=getLeftPropertice($code,2).getChkPropertice($code,2).getTextPropertice($code,2);
			
			$tbl_head="<div style='overflow: hidden;
				width: 745px;
				padding-top: 2px;
				padding-bottom: 2px;'>
				<div style='float: left;
				width: 155px;
				font-size: 15px;
				padding-left: 5px;'>
				সিরিয়াল নং: $tag
				</div>
				<div style='float: left;
				padding-left: 6px;
				font-size: 15px;
				padding-right: 10px;'>
				ডেলিভারি: $karigor_dv_date
				</div>
				<div style='float: left;
				padding-left: 10px;font-size: 15px;'>
				
				</div>
				<div style='float: left;
				padding-left: 30px;font-size: 15px;'>
				মাস্টার: $master_name
				</div>
				<div style='float: left;
				padding-left: 30px;font-size: 15px;'>
				কারিগর: $karigor_name
				</div>
			</div>";
			$item_heading.="<div style='margin-bottom:2px;'>
				
			    $tbl_head
				<table border='1' style='border-collapse: collapse;width:100%;'>
					
					<tr>
						<td style='$padding;width: 18%;font-size:14px;'>
							কোড  নং: $code 
						</td>
						<td style='$padding;width: 60%;font-size:14px;'>
							আইটেম: $name $qty পিছ
						</td>
						<td style='$font2 $padding;text-align: right;padding-right: 5px;'>
							
						</td>
					</tr>
					<tr>
						<td style='font-size:15px;padding-top: 2px;padding-left: 2px;padding-right: 2px;' colspan='3'>
							$get_propertice
						</td>
					</tr>
				</table>
			</div>";
			
			if($qty>0){
				$box3="";
				$qty=($qty>2)? 2 : $qty;
				for($j=0;$j<$qty;$j++){
					@$gnames=$group_array[$j];
					$box3.="<div style='float: left;padding-top: 12px; height: 74px;border: 1px solid gray;margin-right:10px;margin-bottom: 10px;width: 186px; margin-top:2px;padding-left: 10px;'>
						<p style='line-height:5px;font-size:18px'>সিরিয়াল নং: $tag</p>
						<p style='line-height:5px'>কোড  নং: $code</p>
						<p style='line-height:5px'>$cus_name</p>
						<p style='line-height:5px'>গ্রুপ: $gnames</p>
					</div>";
				}
			}
			
			$full_measurement.="<div style='height: 340px;float:left;margin-top: 2px;width:796px;margin-right:5px;padding-bottom: 5px;margin-bottom: 15px;'><div style='width:393px;overflow: hidden;margin-left: 0px;'>
				$box3
				</div><div style='border: 1px solid black;height: 260px;'>
				$item_heading
				<div style='margin-bottom:2px;padding-left:2px'>
					$box1
				</div>
			</div></div>";
			
		}
		
		
		$sales_item="";$c=1;$mc=0;$total=0;
		while($row=mysqli_fetch_array($direct_sale_sql)){
			$mc=$c++;
			$name=$row['item_name'];
			@$item_code=$row['item_code'];
			$qty=$row['item_qty'];
			$price=$row['price'];
			$total=($price*$qty);
			$sales_item.="<tr>
				<td style='font-size:10px;width: 17px;$padding'>
					$mc
				</td>
				<td style='font-size:10px;width: 92px;$padding'>
					$name($item_code)
				</td>
				<td style='font-size:10px;width: 26px;$padding'>
					$qty
				</td>
				<td style='font-size:10px;width: 33px;$align_right'>
					$price
				</td>
				<td style='font-size:10px;width: 51px;$align_right'>
					$total
				</td>
				<td style='font-size:10px;$padding'>
					গজ
				</td>
			</tr>";
		}
		if($_SESSION['ORDER_COPY']==1){
			$head="<tr>
				<th style='$font2 $align_right;width:154px'>
					পূর্বের বাকি
				</th>
				<td style='$font $align_right;width:72px'>
					$previous_due
				</td>
			</tr>";
			$tail="<tr>
				<th style='$font2 $align_right'>
					সর্বমোট বাকি
				</th>
				<td style='$font $align_right'>
					$total_due
				</td>
			</tr>";
		}else{
			$head="";
			$tail="";
		}
		$second_receipt="<div style='overflow: hidden;margin-bottom: 2px;border-bottom: 1px dotted gray;width:796px;margin-top:2px;'>
	<div style='float:left; margin-right: 5px;width: 358px;'>
		<table border='1' style='border-collapse: collapse;margin-right: 5px;width:100%'>
			<tr>
				<td style='$font $padding;width: 12%;'>
					সিরিয়াল নং:
				</td>
				<td style='$font $td $padding;width: 3%;'>
					$tag
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					অর্ডার তাং:
				</td>
				<td style='$font $padding'>
					$ord_date $ord_time
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					ডেলিভারি  তাং:
				</td>
				<td style='$font $padding'>
					$date1($day)
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					নাম:
				</td>
				
				<td style='$font $padding'>
					$cus_name
				</td>
				
				
			</tr>
			<tr>
				<td style='$font $padding'>
					মোবাইল  নং:
				</td>
				
				<td style='$font $padding'>
					$get_mobile
				</td>
				
			</tr>
		</table>
		<div style='overflow:hidden'>
			
			<div style='float: left;margin-top: 1px;'>
				<div style='width:100px;height: 50px;border: 1px solid gray;text-align: center;padding-top: 12px;'>
				নমুনা
				</div>
				
			</div>
			
		</div>
	</div>
	<div style='float:left;width: 305px;margin-right: 5px;'>
		<table border='1' style='border-collapse: collapse;width:100%'>
			<tr>
				<th style='font-size:9px;width: 17px;'>
					নং
				</th>
				<th style='font-size:9px;width: 92px;$padding'>
					বিবরণ 
				</th>
				<th style='font-size:9px;width: 32px;$padding'>
					সংখ্যা
				</th>
				<th style='font-size:9px;width: 33px;$align_right'>
					দর
				</th>
				<th style='font-size:9px;width: 51px;$align_right'>
					মোট
				</th>
				<th style='font-size:9px;$padding'>
					পদ্ধতি
				</th>
			</tr>
			$making_item2
		</table>
		<table border='1' style='border-collapse: collapse;width:100%;margin-top: 1px;'>
			$sales_item
		</table>
	</div>
	<div style='margin-bottom:2px;'>
		<table border='1' style='border-collapse: collapse;width: 120px;'>
			$head 
			<tr>
				<th style='$font2 $align_right'>
					মোট টাকা
				</th>
				<td style='$font $align_right'>
					$total_tk2
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					স্টাইল
				</th>
				<td style='$font $align_right'>
					$design_charge
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					অন্যান্য খরচ
				</th>
				<td style='$font $align_right'>
					$others_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					ছাড় (%)			
				</th>
				<td style='$font.$align_right'>
					
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					ছাড় (টাকা)			
				</th>
				<td style='$font $align_right'>
					$discount_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					সর্বমোট টাকা		
				</th>
				<td style='$font $align_right'>
					$total_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					অগ্রিম
				</th>
				<td style='$font $align_right'>
					$advance_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					বর্তমান বাকি
				</th>
				<td style='$font $align_right'>
					$present_due
				</td>
			</tr>
			$tail 
		</table>
	</div>
</div>";
		//<img src='img/heading.JPG' style='height: 80px;'/>
		$receipt="<div style='overflow: hidden;margin-bottom: 30px;padding-bottom: 30px;border-bottom: 1px dotted gray;width:796px;'>
			<div style='width:796px;height:80px;margin-bottom: 2px;'>
				<img src='img/heading.JPG' style='height: 80px;width:795px'/>
			</div>
	<div style='float:left;width: 465px; margin-right: 5px;'>
		<table border='1' style='border-collapse: collapse;margin-right: 5px;width:100%'>
			<tr>
				<td style='$font $padding;width: 126px;'>
					সিরিয়াল নং:
				</td>
				<td style='$font $padding'>
					$tag
				</td>
				<td style='$font $padding'>
					বিক্রয়কারী :
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					অর্ডার তাং:
				</td>
				<td style='$font $padding'>
					$ord_date $ord_time
				</td>
				<td style='$font $padding'>
					$user_name
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					ডেলিভারি  তাং:
				</td>
				<td style='$font $padding'>
					$date1
				</td>
				<td style='$font $padding'>
					$day
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					নাম:
				</td>
				
				<td style='$font $padding'>
					$cus_name
				</td>
				<td style='$font $padding'>
					$get_mobile
				</td>
				
			</tr>
		</table>
		<div style='overflow:hidden'>
			<div style='float:left;width:360px;height:115px;border: 1px solid gray;margin-top: 1px;margin-right:5px'>
				<img src='img/box.JPG' style='height: 113px; width: 357px;'/>
			</div>
			<div style='float: left;margin-top: 1px;'>
				<div style='width:100px;height: 50px;border: 1px solid gray;text-align: center;padding-top: 12px;'>
				নমুনা
				</div>
				<div style='width:100px;padding-top: 8px;text-align:center'>
				-------
				</div>
				<div style='width:100px;text-align:center;font-size: 10px;'>
				Authority<br/>Signature
				</div>
			</div>
			
		</div>
	</div>
	<div style='float:left;width: 200px;margin-right: 5px;'>
		<table border='1' style='border-collapse: collapse;width:100%'>
			<tr>
				<th style='$font $padding'>
					বিবরণ 
				</th>
				<th style='$font $padding'>
					সংখ্যা
				</th>
			</tr>
			$making_item
		</table>
	</div>
	<div style=''>
		<table border='1' style='border-collapse: collapse;width: 120px;'>
			$head
			<tr>
				<th style='$font2 $align_right'>
					মোট টাকা
				</th>
				<td style='$font $align_right'>
					$total_tk2
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					স্টাইল
				</th>
				<td style='$font $align_right'>
					$design_charge
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					অন্যান্য খরচ
				</th>
				<td style='$font $align_right'>
					$others_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					ছাড় (%)			
				</th>
				<td style='$font.$align_right'>
					
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					ছাড় (টাকা)			
				</th>
				<td style='$font $align_right'>
					$discount_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					সর্বমোট টাকা		
				</th>
				<td style='$font $align_right'>
					$total_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					অগ্রিম
				</th>
				<td style='$font $align_right'>
					$advance_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					বর্তমান বাকি
				</th>
				<td style='$font $align_right'>
					$present_due
				</td>
			</tr>
			$tail
		</table>
	</div>
</div>


	
</div>
$second_receipt
<div style='overflow:hidden;width:796px;margin-top: 0px;'>
	$full_measurement
	
</div>";
/*
<div style='overflow:hidden;width:796px;'>
	$box3
</div>*/
return $receipt;
	}
	
		function printMoneyReceipt2($tag){
		include'db.php';
		date_default_timezone_set("Asia/Dhaka");
		$time=date("h:i:s A");
		$font="font-size:12px;font-weight: bold;";
		$font2="font-size:10px;";
		$align_right="text-align:right;padding-right: 2px;";
		$td="width: 131px;";
		$padding="padding-left:4px;";
		
		$box2="";
		$box3="";
		$com_id=($_SESSION['COM_ID']);
		$max_dsms=$_SESSION['MAX_DSMS'];
		$max_order_record=$_SESSION['MAX_ORDER_RECORD'];
		$max_order_details=$_SESSION['MAX_ORDER_DETAILS'];
		$max_direct_sale=$_SESSION['MAX_DIRECT_SALE'];
		
	$dsms_sql=$conn->query("SELECT date(ord.insert_date) ord_date,time(ord.insert_date) ord_time,ord.fddate,ord.dv_date,ord.amount,ord.cus_name,ord.cus_mobile,ord.discount,ord.design_cost,ord.others_tk,
	(SELECT sum(`amount`) FROM `accounting` WHERE `dsms_id`=ord.id and is_active=1 and `pay_status` in(0,1)) advance_tk,
	(select user_name from user where id=ord.insert_by) user_name,ord.previous_total_due
	from dsms ord WHERE ord.com_id=$com_id and ord.is_active=1 and ord.phy_ord_num='$tag'");
	if(mysqli_num_rows($dsms_sql)>0){
		$dsms_row=mysqli_fetch_array($dsms_sql);
		$date1=$dsms_row['dv_date'];
		$karigor_dv_date=$dsms_row['fddate'];
		$cus_name=$dsms_row['cus_name'];
		$ord_time=date('h:i A', strtotime($dsms_row['ord_time']));
		$get_mobile=$dsms_row['cus_mobile'];
		$ex2=explode("-",$dsms_row['ord_date']); // order date
		$total_tk=$dsms_row['amount'];
		$others_tk=intval($dsms_row['others_tk']);
		$design_charge=intval($dsms_row['design_cost']);
		$discount_tk=$dsms_row['discount'];
		$previous_due=$dsms_row['previous_total_due'];
		//$total_due=$dsms_row['present_due'];
		$advance_tk=$dsms_row['advance_tk'];
		$user_name=$dsms_row['user_name'];
		
	}else{
		return "Warning! Wrong Serial No.";
		exit;
	}
	
	$order_record_sql=$conn->query("SELECT ord.id,(select cus_price from product where id=ord.item_id) cus_price,(select product_name from product where id=ord.item_id) item_name,ord.item_qty,ord.group_name,ord.receive_qty,ord.master_cutting_qty,(select user_name from user where id=ord.karigor_id) karigor_name,(select user_name from user where id=ord.maker) karigor_names,(select user_name from user where id=ord.master_id) master_name,(select user_name from user where id=ord.master_emp_id) master_names FROM order_record ord WHERE ord.com_id=$com_id and ord.is_active=1 and ord.order_number='$tag'");
	$direct_sale_sql=$conn->query("SELECT ds.item_qty,(select product_name from product where id=ds.item_id) item_name,ds.price FROM direct_sale ds WHERE ds.com_id=$com_id and ds.is_active=1 and ds.order_number='$tag'");
	
	$total_tk2=($total_tk-$others_tk-$design_charge+$discount_tk);
	$present_due=($total_tk-$advance_tk);
	$total_due=($present_due+$previous_due);
	$cus_name=substr($cus_name,0,80);
		$ex=explode("-",$date1);
		$date1=$ex[2]."/".$ex[1]."/".$ex[0];
		$day=date('l', strtotime($ex[2]."-".$ex[1]."-".$ex[0]));
		$ord_date=$ex2[2]."/".$ex2[1]."/".$ex2[0];
		$making_item="";$making_item2="";$full_measurement="";
		$c=1;$mc=0;$total=0;
		while($row=mysqli_fetch_array($order_record_sql)){
			$mc=$c++;
			$code=$row['id'];
			if($row['group_name']!=""){
				$group_array=explode(",",$row['group_name']);
			}else{
				$group_array=array();
			}
			
			$name=$row['item_name'];
			$qty=$row['item_qty'];
			$receive_qty=$row['receive_qty'];
			$master_cutting_qty=$row['master_cutting_qty'];
			$karigor_name=$row['karigor_name'];
			$karigor_names=$row['karigor_names'];
			$karigor_name=($qty!=$receive_qty)? $karigor_name : $karigor_names;
			$master_name=($qty!=$master_cutting_qty)? $row['master_name'] : $row['master_names'];
			$cus_price=$row['cus_price'];
			$total=($qty*$cus_price);
			$making_item.="<tr>
				<td style='$font2 $padding'>
					$name
				</td>
				<td style='$font2 $padding'>
					$qty
				</td>
			</tr>";
			$making_item2.="<tr>
				<td style='$font2 $padding'>
					$mc
				</td>
				<td style='$font2 $padding'>
					$name
				</td>
				<td style='$font2 $padding;width:32px'>
					$qty
				</td>
				<td style='$font2 $align_right'>
					$cus_price
				</td>
				<td style='$font2 $align_right'>
					$total
				</td>
				<td style='$font2 $padding'>
					Wages
				</td>
			</tr>";
			$box1="";$item_heading="";$get_propertice="";$tbl_head="";
			$order_details_sql=$conn->query("SELECT measurement,(select title from measurement_head where id=ods.measure_id) measure_title FROM order_details ods WHERE ods.is_active=1 and ods.mtype=1 and ods.order_number='$code'");
			while($detail_row=mysqli_fetch_array($order_details_sql)){
				$measurement=$detail_row['measurement'];
				$measure_title=$detail_row['measure_title'];
				$box1.="<div style='float:left;text-align: center;padding-left:5px;padding-right:5px;margin-right: 1px;'>
					<p style='font-size: 10px;padding-top: 8px;text-align: center; line-height: 0px;'>$measure_title</p>
					<span style='margin-top: -3px;padding-left:3px;padding-right:3px;font-size: 15px;'>$measurement</span>
				</div>";
			}
			
			$get_propertice=getLeftPropertice($code,2).getChkPropertice($code,2).getTextPropertice($code,2);
			
			$tbl_head="<div style='overflow: hidden;
				width: 745px;
				padding-top: 2px;
				padding-bottom: 2px;'>
				<div style='float: left;
				width: 155px;
				font-size: 15px;
				padding-left: 5px;'>
				সিরিয়াল নং: $tag
				</div>
				<div style='float: left;
				padding-left: 6px;
				font-size: 15px;
				padding-right: 10px;'>
				ডেলিভারি: $karigor_dv_date
				</div>
				<div style='float: left;
				padding-left: 10px;font-size: 14px'>
				
				</div>
				<div style='float: left;
				padding-left: 30px;font-size: 15px;'>
				মাস্টার: $master_name
				</div>
				<div style='float: left;
				padding-left: 30px;font-size: 15px;'>
				কারিগর: $karigor_name
				</div>
			</div>";
			$item_heading.="<div style='margin-bottom:2px;'>
				
			    $tbl_head
				<table border='1' style='border-collapse: collapse;width:100%;'>
					
					<tr>
						<td style='$padding;width: 18%;font-size:14px;'>
							কোড  নং: $code 
						</td>
						<td style='$padding;width: 60%;font-size:14px;'>
							আইটেম: $name $qty পিছ
						</td>
						<td style='$font2 $padding;text-align: right;padding-right: 5px;'>
							
						</td>
					</tr>
					<tr>
						<td style='font-size:15px;padding-top: 2px;padding-left: 2px;padding-right: 2px;' colspan='3'>
							$get_propertice
						</td>
					</tr>
				</table>
			</div>";
			
			if($qty>0){
				$box3="";
				$qty=($qty>4)? 4 : $qty;
				for($j=0;$j<$qty;$j++){
					@$gnames=$group_array[0];
					$box3.="<div style='float: left;padding-top: 12px; height: 74px;border: 1px solid gray;margin-right:10px;margin-bottom: 10px;width: 186px; margin-top:2px;padding-left: 10px;'>
						<p style='line-height:5px;font-size:18px'>সিরিয়াল নং: $tag</p>
						<p style='line-height:5px'>কোড  নং: $code</p>
						<p style='line-height:5px'>$cus_name</p>
						<p style='line-height:5px'>গ্রুপ: $gnames</p>
					</div>";
				}
			}
			
			$full_measurement.="<div style='height: 340px;float:left;margin-top: 2px;width:796px;margin-right:5px;padding-bottom: 5px;margin-bottom: 15px;'><div style='width:792px;overflow: hidden;margin-left: 0px;'>
				$box3
				</div><div style='border: 1px solid black;height: 260px;'>
				$item_heading
				<div style='margin-bottom:2px;padding-left:2px'>
					$box1
				</div>
			</div></div>";
			
		}
		
		
		$sales_item="";$c=1;$mc=0;$total=0;
		while($row=mysqli_fetch_array($direct_sale_sql)){
			$mc=$c++;
			$name=$row['item_name'];
			$qty=$row['item_qty'];
			$price=$row['price'];
			$total=($price*$qty);
			$sales_item.="<tr>
				<td style='font-size:10px;width: 17px;$padding'>
					$mc
				</td>
				<td style='font-size:10px;width: 92px;$padding'>
					$name
				</td>
				<td style='font-size:10px;width: 26px;$padding'>
					$qty
				</td>
				<td style='font-size:10px;width: 33px;$align_right'>
					$price
				</td>
				<td style='font-size:10px;width: 51px;$align_right'>
					$total
				</td>
				<td style='font-size:10px;$padding'>
					গজ
				</td>
			</tr>";
		}
		if($_SESSION['ORDER_COPY']==1){
			$head="<tr>
				<th style='$font2 $align_right;width:154px'>
					পূর্বের বাকি
				</th>
				<td style='$font $align_right;width:72px'>
					$previous_due
				</td>
			</tr>";
			$tail="<tr>
				<th style='$font2 $align_right'>
					সর্বমোট বাকি
				</th>
				<td style='$font $align_right'>
					$total_due
				</td>
			</tr>";
		}else{
			$head="";
			$tail="";
		}
		//<img src='img/heading.JPG' style='height: 80px;'/>
		$receipt="<div style='overflow: hidden;margin-bottom: 30px;padding-bottom: 30px;border-bottom: 1px dotted gray;width:796px;'>
			<div style='width:796px;height:80px;margin-bottom: 2px;'>
				<img src='img/heading.JPG' style='height: 80px;width:795px'/>
			</div>
	<div style='float:left;width: 465px; margin-right: 5px;'>
		<table border='1' style='border-collapse: collapse;margin-right: 5px;width:100%'>
			<tr>
				<td style='$font $padding;width: 126px;'>
					সিরিয়াল নং:
				</td>
				<td style='$font $padding'>
					$tag
				</td>
				<td style='$font $padding'>
					বিক্রয়কারী :
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					অর্ডার তাং:
				</td>
				<td style='$font $padding'>
					$ord_date $ord_time
				</td>
				<td style='$font $padding'>
					$user_name
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					সম্ভাব্য ডেলিভারি :
				</td>
				<td style='$font $padding'>
					$date1
				</td>
				<td style='$font $padding'>
					$day
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					নাম:
				</td>
				
				<td style='$font $padding'>
					$cus_name
				</td>
				<td style='$font $padding'>
					$get_mobile
				</td>
				
			</tr>
		</table>
		<div style='overflow:hidden'>
			<div style='float:left;width:360px;height:115px;border: 1px solid gray;margin-top: 1px;margin-right:5px'>
				<img src='img/box.JPG' style='height: 113px; width: 357px;'/>
			</div>
			<div style='float: left;margin-top: 1px;'>
				<div style='width:100px;height: 50px;border: 1px solid gray;text-align: center;padding-top: 12px;'>
				নমুনা
				</div>
				<div style='width:100px;padding-top: 8px;text-align:center'>
				-------
				</div>
				<div style='width:100px;text-align:center;font-size: 10px;'>
				Authority<br/>Signature
				</div>
			</div>
			
		</div>
	</div>
	<div style='float:left;width: 200px;margin-right: 5px;'>
		<table border='1' style='border-collapse: collapse;width:100%'>
			<tr>
				<th style='$font $padding'>
					বিবরণ 
				</th>
				<th style='$font $padding'>
					সংখ্যা
				</th>
			</tr>
			$making_item
		</table>
	</div>
	<div style=''>
		<table border='1' style='border-collapse: collapse;width: 120px;'>
			$head
			<tr>
				<th style='$font2 $align_right'>
					মোট টাকা
				</th>
				<td style='$font $align_right'>
					$total_tk2
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					স্টাইল
				</th>
				<td style='$font $align_right'>
					$design_charge
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					অন্যান্য খরচ
				</th>
				<td style='$font $align_right'>
					$others_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					ছাড় (%)			
				</th>
				<td style='$font.$align_right'>
					
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					ছাড় (টাকা)			
				</th>
				<td style='$font $align_right'>
					$discount_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					সর্বমোট টাকা		
				</th>
				<td style='$font $align_right'>
					$total_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					অগ্রিম
				</th>
				<td style='$font $align_right'>
					$advance_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					বর্তমান বাকি
				</th>
				<td style='$font $align_right'>
					$present_due
				</td>
			</tr>
			$tail
		</table>
	</div>
</div>


	
</div>

<div style='overflow:hidden;width:796px;margin-top: 0px;'>
	$full_measurement
	
</div>";

return $receipt;
	}

function onlyCodePrint($tag){
		include'db.php';
		
		$font="font-size:12px;font-weight: bold;";
		$font2="font-size:10px;";
		$align_right="text-align:right;padding-right: 2px;";
		$td="width: 131px;";
		$padding="padding-left:4px;";
		
		$box2="";
		$box3="";
		$codes="";
		$print_qty="";
		$com_id=($_SESSION['COM_ID']);
	
		$ex_tag=explode('-',$tag);
		if(count($ex_tag)>1){
			$tag=$ex_tag[0];
			if(count($ex_tag)==2 || count($ex_tag)==3){
				$codes=$ex_tag[1];
				$codes=" and ord.id=$codes ";
			}
			if(count($ex_tag)==3){
				$print_qty=$ex_tag[2];
			}
		}
	$dsms_sql=$conn->query("SELECT date(ord.insert_date) ord_date,time(ord.insert_date) ord_time,ord.fddate,ord.dv_date,ord.amount,ord.cus_name,ord.cus_mobile,ord.discount,ord.design_cost,ord.others_tk,
	(SELECT sum(`amount`) FROM `accounting` WHERE `dsms_id`=ord.id and `pay_status` in(0,1)) advance_tk,
	(select user_name from user where id=ord.insert_by) user_name,ord.previous_total_due
	from dsms ord WHERE ord.com_id=$com_id and ord.is_active=1 and ord.phy_ord_num='$tag'");
	if(mysqli_num_rows($dsms_sql)>0){
		$dsms_row=mysqli_fetch_array($dsms_sql);
		
		$cus_name=$dsms_row['cus_name'];
		
		$user_name=$dsms_row['user_name'];
		
	}else{
		return "Warning! Wrong Serial No.";
		exit;
	}
	
	$order_record_sql=$conn->query("SELECT ord.id,(select cus_price from product where id=ord.item_id) cus_price,(select product_name from product where id=ord.item_id) item_name,ord.item_qty,ord.group_name FROM order_record ord WHERE ord.com_id=$com_id $codes and ord.is_active=1 and ord.order_number='$tag'");
	//$direct_sale_sql=$conn->query("SELECT ds.item_qty,(select product_name from product where id=ds.item_id) item_name,ds.price FROM direct_sale ds WHERE ds.com_id=$com_id and ds.is_active=1 and ds.order_number='$tag'");
	
	
	$cus_name=substr($cus_name,0,80);
		
		$making_item="";$making_item2="";$full_measurement="";
		$c=1;$mc=0;$total=0;
		while($row=mysqli_fetch_array($order_record_sql)){
			$mc=$c++;
			$code=$row['id'];
			if($row['group_name']!=""){
				$group_array=explode(",",$row['group_name']);
			}else{
				$group_array=array();
			}
			$qty=$row['item_qty'];
			
			$box1="";$item_heading="";$get_propertice="";$tbl_head="";
		
		
			
			if($qty>0){
				$box3="";
				if($print_qty==""){
					$qty=($qty>4)? ($qty-4) : $qty;
					for($j=0;$j<$qty;$j++){
						@$gnames=$group_array[0];
						$box3.="<div style='float: left;padding-top: 12px; height: 74px;border: 1px solid gray;margin-right:10px;margin-bottom: 10px;width: 186px; margin-top:2px;padding-left: 10px;'>
							<p style='line-height:5px;font-size:18px'>সিরিয়াল নং: $tag</p>
							<p style='line-height:5px'>কোড  নং: $code</p>
							<p style='line-height:5px'>$cus_name</p>
							<p style='line-height:5px'>গ্রুপ: $gnames</p>
						</div>";
					}
				}else{
					//$qty=($qty>4)? ($qty-4) : $qty;
					for($j=0;$j<$print_qty;$j++){
						@$gnames=$group_array[0];
						$box3.="<div style='float: left;padding-top: 12px; height: 74px;border: 1px solid gray;margin-right:10px;margin-bottom: 10px;width: 186px; margin-top:2px;padding-left: 10px;'>
							<p style='line-height:5px;font-size:18px'>সিরিয়াল নং: $tag</p>
							<p style='line-height:5px'>কোড  নং: $code</p>
							<p style='line-height:5px'>$cus_name</p>
							<p style='line-height:5px'>গ্রুপ: $gnames</p>
						</div>";
					}
				}
			}
			
			$full_measurement.="<div style='float:left;margin-top: 2px;width:796px;margin-right:5px;padding-bottom: 5px;margin-bottom: 15px;'><div style='width:792px;overflow: hidden;margin-left: 0px;'>
				$box3
			</div></div>";
			
		}
		
		
$receipt="<div style='overflow:hidden;width:796px;margin-top: 0px;'>
	$full_measurement
	
</div>";

return $receipt;
}
	
	function printMoneyReceiptOnlyMeasurment2($tag){
		include'db.php';
		date_default_timezone_set("Asia/Dhaka");
		$time=date("h:i:s A");
		$font="font-size:12px;font-weight: bold;";
		$font2="font-size:10px;";
		$align_right="text-align:right;padding-right: 2px;";
		$td="width: 131px;";
		$padding="padding-left:4px;";
		
		$box2="";
		$box3="";
		$com_id=($_SESSION['COM_ID']);
		$max_dsms=$_SESSION['MAX_DSMS'];
		$max_order_record=$_SESSION['MAX_ORDER_RECORD'];
		$max_order_details=$_SESSION['MAX_ORDER_DETAILS'];
		$max_direct_sale=$_SESSION['MAX_DIRECT_SALE'];
		
	$dsms_sql=$conn->query("SELECT date(ord.insert_date) ord_date,time(ord.insert_date) ord_time,ord.fddate,ord.dv_date,ord.amount,ord.cus_name,ord.cus_mobile,ord.discount,ord.design_cost,ord.others_tk,
	(SELECT sum(`amount`) FROM `accounting` WHERE `dsms_id`=ord.id and `pay_status` in(0,1)) advance_tk,
	(select user_name from user where id=ord.insert_by) user_name,ord.previous_total_due
	from dsms ord WHERE ord.com_id=$com_id and ord.is_active=1 and ord.phy_ord_num='$tag'");
	if(mysqli_num_rows($dsms_sql)>0){
		$dsms_row=mysqli_fetch_array($dsms_sql);
		$date1=$dsms_row['dv_date'];
		$karigor_dv_date=$dsms_row['fddate'];
		$cus_name=$dsms_row['cus_name'];
		$ord_time=date('h:i A', strtotime($dsms_row['ord_time']));
		$get_mobile=$dsms_row['cus_mobile'];
		$ex2=explode("-",$dsms_row['ord_date']); // order date
		$total_tk=$dsms_row['amount'];
		$others_tk=intval($dsms_row['others_tk']);
		$design_charge=intval($dsms_row['design_cost']);
		$discount_tk=$dsms_row['discount'];
		$previous_due=$dsms_row['previous_total_due'];
		//$total_due=$dsms_row['present_due'];
		$advance_tk=$dsms_row['advance_tk'];
		$user_name=$dsms_row['user_name'];
		
	}else{
		return "Warning! Wrong Serial No.";
		exit;
	}
	$order_record_sql=$conn->query("SELECT ord.id,(select cus_price from product where id=ord.item_id) cus_price,(select product_name from product where id=ord.item_id) item_name,ord.item_qty,ord.group_name,ord.receive_qty,ord.master_cutting_qty,(select user_name from user where id=ord.karigor_id) karigor_name,(select user_name from user where id=ord.maker) karigor_names,(select user_name from user where id=ord.master_id) master_name,(select user_name from user where id=ord.master_emp_id) master_names FROM order_record ord WHERE ord.com_id=$com_id and ord.is_active=1 and ord.order_number='$tag'");

	//$order_record_sql=$conn->query("SELECT ord.id,(select cus_price from product where id=ord.item_id) cus_price,(select product_name from product where id=ord.item_id) item_name,ord.item_qty,ord.group_name FROM order_record ord WHERE ord.com_id=$com_id and ord.is_active=1 and ord.order_number='$tag'");
	//$direct_sale_sql=$conn->query("SELECT ds.item_qty,(select product_name from product where id=ds.item_id) item_name,ds.price FROM direct_sale ds WHERE ds.com_id=$com_id and ds.is_active=1 and ds.order_number='$tag'");
	
	$total_tk2=($total_tk-$others_tk-$design_charge+$discount_tk);
	$present_due=($total_tk-$advance_tk);
	$total_due=($present_due+$previous_due);
	$cus_name=substr($cus_name,0,80);
		$ex=explode("-",$date1);
		$date1=$ex[2]."/".$ex[1]."/".$ex[0];
		$day=date('l', strtotime($ex[2]."-".$ex[1]."-".$ex[0]));
		$ord_date=$ex2[2]."/".$ex2[1]."/".$ex2[0];
		$making_item="";$making_item2="";$full_measurement="";
		$c=1;$mc=0;$total=0;
		while($row=mysqli_fetch_array($order_record_sql)){
			$mc=$c++;
			$code=$row['id'];
			if($row['group_name']!=""){
				$group_array=explode(",",$row['group_name']);
			}else{
				$group_array=array();
			}
			
			$name=$row['item_name'];
			$qty=$row['item_qty'];
			$cus_price=$row['cus_price'];
			$receive_qty=$row['receive_qty'];
			$master_cutting_qty=$row['master_cutting_qty'];
			$karigor_name=$row['karigor_name'];
			$karigor_names=$row['karigor_names'];
			$karigor_name=($qty!=$receive_qty)? $karigor_name : $karigor_names;
			$master_name=($qty!=$master_cutting_qty)? $row['master_name'] : $row['master_names'];
			
			
			$total=($qty*$cus_price);
			$making_item.="<tr>
				<td style='$font2 $padding'>
					$name
				</td>
				<td style='$font2 $padding'>
					$qty
				</td>
			</tr>";
			$making_item2.="<tr>
				<td style='$font2 $padding'>
					$mc
				</td>
				<td style='$font2 $padding'>
					$name
				</td>
				<td style='$font2 $padding;width:32px'>
					$qty
				</td>
				<td style='$font2 $align_right'>
					$cus_price
				</td>
				<td style='$font2 $align_right'>
					$total
				</td>
				<td style='$font2 $padding'>
					Wages
				</td>
			</tr>";
			$box1="";$item_heading="";$get_propertice="";$tbl_head="";
			$order_details_sql=$conn->query("SELECT measurement,(select title from measurement_head where id=ods.measure_id) measure_title FROM order_details ods WHERE ods.is_active=1 and ods.mtype=1 and ods.order_number='$code'");
			while($detail_row=mysqli_fetch_array($order_details_sql)){
				$measurement=$detail_row['measurement'];
				$measure_title=$detail_row['measure_title'];
				$box1.="<div style='float:left;text-align: center;padding-left:5px;padding-right:5px;margin-right: 1px;'>
					<p style='font-size: 10px;padding-top: 8px;text-align: center; line-height: 0px;'>$measure_title</p>
					<span style='margin-top: -3px;padding-left:3px;padding-right:3px;font-size: 15px;'>$measurement</span>
				</div>";
			}
			
			$get_propertice=getLeftPropertice($code,2).getChkPropertice($code,2).getTextPropertice($code,2);
			
			$tbl_head="<div style='overflow: hidden;
				width: 745px;
				padding-top: 2px;
				padding-bottom: 2px;'>
				<div style='float: left;
				width: 155px;
				font-size: 15px;
				padding-left: 5px;'>
				সিরিয়াল নং: $tag
				</div>
				<div style='float: left;
				padding-left: 6px;
				font-size: 15px;
				padding-right: 10px;'>
				ডেলিভারি: $karigor_dv_date
				</div>
				<div style='float: left;
				padding-left: 10px;font-size: 14px;'>
				
				</div>
				<div style='float: left;
				padding-left: 30px;font-size: 15px;'>
				মাস্টার: $master_name
				</div>
				<div style='float: left;
				padding-left: 30px;font-size: 15px;'>
				কারিগর: $karigor_name
				</div>
			</div>";
			$item_heading.="<div style='margin-bottom:2px;'>
				
			    $tbl_head
				<table border='1' style='border-collapse: collapse;width:100%;'>
					
					<tr>
						<td style='$padding;width: 18%;font-size:14px;'>
							কোড  নং: $code 
						</td>
						<td style='$padding;width: 60%;font-size:14px;'>
							আইটেম: $name $qty পিছ
						</td>
						<td style='$font2 $padding;text-align: right;padding-right: 5px;'>
							
						</td>
					</tr>
					<tr>
						<td style='font-size:15px;padding-top: 2px;padding-left: 2px;padding-right: 2px;' colspan='3'>
							$get_propertice
						</td>
					</tr>
				</table>
			</div>";
			
			if($qty>0){
				$box3="";
				$qty=($qty>4)? 4 : $qty;
				for($j=0;$j<$qty;$j++){
					@$gnames=$group_array[0];
					$box3.="<div style='float: left;padding-top: 12px; height: 74px;border: 1px solid gray;margin-right:10px;margin-bottom: 10px;width: 186px; margin-top:2px;padding-left: 10px;'>
						<p style='line-height:5px;font-size:18px'>সিরিয়াল নং: $tag</p>
						<p style='line-height:5px'>কোড  নং: $code</p>
						<p style='line-height:5px'>$cus_name</p>
						<p style='line-height:5px'>গ্রুপ: $gnames</p>
					</div>";
				}
			}
			
			$full_measurement.="<div style='height: 340px;float:left;margin-top: 2px;width:796px;margin-right:5px;padding-bottom: 5px;margin-bottom: 15px;'><div style='width:792px;overflow: hidden;margin-left: 0px;'>
				$box3
				</div><div style='border: 1px solid black;height: 260px;'>
				$item_heading
				<div style='margin-bottom:2px;padding-left:2px'>
					$box1
				</div>
			</div></div>";
			
		}
		
		
$receipt="<div style='overflow:hidden;width:796px;margin-top: 0px;'>
	$full_measurement
	
</div>";

return $receipt;
	}

	function printMoneyReceiptOnlyCustomer2($tag){
		include'db.php';
		date_default_timezone_set("Asia/Dhaka");
		$time=date("h:i:s A");
		$font="font-size:12px;font-weight: bold;";
		$font2="font-size:10px;";
		$align_right="text-align:right;padding-right: 2px;";
		$td="width: 131px;";
		$padding="padding-left:4px;";
		
		$box2="";
		$box3="";
		$com_id=($_SESSION['COM_ID']);
		$max_dsms=$_SESSION['MAX_DSMS'];
		$max_order_record=$_SESSION['MAX_ORDER_RECORD'];
		$max_order_details=$_SESSION['MAX_ORDER_DETAILS'];
		$max_direct_sale=$_SESSION['MAX_DIRECT_SALE'];
		
	$dsms_sql=$conn->query("SELECT date(ord.insert_date) ord_date,time(ord.insert_date) ord_time,ord.fddate,ord.dv_date,ord.amount,ord.cus_name,ord.cus_mobile,ord.discount,ord.design_cost,ord.others_tk,
	(SELECT sum(`amount`) FROM `accounting` WHERE `dsms_id`=ord.id and is_active=1 and `pay_status` in(0,1)) advance_tk,
	(select user_name from user where id=ord.insert_by) user_name,ord.previous_total_due
	from dsms ord WHERE ord.com_id=$com_id and ord.is_active=1 and ord.phy_ord_num='$tag'");
	if(mysqli_num_rows($dsms_sql)>0){
		$dsms_row=mysqli_fetch_array($dsms_sql);
		$date1=$dsms_row['dv_date'];
		$karigor_dv_date=$dsms_row['fddate'];
		$cus_name=$dsms_row['cus_name'];
		$ord_time=date('h:i A', strtotime($dsms_row['ord_time']));
		$get_mobile=$dsms_row['cus_mobile'];
		$ex2=explode("-",$dsms_row['ord_date']); // order date
		$total_tk=$dsms_row['amount'];
		$others_tk=intval($dsms_row['others_tk']);
		$design_charge=intval($dsms_row['design_cost']);
		$discount_tk=$dsms_row['discount'];
		$previous_due=$dsms_row['previous_total_due'];
		//$total_due=$dsms_row['present_due'];
		$advance_tk=$dsms_row['advance_tk'];
		$user_name=$dsms_row['user_name'];
		
	}else{
		return "Warning! Wrong Serial No.";
		exit;
	}
	$order_record_sql=$conn->query("SELECT ord.id,(select cus_price from product where id=ord.item_id) cus_price,(select product_name from product where id=ord.item_id) item_name,ord.item_qty,ord.group_name FROM order_record ord WHERE ord.com_id=$com_id and ord.is_active=1 and ord.order_number='$tag'");
	//$direct_sale_sql=$conn->query("SELECT ds.item_qty,(select product_name from product where id=ds.item_id) item_name,ds.price FROM direct_sale ds WHERE ds.com_id=$com_id and ds.is_active=1 and ds.order_number='$tag'");
	
	$total_tk2=($total_tk-$others_tk-$design_charge+$discount_tk);
	$present_due=($total_tk-$advance_tk);
	$total_due=($present_due+$previous_due);
	$cus_name=substr($cus_name,0,80);
		$ex=explode("-",$date1);
		$date1=$ex[2]."/".$ex[1]."/".$ex[0];
		$day=date('l', strtotime($ex[2]."-".$ex[1]."-".$ex[0]));
		$ord_date=$ex2[2]."/".$ex2[1]."/".$ex2[0];
		$making_item="";$making_item2="";$full_measurement="";
		$c=1;$mc=0;$total=0;
		while($row=mysqli_fetch_array($order_record_sql)){
			$mc=$c++;
			$code=$row['id'];
			if($row['group_name']!=""){
				$group_array=explode(",",$row['group_name']);
			}else{
				$group_array=array();
			}
			
			$name=$row['item_name'];
			$qty=$row['item_qty'];
			$cus_price=$row['cus_price'];
			$total=($qty*$cus_price);
			$making_item.="<tr>
				<td style='$font2 $padding'>
					$name
				</td>
				<td style='$font2 $padding'>
					$qty
				</td>
			</tr>";
			
			
		}
		
		$sales_item="";$c=1;$mc=0;$total=0;
		/*while($row=mysqli_fetch_array($direct_sale_sql)){
			$mc=$c++;
			$name=$row['item_name'];
			$qty=$row['item_qty'];
			$price=$row['price'];
			$total=($price*$qty);
			$sales_item.="<tr>
				<td style='font-size:10px;width: 17px;$padding'>
					$mc
				</td>
				<td style='font-size:10px;width: 92px;$padding'>
					$name
				</td>
				<td style='font-size:10px;width: 26px;$padding'>
					$qty
				</td>
				<td style='font-size:10px;width: 33px;$align_right'>
					$price
				</td>
				<td style='font-size:10px;width: 51px;$align_right'>
					$total
				</td>
				<td style='font-size:10px;$padding'>
					গজ
				</td>
			</tr>";
		}*/
		if($_SESSION['ORDER_COPY']==1){
			$head="<tr>
				<th style='$font2 $align_right;width:154px'>
					পূর্বের বাকি
				</th>
				<td style='$font $align_right;width:72px'>
					$previous_due
				</td>
			</tr>";
			$tail="<tr>
				<th style='$font2 $align_right'>
					সর্বমোট বাকি
				</th>
				<td style='$font $align_right'>
					$total_due
				</td>
			</tr>";
		}else{
			$head="";
			$tail="";
		}
		//<img src='img/heading.JPG' style='height: 80px;'/>
		$receipt="<div style='overflow: hidden;margin-bottom: 30px;padding-bottom: 30px;border-bottom: 1px dotted gray;width:796px;'>
			<div style='width:796px;height:80px;margin-bottom: 2px;'>
				<img src='img/heading.JPG' style='height: 80px;width:795px'/>
			</div>
	<div style='float:left;width: 465px; margin-right: 5px;'>
		<table border='1' style='border-collapse: collapse;margin-right: 5px;width:100%'>
			<tr>
				<td style='$font $padding;width: 126px;'>
					সিরিয়াল নং:
				</td>
				<td style='$font $padding'>
					$tag
				</td>
				<td style='$font $padding'>
					বিক্রয়কারী :
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					অর্ডার তাং:
				</td>
				<td style='$font $padding'>
					$ord_date $ord_time
				</td>
				<td style='$font $padding'>
					$user_name
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					সম্ভাব্য ডেলিভারি :
				</td>
				<td style='$font $padding'>
					$date1
				</td>
				<td style='$font $padding'>
					$day
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					নাম:
				</td>
				
				<td style='$font $padding'>
					$cus_name
				</td>
				<td style='$font $padding'>
					$get_mobile
				</td>
				
			</tr>
		</table>
		<div style='overflow:hidden'>
			<div style='float:left;width:360px;height:115px;border: 1px solid gray;margin-top: 1px;margin-right:5px'>
				<img src='img/box.JPG' style='height: 113px; width: 357px;'/>
			</div>
			<div style='float: left;margin-top: 1px;'>
				<div style='width:100px;height: 50px;border: 1px solid gray;text-align: center;padding-top: 12px;'>
				নমুনা
				</div>
				<div style='width:100px;padding-top: 8px;text-align:center'>
				-------
				</div>
				<div style='width:100px;text-align:center;font-size: 10px;'>
				Authority<br/>Signature
				</div>
			</div>
			
		</div>
	</div>
	<div style='float:left;width: 200px;margin-right: 5px;'>
		<table border='1' style='border-collapse: collapse;width:100%'>
			<tr>
				<th style='$font $padding'>
					বিবরণ 
				</th>
				<th style='$font $padding'>
					সংখ্যা
				</th>
			</tr>
			$making_item
		</table>
	</div>
	<div style=''>
		<table border='1' style='border-collapse: collapse;width: 120px;'>
			$head
			<tr>
				<th style='$font2 $align_right'>
					মোট টাকা
				</th>
				<td style='$font $align_right'>
					$total_tk2
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					স্টাইল
				</th>
				<td style='$font $align_right'>
					$design_charge
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					অন্যান্য খরচ
				</th>
				<td style='$font $align_right'>
					$others_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					ছাড় (%)			
				</th>
				<td style='$font.$align_right'>
					
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					ছাড় (টাকা)			
				</th>
				<td style='$font $align_right'>
					$discount_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					সর্বমোট টাকা		
				</th>
				<td style='$font $align_right'>
					$total_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					অগ্রিম
				</th>
				<td style='$font $align_right'>
					$advance_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					বর্তমান বাকি
				</th>
				<td style='$font $align_right'>
					$present_due
				</td>
			</tr>
			$tail
		</table>
	</div>
</div>


	
</div>

<div style='overflow:hidden;width:796px;margin-top: 0px;'>
	$full_measurement
	
</div>";

return $receipt;
	}
	
	
function printMoneyReceipt13($tag){
		include'db.php';
		date_default_timezone_set("Asia/Dhaka");
		$time=date("h:i:s A");
		$font="font-size:9px;font-weight: bold;";
		$font2="font-size:9px;";
		$align_right="text-align:right;padding-right: 2px;";
		$td="width: 131px;";
		$padding="padding-left:4px;";
		
		$box2="";
		$box3="";
		$com_id=($_SESSION['COM_ID']);
		$max_dsms=$_SESSION['MAX_DSMS'];
		$max_order_record=$_SESSION['MAX_ORDER_RECORD'];
		$max_order_details=$_SESSION['MAX_ORDER_DETAILS'];
		$max_direct_sale=$_SESSION['MAX_DIRECT_SALE'];
		
	$dsms_sql=$conn->query("SELECT date(ord.insert_date) ord_date,time(ord.insert_date) ord_time,ord.fddate,ord.dv_date,ord.amount,ord.cus_name,ord.cus_mobile,ord.discount,ord.design_cost,ord.others_tk,
	(SELECT sum(`amount`) FROM `accounting` WHERE `dsms_id`=ord.id and is_active=1 and `pay_status` in(0,1)) advance_tk,
	(select user_name from user where id=ord.insert_by) user_name,ord.previous_total_due
	from dsms ord WHERE ord.com_id=$com_id and ord.is_active=1 and ord.phy_ord_num='$tag'");
	if(mysqli_num_rows($dsms_sql)>0){
		$dsms_row=mysqli_fetch_array($dsms_sql);
		$date1=$dsms_row['dv_date'];
		$karigor_dv_date=$dsms_row['fddate'];
		$cus_name=$dsms_row['cus_name'];
		$ord_time=date('h:i A', strtotime($dsms_row['ord_time']));
		$get_mobile=$dsms_row['cus_mobile'];
		$ex2=explode("-",$dsms_row['ord_date']); // order date
		$total_tk=$dsms_row['amount'];
		$others_tk=intval($dsms_row['others_tk']);
		$design_charge=intval($dsms_row['design_cost']);
		$discount_tk=$dsms_row['discount'];
		$previous_due=$dsms_row['previous_total_due'];
		//$total_due=$dsms_row['present_due'];
		$advance_tk=$dsms_row['advance_tk'];
		$user_name=$dsms_row['user_name'];
		
	}else{
		return "Warning! Wrong Serial No.";
		exit;
	}
	
	if($discount_tk==0 || $discount_tk==""){
		$title_tr="";
	}else{
		$title_tr="<tr>
				<th style='$font2 $align_right'>
					ছাড় (%)			
				</th>
				<td style='$font.$align_right'>
					
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					ছাড় (টাকা)			
				</th>
				<td style='$font $align_right'>
					$discount_tk
				</td>
			</tr>";
	}
	$order_record_sql=$conn->query("SELECT ord.id,(select cus_price from product where id=ord.item_id) cus_price,(select product_name from product where id=ord.item_id) item_name,ord.item_qty,ord.group_name FROM order_record ord WHERE ord.com_id=$com_id and ord.is_active=1 and ord.order_number='$tag'");
	$direct_sale_sql=$conn->query("SELECT ds.item_qty,(select product_name from product where id=ds.item_id) item_name,ds.price FROM direct_sale ds WHERE ds.com_id=$com_id and ds.is_active=1 and ds.order_number='$tag'");
	
	$total_tk2=($total_tk-$others_tk-$design_charge+$discount_tk);
	$present_due=($total_tk-$advance_tk);
	$total_due=($present_due+$previous_due);
	$cus_name=substr($cus_name,0,20);
		$ex=explode("-",$date1);
		$date1=$ex[2]."/".$ex[1]."/".$ex[0];
		$day=date('l', strtotime($ex[2]."-".$ex[1]."-".$ex[0]));
		$ord_date=$ex2[2]."/".$ex2[1]."/".$ex2[0];
		$making_item="";$making_item2="";$full_measurement="";
		$c=1;$mc=0;$total=0;
		while($row=mysqli_fetch_array($order_record_sql)){
			$mc=$c++;
			$code=$row['id'];
			if($row['group_name']!=""){
				$group_array=explode(",",$row['group_name']);
			}else{
				$group_array=array();
			}
			
			$name=$row['item_name'];
			$qty=$row['item_qty'];
			$cus_price=$row['cus_price'];
			$total=($qty*$cus_price);
			$making_item.="<tr>
				<td style='$font2 $padding'>
					$name
				</td>
				<td style='$font2 $padding'>
					$qty
				</td>
			</tr>";
			$making_item2.="<tr>
				<td style='$font2 $padding'>
					$mc
				</td>
				<td style='$font2 $padding'>
					$name
				</td>
				<td style='$font2 $padding;width:32px'>
					$qty
				</td>
				<td style='$font2 $align_right'>
					$cus_price
				</td>
				<td style='$font2 $align_right'>
					$total
				</td>
				<td style='$font2 $padding'>
					Wages
				</td>
			</tr>";
			$box1="";$item_heading="";$get_propertice="";$tbl_head="";
			$order_details_sql=$conn->query("SELECT measurement,(select title from measurement_head where id=ods.measure_id) measure_title FROM order_details ods WHERE ods.is_active=1 and ods.mtype=1 and ods.order_number='$code'");
			while($detail_row=mysqli_fetch_array($order_details_sql)){
				$measurement=$detail_row['measurement'];
				$measure_title=$detail_row['measure_title'];
				$box1.="<div style='float:left;text-align: center;padding-left:3px;padding-right:3px;margin-right: 1px;'>
					<p style='font-size: 9px;padding-top: 8px;text-align: center; line-height: 0px;'>$measure_title</p>
					<span style='margin-top: -3px;padding-left:3px;padding-right:3px;font-size: 9px;'>$measurement</span>
				</div>";
			}
			
			$get_propertice=getLeftPropertice($code,2).getChkPropertice($code,2).getTextPropertice($code,2);
			
			$tbl_head="<div style='overflow: hidden;
				width: 260px;
				font-size: 9px;
				
				padding-top: 2px;
				padding-bottom: 2px;'>
				<div style='float: left;
				width: 104px;
				
				padding-left: 5px;'>
				সিরিয়াল নং: $tag
				</div>
				<div style='float: left;
				padding-left: 6px;
				
				padding-right: 9px;'>
				ডেলিভারি: $karigor_dv_date
				</div>
				<div style='float: left;
				padding-left: 10px;font-size: 9px;'>
				সংখ্যা: $qty 
				</div>
			</div>";
			$item_heading.="<div style='margin-bottom:2px;'>
				
			    $tbl_head
				<table border='1' style='border-collapse: collapse;width:100%;'>
					
					<tr>
						<td style='$padding;width: 18%;font-size:9px;'>
							আইটেম
						</td>
						<td style='$padding;width: 58%;font-size:9px;'>
							$name
						</td>
						<td style='$font2 $padding;text-align: right;padding-right: 2px;'>
							কোড  নং: $code 
						</td>
					</tr>
					<tr>
						<td style='font-size:9px;padding-top: 2px;padding-left: 2px;padding-right: 2px;' colspan='3'>
							$get_propertice
						</td>
					</tr>
				</table>
			</div>";
			
			if($qty>0){
				$box3="";
				$qty=($qty>2)? 2 : $qty;
				for($j=0;$j<$qty;$j++){
					@$gnames=$group_array[0];
					$box3.="<div style='float: left;padding-top: 12px; height: 52px;border: 1px solid gray;margin-right:10px;margin-bottom: 10px;width: 105px; margin-top:2px;padding-left: 10px;'>
						<p style='line-height:0px;font-size:9px'>সিরিয়াল নং: $tag</p>
						<p style='line-height:0px;font-size:9px'>কোড  নং: $code</p>
						<p style='line-height:0px;font-size:9px'>$cus_name</p>
						<p style='line-height:0px;font-size:9px'>গ্রুপ: $gnames</p>
					</div>";
				}
			}
			
			$full_measurement.="<div style='float:left;margin-top: 2px;width:259px;margin-right:5px;padding-bottom: 3px;margin-bottom: 3px;'><div style='width:186px;overflow: hidden;margin-left: 0px;'>
				$box3
				</div><div style='border: 1px solid black;height: 158px;'>
				$item_heading
				<div style='margin-bottom:2px;padding-left:2px'>
					$box1
				</div>
			</div></div>";
			
		}
		
		
		$sales_item="";$c=1;$mc=0;$total=0;
		while($row=mysqli_fetch_array($direct_sale_sql)){
			$mc=$c++;
			$name=$row['item_name'];
			$qty=$row['item_qty'];
			$price=$row['price'];
			$total=($price*$qty);
			$sales_item.="<tr>
				<td style='font-size:9px;width: 17px;$padding'>
					$mc
				</td>
				<td style='font-size:9px;width: 92px;$padding'>
					$name
				</td>
				<td style='font-size:9px;width: 26px;$padding'>
					$qty
				</td>
				<td style='font-size:9px;width: 33px;$align_right'>
					$price
				</td>
				<td style='font-size:9px;width: 51px;$align_right'>
					$total
				</td>
				<td style='font-size:9px;$padding'>
					গজ
				</td>
			</tr>";
		}
		if($_SESSION['ORDER_COPY']==1){
			$head="<tr>
				<th style='$font2 $align_right;width:154px'>
					পূর্বের বাকি
				</th>
				<td style='$font $align_right;width:72px'>
					$previous_due
				</td>
			</tr>";
			$tail="<tr>
				<th style='$font2 $align_right'>
					সর্বমোট বাকি
				</th>
				<td style='$font $align_right'>
					$total_due
				</td>
			</tr>";
		}else{
			$head="";
			$tail="";
		}
		$second_receipt="<div style='overflow: hidden;margin-bottom: 2px;border-bottom: 1px dotted gray;width:529px;margin-top:2px;margin-left: 85px;'>
	<div style='float:left; margin-right: 5px;width: 188px;'>
		<table border='1' style='border-collapse: collapse;margin-right: 5px;width:100%'>
			<tr>
				<td style='$font $padding;width: 12%;'>
					সিরিয়াল নং:
				</td>
				<td style='$font $td $padding;width: 3%;'>
					$tag
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					অর্ডার তাং:
				</td>
				<td style='$font $padding'>
					$ord_date $ord_time
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					ডেলিভারি  তাং:
				</td>
				<td style='$font $padding'>
					$date1($day)
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					নাম:
				</td>
				
				<td style='$font $padding'>
					$cus_name
				</td>
				
				
			</tr>
			<tr>
				<td style='$font $padding'>
					মোবাইল  নং:
				</td>
				
				<td style='$font $padding'>
					$get_mobile
				</td>
				
			</tr>
		</table>
		<div style='overflow:hidden'>
			
			<div style='float: left;margin-top: 1px;'>
				<div style='width:100px;height: 50px;border: 1px solid gray;text-align: center;padding-top: 12px;'>
				নমুনা
				</div>
				
			</div>
			
		</div>
	</div>
	<div style='float:left;width: 211px;margin-right: 5px;'>
		<table border='1' style='border-collapse: collapse;width:100%'>
			<tr>
				<th style='font-size:9px;width: 17px;'>
					নং
				</th>
				<th style='font-size:9px;width: 92px;$padding'>
					বিবরণ 
				</th>
				<th style='font-size:9px;width: 32px;$padding'>
					সংখ্যা
				</th>
				<th style='font-size:9px;width: 33px;$align_right'>
					দর
				</th>
				<th style='font-size:9px;width: 51px;$align_right'>
					মোট
				</th>
				<th style='font-size:9px;$padding'>
					পদ্ধতি
				</th>
			</tr>
			$making_item2
		</table>
		<table border='1' style='border-collapse: collapse;width:100%;margin-top: 1px;'>
			$sales_item
		</table>
	</div>
	<div style='margin-bottom:2px;'>
		<table border='1' style='border-collapse: collapse;width: 120px;'>
			$head 
			<tr>
				<th style='$font2 $align_right'>
					মোট টাকা
				</th>
				<td style='$font $align_right'>
					$total_tk2
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					স্টাইল
				</th>
				<td style='$font $align_right'>
					$design_charge
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					অন্যান্য খরচ
				</th>
				<td style='$font $align_right'>
					$others_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					ছাড় (%)			
				</th>
				<td style='$font.$align_right'>
					
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					ছাড় (টাকা)			
				</th>
				<td style='$font $align_right'>
					$discount_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					সর্বমোট টাকা		
				</th>
				<td style='$font $align_right'>
					$total_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					অগ্রিম
				</th>
				<td style='$font $align_right'>
					$advance_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					বর্তমান বাকি
				</th>
				<td style='$font $align_right'>
					$present_due
				</td>
			</tr>
			$tail 
		</table>
	</div>
</div>";
		//<img src='img/heading.JPG' style='height: 80px;'/>
		$receipt="<div style='overflow: hidden;margin-bottom: 2px;padding-bottom: 2px;border-bottom: 1px dotted gray;width:529px;margin-left: 85px;'>
			<div style='width:529px;height:80px;margin-bottom: 2px;'>
				<img src='img/heading.JPG' style='height: 80px;width:529px'/>
			</div>
	<div style='float:left;width: 237px; margin-right: 5px;'>
		<table border='1' style='border-collapse: collapse;margin-right: 5px;width:100%'>
			<tr>
				<td style='$font $padding;width: 126px;'>
					সিরিয়াল নং:
				</td>
				<td style='$font $padding;width: 35%;'>
					$tag
				</td>
				<td style='$font $padding;width: 35%;'>
					বিক্রয়কারী :
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					অর্ডার তাং:
				</td>
				<td style='$font $padding'>
					$ord_date $ord_time
				</td>
				<td style='$font $padding'>
					$user_name
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					ডেলিভারি  তাং:
				</td>
				<td style='$font $padding'>
					$date1
				</td>
				<td style='$font $padding'>
					$day
				</td>
			</tr>
			<tr>
				<td style='$font $padding'>
					নাম:
				</td>
				
				<td style='$font $padding'>
					$cus_name
				</td>
				<td style='$font $padding'>
					$get_mobile
				</td>
				
			</tr>
		</table>
		<div style='overflow:hidden'>
			<div style='float:left;width:132px;height:115px;border: 1px solid gray;margin-top: 1px;margin-right:5px'>
				<img src='img/box.JPG' style='height: 113px; width: 130px;'/>
			</div>
			<div style='float: left;margin-top: 1px;'>
				<div style='width:100px;height: 50px;border: 1px solid gray;text-align: center;padding-top: 12px;'>
				নমুনা
				</div>
				<div style='width:100px;padding-top: 8px;text-align:center'>
				-------
				</div>
				<div style='width:100px;text-align:center;font-size: 10px;'>
				Authority<br/>Signature
				</div>
			</div>
			
		</div>
	</div>
	<div style='float:left;width: 160px;margin-right: 5px;'>
		<table border='1' style='border-collapse: collapse;width:100%'>
			<tr>
				<th style='$font $padding'>
					বিবরণ 
				</th>
				<th style='$font $padding'>
					সংখ্যা
				</th>
			</tr>
			$making_item
		</table>
	</div>
	<div style=''>
		<table border='1' style='border-collapse: collapse;width: 120px;'>
			$head
			<tr>
				<th style='$font2 $align_right'>
					মোট টাকা
				</th>
				<td style='$font $align_right'>
					$total_tk2
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					স্টাইল
				</th>
				<td style='$font $align_right'>
					$design_charge
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					অন্যান্য খরচ
				</th>
				<td style='$font $align_right'>
					$others_tk
				</td>
			</tr>
			$title_tr
			<tr>
				<th style='$font2 $align_right'>
					সর্বমোট টাকা		
				</th>
				<td style='$font $align_right'>
					$total_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					অগ্রিম
				</th>
				<td style='$font $align_right'>
					$advance_tk
				</td>
			</tr>
			<tr>
				<th style='$font2 $align_right'>
					বর্তমান বাকি
				</th>
				<td style='$font $align_right'>
					$present_due
				</td>
			</tr>
			$tail
		</table>
	</div>
</div>

$second_receipt

<div style='overflow:hidden;width:529px;margin-left: 85px;'>
	$full_measurement
	
</div>";


return $receipt;
	}
	
	function getCustomerReceptNormal($tag){
		include'db.php';
		date_default_timezone_set("Asia/Dhaka");
		$time=date("h:i:s A");
		$font="font-size:12px;font-weight: bold;";
		$font2="font-size:10px;";
		$align_right="text-align:right;padding-right: 2px;";
		$td="width: 131px;";
		$padding="padding-left:4px;";
		
		$box2="";
		$box3="";
		$com_id=($_SESSION['COM_ID']);
		$max_dsms=$_SESSION['MAX_DSMS'];
		$max_order_record=$_SESSION['MAX_ORDER_RECORD'];
		$max_order_details=$_SESSION['MAX_ORDER_DETAILS'];
		$max_direct_sale=$_SESSION['MAX_DIRECT_SALE'];
		
	$dsms_sql=$conn->query("SELECT date(ord.insert_date) ord_date,ord.fddate,ord.dv_date,ord.amount,ord.cus_name,ord.cus_mobile,ord.discount,ord.design_cost,ord.others_tk,
	(SELECT sum(`amount`) FROM `accounting` WHERE `dsms_id`=ord.id and `pay_status` in(0,1)) advance_tk,
	(select user_name from user where id=ord.insert_by) user_name,ord.previous_total_due
	from dsms ord WHERE ord.com_id=$com_id and ord.is_active=1 and ord.phy_ord_num='$tag'");
	if(mysqli_num_rows($dsms_sql)>0){
		$dsms_row=mysqli_fetch_array($dsms_sql);
		$date1=$dsms_row['dv_date'];
		$karigor_dv_date=$dsms_row['fddate'];
		$cus_name=$dsms_row['cus_name'];
		$get_mobile=$dsms_row['cus_mobile'];
		$ex2=explode("-",$dsms_row['ord_date']); // order date
		$total_tk=$dsms_row['amount'];
		$others_tk=intval($dsms_row['others_tk']);
		$design_charge=intval($dsms_row['design_cost']);
		$discount_tk=$dsms_row['discount'];
		$previous_due=$dsms_row['previous_total_due'];
		//$total_due=$dsms_row['present_due'];
		$advance_tk=$dsms_row['advance_tk'];
		$user_name=$dsms_row['user_name'];
		
	}else{
		return "Warning! Wrong Serial No.";
		exit;
	}
	$order_record_sql=$conn->query("SELECT ord.id,(select product_name from product where id=ord.item_id) item_name,ord.item_qty FROM order_record ord WHERE ord.com_id=$com_id and ord.is_active=1 and ord.order_number='$tag'");
	$shirt="";$pant="";$panjabi="";$Safari="";
	while($iarray=mysqli_fetch_array($order_record_sql)){
		$item=$iarray['item_name'];
		if($item=="Shirt"){
			$shirt.=$iarray['item_name']."(".$iarray['item_qty'].") ";
		}
		if($item=="Coat"){
			$shirt.=$iarray['item_name']."(".$iarray['item_qty'].") ";
		}
		if($item=="Fatua"){
			$shirt.=$iarray['item_name']."(".$iarray['item_qty'].") ";
		}
		
		if($item=="Pant"){
			$pant.=$iarray['item_name']."(".$iarray['item_qty'].") ";
		}
		if($item=="Pajama"){
			$pant.=$iarray['item_name']."(".$iarray['item_qty'].") ";
		}
		
		if($item=="Safari"){
			$Safari.=$iarray['item_name']."(".$iarray['item_qty'].") ";
		}
		
		if($item=="Panjabi"){
			$panjabi.=$iarray['item_name']."(".$iarray['item_qty'].") ";
		}
	}
	
	$total_tk2=($total_tk-$others_tk-$design_charge+$discount_tk);
	$present_due=($total_tk-$advance_tk);
	$total_due=($present_due+$previous_due);
	$cus_name=substr($cus_name,0,20);
		$ex=explode("-",$date1);
		$date1=$ex[2]."/".$ex[1]."/".$ex[0];
		$day=date('l', strtotime($ex[2]."-".$ex[1]."-".$ex[0]));
		$ord_date=$ex2[2]."/".$ex2[1]."/".$ex2[0];
		$making_item="";$making_item2="";$full_measurement="";
		$c=1;$mc=0;$total=0;
		
		
$receipt2="<div style='overflow: hidden;margin-bottom: 5px;padding-bottom: 12px;width:700px;height:322px'>
		<div style='margin-left: 378px;'>
			<div style='height:22px;margin-bottom:3px;border:1px solid gray;padding-left: 5px;padding-top: 1px;'>
				$tag
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$ord_date
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$date1
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$cus_name
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$shirt
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$pant
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$panjabi
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$Safari
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$total_tk/=
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$advance_tk/=
			</div>
			<div style='padding-left: 5px;padding-top: 1px;height:22px;margin-bottom:3px;border:1px solid gray'>
				$present_due/=
			</div>
		</div>
		
	</div>";

return $receipt2;
	}
?>
 
 