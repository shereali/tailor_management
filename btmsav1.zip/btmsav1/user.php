
<div class="login-form">
    <form action="#" method="post">
       
		<div class="form-group">
            <input type="text" maxlength="50" name="user" autocomplete="off" class="form-control" placeholder="User Name" required="required">
        </div>
        
		<div class="form-group">
            <input type="text" maxlength="11" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" name="mobile" autocomplete="off" maxlength="11" class="form-control" placeholder="User Mobile" required="required">
        </div>
			
        <div class="form-group">
            <input autocomplete="off" type="text" maxlength="11" name="log_user" class="form-control" placeholder="login user" required="required">
        </div>
        <div class="form-group">
            <input autocomplete="off" type="password" maxlength="11" name="pass" class="form-control" placeholder="Password" required="required">
        </div>
        <div class="form-group">
            <button type="submit" name="btn" value="btn" class="btn btn-primary btn-block">Submit</button>
        </div>
		</form>
		
		<?php 
		
			if(isset($_REQUEST['btn'])){
				$com_id=$_SESSION['COM_ID'];
				$user=trim($_REQUEST['user']);
				$mobile=trim($_REQUEST['mobile']);
				$log_user=trim($_REQUEST['log_user']);
				$pass=trim($_REQUEST['pass']);
				
			}
		?>
        <div class="clearfix">
            <label class="pull-left checkbox-inline">
			<?php 
			if(isset($_REQUEST['btn'])){
				$chk_pass=$conn->query("select * from user where log_user='$log_user' and pass='$pass' and is_active=1");
			if(mysqli_num_rows($chk_pass)>0){
				echo "Duplicate Password! <a href='home.php?loc=user'>Back</a>";
			}else{
				$usersql=$conn->query("insert into user(com_id,user_name,mobile,log_user,pass) values('$com_id','$user','$mobile','$log_user','$pass')");
				
				if($usersql){
					echo "Success!";
				}
				
			}
			mysqli_close($conn);
			}
			?>
			</label>
            <!--<a href="#" class="pull-right">Forgot Password?</a>-->
        </div>        
    
	
	
   
</div>
