<?php 
session_start();
ob_start();
include'db.php';
include'library.php';

if(isset($_SESSION['USER']) && isset($_SESSION['COM'])){
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>btms</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="file/bootstrap.min.css">
	<link rel="stylesheet" href="cal/css/awa-some.css">
	<link rel="stylesheet" href="cal/css/jquery.dateselect.css">
	<script src="js/globaljs.js"></script>
	
	<!--<link rel="stylesheet" href="datatbl/bootstrap.css">
	<link rel="stylesheet" href="datatbl/datatbl.css">-->
	
	
	<script src="file/jquery.min.js"></script>
	<script src="file/bootstrap.min.js"></script>
 
  
</head>
<body style="background:#4d567514">


<div class="container" style="background:#4e181808;padding-bottom:15px">
	<div class="row" style="margin-top: 10px; !important">
	<div class="col-xs-12 col-sm-12"> 
		<?php 
		if($_SESSION['USER_TYPE']==0 || $_SESSION['USER_TYPE']==1 || $_SESSION['USER_TYPE']==2){
			if($_SESSION['MBILL']!=2){
				if($_SESSION['DIRECT_SALE']==1){
			?>
			
			<a href="home.php?loc=direct_sales" class="btn btn-info">Direct Sales</a>
			<?php 
				}
				if($_SESSION['ORDER_NAME']==1){
					if($_SESSION['is_barcode']==0){
						?>
						<a href="home.php?loc=send" class="btn btn-primary">Operation</a>
						<?php 
					}else{
						?>
						<a href="home.php?loc=send_barcode" class="btn btn-primary">Operation</a>
						<?php
					}
				}
			if($_SESSION['PENDING']==1){
			?>
			  <a href="home.php?loc=history" class="btn btn-success">Pending</a>
			  <?php 
			}
			
			?>
			  <a href="home.php?loc=decision" class="btn btn-info">Decision</a>
			  <a href="home.php?loc=expired_delivery" class="btn btn-default">Expired SMS</a>
			  <a href="home.php?loc=all" class="btn btn-warning">Search</a>
			<?php } ?>  
			  
			  <!--<a href="home.php?loc=tord" class="btn btn-primary">Report</a>-->
			  <a href="home.php?loc=tutorial" class="btn btn-success">Tutorials</a>
			  <a href="signout.php" class="btn btn-danger">Out</a>
			<?php 
		}
		/*else if($_SESSION['USER_TYPE']==2){ ?>
			<a href="home.php?loc=todays" class="btn btn-primary">Todays</a>
		  <a href="home.php?loc=monthly" class="btn btn-success">Month</a>
		  <a href="home.php?loc=premonthly" class="btn btn-warning">Pre Month</a>
		  <a href="signout.php" class="btn btn-danger">Out</a>
		<?php 
		} */
		?>
		<span style="margin-left: 5px;font-weight: bold;"><?php echo $_SESSION['USER']; ?></span>
		<img style="height: 35px;float: right;" src="img/selai.png"/>
	</div>
	</div>
	<div id="show_page">
	<?php 
	
	if($_SESSION['USER_TYPE']==0 || $_SESSION['USER_TYPE']==1 || $_SESSION['USER_TYPE']==2){
			if(isset($_REQUEST['loc'])){
				if($_REQUEST['loc']=="history"){
					
					include 'history.php';
				}else if($_REQUEST['loc']=="expired_delivery"){
					include 'expired_delivery.php';
				}else if($_REQUEST['loc']=="all"){
					echo "<h5>Search(<b>$_SESSION[COM]</b>)</h5>";
					include 'all.php';
				}else if($_REQUEST['loc']=="tord"){
					echo "<h5>Report(<b>$_SESSION[COM]</b>)</h5>";
					include 'report_ord.php';
				}else if($_REQUEST['loc']=="tutorial"){
					echo "<h5>All Tutorials(<b>$_SESSION[COM]</b>)</h5>";
					include 'tutorials.php';
				}else if($_REQUEST['loc']=="send"){
					echo "<h5>Operation(<b>$_SESSION[COM]</b>)</h5>";
					include 'sms_send.php';
				}else if($_REQUEST['loc']=="send_barcode"){
					echo "<h5>Operation(<b>$_SESSION[COM]</b>)</h5>";
					include 'sms_send_barcode.php';
				}else if($_REQUEST['loc']=="direct_sales"){
					echo "<h5>Direct Sales(<b>$_SESSION[COM]</b>)</h5>";
					include 'direct_sales.php';
				}else if($_REQUEST['loc']=="registration"){
					echo "<h5>Reg.(<b>$_SESSION[COM]</b>)</h5>";
					include 'registration.php';
				}else if($_REQUEST['loc']=="purchase"){
					echo "<h5>Purchase(<b>$_SESSION[COM]</b>)</h5>";
					include 'purchase.php';
				}else if($_REQUEST['loc']=="view"){
					echo "<h5>View User(<b>$_SESSION[COM]</b>)</h5>";
					include 'view.php';
				}else if($_REQUEST['loc']=="user"){
					echo "<h5>Create User(<b>$_SESSION[COM]</b>)</h5>";
					include 'user.php';
				}else if($_REQUEST['loc']=="decision"){
					echo "<h5>Decision(<b>$_SESSION[COM]</b>)</h5>";
					include 'decision.php';
				}
			}else{
				if($_SESSION['MBILL']!=2){
					if($_SESSION['is_barcode']==1){
						echo "<h5>Operation(<b>$_SESSION[COM]</b>)</h5>";
						include 'sms_send_barcode.php';
					}else{
						echo "<h5>Operation(<b>$_SESSION[COM]</b>)</h5>";
						include 'sms_send.php';
					}
				}
			}
	}
	
	/*else if($_SESSION['USER_TYPE']==2){
		if(isset($_REQUEST['loc'])){
				if($_REQUEST['loc']=="premonthly"){
					echo "<h5>Pre Month(<b>$_SESSION[COM]</b>)</h5>";
					include 'premonthly.php';
				}else if($_REQUEST['loc']=="todays"){
					echo "<h5>Todays(<b>$_SESSION[COM]</b>)</h5>";
					include 'todays.php';
				}else if($_REQUEST['loc']=="monthly"){
					echo "<h5>Monthly(<b>$_SESSION[COM]</b>)</h5>";
					include 'monthly.php';
				}
			}else{
				echo "<h5>Todays(<b>$_SESSION[COM]</b>)</h5>";
				include 'todays.php';
			}
	}*/
	if($_SESSION['MBILL']==1){
		echo "<b>$_SESSION[COM]</b>";
		?>
		<div id="chk_desktop_time">
			<div style="text-align: center;border: 2px solid #7A3EEA;padding: 40px;font-size: 35px;color: #7A3EEA;"><p>৫ তারিখ এর মধ্যে Software এর  Monthly বিল পরিশোধ করার জন্য অনুরোধ করা হলো!!</p></div>
		</div>
		<?php 
		$_SESSION['MBILL']=0;
	}else if($_SESSION['MBILL']==2){
		echo "<b>$_SESSION[COM]</b>";
		?>
		<div class="row">
		<div class="col-xs-12 col-sm-4">
			<div id="chk_desktop_time">
				<div style="margin-bottom: 15px;text-align: center;border: 2px solid #7A3EEA;padding: 40px;font-size: 35px;color: #7A3EEA;"><p>আপনি সফটওয়্যার এর  Monthly বিল পরিশোধ করেন নাই !  বিল পরিশোধ করার জন্য অনুরোধ করা হলো!!</p></div>
			</div>
			<span style="font-size: 30px;">বিল পরিশোধ এর জন্য এই নম্বর এ Bkash করুন-<b><span style="color:red">01719027713</span></b></span>
		</div>
		<div class="col-xs-12 col-sm-8">
			<?php 
			date_default_timezone_set("Asia/Dhaka");
			$mnt="0"; 
			$year="0";
			$com_id=($_SESSION['COM_ID']);
			$bill_sql=$conn->query("select bill,sec_id,billing_month,billing_year,is_active,bill_pay_date from billing where com_id=$com_id order by id desc limit 1,1");
			if(mysqli_num_rows($bill_sql)>0){
				$bill_array=mysqli_fetch_array($bill_sql);
				$bmonth=date("F", mktime(0, 0, 0, $bill_array['billing_month'], 10)).'-'.$bill_array['billing_year'];
				if($bill_array['bill']!=0 && $bill_array['is_active']==1){
					$sataus='<span style="color:green">Paid</span>';
					$chk_sataus=1;
				}else{
					$sataus='<span style="color:red">Unpaid</span>';
					$chk_sataus=0;
				}
			}else{
				$bmonth="";
				$sataus='<span style="color:red">---</span>';
				$chk_sataus=0;
			}
			$order=$conn->query("select count(ds.id) tot from dsms ds where ds.is_active=1 and ds.com_id=$com_id and month(ds.insert_date)=$mnt and year(ds.insert_date)=$year");
			
			if(mysqli_num_rows($order)>0){
				$ord=mysqli_fetch_array($order);
				$order_num=$ord['tot'];
			}else{
				$order_num=0;
			}
			if($_SESSION['SOFT_CHARGE']>0 && $_SESSION['SMS_SERVICE']!=1){ // per order bill but not get sms service
				//only soft
				$soft=$_SESSION['SOFT_CHARGE'];
				$total=round(floatval($order_num)*$soft);
				$security=getSecurity($total);
				$tbl="<table id='example' class='table table-striped table-bordered'>
					<thead>
						<tr>
							<th>Total Order(qty)</th>
							<th>Per Order(tk)</th>
							<th>Total(round tk)</th>
							<th>Security Code</th>
							<th>Status</th>
						</tr>
					</thead>
					<tbody id='tbl_three'>
						<tr>
							<td>$order_num</td>
							<th>$soft</th>
							<th style='background:#73CEFB;color:white'>$total</th>
							<th>$security</th>
							<th>$sataus</th>
						</tr>
					</tbody>
				</table>";
			}
			if($_SESSION['SOFT_CHARGE']>0 && $_SESSION['SMS_SERVICE']==1){ // per order charge and per sms bill
				// soft and sms
				$soft=$_SESSION['SOFT_CHARGE'];
				//$sms=$_SESSION['SMS_CHARGE'];
				//$total=(floatval($order_num)*($soft+floatval($sms)));
				$total=round(floatval($order_num)*($soft));
				$security=getSecurity($total);
				$tbl="<table id='example' class='table table-striped table-bordered'>
					<thead>
						<tr>
							<th>Total Order(qty)</th>
							<th>Per Order(tk)</th>
							<th>Total(round tk)</th>
							<th>Security Code</th>
							<th>Status</th>
						</tr>
					</thead>
					<tbody id='tbl_three'>
						<tr>
							<th>$order_num</th>
							<th>$soft</th>
							<th style='background:#73CEFB;color:white'>$total</th>
							<th>$security</th>
							<th>$sataus</th>
						</tr>
					</tbody>
				</table>";
			}
			
			if($_SESSION['SOFT_CHARGE']==0){ //monthly bill
				// monthly bill
				$total="500";
				$security=getSecurity($total);
				$tbl="<table id='example' class='table table-striped table-bordered'>
					<thead>
						<tr>
							<th>Total Order(qty)</th>
							<th>Per Month(tk)</th>
							<th>Total(tk)</th>
							<th>Security Code</th>
							<th>Status</th>
						</tr>
					</thead>
					<tbody id='tbl_three'>
						<tr>
							<th>$order_num</th>
							<th>$total</th>
							<th style='background:#73CEFB;color:white'>$total</th>
							<th>$security</th>
							<th>$sataus</th>
						</tr>
					</tbody>
				</table>";
			}
			
			?>
				<div class="col-xs-12 col-sm-12">
				
				<div class="panel panel-success">
				  <div class="panel-heading" style="text-align:center">Bill(<?php echo @$bmonth; ?>)</div>
				  <div class="panel-body">
					<div>
						<h4 style="text-align: center;line-height: 0px;"><?php echo $_SESSION['COM']; ?></h4>
						<p style="text-align: center;"><?php echo $_SESSION['COM_ADDRESS']; ?></p>
						<?php echo $tbl; ?>
					</div>
				  </div>
				</div>
							
				</div>
			<?php 
			if($chk_sataus==0){
				
			?>
			<div class="col-xs-12 col-sm-4">
					<div class="panel panel-success">
					  <div class="panel-heading" style="text-align:center">Step-1</div>
					  <div class="panel-body">
						<p style="font-size:13px;color:red;text-align:justify">1. Software এর  Monthly Bill আগে  <b>01719027713</b> এই নম্বর এ Bkash করুন.</p>
						<p style="font-size:13px;color:red;text-align:justify">2. Step-2 তে আপনি যে মোবাইল নম্বর থেকে Bkash করেছেন সেই নম্বর টি Sender Bkash Number হিসেবে বসিয়ে Send এ ক্লিক করুন.</p>
						<p style="font-size:13px;color:red;text-align:justify">2. Step-3 তে আপনার মোবাইল নম্বর এ দুইটি PIN Number SMS করা হবে তা PIN-1এবং PIN-2 তে বসিয়ে Verify এ ক্লিক করুন.</p>
					 </div>
					</div>
							
				</div>
				<div class="col-xs-12 col-sm-4">
					<div class="panel panel-info">
					  <div class="panel-heading" style="text-align:center">Step-2</div>
					  <div class="panel-body">
						<label for="comment">Total Bill(Tk)</label>
						<input type="text" readonly class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;background:#73CEFB;color:white" value="<?php echo $total; ?>" autocomplete="off" name="bill_tk" id="bill_tk" required/>
						<label for="comment">Security Code</label>
						<input type="text" readonly class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" autocomplete="off" value="<?php echo $security; ?>" name="security_code" id="security_code" required/>
						<label for="comment">Sender Bkash Number</label>
						<input type="text" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;" maxlength="11" autocomplete="off" name="sender_number" id="sender_numbers" required/>
					    <button onclick="sendMonthlyBill();" style="margin-top:15px" name="btn" value="sub" id="bill_btn" class="btn btn-info">Send</button>
						<span id="bsms"></span>
					 </div>
					</div>
							
				</div>
				<div class="col-xs-12 col-sm-4">
				
				<div class="panel panel-warning">
				  <div class="panel-heading" style="text-align:center">Verification(Step-3)</div>
				  <div class="panel-body">
					<label for="comment">PIN-1</label>
					<input type="text" class="form-control" style="font-weight: bold;font-size:18px;font-style: italic;color:red" maxlength="5" autocomplete="off" name="pin1" id="pina" required/>
					<label for="comment">PIN-2</label>
					<input type="text" class="form-control" style="font-weight: bold;font-size:18px;font-style: italic;color:red" maxlength="5" autocomplete="off" name="pin2" id="pinb" required/>
					<input type="hidden" id="bill_save" value="<?php echo $total; ?>"/>
					<input type="hidden" id="security_save" value="<?php echo $security; ?>"/>
					<input type="hidden" id="month_year" value="<?php echo @$bill_array['billing_month']."_".@$bill_array['billing_year']; ?>"/>
				  <button onclick="verificationChk();" style="margin-top:15px" name="btn" value="sub" id="verify_btn" class="btn btn-warning">Verify</button>
				  <span id="vsms"></span>
				  </div>
				</div>
							
				</div>
			<?php 
		}
		?>
		</div>
		</div>
		<?php 
		
		
	}else{
		if($_SESSION['WARNING']==1){
			?>
			<div id="chk_desktop_time">
				<div style="text-align: center;border: 2px solid red;padding: 40px;font-size: 35px;color: red;margin-top: 16px;"><p>আপনার Desktop/Laptop এর তারিখ এবং সময় ঠিক আছে কিনা চেক করে নিন!!</p></div>
			</div>
			<?php 
		}
	}
	$_SESSION['WARNING']=0;	
	
	?>
</div>

<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" id="heading_id"></h4>
        </div>
        <div class="modal-body">
          <img id="add_img" src="" style="width:870px;height:450px" alt="your image" />
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  <span data-toggle="modal" id="show_advertise" data-target="#myModal"></span>
</div>

	<script type="text/javascript" src="cal/js/apiajax.js"></script>
	<script type="text/javascript" src="cal/js/mousewheel.js"></script>
	<script type="text/javascript" src="cal/js/jquery.dateselect.js"></script>
	
	<script src="js/select2/select2.full.min.js"></script>
	<link rel="stylesheet" href="js/select2/select2.min.css">
	<!--<script type="text/javascript" src="datatbl/jquery-3.5.1.js"></script>
	<script type="text/javascript" src="datatbl/datatbl.js"></script>
	<script type="text/javascript" src="datatbl/datatbl.min.js"></script>-->

<script>

	function showPage(page){
		$.ajax({
					type: 'post',
					url: 'ajax.php',
					data: {
						page: page,page_btn:1
					},
					 beforeSend: function () {
						$("#show_page").show();
						$("#show_page").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						$("#show_page").html(response);
					 }
			});
	}
	
	

	
		function setSms(){
		var txt_sms=$("#txt_sms").val();
		
		var t="",m="";
		if(txt_sms==""){
			$("#txt_sms").css("border-color","red");
			t=1;
		}else{
			$("#txt_sms").css("border-color","#CCCCCC");
		}
		
		if(t==1){
			exit();
		}else{
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						txt_sms: txt_sms,set_btn:1
					},
					 beforeSend: function () {
						$("#sms").show();
						$("#sms").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response==20000000){
							$("#sms").html("Invalid Text SMS!").css("color","red");
						}else{
						$("#sms").html("Set Success!").css("color","green");
						$("#txt_sms").val(null);
						$("#setpanel").html(response);
						
						}
					 }
			});
		}
		
	}
	
	
	function activeInactive(id,acinac){
		$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						text_id: id,acinac:acinac,activeInactive:1
					},
					 beforeSend: function () {
						$("#sms").show();
						$("#sms").html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response==20000000){
							$("#sms").html("SMS Text Set Invalid!").css("color","red");
						}else{
						$("#sms").html("Set Success!").css("color","green");
						$("#txt_sms").val(null);
						$("#setpanel").html(response);
						
						}
					 }
			});
	}
	
	
	
	function reSendSms(id){
		var txt_sms=$("#txt_sms"+id).val();
		var mobile=$("#mobile"+id).val();
		var date1=$("#date1"+id).val();
		var sms_id=$("#sms_id"+id).val();
		var tagnum=$("#tagnum"+id).val();
		var order_type=$("#order_type"+id).val();
		var t="",m="",d="";
		
		var sp=mobile.split(",");
		if(sp.length>1){
			$("#mobile"+id).css("border-color","red");
			$("#sms"+id).html("Invalid! More than one mobile.").css("color","red");
			m=1;
		}
		if(mobile==""){
			$("#mobile"+id).css("border-color","red");
			m=1;
		}else{
			$("#mobile"+id).css("border-color","#CCCCCC");
		}
		
		if(date1==""){
			$("#date1"+id).css("border-color","red");
			d=1;
		}else{
			$("#date1"+id).css("border-color","#CCCCCC");
		}
		
		if(m==1 || d==1){
			exit();
		}else{
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						txt_sms: txt_sms,mobile:mobile,rem_sms_hidden:'',date1:date1,sms_id:sms_id,tagnum:tagnum,order_type:order_type,resend_btn:1
					},
					 beforeSend: function () {
						$("#sms"+id).show();
						$("#sms"+id).html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response==20000000){
							$("#sms"+id).html("Invalid Text SMS!").css("color","red");
						}else if(response==10000000){
							$("#sms"+id).html("SMS Not Available!").css("color","red");
						}else if(response==30000000){
							window.location.href = "signout.php";
						}else{
						$("#sms"+id).html("Update Success!").css("color","green");
						
						}
					 }
			});
		}
		
	}
	
	function showAdvertaisement(){
		$.ajax({
				type: 'post',
				url: 'sql.php',
				data: {
					show_advertise:1
				},
				 success: function (response) {
					console.log(response);
					if(response!=2){
						$("#show_advertise").click();
						$('#add_img').attr('src', response);
					}
				 }
			});
	}
	
	
	
</script>
<?php 
	if($_SESSION['SHOW_ADD']==0){
?>
<script>
	$(document).ready(function(){
		showAdvertaisement();
	});
</script>
<?php 
	}
	$_SESSION['SHOW_ADD']=1;
?>

</body>
</html>


<?php
 }else{
	 header("location:index.php?id=1");
 } 
?>
