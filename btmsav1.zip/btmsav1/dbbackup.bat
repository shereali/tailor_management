set path=D:\wamp64\bin\mysql\mysql5.7.14\bin

mysqldump -u root btmsav1 > "D:\dbbackup\btmsav1.sql"