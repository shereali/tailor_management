
<?php 

	$com_id=$_SESSION['COM_ID'];
	$dates=date("Y-m-d");
	date_default_timezone_set("Asia/Dhaka");
	$dday=$_SESSION['CUS_DELIVERY'];
	$exday=explode("-",date('d-m-Y', strtotime(date('d-m-Y'). " +$dday day")));
	$cdate=date("h:i:s A");
	$dday=$exday[0]."/".$exday[1]."/".$exday[2];
	$rem_sms=$conn->query("select (select rem_sms from rem_sms where com_id=c.id) remaining,c.status from company c where c.is_active=1 and c.id=$com_id");
	$product=$conn->query("select * from product where is_active=1 and com_id=$com_id and ptype=1 order by id asc");
	$product_fabrics=$conn->query("select * from product where is_active=2 order by id asc");
	$expense=$conn->query("select * from expense_type where is_active=1");
	$expense_detail=$conn->query("select ex.id,ex.expense_type,ex.expense,ex.remarks,(select expense from expense_type where id=ex.expense_type) ex_title from expenses ex where ex.is_active=1 and date(ex.insert_date)='$dates'");
	mysqli_close($conn);
	if(mysqli_num_rows($rem_sms)>0){
	$srow=mysqli_fetch_array($rem_sms);
?>

<div class="tab-content">

	<div class="panel-group">
	
	<div class="panel panel-info">
      <div class="panel-heading">Year wise Search</div>
      <div class="panel-body">
			<div class="col-xs-12 col-sm-6">
				<p for="comment">Enter Year</p>
					<input type="text" maxlength="11" value="<?php echo date("Y"); ?>" style="font-weight: bold;font-size:18px;font-style: italic;" name="mobile" autocomplete="off" placeholder="Enter Only Year" id="year" class="form-control">
				<br/>
				<button onclick="searchOrder();" name="btn" id="srcbymob" value="sub" class="btn btn-success">Search</button>
				<span id="sms"></span>
				<div id="showord_num" style="margin-top: 15px;">
				
				</div>
				<div id="showord_num2" style="margin-top: 15px;">
				
				</div>
				<input type="hidden" id="horder"/>
			</div>
	  </div>
    </div>
	
	</div>
</div>


  
  
  <script>
	function searchOrder(){
		var year=$("#year").val().trim();
		if(year!=""){
			$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					year:year,searchYearlyOrder:1
				},
				 beforeSend: function () {
					$("#showord_num").html('<img src="img/loading.gif"/>');
				},
				 success: function (response) {
					console.log(response);
					$("#horder").val(response);
						$("#showord_num").html("Total Order: <a href='javascript:void(0)' onclick='showDetailOrder()'><b>"+response+"</b><a>").css("color","black");
						$("#showord_num2").html(null);
				}
			});
		}
	}
	
	function showDetailOrder(){
		var horder=$("#horder").val();
		var year=$("#year").val().trim();
		$.ajax({
			type: 'post',
			url: 'ajax.php',
			data: {
				year:year,horder:horder,showDetailYearlyOrder:1
			},
			 beforeSend: function () {
				$("#showord_num2").html('<img src="img/loading.gif"/>');
			},
			 success: function (response) {
				console.log(response);
					$("#showord_num2").html(response).css("color","black");
			}
		});
	}
</script>

<style>
.chkbox{
	 -ms-transform: scale(2); /* IE */
  -moz-transform: scale(2); /* FF */
  -webkit-transform: scale(2); /* Safari and Chrome */
  -o-transform: scale(2); /* Opera */
  transform: scale(2);
  padding: 10px;
}

.checkboxtext
{
  /* Checkbox text */
  font-size: 120%;
  display: inline;
  padding-left: 6px;
  padding-right: 40px;
}
#tblhight{
			overflow-y: scroll;
		overflow-x: hidden;
</style>

<?php
	}else{
		header("location:index.php?id=1");
	}
?>
