

<?php 

	$com_id=$_SESSION['COM_ID'];
	$psmsquery=$conn->query("select ds.id,ds.sms_status,ds.dv_date,ds.txt_sms,date(ds.insert_date) indate,ds.tagnum,ds.order_type,ds.cus_mobile umobile,ds.phy_ord_num,ds.amount,ds.cus_name,ds.discount,(select sum(ac.amount) from accounting ac where ac.is_active=1 and ac.dsms_id=ds.id and ac.pay_status in(0,1)) advancePay,(select id from customer where cus_mobile=ds.cus_mobile limit 0,1) cus_id,ds.factory_status from dsms ds where ds.is_active=1 and ds.phy_dv_date IS NULL and ds.occasion=0 and ds.com_id='$com_id' order by ds.id desc limit 0,5");
	$tending=$conn->query("select count(id) totp from dsms where `is_active`=1 and `phy_dv_date` IS NULL and `occasion`=0 and com_id=$com_id");
	
	if(mysqli_num_rows($psmsquery)>0){
		$pcount=mysqli_fetch_array($tending);
		$totp=$pcount['totp'];
		echo "<h5>Pending <span style='color:red'>$totp</span> (<b>$_SESSION[COM]</b>)</h5>";
?>

<!--------------------------------------------------------------------------------->


  <div class="tab-content">
   
    <div class="panel-group">
  <div id="show_history">
   <?php 
			$i=1;
			$date=date("Y-m-d");
			
				while($row=mysqli_fetch_array($psmsquery)){
					$j=$i++;
					$sms_id=$row['id'];
					$sms_status=$row['sms_status'];
					$dv_date=explode("-",$row['dv_date']);
					$dv_date=$dv_date[2]."/".$dv_date[1]."/".$dv_date[0];
					@$txt_sms=$row['txt_sms'];
					@$tagnum=$row['tagnum'];
					@$order_type=$row['order_type'];
					@$amount=$row['amount'];
					@$advancePay=$row['advancePay'];
					@$discount=$row['discount'];
					@$cus_id=$row['cus_id'];
					
					@$umobile=$row['umobile']; //implode(",",$mobiles);
					$chk_com_p=$conn->query("SELECT (select product_name from product where id=sd.item_id) pname,sd.item_qty pqty,sd.order_number,sd.receive_qty FROM `order_record` sd WHERE sd.com_id=$com_id and sd.is_active=1 and sd.dsms_id=$sms_id");
					if($date==$row['indate']){
						echo "<div class='panel panel-info'>";
						
					}else{
						
						echo "<div class='panel panel-success'>";
					}
				if(mysqli_num_rows($chk_com_p)<=0){
					$conn->query("update dsms set is_active=0 where id=$sms_id");
				}
			?>
	
   
      <div class="panel-heading"><?php  echo $j.". (".date('d/m/Y',strtotime($row['indate'])).")"; if($sms_status==0) echo " pending "; else echo " sent "; ?></div>
	 
      <div class="panel-body">
			
			
			<div class="row">
			<div class="col-xs-12 col-sm-6">
				<p for="comment">Serial: 
				<span style='cursor: pointer;color:red;font-weight:bold' data-toggle="modal" data-target="#myModal" onclick="showMeasurement('1','<?php echo @$row['phy_ord_num']; ?>')">
					<?php echo $row['phy_ord_num']; ?>
				</span>
				</p>
				<label for="comment">Delivery Date:</label>
					<input type="text" style="font-weight: bold;font-size:18px;font-style: italic;color:green" name="date1" id="date1<?php echo $j; ?>" value="<?php echo $dv_date; ?>" class="form-control" data-select="date">
				<label for="comment">Customer Name: <span style="color:green"></span></label>
				<input type="hidden" class="form-control" name="sms_id" id="sms_id<?php echo $j; ?>" value="<?php echo $sms_id; ?>" />
				<input type="text" class="form-control" value="<?php echo $row['cus_name']; ?>" style="font-weight: bold;font-size:18px;font-style: italic;color:green"  name="cus_name" id="cus_name<?php echo $j; ?>" />		
				<input type="hidden"  name="org_dv_date" id="org_dv_date<?php echo $j; ?>" value="<?php echo $dv_date; ?>" />
				
				  <label for="comment">Mobile Number:</label>
				  <input type="text" class="form-control" value="<?php echo $umobile; ?>" maxlength="11" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="font-weight: bold;font-size:18px;font-style: italic;color:green" name="mobile" id="mobile<?php echo $j; ?>" />
				  <input type="hidden" value="<?php echo $umobile; ?>"  name="mobile" id="hidemobile<?php echo $j; ?>" />
				  <input type="hidden" value="<?php echo @$amount; ?>"  name="mobile" id="totalamount<?php echo $j; ?>" />
				  <input type="hidden" value="<?php echo @$advancePay; ?>"  name="mobile" id="advancePay<?php echo $j; ?>" />
				  <input type="hidden" value="<?php echo @$cus_id; ?>"  name="mobile" id="cus_id<?php echo $j; ?>" />
				  <input type="hidden" value="<?php echo @$row['cus_name']; ?>"  name="mobile" id="hidden_cus_name<?php echo $j; ?>" />
				  <p for="comment" style="color:blue">Production Receive: <b><?php echo ($row['factory_status']==1 || $row['factory_status']==2)? "Yes" : "No"; ?></b></p>
			</div>
			<div class="col-xs-12 col-sm-6">
				<span for="">Dress Details:</span>
				<table id="example" class="table table-striped table-bordered">
				
					<thead>
						<tr>
							<th>SL</th>
							<th>Dress/Order Number</th>
							<th>Qty</th>
						</tr>
					</thead>
					<tbody>
					<?php 
					$jj=1;
					while($rrows=mysqli_fetch_array($chk_com_p)){
						$pname=$rrows['pname'];
						$pqty=$rrows['pqty'];
						$order_number=$rrows['order_number'];
						$receive_qty=$rrows['receive_qty'];
						if($receive_qty<$pqty){
							$rd="<span id='dqty$jj$j'>($receive_qty)</span>";
						}else{
							$rd="<span style='color:blue' id='dqty$jj$j'>($receive_qty)</span>";
						}
						?>
						<tr>
							<td>
								<b><?php echo $jj++; ?></b>
							</td>
							<td><b>
								<?php echo $pname." ".$rd; ?>
							</b>
							</td>
							<td><b>
								<?php echo $pqty; ?>
							</b>
							</td>
						
						</tr>
						<?php  
					}
					
					?>
					</tbody>
				</table>
				<button onclick="updateOrder('<?php echo $j; ?>');" name="btn" value="sub" id="updatebtn<?php echo $j; ?>" class="btn btn-success">Update</button>
				<span id="sms<?php echo $j; ?>"></span>
			</div>
			</div>
	  </div>
	 
    </div>
	
 <?php } ?>
 </div>
 <?php 
	if(@$totp>5){
 ?>
 <div class="form-group" style="margin-top:15px">
  <button onclick="seaMore();" name="btn" id="morebtn" class="btn btn-danger">More+</button><span id="load_img"></span>
  </div>
	<?php } ?>
  </div>
  
 
  <input type="hidden" id="last_id" value="5"/>	
  <br/>
	<?php 
	mysqli_close($conn);
	} 
	?>
	
 
  
    </div>

    
  
  </div>
<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" id="heading_id"></h4>
        </div>
        <div class="modal-body">
          <span id="smeasurement"></span>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<!--------------------------------------------------------------------------------->


  
	
	
  <script>
	
	
	function updateOrder(id){
		var mobile=$("#mobile"+id).val();
		var hidemobile=$("#hidemobile"+id).val();
		var hidden_cus_name=$("#hidden_cus_name"+id).val();
		var totalamount=$("#totalamount"+id).val();
		var advancePay=$("#advancePay"+id).val();
		var cus_id=$("#cus_id"+id).val();
		var date1=$("#date1"+id).val();
		var sms_id=$("#sms_id"+id).val();
		var org_dv_date=$("#org_dv_date"+id).val();
		var cus_name=$("#cus_name"+id).val();
		var t="",m="",d="",order_no="";
		if(confirm("আপনি কি আপডেট করতে চান?")){	
		if(mobile=="" || mobile.length<11 || mobile.length>11){
			$("#mobile"+id).css("border-color","red");
			m=1;
		}else{
			$("#mobile"+id).css("border-color","#CCCCCC");
		}
		
		if(date1==""){
			$("#date1"+id).css("border-color","red");
			d=1;
		}else{
			$("#date1"+id).css("border-color","#CCCCCC");
		}
		
		var chkmobile =mobile.split(",");
		if(chkmobile.length>1){
			$("#mobile").css("border-color","red");
			m=1;
		}else{
			$("#mobile").css("border-color","#CCCCCC");
		}
		
		//discount:discount,txt_sms: txt_sms,mobile:mobile,tag:2,date1:date1,sms_id:sms_id,tagnum:tagnum,order_type:order_type,phy_ord_num:phy_ord_num,org_dv_date:org_dv_date,amount:amount,cus_name:cus_name,resend_btn:1
		if(m==1 || d==1){
			exit();
		}else{
			document.getElementById("updatebtn"+id).disabled = true;
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						mobile:mobile,
						hidemobile:hidemobile,
						hidden_cus_name:hidden_cus_name,
						totalamount:totalamount,
						advancePay:advancePay,
						date1:date1,
						sms_id:sms_id,
						cus_id:cus_id,
						org_dv_date:org_dv_date,
						cus_name:cus_name,
						resend_btn:1
					},
					 beforeSend: function () {
						$("#sms"+id).show();
						$("#sms"+id).html('<img src="img/loading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						if(response==20000000){
							$("#sms"+id).html("Invalid Text SMS!").css("color","red");
						}else if(response==10000000){
							$("#sms"+id).html("SMS Not Available!").css("color","red");
						}else if(response==40000000){
							$("#sms"+id).html("Invalid Mobile No.!").css("color","red");
						}else if(response==30000000){
							window.location.href = "signout.php";
						}else{
						$("#sms"+id).html("Update Success!").css("color","green");
						document.getElementById("updatebtn"+id).disabled = false;
						}
					 }
			});
		}
	}
		
	}
	
	
	/*$(window).scroll(function() {
		behavior: 'smooth'
  if($(window).scrollTop() + $(window).height() == $(document).height()) {
      console.log("bottom!");
	   seaMoreInfo($("#last_id").val());
   }
});*/


	function showMeasurement(sl,ord_num){
		$.ajax({
				type: 'post',
				url: 'ajax.php',
				data: {
					ord_num:ord_num,smeasurement:1
				},
				 beforeSend: function () {
					$("#smeasurement").html('<img src="img/loading.gif"/>');
				},
				 success: function (response) {
					console.log(response);
					$("#heading_id").html("Measurement");
					$("#smeasurement").html(response);
				}
		});
	}


function seaMore(){
seaMoreInfo($("#last_id").val());

document.getElementById("morebtn").disabled = true;	
}

function seaMoreInfo(last_id){
			$.ajax({
					type: 'post',
					url: 'ajax.php',
					data: {
						last_id: last_id,page: 'history',page_btn:1
					},
					 beforeSend: function () {
						$("#load_img").show();
						$("#load_img").html('<img src="img/loading.gif"/>');
					},
					success: function (response) {
						console.log(response);
						$("#load_img").hide();
						if(response!=2){
						$("#show_history").append(response);
						$("#last_id").val((parseInt(last_id)+5));
						document.getElementById("morebtn").disabled = false;	
						}else{
							$("#last_id").val(0);
							document.getElementById("morebtn").disabled = true;
						}
					}
			});
	}
	
	
	
</script>

