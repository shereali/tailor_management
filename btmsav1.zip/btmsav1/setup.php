<form action="redirect.php" method="post">
	<input type="password" name="getpass" placeholder="xxxxxxxxxx" />
	<input type="submit" name="sub_btn" value="Go"/>
</form>

