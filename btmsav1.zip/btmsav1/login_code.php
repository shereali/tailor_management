<?php 
ini_set('session.gc_maxlifetime', 30*60);
 session_start();
	ob_start();
	include'library.php';
	include'db.php';
	
	$user=$_POST['username'];
	$password=$_POST['pass'];
	
	
	//u.direct_sale,
	$sql=$conn->query("select u.user_name,u.user_type,u.settings,c.mobile_num com_mobile,c.sversion,c.factory_delivery,c.customer_delivery,c.set_tax,
	c.apply_selling_price,c.sefty_stock,c.is_stock,c.backup,c.com_name,c.soft_type,c.sms_service,c.is_barcode,
	c.daily_attendance,c.order_sms,c.item_receive_sms,c.emp_payment_sms,c.soft_charge,c.fab_money_receipt_type,c.sms_charge,c.api,CASE
	WHEN c.com_head_id>0 THEN (select com_name from company where id=c.com_head_id)
	ELSE '' END haed_name,(SELECT group_concat(id separator '_') FROM company WHERE com_head_id=c.id AND 
	is_active=1) brach_id,u.order_name,u.pending,u.urgent,u.todays,u.tomorrow,u.n3d,u.search,u.archive,u.mobile_num,u.prints,c.measure_type,c.order_copy,
	c.id,c.address,c.design_set,c.ord_settings,u.id as uid,c.email,(select max(id) from dsms) max_dsms,(select max(id) from order_record) max_order_record,c.active_reference,c.reference_amount,
	(select max(id) from order_details) max_order_details,(select max(id) from direct_sale) max_direct_sale	from user u,company c where u.com_id=c.id and c.is_active=1 and u.is_active=1 and u.log_user='$user' and u.pass='$password'");
 
	if(mysqli_num_rows($sql)>0){
		$row=mysqli_fetch_array($sql);
			$com_id=$_SESSION['COM_ID']=$row['id'];
			date_default_timezone_set("Asia/Dhaka");
			$date=date("F-Y", strtotime("-1 months")); //exit();
			$ex=explode("-",$date);
			$mnt=date("m", strtotime("-1 months")); 
			$day=date("d"); 
			$year=$ex[1];
			$bill_sql=$conn->query("select bill,sec_id,billing_month,billing_year,is_active,bill_pay_date from billing where com_id=$com_id order by id desc limit 1,1");
			if(mysqli_num_rows($bill_sql)>0){
				$bill_array=mysqli_fetch_array($bill_sql);
				if($bill_array['bill']!=0 && $bill_array['sec_id']!=""){
					$_SESSION['MBILL']=0;
				}else{
					if($day<6){
					$_SESSION['MBILL']=1; //bill warning
					}else{
						if($bill_array['bill']==0 && $bill_array['sec_id']==""){
						$_SESSION['MBILL']=2; // operation deactivate
						}else{
							$_SESSION['MBILL']=0;
						}
					}
				}
			}else{
				$_SESSION['MBILL']=0;
			}
			$securitysql=$conn->query("select dsecurity from device_security where is_active=1");
			$security=array();
			if(mysqli_num_rows($securitysql)>0){
				while($securityarray=mysqli_fetch_array($securitysql)){
					$security[]=$securityarray['dsecurity'];
				}
			}
		$_SESSION['USER']=$row['user_name'];
		if(in_array(getData(1),$security)){
		if($row['user_type']==2){ //1= super admin,0 =entry user,2=owner
			$_SESSION['COM']=$row['com_name'];
			$_SESSION['BRANCH_ID']=$row['brach_id'];
		}else if($row['user_type']==0 || $row['user_type']==1){
			if($row['haed_name']!=""){
				$_SESSION['COM']=$row['haed_name']."(".$row['com_name'].")";
			}else{
				$_SESSION['COM']=$row['com_name'];
			}
			$_SESSION['BRANCH_ID']="";
		}
		$_SESSION['USER_TYPE']=$row['user_type'];
		$_SESSION['COM_ADDRESS']=$row['address'];
		$_SESSION['COM_MOBILE']=$row['com_mobile'];
		$_SESSION['USER_ID']=$row['uid'];
		$_SESSION['SETTINGS']=$row['settings'];
		$_SESSION['SOFT_TYPE']=$row['soft_type']; //1=online,2=offline
		$_SESSION['SVERSION']=$row['sversion']; //0=computer generated copy,1=physical book order,2= mearge order
		$_SESSION['FAC_DELIVERY']=$row['factory_delivery']; //Factory delivery day setup
		$_SESSION['CUS_DELIVERY']=$row['customer_delivery'];
		$_SESSION['SET_TAX']=$row['set_tax'];
		
		$_SESSION['DIRECT_SALE']=0;//$row['direct_sale'];
		$_SESSION['ORDER_NAME']=$row['order_name'];
		$_SESSION['PENDING']=$row['pending'];
		$_SESSION['URGENT']=$row['urgent'];
		$_SESSION['TODAYS']=$row['todays'];
		$_SESSION['TOMORROW']=$row['tomorrow'];
		$_SESSION['N3D']=$row['n3d'];
		$_SESSION['SEARCH']=$row['search'];
		$_SESSION['ARCHIVE']=$row['archive'];
		$_SESSION['MOBILE_NUM']=$row['mobile_num'];
		$_SESSION['PRINT']=$row['prints'];
		$_SESSION['SMS_SERVICE']=$row['sms_service'];
		$_SESSION['SOFT_CHARGE']=$row['soft_charge'];
		$_SESSION['SMS_CHARGE']=$row['sms_charge'];
		$_SESSION['API']=$row['api'];
		$_SESSION['LOG_USER']=$user;
		$_SESSION['LOG_PASS']=$password;
		$_SESSION['MEASURE_TYPE']=$row['measure_type']; //0=standerd,1=Local,2=Normal
		$_SESSION['WARNING']=1;
		$_SESSION['ITEM_SETTINGS']=0;
		$_SESSION['SHOW_ADD']=0;
		//db table last id
		$_SESSION['MAX_DSMS']=$row['max_dsms'];
		$_SESSION['MAX_ORDER_RECORD']=($row['max_order_record']=="" || $row['max_order_record']==0)? '0': $row['max_order_record'];
		$_SESSION['MAX_ORDER_DETAILS']=($row['max_order_details']=="" || $row['max_order_details']==0)? '0': $row['max_order_details'];
		$_SESSION['MAX_DIRECT_SALE']=($row['max_direct_sale']=="" || $row['max_direct_sale']==0)? '0': $row['max_direct_sale'];
		$_SESSION['SHOW_DESIGN']=$row['design_set'];
		//$_SESSION['OLD_ORDER_STATUS']=1;
		$_SESSION['OLD_ORDER_STATUS']=$row['sversion']; //0=corrent copy,1=old copy;
		$_SESSION['ORD_SETTINGS']=$row['ord_settings']; //0=hide order report,1=show order report;
		$_SESSION['EMAIL']=$row['email']; //0=hide order report,1=show order report;
		$_SESSION['ACTIVE_REFERENCE']=$row['active_reference']; //Reference status;
		$_SESSION['REFERENCE_AMOUNT']=$row['reference_amount']; //Reference amount(%)
		$_SESSION['ORDER_COPY']=$row['order_copy']; //Reference amount(%)
		$_SESSION['BACKUP']=$row['backup']; //db backup
		$_SESSION['IS_STOCK']=$row['is_stock']; //1=maintaining stock, 0=not maintaining stock 
		$_SESSION['APPLY_SELLING_PRICE']=$row['apply_selling_price']; //1=applying selling price, 0=not apply selling price
		$_SESSION['SAFETY_STOCK']=$row['sefty_stock']; 
		$_SESSION['order_sms']=$row['order_sms']; 
		$_SESSION['is_barcode']=$row['is_barcode']; 
		$_SESSION['daily_attendance']=$row['daily_attendance']; 
		$_SESSION['item_receive_sms']=$row['item_receive_sms']; 
		$_SESSION['emp_payment_sms']=$row['emp_payment_sms']; 
		$_SESSION['FAB_MONEY_RECEIPT_TYPE']=$row['fab_money_receipt_type']; //0= pos receipt,1=normal receipt 
		
		header("location:home.php");
		}else{
			header("location:index.php?id=1&chk=1");
		}
	}else{
		header("location:index.php?id=1&chk=2");
	}
		
?>