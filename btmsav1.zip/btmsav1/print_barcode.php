
  <div class="tab-content">
   	<div class="panel-group">
			<div id="show_history">
			   
					<div class='panel panel-info' style="color: black; box-shadow: inset 0 0 1em gray; padding: 15px;margin-left: 0px;margin-right: 0px;">
						 <div class="panel-heading">Barcode Printing Panel</div>
						 <div class="panel-body">
								<div class="row">
								<div class="col-xs-12 col-sm-6">
									<div style="padding: 15px;border: 2px solid gray;">
									<div style="text-align: center;font-size: 28px;font-weight: bold;">
										Barcode Generator
									</div>
									<div style="margin-left: 140px">
										<table>
											<tr>
												<td style="width: 20%;">
												<b>Barcode Number</b>
												</td>
												<td style="width: 60%;">
													<textarea rows="18" col="25" id="barcode_all" onfocus="this.value=''; setbg('#e5fff3');" onblur="setbg('white');"></textarea>
												</td>
											</tr>
											<tr>
												<td>
												
												</td>
												<td>
													<button onclick="getBarcode();" style="margin-left: 30px;" name="btn" id="srcbymob_print" value="sub" class="btn btn-success">GENERATE</button>		
												</td>
											</tr>
											<tr>
												<td>
												
												</td>
												<td>
													<span id="loading">
													
													</span>
												</td>
											</tr>
										</table>
									</div>
									</div>
								</div>
								<div class="col-xs-12 col-sm-6">
									<div class="row">
										<div class="col-xs-12 col-sm-2">
						
												<!--<button onclick="printOrder();" name="btn" id="printBtns" value="sub" class="btn btn-info">Print</button>-->
												
												<button onclick="printOrderOthers();" name="btn" id="printBtns" value="sub" class="btn btn-info">Print</button>
												
										</div>
									</div>
									<div style="padding: 15px;border: 2px solid gray;">
										<div id="barcode_area">
										</div>
									</div>
								</div>
								</div>
						  </div>
					</div>

			</div>
	 
	   </div>
  </div>


<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" id="heading_id"></h4>
        </div>
        <div class="modal-body">
          <span id="smeasurement"></span>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<!--------------------------------------------------------------------------------->


  
	
	
  <script>
	
	
	function getBarcode(id){
		var barcode_all=$("#barcode_all").val();
		if(barcode_all==""){
			alert("Enter barcode number.");
			$("#barcode_all").focus();
			return;
		}
		
		document.getElementById("srcbymob_print").disabled = true;
			$.ajax({
					type: 'post',
					url: 'sql.php',
					data: {
						barcode_all:barcode_all,
						getBarcode:1
					},
					 beforeSend: function () {
						$("#barcode_area"+id).html('<img src="img/reloading.gif"/>');
					},
					 success: function (response) {
						console.log(response);
						$("#barcode_area").html(response);
						document.getElementById("srcbymob_print").disabled = false;
					 }
			});
	
	}
	
	function printOrderOthers(){
		var order_number="";
		printDivOthers("barcode_area");
	}
	
	function printDivOthers(divName) {
		var printContents = document.getElementById(divName).innerHTML;
		var originalContents = document.body.innerHTML;
		document.body.innerHTML = printContents;
		window.print();
		document.body.innerHTML = originalContents;
		$("#barcode_area").html(null);
	}
	

	
</script>

